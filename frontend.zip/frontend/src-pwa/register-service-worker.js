import { register } from "register-service-worker";

register(`${process.env.SERVICE_WORKER_FILE}`, {
  ready() {
    console.log("✅ Service Worker Está activo y listo para Web Push.");
  },
  registered() {
    console.log("✅ Service Worker ¡Registrado correctamente!");
  },
  cached() {
    console.log("⚡ PWA En caché para uso sin conexión.");
  },
  updatefound() {
    console.log("🔄 Nuevo Service Worker Encontrado. Actualizando...");
  },
  updated() {
    console.log("🔄 Nuevo contenido disponible, por favor, actualiza la página.");
    window.location.reload(true);
  },
  offline() {
    console.log("⚠️ Sin conexión a internet. La aplicación se está ejecutando sin conexión.");
  },
  error(error) {
    console.error("❌ Error en Service Worker:", error);
  },
});
