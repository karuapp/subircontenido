import Vue from 'vue';
import VueI18n from 'vue-i18n';
import es from 'src/components/i18n/es.js';
import en from 'src/components/i18n/en';
import pt from 'src/components/i18n/pt';
import ar from 'src/components/i18n/ar';
import de from 'src/components/i18n/de';
import it from 'src/components/i18n/it';
import fr from 'src/components/i18n/fr';
import zh from 'src/components/i18n/zh';
import ja from 'src/components/i18n/ja';

Vue.use(VueI18n);

const messages = {
  es,
  en,
  pt,
  ar,
  de,
  it,
  fr,
  zh,
  ja
}

const i18n = new VueI18n({
  locale: localStorage.getItem('language') || 'es',
  fallbackLocale: 'en',
  messages,
});

export default ({ app }) => {
  app.i18n = i18n;
};

export { i18n };
