import { io } from 'socket.io-client'

// export const socketIO = () => {
//   return io(process.env.URL_API, {
//     reconnection: true,
//     autoConnect: true,
//     transports: ['websocket', 'polling'],
//     auth: (cb) => {
//       const tokenItem = localStorage.getItem('token')
//       const token = tokenItem ? JSON.parse(tokenItem) : null
//       // eslint-disable-next-line standard/no-callback-literal
//       cb({ token })
//     }
//   })
// }

export const socketIO = () => {
  const tokenItem = localStorage.getItem('token')
  const token = tokenItem ? JSON.parse(tokenItem) : null
  
  return io(process.env.URL_API, {
    reconnection: true,
    autoConnect: true,
    transports: ['websocket', 'polling'],
    // Voltar para a sintaxe de callback que o backend espera
    auth: (cb) => {
      const tokenItem = localStorage.getItem('token')
      const token = tokenItem ? JSON.parse(tokenItem) : null
      
      if (!token) {
        cb({ token: null })
        return
      }
      
      cb({ token })
    },
    // Configurações adicionais para melhor compatibilidade
    forceNew: true,
    timeout: 20000
  })
}

const socket = socketIO()

// Sistema de gerenciamento de memória
let socketListeners = []

const addSocketListener = (event, handler) => {
  socket.on(event, handler);
  socketListeners.push({ event, handler });
};

const removeAllSocketListeners = () => {
  socketListeners.forEach(({ event, handler }) => {
    socket.off(event, handler);
  });
  socketListeners = [];
};

const cleanupMemory = () => {
  removeAllSocketListeners();
};

socket.io.on('error', (error) => {
  console.error('socket error', error)
})

addSocketListener('connect', () => {
  // console.log('✅ SOCKET ID:', socket.id)
  console.log('🔗 SOCKET CONNECTED:', socket.connected)
  // console.log('🌐 SOCKET URL:', socket.io.uri)
  // console.log('🔗 SOCKET TRANSPORT:', socket.io.engine.transport.name)
})

addSocketListener('connect_error', (error) => {
  console.error('socket connect error:', error)
  console.error('error details:', {
    message: error.message,
    description: error.description,
    context: error.context
  })
  
  // Verificar se é erro de autenticação
  if (error.message === 'authentication error') {
    console.log('authentication error detected')
    console.log('checking token in localstorage...')
    const tokenItem = localStorage.getItem('token')
    console.log('token in localstorage:', tokenItem ? 'SIM' : 'NÃO')
    
    if (tokenItem) {
      try {
        const token = JSON.parse(tokenItem)
        console.log('valid json token', token ? 'SIM' : 'NÃO')
      } catch (e) {
        console.log('invalid json token', e.message)
      }
    }
  }
})

addSocketListener('reconnect_attempt', (attemptNumber) => {
  console.log('reconnect attempt', attemptNumber)
})

addSocketListener('reconnect', (attemptNumber) => {
  console.log('reconnect', attemptNumber)
})

addSocketListener('reconnect_error', (error) => {
  console.error('reconnect error', error)
})

addSocketListener('disconnect', (reason) => {
  console.info('socket disconnect', reason)

  if (reason === "io server disconnect") {
    // the disconnection was initiated by the server, you need to reconnect manually
    console.log('reconnecting manually...')
    socket.connect();
  } else if (reason === "transport close") {
    console.log('transport closed - waiting for automatic reconnection...')
  } else if (reason === "ping timeout") {
    console.log('ping timeout - waiting for automatic reconnection...')
  } else {
    console.log('disconnection by:', reason)
  }
  // else the socket will automatically try to reconnect
})

// Métodos de limpeza de memória
socket.cleanupMemory = cleanupMemory;
socket.removeAllSocketListeners = removeAllSocketListeners;

export default socket
