<template>
  <div class="terminal" v-if="userProfile === 'superadmin'">
    <h1 :class="{'text-white': $q.dark.isActive}" >{{ $t('terminal.title') }}</h1>
    <textarea v-model="output" readonly rows="10" class="output"></textarea>
    <div class="input-area">
      <input
        type="text"
        v-model="command"
        @keyup.enter="sendCommand"
        :placeholder="$t('terminal.placeholder')"
        class="input"
      />
      <q-btn
        color="primary"
        :label="$t('terminal.sendButton')"
        @click="sendCommand"
        class="send-button"
      />
    </div>
  </div>
</template>

<script>
import { Terminal } from 'src/service/terminal';

export default {
  name: 'Terminal',
  data() {
    return {
      command: '',
      output: '',
      userProfile: 'user'
    };
  },
  methods: {
    async sendCommand() {
      if (this.command.trim()) {
        try {
          const data = { command: this.command };
          const response = await Terminal(data);
          if (response.data && response.data.output) {
            this.output += `> ${this.command}\n${response.data.output}\n`;
          } else {
            this.output += `> ${this.command}\n${this.$t('terminal.noOutput')}\n`;
          }
          this.command = '';
        } catch (error) {
          this.output += `${this.$t('terminal.error')}${error.response ? error.response.data.error : error.message}\n`;
        }
      }
    }
  },
  mounted() {
    this.userProfile = localStorage.getItem('profile')
  }
};
</script>

<style lang="scss" scoped>
.terminal {
  display: flex;
  flex-direction: column;
  margin: 20px;
  background: rgba(255, 255, 255, 0.85);
  backdrop-filter: blur(12px);
  border-radius: 20px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  padding: 2rem;
  animation: terminalFadeIn 0.5s ease-out;

  h1 {
    color: var(--q-primary);
    font-size: 2rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
    text-align: center;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
}

.output {
  flex-grow: 1;
  background: rgba(30, 30, 30, 0.95);
  color: #d4d4d4;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  padding: 1rem;
  margin-bottom: 1rem;
  height: 400px;
  overflow-y: auto;
  white-space: pre-wrap;
  word-wrap: break-word;
  font-family: 'Fira Code', monospace;
  font-size: 0.9rem;
  line-height: 1.5;
  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;

  &:hover {
    box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.2);
  }

  &::-webkit-scrollbar {
    width: 8px;
  }

  &::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 4px;
  }

  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 4px;
    
    &:hover {
      background: rgba(255, 255, 255, 0.3);
    }
  }
}

.input-area {
  display: flex;
  gap: 1rem;
  margin-top: 1rem;
}

.input {
  flex-grow: 1;
  padding: 0.8rem 1rem;
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.9);
  font-size: 1rem;
  transition: all 0.3s ease;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);

  &:focus {
    outline: none;
    border-color: var(--q-primary);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transform: translateY(-1px);
  }

  &::placeholder {
    color: rgba(0, 0, 0, 0.4);
  }
}

.send-button {
  padding: 0.8rem 1.5rem;
  border-radius: 12px;
  font-weight: 500;
  letter-spacing: 0.5px;
  transition: all 0.3s ease;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
  }
}

.command {
  color: var(--q-positive);
  font-weight: 600;
}

.response {
  color: #d4d4d4;
}

@keyframes terminalFadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Estilos para o modo escuro */
body.body--dark {
  .terminal {
    background: rgba(30, 30, 30, 0.85);
    border-color: rgba(255, 255, 255, 0.1);

    .input {
      background: rgba(255, 255, 255, 0.05);
      border-color: rgba(255, 255, 255, 0.1);
      color: #fff;

      &::placeholder {
        color: rgba(255, 255, 255, 0.4);
      }
    }
  }
}

/* Responsividade */
@media (max-width: 600px) {
  .terminal {
    margin: 10px;
    padding: 1rem;

    h1 {
      font-size: 1.5rem;
    }

    .output {
      height: 300px;
    }

    .input-area {
      flex-direction: column;
      gap: 0.5rem;
    }

    .send-button {
      width: 100%;
    }
  }
}
</style>
