<template>
    <div class="container">
    <div class="login-section fixed-layout">
      <q-layout class="vertical-center full-width">
        <q-page-container>
          <q-page class="flex justify-center items-center">
            <q-ajax-bar position="top" color="primary" size="5px" />
            <div class="login-content">
              <q-img
                src="/logo.png"
                spinner-color="white"
                class="logo-image q-mb-lg q-px-md no-cover"
                style="max-width: 120%"
              />
              <q-separator spaced />
              <div class="text-primary">
                <div class="text-h6">{{ $t('signup.title') }}</div>
                <div>
                  <q-input
                  v-model="form.name"
                  label="Nombre de la empresa"
                  outlined
                  clearable
                  class="q-mb-md"
                  required
                >
                  <template v-slot:prepend>
                    <q-icon name="mdi-account-check-outline" color="primary" />
                  </template>
                </q-input>



                <q-input
                  v-model="form.email"
                  label="Correo electrónico"
                  type="email"
                  outlined
                  clearable
                  class="q-mb-md"
                  required
                >
                  <template v-slot:prepend>
                    <q-icon name="mdi-email-outline" color="primary" />
                  </template>
                </q-input>

                <q-input
                  v-model="form.userName"
                  label="Nombre de usuario"
                  outlined
                  clearable
                  class="q-mb-md"
                  required
                >
                  <template v-slot:prepend>
                    <q-icon name="mdi-account-outline" color="primary" />
                  </template>
                </q-input>

                <q-input
                  v-model="form.password"
                  :type="showPassword ? 'text' : 'password'"
                  label="Contraseña"
                  outlined
                  clearable
                  class="q-mb-md"
                  required
                >
                  <template v-slot:prepend>
                    <q-icon name="mdi-shield-key-outline" color="primary" />
                  </template>
                  <template v-slot:append>
                    <q-icon
                      :name="showPassword ? 'visibility' : 'visibility_off'"
                      class="cursor-pointer"
                      @click="showPassword = !showPassword"
                    />
                  </template>
                </q-input>

                <q-select
                  v-model="form.plan"
                  label="Selecciona un plan"
                  outlined
                  class="q-mb-md"
                  :options="planOptions"
                  option-label="label"
                  option-value="value"
                  emit-value
                  map-options
                  required
                >
                  <template v-slot:prepend>
                    <q-icon name="mdi-package-variant-closed" color="primary" />
                  </template>
                </q-select>

                <q-checkbox
                  v-model="form.acceptTerms"
                  label="Acepto los términos y condiciones"
                  class="q-mb-md"
                  required
                />

                <q-btn
                  color="primary"
                  @click="submitForm"
                  :loading="loading"
                  style="width: 150px"
                >
                  Registrarse
                </q-btn>

                <q-btn
                  class="bg-red text-white"
                  @click="goToLogin"
                  style="width: 150px"
                >
                  Ir al Login
                </q-btn>
              </div>
            </div>
          </q-page>
        </q-page-container>
      </q-layout>
    </div>
    <div class="video-container">
      <video
        autoplay
        muted
        loop
        style="width: 100%; height: auto; object-fit: cover; "
      >
        <source src="../assets/110694.mp4" type="video/mp4" />
      </video>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        name: '',
        identity: '',
        email: '',
        userName: '',
        password: '',
        acceptTerms: false,
        plan: 'plan1' // valor por defecto
      },
      planOptions: [
        { label: '💼 Plan Emprendedor 1 canal / 5 Agentes', value: 'plan1' },
        { label: '🚀 Plan Profesional 3 canales / 15 usuarios', value: 'plan2' },
        { label: '🚀 Plan Enterprise 5 canales / 10 usuarios', value: 'plan3' }
      ],
      showPassword: false,
      loading: false
    };
  },
  methods: {
    async submitForm() {
      if (
        !this.form.name ||
       
        !this.form.email ||
        !this.form.userName ||
        !this.form.password ||
        !this.form.acceptTerms ||
        !this.form.plan
      ) {
        this.$q.notify({
          type: 'negative',
          message: 'Por favor, completa todos los campos y acepta los términos.'
        });
        return;
      }

      this.loading = true;

      // Asignar valores según el plan seleccionado
      let maxUsers = 1;
      let maxConnections = 5;

      switch (this.form.plan) {
        case 'plan2':
          maxUsers = 15;
          maxConnections = 3;
          break;
        case 'plan3':
          maxUsers = 10;
          maxConnections = 5;
          break;
      }

      const payload = {
        status: 'active',
        name: this.form.name,
        maxUsers,
        maxConnections,
        acceptTerms: true,
        email: this.form.email,
        password: this.form.password,
        userName: this.form.userName,
        
        profile: 'admin',
        trial: 'enabled',
        trialPeriod: 14
      };

      try {
        const response = await fetch('https://api.intnobyte.com/tenantApiStoreTenant', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer intnobyte'
          },
          body: JSON.stringify(payload)
        });

        if (!response.ok) {
          let errorMsg = 'Error en el registro';
          try {
            const errorData = await response.json();
            if (errorData.message) errorMsg = errorData.message;
          } catch {
            errorMsg = await response.text();
          }
          throw new Error(errorMsg);
        }

        this.$q.notify({
          type: 'positive',
          message: 'Registro exitoso'
        });

        this.resetForm();
        this.$router.push('/login');

      } catch (error) {
        this.$q.notify({
          type: 'negative',
          message: error.message
        });
      } finally {
        this.loading = false;
      }
    },

    goToLogin() {
      this.$router.push('/login');
    },

    resetForm() {
      this.form = {
        name: '',
        identity: '',
        email: '',
        userName: '',
        password: '',
        acceptTerms: false,
        plan: 'plan1'
      };
      this.showPassword = false;
    }
  }
};
</script>

<style scoped>
.container {
  display: flex;
  height: 100vh;
  position: relative;
  overflow: hidden;
}

.login-section {
  width: 45%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  background: linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(255, 255, 255, 0.85));
  backdrop-filter: blur(10px);
  position: relative;
  z-index: 2;
  box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);
}

.full-width {
  width: 100%;
}

.no-cover .q-img__image {
  background-size: contain !important;
}

.login-content {
  width: 350px;
  max-width: 350px;
  text-align: center;
  padding: 2rem;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 20px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  animation: fadeIn 0.5s ease-out;
}

.video-container {
  display: flex;
  justify-content: flex-end;
  width: 55%;
  position: relative;
  overflow: hidden;
}

.video-container video {
  width: 100%;
  height: 100%;
  object-fit: cover;
  filter: brightness(0.8) contrast(1.1);
  transition: transform 0.3s ease;
}

.video-container:hover video {
  transform: scale(1.05);
}

.logo-image {
  height: auto;
  max-width: 100%;
  margin-bottom: 2rem;
  transition: transform 0.3s ease;
}

.logo-image:hover {
  transform: scale(1.02);
}

.q-input, .q-select {
  margin-bottom: 1rem;
}

.q-input .q-field__control, .q-select .q-field__control {
  border-radius: 12px;
  transition: all 0.3s ease;
}

.q-input .q-field__control:hover, .q-select .q-field__control:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

.q-input .q-field__native, .q-select .q-field__native {
  padding: 8px 12px;
}

.q-btn {
  border-radius: 12px;
  font-weight: 500;
  letter-spacing: 0.5px;
  transition: all 0.3s ease;
  margin: 0.5rem;
}

.q-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.q-btn--negative {
  background: rgba(244, 67, 54, 0.1);
  color: var(--q-negative);
}

.q-btn--negative:hover {
  background: rgba(244, 67, 54, 0.2);
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 600px) {
  .video-container {
    display: none;
  }
  
  .login-section {
    width: 100%;
    background: linear-gradient(135deg, rgba(255, 255, 255, 0.98), rgba(255, 255, 255, 0.95));
  }
  
  .login-content {
    margin: 0 1rem;
    padding: 1.5rem;
  }
}

/* Estilos para o modo escuro */
body.body--dark .login-section {
  background: linear-gradient(135deg, rgba(30, 30, 30, 0.95), rgba(20, 20, 20, 0.85));
}

body.body--dark .login-content {
  background: rgba(30, 30, 30, 0.9);
  border-color: rgba(255, 255, 255, 0.1);
}

body.body--dark .q-input .q-field__control,
body.body--dark .q-select .q-field__control {
  background: rgba(255, 255, 255, 0.05);
}

body.body--dark .q-btn--negative {
  background: rgba(244, 67, 54, 0.2);
  color: #ff6b6b;
}

body.body--dark .q-btn--negative:hover {
  background: rgba(244, 67, 54, 0.3);
}
</style>