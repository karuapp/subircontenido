<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-08-11 00:03:37 --> Config Class Initialized
INFO - 2025-08-11 00:03:37 --> Hooks Class Initialized
DEBUG - 2025-08-11 00:03:37 --> UTF-8 Support Enabled
INFO - 2025-08-11 00:03:37 --> Utf8 Class Initialized
INFO - 2025-08-11 00:03:37 --> URI Class Initialized
DEBUG - 2025-08-11 00:03:37 --> No URI present. Default controller set.
INFO - 2025-08-11 00:03:37 --> Router Class Initialized
INFO - 2025-08-11 00:03:37 --> Output Class Initialized
INFO - 2025-08-11 00:03:37 --> Security Class Initialized
DEBUG - 2025-08-11 00:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 00:03:37 --> CSRF cookie sent
INFO - 2025-08-11 00:03:37 --> Input Class Initialized
INFO - 2025-08-11 00:03:37 --> Language Class Initialized
INFO - 2025-08-11 00:03:37 --> Loader Class Initialized
INFO - 2025-08-11 00:03:37 --> Helper loaded: url_helper
INFO - 2025-08-11 00:03:37 --> Helper loaded: form_helper
INFO - 2025-08-11 00:03:37 --> Helper loaded: custom_helper
INFO - 2025-08-11 00:03:37 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 00:03:37 --> Helper loaded: currency_helper
INFO - 2025-08-11 00:03:37 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 00:03:37 --> Database Driver Class Initialized
ERROR - 2025-08-11 00:03:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:37 --> Unable to connect to the database
INFO - 2025-08-11 00:03:37 --> Form Validation Class Initialized
ERROR - 2025-08-11 00:03:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:37 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time C:\xampp\htdocs\system\libraries\Session\Session_driver.php 205
ERROR - 2025-08-11 00:03:37 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\xampp\tmp) C:\xampp\htdocs\system\libraries\Session\Session.php 143
INFO - 2025-08-11 00:03:37 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 00:03:37 --> Controller Class Initialized
ERROR - 2025-08-11 00:03:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:37 --> Unable to connect to the database
ERROR - 2025-08-11 00:03:37 --> Query error: Access denied for user 'comidas'@'localhost' (using password: YES) - Invalid query: SELECT a.currency_name,a.currency,a.currency_code,a.symbol,b.currency_placement FROM db_currency a,db_sitesettings b WHERE a.id=b.currency_id AND b.id=1
ERROR - 2025-08-11 00:03:37 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp\htdocs\application\core\MY_Controller.php 19
INFO - 2025-08-11 00:03:38 --> Config Class Initialized
INFO - 2025-08-11 00:03:38 --> Hooks Class Initialized
DEBUG - 2025-08-11 00:03:38 --> UTF-8 Support Enabled
INFO - 2025-08-11 00:03:38 --> Utf8 Class Initialized
INFO - 2025-08-11 00:03:38 --> URI Class Initialized
DEBUG - 2025-08-11 00:03:38 --> No URI present. Default controller set.
INFO - 2025-08-11 00:03:38 --> Router Class Initialized
INFO - 2025-08-11 00:03:38 --> Output Class Initialized
INFO - 2025-08-11 00:03:38 --> Security Class Initialized
DEBUG - 2025-08-11 00:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 00:03:38 --> CSRF cookie sent
INFO - 2025-08-11 00:03:38 --> Input Class Initialized
INFO - 2025-08-11 00:03:38 --> Language Class Initialized
INFO - 2025-08-11 00:03:38 --> Loader Class Initialized
INFO - 2025-08-11 00:03:38 --> Helper loaded: url_helper
INFO - 2025-08-11 00:03:38 --> Helper loaded: form_helper
INFO - 2025-08-11 00:03:38 --> Helper loaded: custom_helper
INFO - 2025-08-11 00:03:38 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 00:03:38 --> Helper loaded: currency_helper
INFO - 2025-08-11 00:03:38 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 00:03:38 --> Database Driver Class Initialized
ERROR - 2025-08-11 00:03:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:38 --> Unable to connect to the database
INFO - 2025-08-11 00:03:38 --> Form Validation Class Initialized
ERROR - 2025-08-11 00:03:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:38 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time C:\xampp\htdocs\system\libraries\Session\Session_driver.php 205
ERROR - 2025-08-11 00:03:38 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\xampp\tmp) C:\xampp\htdocs\system\libraries\Session\Session.php 143
INFO - 2025-08-11 00:03:38 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 00:03:38 --> Controller Class Initialized
ERROR - 2025-08-11 00:03:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:38 --> Unable to connect to the database
ERROR - 2025-08-11 00:03:38 --> Query error: Access denied for user 'comidas'@'localhost' (using password: YES) - Invalid query: SELECT a.currency_name,a.currency,a.currency_code,a.symbol,b.currency_placement FROM db_currency a,db_sitesettings b WHERE a.id=b.currency_id AND b.id=1
ERROR - 2025-08-11 00:03:38 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp\htdocs\application\core\MY_Controller.php 19
INFO - 2025-08-11 00:03:38 --> Config Class Initialized
INFO - 2025-08-11 00:03:38 --> Hooks Class Initialized
DEBUG - 2025-08-11 00:03:38 --> UTF-8 Support Enabled
INFO - 2025-08-11 00:03:38 --> Utf8 Class Initialized
INFO - 2025-08-11 00:03:38 --> URI Class Initialized
DEBUG - 2025-08-11 00:03:38 --> No URI present. Default controller set.
INFO - 2025-08-11 00:03:38 --> Router Class Initialized
INFO - 2025-08-11 00:03:38 --> Output Class Initialized
INFO - 2025-08-11 00:03:38 --> Security Class Initialized
DEBUG - 2025-08-11 00:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 00:03:38 --> CSRF cookie sent
INFO - 2025-08-11 00:03:38 --> Input Class Initialized
INFO - 2025-08-11 00:03:38 --> Language Class Initialized
INFO - 2025-08-11 00:03:38 --> Loader Class Initialized
INFO - 2025-08-11 00:03:38 --> Helper loaded: url_helper
INFO - 2025-08-11 00:03:38 --> Helper loaded: form_helper
INFO - 2025-08-11 00:03:38 --> Helper loaded: custom_helper
INFO - 2025-08-11 00:03:38 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 00:03:38 --> Helper loaded: currency_helper
INFO - 2025-08-11 00:03:38 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 00:03:38 --> Database Driver Class Initialized
ERROR - 2025-08-11 00:03:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:38 --> Unable to connect to the database
INFO - 2025-08-11 00:03:38 --> Form Validation Class Initialized
ERROR - 2025-08-11 00:03:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:38 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time C:\xampp\htdocs\system\libraries\Session\Session_driver.php 205
ERROR - 2025-08-11 00:03:38 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\xampp\tmp) C:\xampp\htdocs\system\libraries\Session\Session.php 143
INFO - 2025-08-11 00:03:38 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 00:03:38 --> Controller Class Initialized
ERROR - 2025-08-11 00:03:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:38 --> Unable to connect to the database
ERROR - 2025-08-11 00:03:38 --> Query error: Access denied for user 'comidas'@'localhost' (using password: YES) - Invalid query: SELECT a.currency_name,a.currency,a.currency_code,a.symbol,b.currency_placement FROM db_currency a,db_sitesettings b WHERE a.id=b.currency_id AND b.id=1
ERROR - 2025-08-11 00:03:38 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp\htdocs\application\core\MY_Controller.php 19
INFO - 2025-08-11 00:03:39 --> Config Class Initialized
INFO - 2025-08-11 00:03:39 --> Hooks Class Initialized
DEBUG - 2025-08-11 00:03:39 --> UTF-8 Support Enabled
INFO - 2025-08-11 00:03:39 --> Utf8 Class Initialized
INFO - 2025-08-11 00:03:39 --> URI Class Initialized
DEBUG - 2025-08-11 00:03:39 --> No URI present. Default controller set.
INFO - 2025-08-11 00:03:39 --> Router Class Initialized
INFO - 2025-08-11 00:03:39 --> Output Class Initialized
INFO - 2025-08-11 00:03:39 --> Security Class Initialized
DEBUG - 2025-08-11 00:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 00:03:39 --> CSRF cookie sent
INFO - 2025-08-11 00:03:39 --> Input Class Initialized
INFO - 2025-08-11 00:03:39 --> Language Class Initialized
INFO - 2025-08-11 00:03:39 --> Loader Class Initialized
INFO - 2025-08-11 00:03:39 --> Helper loaded: url_helper
INFO - 2025-08-11 00:03:39 --> Helper loaded: form_helper
INFO - 2025-08-11 00:03:40 --> Helper loaded: custom_helper
INFO - 2025-08-11 00:03:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 00:03:40 --> Helper loaded: currency_helper
INFO - 2025-08-11 00:03:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 00:03:40 --> Database Driver Class Initialized
ERROR - 2025-08-11 00:03:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:40 --> Unable to connect to the database
INFO - 2025-08-11 00:03:40 --> Form Validation Class Initialized
ERROR - 2025-08-11 00:03:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:40 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time C:\xampp\htdocs\system\libraries\Session\Session_driver.php 205
ERROR - 2025-08-11 00:03:40 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\xampp\tmp) C:\xampp\htdocs\system\libraries\Session\Session.php 143
INFO - 2025-08-11 00:03:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 00:03:40 --> Controller Class Initialized
ERROR - 2025-08-11 00:03:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:40 --> Unable to connect to the database
ERROR - 2025-08-11 00:03:40 --> Query error: Access denied for user 'comidas'@'localhost' (using password: YES) - Invalid query: SELECT a.currency_name,a.currency,a.currency_code,a.symbol,b.currency_placement FROM db_currency a,db_sitesettings b WHERE a.id=b.currency_id AND b.id=1
ERROR - 2025-08-11 00:03:40 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp\htdocs\application\core\MY_Controller.php 19
INFO - 2025-08-11 00:03:40 --> Config Class Initialized
INFO - 2025-08-11 00:03:40 --> Hooks Class Initialized
DEBUG - 2025-08-11 00:03:40 --> UTF-8 Support Enabled
INFO - 2025-08-11 00:03:40 --> Utf8 Class Initialized
INFO - 2025-08-11 00:03:40 --> URI Class Initialized
DEBUG - 2025-08-11 00:03:40 --> No URI present. Default controller set.
INFO - 2025-08-11 00:03:40 --> Router Class Initialized
INFO - 2025-08-11 00:03:40 --> Output Class Initialized
INFO - 2025-08-11 00:03:40 --> Security Class Initialized
DEBUG - 2025-08-11 00:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 00:03:40 --> CSRF cookie sent
INFO - 2025-08-11 00:03:40 --> Input Class Initialized
INFO - 2025-08-11 00:03:40 --> Language Class Initialized
INFO - 2025-08-11 00:03:40 --> Loader Class Initialized
INFO - 2025-08-11 00:03:40 --> Helper loaded: url_helper
INFO - 2025-08-11 00:03:40 --> Helper loaded: form_helper
INFO - 2025-08-11 00:03:40 --> Helper loaded: custom_helper
INFO - 2025-08-11 00:03:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 00:03:40 --> Helper loaded: currency_helper
INFO - 2025-08-11 00:03:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 00:03:40 --> Database Driver Class Initialized
ERROR - 2025-08-11 00:03:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:40 --> Unable to connect to the database
INFO - 2025-08-11 00:03:40 --> Form Validation Class Initialized
ERROR - 2025-08-11 00:03:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:40 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time C:\xampp\htdocs\system\libraries\Session\Session_driver.php 205
ERROR - 2025-08-11 00:03:40 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\xampp\tmp) C:\xampp\htdocs\system\libraries\Session\Session.php 143
INFO - 2025-08-11 00:03:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 00:03:40 --> Controller Class Initialized
ERROR - 2025-08-11 00:03:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:03:40 --> Unable to connect to the database
ERROR - 2025-08-11 00:03:40 --> Query error: Access denied for user 'comidas'@'localhost' (using password: YES) - Invalid query: SELECT a.currency_name,a.currency,a.currency_code,a.symbol,b.currency_placement FROM db_currency a,db_sitesettings b WHERE a.id=b.currency_id AND b.id=1
ERROR - 2025-08-11 00:03:40 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp\htdocs\application\core\MY_Controller.php 19
INFO - 2025-08-11 00:05:40 --> Config Class Initialized
INFO - 2025-08-11 00:05:40 --> Hooks Class Initialized
DEBUG - 2025-08-11 00:05:40 --> UTF-8 Support Enabled
INFO - 2025-08-11 00:05:40 --> Utf8 Class Initialized
INFO - 2025-08-11 00:05:40 --> URI Class Initialized
DEBUG - 2025-08-11 00:05:40 --> No URI present. Default controller set.
INFO - 2025-08-11 00:05:40 --> Router Class Initialized
INFO - 2025-08-11 00:05:40 --> Output Class Initialized
INFO - 2025-08-11 00:05:40 --> Security Class Initialized
DEBUG - 2025-08-11 00:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 00:05:40 --> CSRF cookie sent
INFO - 2025-08-11 00:05:40 --> Input Class Initialized
INFO - 2025-08-11 00:05:40 --> Language Class Initialized
INFO - 2025-08-11 00:05:40 --> Loader Class Initialized
INFO - 2025-08-11 00:05:40 --> Helper loaded: url_helper
INFO - 2025-08-11 00:05:40 --> Helper loaded: form_helper
INFO - 2025-08-11 00:05:40 --> Helper loaded: custom_helper
INFO - 2025-08-11 00:05:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 00:05:40 --> Helper loaded: currency_helper
INFO - 2025-08-11 00:05:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 00:05:40 --> Database Driver Class Initialized
ERROR - 2025-08-11 00:05:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:05:40 --> Unable to connect to the database
INFO - 2025-08-11 00:05:40 --> Form Validation Class Initialized
ERROR - 2025-08-11 00:05:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:05:40 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time C:\xampp\htdocs\system\libraries\Session\Session_driver.php 205
ERROR - 2025-08-11 00:05:40 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\xampp\tmp) C:\xampp\htdocs\system\libraries\Session\Session.php 143
INFO - 2025-08-11 00:05:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 00:05:40 --> Controller Class Initialized
ERROR - 2025-08-11 00:05:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:05:40 --> Unable to connect to the database
ERROR - 2025-08-11 00:05:40 --> Query error: Access denied for user 'comidas'@'localhost' (using password: YES) - Invalid query: SELECT a.currency_name,a.currency,a.currency_code,a.symbol,b.currency_placement FROM db_currency a,db_sitesettings b WHERE a.id=b.currency_id AND b.id=1
ERROR - 2025-08-11 00:05:40 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp\htdocs\application\core\MY_Controller.php 19
INFO - 2025-08-11 00:05:40 --> Config Class Initialized
INFO - 2025-08-11 00:05:40 --> Hooks Class Initialized
DEBUG - 2025-08-11 00:05:40 --> UTF-8 Support Enabled
INFO - 2025-08-11 00:05:40 --> Utf8 Class Initialized
INFO - 2025-08-11 00:05:40 --> URI Class Initialized
DEBUG - 2025-08-11 00:05:40 --> No URI present. Default controller set.
INFO - 2025-08-11 00:05:40 --> Router Class Initialized
INFO - 2025-08-11 00:05:40 --> Output Class Initialized
INFO - 2025-08-11 00:05:40 --> Security Class Initialized
DEBUG - 2025-08-11 00:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 00:05:40 --> CSRF cookie sent
INFO - 2025-08-11 00:05:40 --> Input Class Initialized
INFO - 2025-08-11 00:05:40 --> Language Class Initialized
INFO - 2025-08-11 00:05:40 --> Loader Class Initialized
INFO - 2025-08-11 00:05:40 --> Helper loaded: url_helper
INFO - 2025-08-11 00:05:40 --> Helper loaded: form_helper
INFO - 2025-08-11 00:05:40 --> Helper loaded: custom_helper
INFO - 2025-08-11 00:05:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 00:05:40 --> Helper loaded: currency_helper
INFO - 2025-08-11 00:05:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 00:05:40 --> Database Driver Class Initialized
ERROR - 2025-08-11 00:05:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:05:40 --> Unable to connect to the database
INFO - 2025-08-11 00:05:40 --> Form Validation Class Initialized
ERROR - 2025-08-11 00:05:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:05:40 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time C:\xampp\htdocs\system\libraries\Session\Session_driver.php 205
ERROR - 2025-08-11 00:05:40 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\xampp\tmp) C:\xampp\htdocs\system\libraries\Session\Session.php 143
INFO - 2025-08-11 00:05:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 00:05:40 --> Controller Class Initialized
ERROR - 2025-08-11 00:05:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'comidas'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2025-08-11 00:05:40 --> Unable to connect to the database
ERROR - 2025-08-11 00:05:40 --> Query error: Access denied for user 'comidas'@'localhost' (using password: YES) - Invalid query: SELECT a.currency_name,a.currency,a.currency_code,a.symbol,b.currency_placement FROM db_currency a,db_sitesettings b WHERE a.id=b.currency_id AND b.id=1
ERROR - 2025-08-11 00:05:40 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp\htdocs\application\core\MY_Controller.php 19
INFO - 2025-08-11 00:10:35 --> Config Class Initialized
INFO - 2025-08-11 00:10:35 --> Hooks Class Initialized
DEBUG - 2025-08-11 00:10:35 --> UTF-8 Support Enabled
INFO - 2025-08-11 00:10:35 --> Utf8 Class Initialized
INFO - 2025-08-11 00:10:35 --> URI Class Initialized
DEBUG - 2025-08-11 00:10:35 --> No URI present. Default controller set.
INFO - 2025-08-11 00:10:35 --> Router Class Initialized
INFO - 2025-08-11 00:10:35 --> Output Class Initialized
INFO - 2025-08-11 00:10:35 --> Security Class Initialized
DEBUG - 2025-08-11 00:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 00:10:35 --> CSRF cookie sent
INFO - 2025-08-11 00:10:35 --> Input Class Initialized
INFO - 2025-08-11 00:10:35 --> Language Class Initialized
INFO - 2025-08-11 00:10:35 --> Loader Class Initialized
INFO - 2025-08-11 00:10:35 --> Helper loaded: url_helper
INFO - 2025-08-11 00:10:35 --> Helper loaded: form_helper
INFO - 2025-08-11 00:10:35 --> Helper loaded: custom_helper
INFO - 2025-08-11 00:10:35 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 00:10:35 --> Helper loaded: currency_helper
INFO - 2025-08-11 00:10:35 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 00:10:35 --> Database Driver Class Initialized
INFO - 2025-08-11 00:10:35 --> Form Validation Class Initialized
INFO - 2025-08-11 00:10:35 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 00:10:35 --> Controller Class Initialized
INFO - 2025-08-11 00:11:09 --> Config Class Initialized
INFO - 2025-08-11 00:11:09 --> Hooks Class Initialized
DEBUG - 2025-08-11 00:11:09 --> UTF-8 Support Enabled
INFO - 2025-08-11 00:11:09 --> Utf8 Class Initialized
INFO - 2025-08-11 00:11:09 --> URI Class Initialized
DEBUG - 2025-08-11 00:11:09 --> No URI present. Default controller set.
INFO - 2025-08-11 00:11:09 --> Router Class Initialized
INFO - 2025-08-11 00:11:09 --> Output Class Initialized
INFO - 2025-08-11 00:11:09 --> Security Class Initialized
DEBUG - 2025-08-11 00:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 00:11:09 --> CSRF cookie sent
INFO - 2025-08-11 00:11:09 --> Input Class Initialized
INFO - 2025-08-11 00:11:09 --> Language Class Initialized
INFO - 2025-08-11 00:11:09 --> Loader Class Initialized
INFO - 2025-08-11 00:11:09 --> Helper loaded: url_helper
INFO - 2025-08-11 00:11:09 --> Helper loaded: form_helper
INFO - 2025-08-11 00:11:09 --> Helper loaded: custom_helper
INFO - 2025-08-11 00:11:09 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 00:11:09 --> Helper loaded: currency_helper
INFO - 2025-08-11 00:11:09 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 00:11:09 --> Database Driver Class Initialized
INFO - 2025-08-11 00:11:09 --> Form Validation Class Initialized
INFO - 2025-08-11 00:11:09 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 00:11:09 --> Controller Class Initialized
INFO - 2025-08-11 02:40:16 --> Config Class Initialized
INFO - 2025-08-11 02:40:16 --> Hooks Class Initialized
DEBUG - 2025-08-11 02:40:16 --> UTF-8 Support Enabled
INFO - 2025-08-11 02:40:16 --> Utf8 Class Initialized
INFO - 2025-08-11 02:40:16 --> URI Class Initialized
DEBUG - 2025-08-11 02:40:16 --> No URI present. Default controller set.
INFO - 2025-08-11 02:40:16 --> Router Class Initialized
INFO - 2025-08-11 02:40:16 --> Output Class Initialized
INFO - 2025-08-11 02:40:16 --> Security Class Initialized
DEBUG - 2025-08-11 02:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 02:40:16 --> CSRF cookie sent
INFO - 2025-08-11 02:40:16 --> Input Class Initialized
INFO - 2025-08-11 02:40:16 --> Language Class Initialized
INFO - 2025-08-11 02:40:16 --> Loader Class Initialized
INFO - 2025-08-11 02:40:16 --> Helper loaded: url_helper
INFO - 2025-08-11 02:40:16 --> Helper loaded: form_helper
INFO - 2025-08-11 02:40:16 --> Helper loaded: custom_helper
INFO - 2025-08-11 02:40:16 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 02:40:16 --> Helper loaded: currency_helper
INFO - 2025-08-11 02:40:16 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 02:40:16 --> Database Driver Class Initialized
INFO - 2025-08-11 02:40:16 --> Form Validation Class Initialized
INFO - 2025-08-11 02:40:16 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 02:40:16 --> Controller Class Initialized
INFO - 2025-08-11 02:43:12 --> Config Class Initialized
INFO - 2025-08-11 02:43:12 --> Hooks Class Initialized
DEBUG - 2025-08-11 02:43:12 --> UTF-8 Support Enabled
INFO - 2025-08-11 02:43:12 --> Utf8 Class Initialized
INFO - 2025-08-11 02:43:12 --> URI Class Initialized
DEBUG - 2025-08-11 02:43:12 --> No URI present. Default controller set.
INFO - 2025-08-11 02:43:12 --> Router Class Initialized
INFO - 2025-08-11 02:43:12 --> Output Class Initialized
INFO - 2025-08-11 02:43:12 --> Security Class Initialized
DEBUG - 2025-08-11 02:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 02:43:12 --> CSRF cookie sent
INFO - 2025-08-11 02:43:12 --> Input Class Initialized
INFO - 2025-08-11 02:43:12 --> Language Class Initialized
INFO - 2025-08-11 02:43:12 --> Loader Class Initialized
INFO - 2025-08-11 02:43:12 --> Helper loaded: url_helper
INFO - 2025-08-11 02:43:12 --> Helper loaded: form_helper
INFO - 2025-08-11 02:43:12 --> Helper loaded: custom_helper
INFO - 2025-08-11 02:43:12 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 02:43:12 --> Helper loaded: currency_helper
INFO - 2025-08-11 02:43:12 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 02:43:12 --> Database Driver Class Initialized
INFO - 2025-08-11 02:43:12 --> Form Validation Class Initialized
INFO - 2025-08-11 02:43:12 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 02:43:12 --> Controller Class Initialized
INFO - 2025-08-11 02:43:36 --> Config Class Initialized
INFO - 2025-08-11 02:43:36 --> Hooks Class Initialized
DEBUG - 2025-08-11 02:43:36 --> UTF-8 Support Enabled
INFO - 2025-08-11 02:43:36 --> Utf8 Class Initialized
INFO - 2025-08-11 02:43:36 --> URI Class Initialized
DEBUG - 2025-08-11 02:43:36 --> No URI present. Default controller set.
INFO - 2025-08-11 02:43:36 --> Router Class Initialized
INFO - 2025-08-11 02:43:36 --> Output Class Initialized
INFO - 2025-08-11 02:43:36 --> Security Class Initialized
DEBUG - 2025-08-11 02:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-11 02:43:36 --> CSRF cookie sent
INFO - 2025-08-11 02:43:36 --> Input Class Initialized
INFO - 2025-08-11 02:43:36 --> Language Class Initialized
INFO - 2025-08-11 02:43:36 --> Loader Class Initialized
INFO - 2025-08-11 02:43:36 --> Helper loaded: url_helper
INFO - 2025-08-11 02:43:36 --> Helper loaded: form_helper
INFO - 2025-08-11 02:43:36 --> Helper loaded: custom_helper
INFO - 2025-08-11 02:43:36 --> Helper loaded: appinfo_helper
INFO - 2025-08-11 02:43:36 --> Helper loaded: currency_helper
INFO - 2025-08-11 02:43:36 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-11 02:43:36 --> Database Driver Class Initialized
INFO - 2025-08-11 02:43:36 --> Form Validation Class Initialized
INFO - 2025-08-11 02:43:36 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-11 02:43:36 --> Controller Class Initialized
