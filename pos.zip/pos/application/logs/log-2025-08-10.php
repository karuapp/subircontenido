<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-08-10 16:10:35 --> File loaded: C:\xampp\htdocs\application\views\login.php
INFO - 2025-08-10 16:10:35 --> Final output sent to browser
DEBUG - 2025-08-10 16:10:35 --> Total execution time: 0.0832
INFO - 2025-08-10 16:11:09 --> File loaded: C:\xampp\htdocs\application\views\login.php
INFO - 2025-08-10 16:11:09 --> Final output sent to browser
DEBUG - 2025-08-10 16:11:09 --> Total execution time: 0.0456
INFO - 2025-08-10 18:40:16 --> File loaded: C:\xampp\htdocs\application\views\login.php
INFO - 2025-08-10 18:40:16 --> Final output sent to browser
DEBUG - 2025-08-10 18:40:16 --> Total execution time: 0.1391
INFO - 2025-08-10 18:43:12 --> File loaded: C:\xampp\htdocs\application\views\login.php
INFO - 2025-08-10 18:43:12 --> Final output sent to browser
DEBUG - 2025-08-10 18:43:12 --> Total execution time: 0.0431
INFO - 2025-08-10 18:43:36 --> File loaded: C:\xampp\htdocs\application\views\login.php
INFO - 2025-08-10 18:43:36 --> Final output sent to browser
DEBUG - 2025-08-10 18:43:36 --> Total execution time: 0.0619
