<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-08-14 21:29:10 --> Config Class Initialized
INFO - 2025-08-14 21:29:10 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:29:10 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:29:10 --> Utf8 Class Initialized
INFO - 2025-08-14 21:29:11 --> URI Class Initialized
DEBUG - 2025-08-14 21:29:11 --> No URI present. Default controller set.
INFO - 2025-08-14 21:29:11 --> Router Class Initialized
INFO - 2025-08-14 21:29:11 --> Output Class Initialized
INFO - 2025-08-14 21:29:11 --> Security Class Initialized
DEBUG - 2025-08-14 21:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:29:11 --> CSRF cookie sent
INFO - 2025-08-14 21:29:11 --> Input Class Initialized
INFO - 2025-08-14 21:29:11 --> Language Class Initialized
INFO - 2025-08-14 21:29:11 --> Loader Class Initialized
INFO - 2025-08-14 21:29:11 --> Helper loaded: url_helper
INFO - 2025-08-14 21:29:11 --> Helper loaded: form_helper
INFO - 2025-08-14 21:29:11 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:29:11 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:29:11 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:29:11 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:29:11 --> Database Driver Class Initialized
INFO - 2025-08-14 21:29:11 --> Form Validation Class Initialized
INFO - 2025-08-14 21:29:11 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:29:11 --> Controller Class Initialized
INFO - 2025-08-14 13:29:11 --> File loaded: C:\xampp\htdocs\application\views\login.php
INFO - 2025-08-14 13:29:11 --> Final output sent to browser
DEBUG - 2025-08-14 13:29:11 --> Total execution time: 0.1318
INFO - 2025-08-14 21:29:14 --> Config Class Initialized
INFO - 2025-08-14 21:29:14 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:29:14 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:29:14 --> Utf8 Class Initialized
INFO - 2025-08-14 21:29:14 --> URI Class Initialized
INFO - 2025-08-14 21:29:14 --> Router Class Initialized
INFO - 2025-08-14 21:29:14 --> Output Class Initialized
INFO - 2025-08-14 21:29:14 --> Security Class Initialized
DEBUG - 2025-08-14 21:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:29:14 --> CSRF cookie sent
INFO - 2025-08-14 21:29:14 --> CSRF token verified
INFO - 2025-08-14 21:29:14 --> Input Class Initialized
INFO - 2025-08-14 21:29:14 --> Language Class Initialized
INFO - 2025-08-14 21:29:14 --> Loader Class Initialized
INFO - 2025-08-14 21:29:14 --> Helper loaded: url_helper
INFO - 2025-08-14 21:29:14 --> Helper loaded: form_helper
INFO - 2025-08-14 21:29:14 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:29:14 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:29:14 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:29:14 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:29:14 --> Database Driver Class Initialized
INFO - 2025-08-14 21:29:14 --> Form Validation Class Initialized
INFO - 2025-08-14 21:29:15 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:29:15 --> Controller Class Initialized
INFO - 2025-08-14 13:29:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 21:29:15 --> Config Class Initialized
INFO - 2025-08-14 21:29:15 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:29:15 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:29:15 --> Utf8 Class Initialized
INFO - 2025-08-14 21:29:15 --> URI Class Initialized
INFO - 2025-08-14 21:29:15 --> Router Class Initialized
INFO - 2025-08-14 21:29:15 --> Output Class Initialized
INFO - 2025-08-14 21:29:15 --> Security Class Initialized
DEBUG - 2025-08-14 21:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:29:15 --> CSRF cookie sent
INFO - 2025-08-14 21:29:15 --> Input Class Initialized
INFO - 2025-08-14 21:29:15 --> Language Class Initialized
INFO - 2025-08-14 21:29:15 --> Loader Class Initialized
INFO - 2025-08-14 21:29:15 --> Helper loaded: url_helper
INFO - 2025-08-14 21:29:15 --> Helper loaded: form_helper
INFO - 2025-08-14 21:29:15 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:29:15 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:29:15 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:29:15 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:29:15 --> Database Driver Class Initialized
INFO - 2025-08-14 21:29:15 --> Form Validation Class Initialized
INFO - 2025-08-14 21:29:15 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:29:15 --> Controller Class Initialized
INFO - 2025-08-14 13:29:15 --> File loaded: C:\xampp\htdocs\application\views\login.php
INFO - 2025-08-14 13:29:15 --> Final output sent to browser
DEBUG - 2025-08-14 13:29:15 --> Total execution time: 0.0532
INFO - 2025-08-14 21:29:29 --> Config Class Initialized
INFO - 2025-08-14 21:29:29 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:29:29 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:29:29 --> Utf8 Class Initialized
INFO - 2025-08-14 21:29:29 --> URI Class Initialized
INFO - 2025-08-14 21:29:29 --> Router Class Initialized
INFO - 2025-08-14 21:29:29 --> Output Class Initialized
INFO - 2025-08-14 21:29:29 --> Security Class Initialized
DEBUG - 2025-08-14 21:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:29:29 --> CSRF cookie sent
INFO - 2025-08-14 21:29:29 --> CSRF token verified
INFO - 2025-08-14 21:29:29 --> Input Class Initialized
INFO - 2025-08-14 21:29:29 --> Language Class Initialized
INFO - 2025-08-14 21:29:29 --> Loader Class Initialized
INFO - 2025-08-14 21:29:29 --> Helper loaded: url_helper
INFO - 2025-08-14 21:29:29 --> Helper loaded: form_helper
INFO - 2025-08-14 21:29:29 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:29:29 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:29:29 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:29:29 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:29:29 --> Database Driver Class Initialized
INFO - 2025-08-14 21:29:29 --> Form Validation Class Initialized
INFO - 2025-08-14 21:29:29 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:29:29 --> Controller Class Initialized
INFO - 2025-08-14 13:29:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:29:29 --> Model "Login_model" initialized
INFO - 2025-08-14 21:29:29 --> Config Class Initialized
INFO - 2025-08-14 21:29:29 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:29:29 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:29:29 --> Utf8 Class Initialized
INFO - 2025-08-14 21:29:29 --> URI Class Initialized
INFO - 2025-08-14 21:29:29 --> Router Class Initialized
INFO - 2025-08-14 21:29:29 --> Output Class Initialized
INFO - 2025-08-14 21:29:29 --> Security Class Initialized
DEBUG - 2025-08-14 21:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:29:29 --> CSRF cookie sent
INFO - 2025-08-14 21:29:29 --> Input Class Initialized
INFO - 2025-08-14 21:29:29 --> Language Class Initialized
INFO - 2025-08-14 21:29:29 --> Loader Class Initialized
INFO - 2025-08-14 21:29:29 --> Helper loaded: url_helper
INFO - 2025-08-14 21:29:29 --> Helper loaded: form_helper
INFO - 2025-08-14 21:29:29 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:29:29 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:29:29 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:29:29 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:29:29 --> Database Driver Class Initialized
INFO - 2025-08-14 21:29:29 --> Form Validation Class Initialized
INFO - 2025-08-14 21:29:29 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:29:29 --> Controller Class Initialized
INFO - 2025-08-14 13:29:29 --> Model "Language_model" initialized
INFO - 2025-08-14 13:29:29 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:29:29 --> Model "Dashboard_model" initialized
INFO - 2025-08-14 13:29:29 --> File loaded: C:\xampp\htdocs\application\views\footer.php
INFO - 2025-08-14 13:29:29 --> File loaded: C:\xampp\htdocs\application\views\dashboard.php
INFO - 2025-08-14 13:29:29 --> Final output sent to browser
DEBUG - 2025-08-14 13:29:29 --> Total execution time: 0.1331
INFO - 2025-08-14 21:31:47 --> Config Class Initialized
INFO - 2025-08-14 21:31:47 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:31:47 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:31:47 --> Utf8 Class Initialized
INFO - 2025-08-14 21:31:47 --> URI Class Initialized
INFO - 2025-08-14 21:31:47 --> Router Class Initialized
INFO - 2025-08-14 21:31:47 --> Output Class Initialized
INFO - 2025-08-14 21:31:47 --> Security Class Initialized
DEBUG - 2025-08-14 21:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:31:47 --> CSRF cookie sent
INFO - 2025-08-14 21:31:47 --> Input Class Initialized
INFO - 2025-08-14 21:31:47 --> Language Class Initialized
INFO - 2025-08-14 21:31:47 --> Loader Class Initialized
INFO - 2025-08-14 21:31:47 --> Helper loaded: url_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: form_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:31:47 --> Database Driver Class Initialized
INFO - 2025-08-14 21:31:47 --> Form Validation Class Initialized
INFO - 2025-08-14 21:31:47 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:31:47 --> Controller Class Initialized
INFO - 2025-08-14 13:31:47 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:31:47 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:31:47 --> Helper loaded: sms_template_helper
ERROR - 2025-08-14 13:31:47 --> Could not find the language line "previous_due"
ERROR - 2025-08-14 13:31:47 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:31:47 --> File loaded: C:\xampp\htdocs\application\views\pos.php
INFO - 2025-08-14 13:31:47 --> Final output sent to browser
DEBUG - 2025-08-14 13:31:47 --> Total execution time: 0.1017
INFO - 2025-08-14 21:31:47 --> Config Class Initialized
INFO - 2025-08-14 21:31:47 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:31:47 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:31:47 --> Utf8 Class Initialized
INFO - 2025-08-14 21:31:47 --> URI Class Initialized
INFO - 2025-08-14 21:31:47 --> Router Class Initialized
INFO - 2025-08-14 21:31:47 --> Output Class Initialized
INFO - 2025-08-14 21:31:47 --> Security Class Initialized
DEBUG - 2025-08-14 21:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:31:47 --> CSRF cookie sent
INFO - 2025-08-14 21:31:47 --> Input Class Initialized
INFO - 2025-08-14 21:31:47 --> Language Class Initialized
ERROR - 2025-08-14 21:31:47 --> 404 Page Not Found: Theme/plugins
INFO - 2025-08-14 21:31:47 --> Config Class Initialized
INFO - 2025-08-14 21:31:47 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:31:47 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:31:47 --> Utf8 Class Initialized
INFO - 2025-08-14 21:31:47 --> URI Class Initialized
INFO - 2025-08-14 21:31:47 --> Router Class Initialized
INFO - 2025-08-14 21:31:47 --> Output Class Initialized
INFO - 2025-08-14 21:31:47 --> Security Class Initialized
DEBUG - 2025-08-14 21:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:31:47 --> CSRF cookie sent
INFO - 2025-08-14 21:31:47 --> CSRF token verified
INFO - 2025-08-14 21:31:47 --> Input Class Initialized
INFO - 2025-08-14 21:31:47 --> Language Class Initialized
INFO - 2025-08-14 21:31:47 --> Loader Class Initialized
INFO - 2025-08-14 21:31:47 --> Helper loaded: url_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: form_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:31:47 --> Database Driver Class Initialized
INFO - 2025-08-14 21:31:47 --> Form Validation Class Initialized
INFO - 2025-08-14 21:31:47 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:31:47 --> Controller Class Initialized
INFO - 2025-08-14 13:31:47 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:31:47 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:31:47 --> Final output sent to browser
DEBUG - 2025-08-14 13:31:47 --> Total execution time: 0.0387
INFO - 2025-08-14 21:31:47 --> Config Class Initialized
INFO - 2025-08-14 21:31:47 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:31:47 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:31:47 --> Utf8 Class Initialized
INFO - 2025-08-14 21:31:47 --> URI Class Initialized
INFO - 2025-08-14 21:31:47 --> Router Class Initialized
INFO - 2025-08-14 21:31:47 --> Output Class Initialized
INFO - 2025-08-14 21:31:47 --> Security Class Initialized
DEBUG - 2025-08-14 21:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:31:47 --> CSRF cookie sent
INFO - 2025-08-14 21:31:47 --> CSRF token verified
INFO - 2025-08-14 21:31:47 --> Input Class Initialized
INFO - 2025-08-14 21:31:47 --> Language Class Initialized
INFO - 2025-08-14 21:31:47 --> Loader Class Initialized
INFO - 2025-08-14 21:31:47 --> Helper loaded: url_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: form_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:31:47 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:31:47 --> Database Driver Class Initialized
INFO - 2025-08-14 21:31:47 --> Form Validation Class Initialized
INFO - 2025-08-14 21:31:47 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:31:47 --> Controller Class Initialized
INFO - 2025-08-14 13:31:47 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:31:47 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:31:47 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:31:47 --> Final output sent to browser
DEBUG - 2025-08-14 13:31:47 --> Total execution time: 0.0484
INFO - 2025-08-14 21:31:47 --> Config Class Initialized
INFO - 2025-08-14 21:31:47 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:31:47 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:31:47 --> Utf8 Class Initialized
INFO - 2025-08-14 21:31:47 --> URI Class Initialized
INFO - 2025-08-14 21:31:47 --> Router Class Initialized
INFO - 2025-08-14 21:31:47 --> Output Class Initialized
INFO - 2025-08-14 21:31:47 --> Security Class Initialized
DEBUG - 2025-08-14 21:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:31:47 --> CSRF cookie sent
INFO - 2025-08-14 21:31:47 --> Input Class Initialized
INFO - 2025-08-14 21:31:47 --> Language Class Initialized
ERROR - 2025-08-14 21:31:47 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:32:10 --> Config Class Initialized
INFO - 2025-08-14 21:32:10 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:32:10 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:32:10 --> Utf8 Class Initialized
INFO - 2025-08-14 21:32:10 --> URI Class Initialized
INFO - 2025-08-14 21:32:10 --> Router Class Initialized
INFO - 2025-08-14 21:32:10 --> Output Class Initialized
INFO - 2025-08-14 21:32:10 --> Security Class Initialized
DEBUG - 2025-08-14 21:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:32:10 --> CSRF cookie sent
INFO - 2025-08-14 21:32:10 --> CSRF token verified
INFO - 2025-08-14 21:32:10 --> Input Class Initialized
INFO - 2025-08-14 21:32:10 --> Language Class Initialized
INFO - 2025-08-14 21:32:10 --> Loader Class Initialized
INFO - 2025-08-14 21:32:10 --> Helper loaded: url_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: form_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:32:10 --> Database Driver Class Initialized
INFO - 2025-08-14 21:32:10 --> Form Validation Class Initialized
INFO - 2025-08-14 21:32:10 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:32:10 --> Controller Class Initialized
INFO - 2025-08-14 13:32:10 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:32:10 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:32:10 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:32:10 --> Model "Sales_model" initialized
INFO - 2025-08-14 21:32:10 --> Config Class Initialized
INFO - 2025-08-14 21:32:10 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:32:10 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:32:10 --> Utf8 Class Initialized
INFO - 2025-08-14 21:32:10 --> URI Class Initialized
INFO - 2025-08-14 21:32:10 --> Router Class Initialized
INFO - 2025-08-14 21:32:10 --> Output Class Initialized
INFO - 2025-08-14 21:32:10 --> Security Class Initialized
DEBUG - 2025-08-14 21:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:32:10 --> CSRF cookie sent
INFO - 2025-08-14 21:32:10 --> CSRF token verified
INFO - 2025-08-14 21:32:10 --> Input Class Initialized
INFO - 2025-08-14 21:32:10 --> Language Class Initialized
INFO - 2025-08-14 21:32:10 --> Config Class Initialized
INFO - 2025-08-14 21:32:10 --> Hooks Class Initialized
INFO - 2025-08-14 21:32:10 --> Loader Class Initialized
INFO - 2025-08-14 21:32:10 --> Helper loaded: url_helper
DEBUG - 2025-08-14 21:32:10 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:32:10 --> Utf8 Class Initialized
INFO - 2025-08-14 21:32:10 --> Helper loaded: form_helper
INFO - 2025-08-14 21:32:10 --> URI Class Initialized
INFO - 2025-08-14 21:32:10 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:32:10 --> Router Class Initialized
INFO - 2025-08-14 21:32:10 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:32:10 --> Output Class Initialized
INFO - 2025-08-14 21:32:10 --> Security Class Initialized
DEBUG - 2025-08-14 21:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:32:10 --> CSRF cookie sent
INFO - 2025-08-14 21:32:10 --> Input Class Initialized
INFO - 2025-08-14 21:32:10 --> Language Class Initialized
INFO - 2025-08-14 21:32:10 --> Database Driver Class Initialized
INFO - 2025-08-14 21:32:10 --> Loader Class Initialized
INFO - 2025-08-14 21:32:10 --> Form Validation Class Initialized
INFO - 2025-08-14 21:32:10 --> Helper loaded: url_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: form_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:32:10 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:32:10 --> Controller Class Initialized
INFO - 2025-08-14 21:32:10 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 13:32:10 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:32:10 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:32:10 --> Final output sent to browser
DEBUG - 2025-08-14 13:32:10 --> Total execution time: 0.0431
INFO - 2025-08-14 21:32:10 --> Database Driver Class Initialized
INFO - 2025-08-14 21:32:10 --> Config Class Initialized
INFO - 2025-08-14 21:32:10 --> Hooks Class Initialized
INFO - 2025-08-14 21:32:10 --> Form Validation Class Initialized
DEBUG - 2025-08-14 21:32:10 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:32:10 --> Utf8 Class Initialized
INFO - 2025-08-14 21:32:10 --> URI Class Initialized
INFO - 2025-08-14 21:32:10 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:32:10 --> Controller Class Initialized
INFO - 2025-08-14 21:32:10 --> Router Class Initialized
INFO - 2025-08-14 13:32:10 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 21:32:10 --> Output Class Initialized
INFO - 2025-08-14 13:32:10 --> Model "Pos_model" initialized
INFO - 2025-08-14 21:32:10 --> Security Class Initialized
INFO - 2025-08-14 13:32:10 --> Helper loaded: sms_template_helper
DEBUG - 2025-08-14 21:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:32:10 --> CSRF cookie sent
INFO - 2025-08-14 21:32:10 --> CSRF token verified
INFO - 2025-08-14 21:32:10 --> Input Class Initialized
INFO - 2025-08-14 21:32:10 --> Language Class Initialized
ERROR - 2025-08-14 13:32:10 --> Could not find the language line "company_address"
ERROR - 2025-08-14 13:32:10 --> Could not find the language line "previous_due"
INFO - 2025-08-14 13:32:10 --> Model "Qrcode_model" initialized
INFO - 2025-08-14 21:32:10 --> Loader Class Initialized
INFO - 2025-08-14 21:32:10 --> Helper loaded: url_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: form_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:32:10 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:32:10 --> Database Driver Class Initialized
INFO - 2025-08-14 21:32:10 --> Form Validation Class Initialized
INFO - 2025-08-14 13:32:10 --> File loaded: C:\xampp\htdocs\application\views\sal-invoice-pos.php
INFO - 2025-08-14 13:32:10 --> Final output sent to browser
DEBUG - 2025-08-14 13:32:10 --> Total execution time: 0.1228
INFO - 2025-08-14 21:32:10 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:32:10 --> Controller Class Initialized
INFO - 2025-08-14 13:32:10 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:32:10 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:32:10 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:32:10 --> Final output sent to browser
DEBUG - 2025-08-14 13:32:10 --> Total execution time: 0.0986
INFO - 2025-08-14 21:32:11 --> Config Class Initialized
INFO - 2025-08-14 21:32:11 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:32:11 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:32:11 --> Utf8 Class Initialized
INFO - 2025-08-14 21:32:11 --> URI Class Initialized
INFO - 2025-08-14 21:32:11 --> Router Class Initialized
INFO - 2025-08-14 21:32:11 --> Output Class Initialized
INFO - 2025-08-14 21:32:11 --> Security Class Initialized
DEBUG - 2025-08-14 21:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:32:11 --> CSRF cookie sent
INFO - 2025-08-14 21:32:11 --> Input Class Initialized
INFO - 2025-08-14 21:32:11 --> Language Class Initialized
ERROR - 2025-08-14 21:32:11 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:34:59 --> Config Class Initialized
INFO - 2025-08-14 21:34:59 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:34:59 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:34:59 --> Utf8 Class Initialized
INFO - 2025-08-14 21:34:59 --> URI Class Initialized
INFO - 2025-08-14 21:34:59 --> Router Class Initialized
INFO - 2025-08-14 21:34:59 --> Output Class Initialized
INFO - 2025-08-14 21:34:59 --> Security Class Initialized
DEBUG - 2025-08-14 21:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:34:59 --> CSRF cookie sent
INFO - 2025-08-14 21:34:59 --> Input Class Initialized
INFO - 2025-08-14 21:34:59 --> Language Class Initialized
INFO - 2025-08-14 21:34:59 --> Loader Class Initialized
INFO - 2025-08-14 21:34:59 --> Helper loaded: url_helper
INFO - 2025-08-14 21:34:59 --> Helper loaded: form_helper
INFO - 2025-08-14 21:34:59 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:34:59 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:34:59 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:34:59 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:34:59 --> Database Driver Class Initialized
INFO - 2025-08-14 21:34:59 --> Form Validation Class Initialized
INFO - 2025-08-14 21:34:59 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:34:59 --> Controller Class Initialized
INFO - 2025-08-14 13:34:59 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:34:59 --> Model "Sales_model" initialized
INFO - 2025-08-14 13:34:59 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:34:59 --> File loaded: C:\xampp\htdocs\application\views\sales-list.php
INFO - 2025-08-14 13:34:59 --> Final output sent to browser
DEBUG - 2025-08-14 13:34:59 --> Total execution time: 0.0753
INFO - 2025-08-14 21:34:59 --> Config Class Initialized
INFO - 2025-08-14 21:34:59 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:34:59 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:34:59 --> Utf8 Class Initialized
INFO - 2025-08-14 21:34:59 --> URI Class Initialized
INFO - 2025-08-14 21:34:59 --> Router Class Initialized
INFO - 2025-08-14 21:34:59 --> Output Class Initialized
INFO - 2025-08-14 21:34:59 --> Security Class Initialized
DEBUG - 2025-08-14 21:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:34:59 --> CSRF cookie sent
INFO - 2025-08-14 21:34:59 --> CSRF token verified
INFO - 2025-08-14 21:34:59 --> Input Class Initialized
INFO - 2025-08-14 21:34:59 --> Language Class Initialized
INFO - 2025-08-14 21:34:59 --> Loader Class Initialized
INFO - 2025-08-14 21:34:59 --> Helper loaded: url_helper
INFO - 2025-08-14 21:34:59 --> Helper loaded: form_helper
INFO - 2025-08-14 21:34:59 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:34:59 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:34:59 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:34:59 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:34:59 --> Database Driver Class Initialized
INFO - 2025-08-14 21:34:59 --> Form Validation Class Initialized
INFO - 2025-08-14 21:34:59 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:34:59 --> Controller Class Initialized
INFO - 2025-08-14 13:34:59 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:34:59 --> Model "Sales_model" initialized
INFO - 2025-08-14 13:34:59 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:34:59 --> Final output sent to browser
DEBUG - 2025-08-14 13:34:59 --> Total execution time: 0.0481
INFO - 2025-08-14 21:35:03 --> Config Class Initialized
INFO - 2025-08-14 21:35:03 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:35:03 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:35:03 --> Utf8 Class Initialized
INFO - 2025-08-14 21:35:03 --> URI Class Initialized
INFO - 2025-08-14 21:35:03 --> Router Class Initialized
INFO - 2025-08-14 21:35:03 --> Output Class Initialized
INFO - 2025-08-14 21:35:03 --> Security Class Initialized
DEBUG - 2025-08-14 21:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:35:03 --> CSRF cookie sent
INFO - 2025-08-14 21:35:03 --> Input Class Initialized
INFO - 2025-08-14 21:35:03 --> Language Class Initialized
INFO - 2025-08-14 21:35:03 --> Loader Class Initialized
INFO - 2025-08-14 21:35:03 --> Helper loaded: url_helper
INFO - 2025-08-14 21:35:03 --> Helper loaded: form_helper
INFO - 2025-08-14 21:35:03 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:35:03 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:35:03 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:35:03 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:35:03 --> Database Driver Class Initialized
INFO - 2025-08-14 21:35:03 --> Form Validation Class Initialized
INFO - 2025-08-14 21:35:03 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:35:03 --> Controller Class Initialized
INFO - 2025-08-14 13:35:03 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:35:03 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:35:03 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:35:03 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:35:03 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:35:03 --> Final output sent to browser
DEBUG - 2025-08-14 13:35:03 --> Total execution time: 0.0674
INFO - 2025-08-14 21:35:25 --> Config Class Initialized
INFO - 2025-08-14 21:35:25 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:35:25 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:35:25 --> Utf8 Class Initialized
INFO - 2025-08-14 21:35:25 --> URI Class Initialized
DEBUG - 2025-08-14 21:35:25 --> No URI present. Default controller set.
INFO - 2025-08-14 21:35:25 --> Router Class Initialized
INFO - 2025-08-14 21:35:25 --> Output Class Initialized
INFO - 2025-08-14 21:35:25 --> Security Class Initialized
DEBUG - 2025-08-14 21:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:35:25 --> CSRF cookie sent
INFO - 2025-08-14 21:35:25 --> CSRF token verified
INFO - 2025-08-14 21:35:25 --> Input Class Initialized
INFO - 2025-08-14 21:35:25 --> Language Class Initialized
INFO - 2025-08-14 21:35:25 --> Loader Class Initialized
INFO - 2025-08-14 21:35:25 --> Helper loaded: url_helper
INFO - 2025-08-14 21:35:25 --> Helper loaded: form_helper
INFO - 2025-08-14 21:35:25 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:35:25 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:35:25 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:35:25 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:35:25 --> Database Driver Class Initialized
INFO - 2025-08-14 21:35:25 --> Form Validation Class Initialized
INFO - 2025-08-14 21:35:25 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:35:25 --> Controller Class Initialized
INFO - 2025-08-14 13:35:25 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 21:35:25 --> Config Class Initialized
INFO - 2025-08-14 21:35:25 --> Hooks Class Initialized
INFO - 2025-08-14 21:35:25 --> Config Class Initialized
INFO - 2025-08-14 21:35:25 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:35:25 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:35:25 --> Utf8 Class Initialized
INFO - 2025-08-14 21:35:25 --> URI Class Initialized
DEBUG - 2025-08-14 21:35:25 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:35:25 --> Utf8 Class Initialized
INFO - 2025-08-14 21:35:25 --> Router Class Initialized
INFO - 2025-08-14 21:35:25 --> URI Class Initialized
INFO - 2025-08-14 21:35:25 --> Router Class Initialized
INFO - 2025-08-14 21:35:25 --> Output Class Initialized
INFO - 2025-08-14 21:35:25 --> Security Class Initialized
INFO - 2025-08-14 21:35:25 --> Output Class Initialized
DEBUG - 2025-08-14 21:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:35:25 --> Security Class Initialized
INFO - 2025-08-14 21:35:25 --> CSRF cookie sent
INFO - 2025-08-14 21:35:25 --> Input Class Initialized
INFO - 2025-08-14 21:35:25 --> Language Class Initialized
DEBUG - 2025-08-14 21:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:35:25 --> CSRF cookie sent
INFO - 2025-08-14 21:35:25 --> Input Class Initialized
INFO - 2025-08-14 21:35:25 --> Language Class Initialized
INFO - 2025-08-14 21:35:25 --> Loader Class Initialized
ERROR - 2025-08-14 21:35:25 --> 404 Page Not Found: Faviconico/index
INFO - 2025-08-14 21:35:25 --> Helper loaded: url_helper
INFO - 2025-08-14 21:35:25 --> Helper loaded: form_helper
INFO - 2025-08-14 21:35:25 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:35:25 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:35:25 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:35:25 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:35:25 --> Database Driver Class Initialized
INFO - 2025-08-14 21:35:25 --> Form Validation Class Initialized
INFO - 2025-08-14 21:35:25 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:35:25 --> Controller Class Initialized
INFO - 2025-08-14 13:35:25 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:35:25 --> Model "Dashboard_model" initialized
INFO - 2025-08-14 13:35:25 --> File loaded: C:\xampp\htdocs\application\views\footer.php
INFO - 2025-08-14 13:35:25 --> File loaded: C:\xampp\htdocs\application\views\dashboard.php
INFO - 2025-08-14 13:35:25 --> Final output sent to browser
DEBUG - 2025-08-14 13:35:25 --> Total execution time: 0.0624
INFO - 2025-08-14 21:35:31 --> Config Class Initialized
INFO - 2025-08-14 21:35:31 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:35:31 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:35:31 --> Utf8 Class Initialized
INFO - 2025-08-14 21:35:31 --> URI Class Initialized
INFO - 2025-08-14 21:35:31 --> Router Class Initialized
INFO - 2025-08-14 21:35:31 --> Output Class Initialized
INFO - 2025-08-14 21:35:31 --> Security Class Initialized
DEBUG - 2025-08-14 21:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:35:31 --> CSRF cookie sent
INFO - 2025-08-14 21:35:31 --> Input Class Initialized
INFO - 2025-08-14 21:35:31 --> Language Class Initialized
INFO - 2025-08-14 21:35:31 --> Loader Class Initialized
INFO - 2025-08-14 21:35:31 --> Helper loaded: url_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: form_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:35:31 --> Database Driver Class Initialized
INFO - 2025-08-14 21:35:31 --> Form Validation Class Initialized
INFO - 2025-08-14 21:35:31 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:35:31 --> Controller Class Initialized
INFO - 2025-08-14 13:35:31 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:35:31 --> Model "Items_model" initialized
INFO - 2025-08-14 13:35:31 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:35:31 --> Final output sent to browser
DEBUG - 2025-08-14 13:35:31 --> Total execution time: 0.0639
INFO - 2025-08-14 21:35:31 --> Config Class Initialized
INFO - 2025-08-14 21:35:31 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:35:31 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:35:31 --> Utf8 Class Initialized
INFO - 2025-08-14 21:35:31 --> URI Class Initialized
INFO - 2025-08-14 21:35:31 --> Router Class Initialized
INFO - 2025-08-14 21:35:31 --> Output Class Initialized
INFO - 2025-08-14 21:35:31 --> Security Class Initialized
DEBUG - 2025-08-14 21:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:35:31 --> CSRF cookie sent
INFO - 2025-08-14 21:35:31 --> CSRF token verified
INFO - 2025-08-14 21:35:31 --> Input Class Initialized
INFO - 2025-08-14 21:35:31 --> Language Class Initialized
INFO - 2025-08-14 21:35:31 --> Loader Class Initialized
INFO - 2025-08-14 21:35:31 --> Helper loaded: url_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: form_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:35:31 --> Database Driver Class Initialized
INFO - 2025-08-14 21:35:31 --> Form Validation Class Initialized
INFO - 2025-08-14 21:35:31 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:35:31 --> Controller Class Initialized
INFO - 2025-08-14 13:35:31 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:35:31 --> Model "Items_model" initialized
INFO - 2025-08-14 13:35:31 --> Final output sent to browser
DEBUG - 2025-08-14 13:35:31 --> Total execution time: 0.0450
INFO - 2025-08-14 21:35:31 --> Config Class Initialized
INFO - 2025-08-14 21:35:31 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:35:31 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:35:31 --> Utf8 Class Initialized
INFO - 2025-08-14 21:35:31 --> URI Class Initialized
INFO - 2025-08-14 21:35:31 --> Router Class Initialized
INFO - 2025-08-14 21:35:31 --> Output Class Initialized
INFO - 2025-08-14 21:35:31 --> Security Class Initialized
DEBUG - 2025-08-14 21:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:35:31 --> CSRF cookie sent
INFO - 2025-08-14 21:35:31 --> Input Class Initialized
INFO - 2025-08-14 21:35:31 --> Language Class Initialized
ERROR - 2025-08-14 21:35:31 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:35:31 --> Config Class Initialized
INFO - 2025-08-14 21:35:31 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:35:31 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:35:31 --> Utf8 Class Initialized
INFO - 2025-08-14 21:35:31 --> URI Class Initialized
INFO - 2025-08-14 21:35:31 --> Router Class Initialized
INFO - 2025-08-14 21:35:31 --> Output Class Initialized
INFO - 2025-08-14 21:35:31 --> Security Class Initialized
DEBUG - 2025-08-14 21:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:35:31 --> CSRF cookie sent
INFO - 2025-08-14 21:35:31 --> Input Class Initialized
INFO - 2025-08-14 21:35:31 --> Language Class Initialized
INFO - 2025-08-14 21:35:31 --> Loader Class Initialized
INFO - 2025-08-14 21:35:31 --> Helper loaded: url_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: form_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:35:31 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:35:31 --> Database Driver Class Initialized
INFO - 2025-08-14 21:35:31 --> Form Validation Class Initialized
INFO - 2025-08-14 21:35:31 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:35:31 --> Controller Class Initialized
INFO - 2025-08-14 13:35:31 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:35:31 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:35:31 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:35:31 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:35:31 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:35:31 --> Final output sent to browser
DEBUG - 2025-08-14 13:35:31 --> Total execution time: 0.0552
INFO - 2025-08-14 21:35:42 --> Config Class Initialized
INFO - 2025-08-14 21:35:42 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:35:42 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:35:42 --> Utf8 Class Initialized
INFO - 2025-08-14 21:35:42 --> URI Class Initialized
INFO - 2025-08-14 21:35:42 --> Router Class Initialized
INFO - 2025-08-14 21:35:42 --> Output Class Initialized
INFO - 2025-08-14 21:35:42 --> Security Class Initialized
DEBUG - 2025-08-14 21:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:35:42 --> CSRF cookie sent
INFO - 2025-08-14 21:35:42 --> CSRF token verified
INFO - 2025-08-14 21:35:42 --> Input Class Initialized
INFO - 2025-08-14 21:35:42 --> Language Class Initialized
INFO - 2025-08-14 21:35:42 --> Loader Class Initialized
INFO - 2025-08-14 21:35:42 --> Helper loaded: url_helper
INFO - 2025-08-14 21:35:42 --> Helper loaded: form_helper
INFO - 2025-08-14 21:35:42 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:35:42 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:35:42 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:35:42 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:35:42 --> Database Driver Class Initialized
INFO - 2025-08-14 21:35:42 --> Form Validation Class Initialized
INFO - 2025-08-14 21:35:42 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:35:42 --> Controller Class Initialized
INFO - 2025-08-14 13:35:42 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:35:42 --> Model "Brand_model" initialized
INFO - 2025-08-14 13:35:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:35:42 --> Final output sent to browser
DEBUG - 2025-08-14 13:35:42 --> Total execution time: 0.0519
INFO - 2025-08-14 21:37:28 --> Config Class Initialized
INFO - 2025-08-14 21:37:28 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:37:28 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:37:28 --> Utf8 Class Initialized
INFO - 2025-08-14 21:37:28 --> URI Class Initialized
DEBUG - 2025-08-14 21:37:28 --> No URI present. Default controller set.
INFO - 2025-08-14 21:37:28 --> Router Class Initialized
INFO - 2025-08-14 21:37:28 --> Output Class Initialized
INFO - 2025-08-14 21:37:28 --> Security Class Initialized
DEBUG - 2025-08-14 21:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:37:28 --> CSRF cookie sent
INFO - 2025-08-14 21:37:28 --> CSRF token verified
INFO - 2025-08-14 21:37:28 --> Input Class Initialized
INFO - 2025-08-14 21:37:28 --> Language Class Initialized
INFO - 2025-08-14 21:37:28 --> Loader Class Initialized
INFO - 2025-08-14 21:37:28 --> Helper loaded: url_helper
INFO - 2025-08-14 21:37:28 --> Helper loaded: form_helper
INFO - 2025-08-14 21:37:28 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:37:28 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:37:28 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:37:28 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:37:28 --> Database Driver Class Initialized
INFO - 2025-08-14 21:37:28 --> Form Validation Class Initialized
INFO - 2025-08-14 21:37:28 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:37:28 --> Controller Class Initialized
INFO - 2025-08-14 13:37:28 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 21:37:28 --> Config Class Initialized
INFO - 2025-08-14 21:37:28 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:37:28 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:37:28 --> Utf8 Class Initialized
INFO - 2025-08-14 21:37:28 --> URI Class Initialized
INFO - 2025-08-14 21:37:28 --> Router Class Initialized
INFO - 2025-08-14 21:37:28 --> Output Class Initialized
INFO - 2025-08-14 21:37:28 --> Security Class Initialized
DEBUG - 2025-08-14 21:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:37:28 --> CSRF cookie sent
INFO - 2025-08-14 21:37:28 --> Input Class Initialized
INFO - 2025-08-14 21:37:28 --> Language Class Initialized
INFO - 2025-08-14 21:37:28 --> Loader Class Initialized
INFO - 2025-08-14 21:37:28 --> Helper loaded: url_helper
INFO - 2025-08-14 21:37:28 --> Helper loaded: form_helper
INFO - 2025-08-14 21:37:28 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:37:28 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:37:28 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:37:28 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:37:28 --> Database Driver Class Initialized
INFO - 2025-08-14 21:37:28 --> Form Validation Class Initialized
INFO - 2025-08-14 21:37:28 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:37:28 --> Controller Class Initialized
INFO - 2025-08-14 13:37:28 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:37:28 --> Model "Dashboard_model" initialized
INFO - 2025-08-14 13:37:28 --> File loaded: C:\xampp\htdocs\application\views\footer.php
INFO - 2025-08-14 13:37:28 --> File loaded: C:\xampp\htdocs\application\views\dashboard.php
INFO - 2025-08-14 13:37:28 --> Final output sent to browser
DEBUG - 2025-08-14 13:37:28 --> Total execution time: 0.0663
INFO - 2025-08-14 21:37:34 --> Config Class Initialized
INFO - 2025-08-14 21:37:34 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:37:34 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:37:34 --> Utf8 Class Initialized
INFO - 2025-08-14 21:37:34 --> URI Class Initialized
INFO - 2025-08-14 21:37:34 --> Router Class Initialized
INFO - 2025-08-14 21:37:34 --> Output Class Initialized
INFO - 2025-08-14 21:37:34 --> Security Class Initialized
DEBUG - 2025-08-14 21:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:37:34 --> CSRF cookie sent
INFO - 2025-08-14 21:37:34 --> Input Class Initialized
INFO - 2025-08-14 21:37:34 --> Language Class Initialized
INFO - 2025-08-14 21:37:34 --> Loader Class Initialized
INFO - 2025-08-14 21:37:34 --> Helper loaded: url_helper
INFO - 2025-08-14 21:37:34 --> Helper loaded: form_helper
INFO - 2025-08-14 21:37:34 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:37:34 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:37:34 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:37:34 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:37:34 --> Database Driver Class Initialized
INFO - 2025-08-14 21:37:34 --> Form Validation Class Initialized
INFO - 2025-08-14 21:37:34 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:37:34 --> Controller Class Initialized
INFO - 2025-08-14 13:37:34 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:37:34 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:37:34 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:37:34 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:37:34 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:37:34 --> Final output sent to browser
DEBUG - 2025-08-14 13:37:34 --> Total execution time: 0.0532
INFO - 2025-08-14 21:37:37 --> Config Class Initialized
INFO - 2025-08-14 21:37:37 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:37:37 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:37:37 --> Utf8 Class Initialized
INFO - 2025-08-14 21:37:37 --> URI Class Initialized
INFO - 2025-08-14 21:37:37 --> Router Class Initialized
INFO - 2025-08-14 21:37:37 --> Output Class Initialized
INFO - 2025-08-14 21:37:37 --> Security Class Initialized
DEBUG - 2025-08-14 21:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:37:37 --> CSRF cookie sent
INFO - 2025-08-14 21:37:37 --> Input Class Initialized
INFO - 2025-08-14 21:37:37 --> Language Class Initialized
INFO - 2025-08-14 21:37:37 --> Loader Class Initialized
INFO - 2025-08-14 21:37:37 --> Helper loaded: url_helper
INFO - 2025-08-14 21:37:37 --> Helper loaded: form_helper
INFO - 2025-08-14 21:37:37 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:37:37 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:37:37 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:37:37 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:37:37 --> Database Driver Class Initialized
INFO - 2025-08-14 21:37:37 --> Form Validation Class Initialized
INFO - 2025-08-14 21:37:37 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:37:37 --> Controller Class Initialized
INFO - 2025-08-14 13:37:37 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:37:37 --> Model "Items_model" initialized
INFO - 2025-08-14 13:37:37 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:37:37 --> Final output sent to browser
DEBUG - 2025-08-14 13:37:37 --> Total execution time: 0.0675
INFO - 2025-08-14 21:37:38 --> Config Class Initialized
INFO - 2025-08-14 21:37:38 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:37:38 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:37:38 --> Utf8 Class Initialized
INFO - 2025-08-14 21:37:38 --> URI Class Initialized
INFO - 2025-08-14 21:37:38 --> Router Class Initialized
INFO - 2025-08-14 21:37:38 --> Output Class Initialized
INFO - 2025-08-14 21:37:38 --> Security Class Initialized
DEBUG - 2025-08-14 21:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:37:38 --> CSRF cookie sent
INFO - 2025-08-14 21:37:38 --> CSRF token verified
INFO - 2025-08-14 21:37:38 --> Input Class Initialized
INFO - 2025-08-14 21:37:38 --> Language Class Initialized
INFO - 2025-08-14 21:37:38 --> Loader Class Initialized
INFO - 2025-08-14 21:37:38 --> Helper loaded: url_helper
INFO - 2025-08-14 21:37:38 --> Helper loaded: form_helper
INFO - 2025-08-14 21:37:38 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:37:38 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:37:38 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:37:38 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:37:38 --> Database Driver Class Initialized
INFO - 2025-08-14 21:37:38 --> Form Validation Class Initialized
INFO - 2025-08-14 21:37:38 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:37:38 --> Controller Class Initialized
INFO - 2025-08-14 13:37:38 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:37:38 --> Model "Items_model" initialized
INFO - 2025-08-14 13:37:38 --> Final output sent to browser
DEBUG - 2025-08-14 13:37:38 --> Total execution time: 0.0553
INFO - 2025-08-14 21:37:38 --> Config Class Initialized
INFO - 2025-08-14 21:37:38 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:37:38 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:37:38 --> Utf8 Class Initialized
INFO - 2025-08-14 21:37:38 --> URI Class Initialized
INFO - 2025-08-14 21:37:38 --> Router Class Initialized
INFO - 2025-08-14 21:37:38 --> Output Class Initialized
INFO - 2025-08-14 21:37:38 --> Security Class Initialized
DEBUG - 2025-08-14 21:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:37:38 --> CSRF cookie sent
INFO - 2025-08-14 21:37:38 --> Input Class Initialized
INFO - 2025-08-14 21:37:38 --> Language Class Initialized
ERROR - 2025-08-14 21:37:38 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:37:40 --> Config Class Initialized
INFO - 2025-08-14 21:37:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:37:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:37:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:37:40 --> URI Class Initialized
INFO - 2025-08-14 21:37:40 --> Router Class Initialized
INFO - 2025-08-14 21:37:40 --> Output Class Initialized
INFO - 2025-08-14 21:37:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:37:40 --> CSRF cookie sent
INFO - 2025-08-14 21:37:40 --> Input Class Initialized
INFO - 2025-08-14 21:37:40 --> Language Class Initialized
INFO - 2025-08-14 21:37:40 --> Loader Class Initialized
INFO - 2025-08-14 21:37:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:37:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:37:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:37:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:37:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:37:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:37:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:37:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:37:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:37:40 --> Controller Class Initialized
INFO - 2025-08-14 13:37:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:37:40 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:37:40 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:37:40 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:37:40 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:37:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:37:40 --> Total execution time: 0.0553
INFO - 2025-08-14 21:38:12 --> Config Class Initialized
INFO - 2025-08-14 21:38:12 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:38:12 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:38:12 --> Utf8 Class Initialized
INFO - 2025-08-14 21:38:12 --> URI Class Initialized
DEBUG - 2025-08-14 21:38:12 --> No URI present. Default controller set.
INFO - 2025-08-14 21:38:12 --> Router Class Initialized
INFO - 2025-08-14 21:38:12 --> Output Class Initialized
INFO - 2025-08-14 21:38:12 --> Security Class Initialized
DEBUG - 2025-08-14 21:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:38:12 --> CSRF cookie sent
INFO - 2025-08-14 21:38:12 --> CSRF token verified
INFO - 2025-08-14 21:38:12 --> Input Class Initialized
INFO - 2025-08-14 21:38:12 --> Language Class Initialized
INFO - 2025-08-14 21:38:12 --> Loader Class Initialized
INFO - 2025-08-14 21:38:12 --> Helper loaded: url_helper
INFO - 2025-08-14 21:38:12 --> Helper loaded: form_helper
INFO - 2025-08-14 21:38:12 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:38:12 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:38:12 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:38:12 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:38:12 --> Database Driver Class Initialized
INFO - 2025-08-14 21:38:12 --> Form Validation Class Initialized
INFO - 2025-08-14 21:38:12 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:38:12 --> Controller Class Initialized
INFO - 2025-08-14 13:38:12 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 21:38:12 --> Config Class Initialized
INFO - 2025-08-14 21:38:12 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:38:12 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:38:12 --> Utf8 Class Initialized
INFO - 2025-08-14 21:38:12 --> URI Class Initialized
INFO - 2025-08-14 21:38:12 --> Router Class Initialized
INFO - 2025-08-14 21:38:12 --> Output Class Initialized
INFO - 2025-08-14 21:38:12 --> Security Class Initialized
DEBUG - 2025-08-14 21:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:38:12 --> CSRF cookie sent
INFO - 2025-08-14 21:38:12 --> Input Class Initialized
INFO - 2025-08-14 21:38:12 --> Language Class Initialized
INFO - 2025-08-14 21:38:12 --> Loader Class Initialized
INFO - 2025-08-14 21:38:12 --> Helper loaded: url_helper
INFO - 2025-08-14 21:38:12 --> Helper loaded: form_helper
INFO - 2025-08-14 21:38:12 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:38:12 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:38:12 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:38:12 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:38:12 --> Database Driver Class Initialized
INFO - 2025-08-14 21:38:12 --> Form Validation Class Initialized
INFO - 2025-08-14 21:38:12 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:38:12 --> Controller Class Initialized
INFO - 2025-08-14 13:38:12 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:38:12 --> Model "Dashboard_model" initialized
INFO - 2025-08-14 13:38:12 --> File loaded: C:\xampp\htdocs\application\views\footer.php
INFO - 2025-08-14 13:38:12 --> File loaded: C:\xampp\htdocs\application\views\dashboard.php
INFO - 2025-08-14 13:38:12 --> Final output sent to browser
DEBUG - 2025-08-14 13:38:12 --> Total execution time: 0.0597
INFO - 2025-08-14 21:38:16 --> Config Class Initialized
INFO - 2025-08-14 21:38:16 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:38:16 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:38:16 --> Utf8 Class Initialized
INFO - 2025-08-14 21:38:16 --> URI Class Initialized
INFO - 2025-08-14 21:38:16 --> Router Class Initialized
INFO - 2025-08-14 21:38:16 --> Output Class Initialized
INFO - 2025-08-14 21:38:16 --> Security Class Initialized
DEBUG - 2025-08-14 21:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:38:16 --> CSRF cookie sent
INFO - 2025-08-14 21:38:16 --> Input Class Initialized
INFO - 2025-08-14 21:38:16 --> Language Class Initialized
INFO - 2025-08-14 21:38:16 --> Loader Class Initialized
INFO - 2025-08-14 21:38:16 --> Helper loaded: url_helper
INFO - 2025-08-14 21:38:16 --> Helper loaded: form_helper
INFO - 2025-08-14 21:38:16 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:38:16 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:38:16 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:38:16 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:38:16 --> Database Driver Class Initialized
INFO - 2025-08-14 21:38:16 --> Form Validation Class Initialized
INFO - 2025-08-14 21:38:16 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:38:16 --> Controller Class Initialized
INFO - 2025-08-14 13:38:16 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:38:16 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:38:16 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:38:16 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:38:16 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:38:16 --> Final output sent to browser
DEBUG - 2025-08-14 13:38:16 --> Total execution time: 0.0766
INFO - 2025-08-14 21:39:04 --> Config Class Initialized
INFO - 2025-08-14 21:39:04 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:04 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:04 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:04 --> URI Class Initialized
INFO - 2025-08-14 21:39:04 --> Router Class Initialized
INFO - 2025-08-14 21:39:04 --> Output Class Initialized
INFO - 2025-08-14 21:39:04 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:04 --> CSRF cookie sent
INFO - 2025-08-14 21:39:04 --> CSRF token verified
INFO - 2025-08-14 21:39:04 --> Input Class Initialized
INFO - 2025-08-14 21:39:04 --> Language Class Initialized
INFO - 2025-08-14 21:39:04 --> Loader Class Initialized
INFO - 2025-08-14 21:39:04 --> Helper loaded: url_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: form_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:39:04 --> Database Driver Class Initialized
INFO - 2025-08-14 21:39:04 --> Form Validation Class Initialized
INFO - 2025-08-14 21:39:04 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:39:04 --> Controller Class Initialized
INFO - 2025-08-14 13:39:04 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:39:04 --> Model "Items_model" initialized
INFO - 2025-08-14 13:39:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:39:04 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:39:04 --> Final output sent to browser
DEBUG - 2025-08-14 13:39:04 --> Total execution time: 0.0604
INFO - 2025-08-14 21:39:04 --> Config Class Initialized
INFO - 2025-08-14 21:39:04 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:04 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:04 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:04 --> URI Class Initialized
INFO - 2025-08-14 21:39:04 --> Router Class Initialized
INFO - 2025-08-14 21:39:04 --> Output Class Initialized
INFO - 2025-08-14 21:39:04 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:04 --> CSRF cookie sent
INFO - 2025-08-14 21:39:04 --> Input Class Initialized
INFO - 2025-08-14 21:39:04 --> Language Class Initialized
INFO - 2025-08-14 21:39:04 --> Loader Class Initialized
INFO - 2025-08-14 21:39:04 --> Helper loaded: url_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: form_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:39:04 --> Database Driver Class Initialized
INFO - 2025-08-14 21:39:04 --> Form Validation Class Initialized
INFO - 2025-08-14 21:39:04 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:39:04 --> Controller Class Initialized
INFO - 2025-08-14 13:39:04 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:39:04 --> Model "Items_model" initialized
INFO - 2025-08-14 13:39:04 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:39:04 --> Final output sent to browser
DEBUG - 2025-08-14 13:39:04 --> Total execution time: 0.0540
INFO - 2025-08-14 21:39:04 --> Config Class Initialized
INFO - 2025-08-14 21:39:04 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:04 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:04 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:04 --> URI Class Initialized
INFO - 2025-08-14 21:39:04 --> Router Class Initialized
INFO - 2025-08-14 21:39:04 --> Output Class Initialized
INFO - 2025-08-14 21:39:04 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:04 --> CSRF cookie sent
INFO - 2025-08-14 21:39:04 --> CSRF token verified
INFO - 2025-08-14 21:39:04 --> Input Class Initialized
INFO - 2025-08-14 21:39:04 --> Language Class Initialized
INFO - 2025-08-14 21:39:04 --> Loader Class Initialized
INFO - 2025-08-14 21:39:04 --> Helper loaded: url_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: form_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:39:04 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:39:04 --> Database Driver Class Initialized
INFO - 2025-08-14 21:39:04 --> Form Validation Class Initialized
INFO - 2025-08-14 21:39:04 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:39:04 --> Controller Class Initialized
INFO - 2025-08-14 13:39:04 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:39:04 --> Model "Items_model" initialized
INFO - 2025-08-14 13:39:04 --> Final output sent to browser
DEBUG - 2025-08-14 13:39:04 --> Total execution time: 0.0463
INFO - 2025-08-14 21:39:04 --> Config Class Initialized
INFO - 2025-08-14 21:39:04 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:04 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:04 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:04 --> URI Class Initialized
INFO - 2025-08-14 21:39:04 --> Router Class Initialized
INFO - 2025-08-14 21:39:04 --> Output Class Initialized
INFO - 2025-08-14 21:39:04 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:04 --> CSRF cookie sent
INFO - 2025-08-14 21:39:04 --> Input Class Initialized
INFO - 2025-08-14 21:39:04 --> Language Class Initialized
ERROR - 2025-08-14 21:39:04 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:39:13 --> Config Class Initialized
INFO - 2025-08-14 21:39:13 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:13 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:13 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:13 --> URI Class Initialized
INFO - 2025-08-14 21:39:13 --> Router Class Initialized
INFO - 2025-08-14 21:39:13 --> Output Class Initialized
INFO - 2025-08-14 21:39:13 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:13 --> CSRF cookie sent
INFO - 2025-08-14 21:39:13 --> Input Class Initialized
INFO - 2025-08-14 21:39:13 --> Language Class Initialized
INFO - 2025-08-14 21:39:13 --> Loader Class Initialized
INFO - 2025-08-14 21:39:13 --> Helper loaded: url_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: form_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:39:13 --> Database Driver Class Initialized
INFO - 2025-08-14 21:39:13 --> Form Validation Class Initialized
INFO - 2025-08-14 21:39:13 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:39:13 --> Controller Class Initialized
INFO - 2025-08-14 13:39:13 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:39:13 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:39:13 --> Helper loaded: sms_template_helper
ERROR - 2025-08-14 13:39:13 --> Could not find the language line "previous_due"
ERROR - 2025-08-14 13:39:13 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:39:13 --> File loaded: C:\xampp\htdocs\application\views\pos.php
INFO - 2025-08-14 13:39:13 --> Final output sent to browser
DEBUG - 2025-08-14 13:39:13 --> Total execution time: 0.0702
INFO - 2025-08-14 21:39:13 --> Config Class Initialized
INFO - 2025-08-14 21:39:13 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:13 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:13 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:13 --> URI Class Initialized
INFO - 2025-08-14 21:39:13 --> Router Class Initialized
INFO - 2025-08-14 21:39:13 --> Output Class Initialized
INFO - 2025-08-14 21:39:13 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:13 --> CSRF cookie sent
INFO - 2025-08-14 21:39:13 --> CSRF token verified
INFO - 2025-08-14 21:39:13 --> Input Class Initialized
INFO - 2025-08-14 21:39:13 --> Language Class Initialized
INFO - 2025-08-14 21:39:13 --> Loader Class Initialized
INFO - 2025-08-14 21:39:13 --> Helper loaded: url_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: form_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:39:13 --> Database Driver Class Initialized
INFO - 2025-08-14 21:39:13 --> Form Validation Class Initialized
INFO - 2025-08-14 21:39:13 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:39:13 --> Controller Class Initialized
INFO - 2025-08-14 13:39:13 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:39:13 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:39:13 --> Final output sent to browser
DEBUG - 2025-08-14 13:39:13 --> Total execution time: 0.0409
INFO - 2025-08-14 21:39:13 --> Config Class Initialized
INFO - 2025-08-14 21:39:13 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:13 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:13 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:13 --> URI Class Initialized
INFO - 2025-08-14 21:39:13 --> Router Class Initialized
INFO - 2025-08-14 21:39:13 --> Output Class Initialized
INFO - 2025-08-14 21:39:13 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:13 --> CSRF cookie sent
INFO - 2025-08-14 21:39:13 --> CSRF token verified
INFO - 2025-08-14 21:39:13 --> Input Class Initialized
INFO - 2025-08-14 21:39:13 --> Language Class Initialized
INFO - 2025-08-14 21:39:13 --> Loader Class Initialized
INFO - 2025-08-14 21:39:13 --> Helper loaded: url_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: form_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:39:13 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:39:13 --> Database Driver Class Initialized
INFO - 2025-08-14 21:39:13 --> Form Validation Class Initialized
INFO - 2025-08-14 21:39:13 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:39:13 --> Controller Class Initialized
INFO - 2025-08-14 13:39:13 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:39:13 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:39:13 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:39:13 --> Final output sent to browser
DEBUG - 2025-08-14 13:39:13 --> Total execution time: 0.0484
INFO - 2025-08-14 21:39:13 --> Config Class Initialized
INFO - 2025-08-14 21:39:13 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:13 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:13 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:13 --> URI Class Initialized
INFO - 2025-08-14 21:39:13 --> Router Class Initialized
INFO - 2025-08-14 21:39:13 --> Output Class Initialized
INFO - 2025-08-14 21:39:13 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:13 --> CSRF cookie sent
INFO - 2025-08-14 21:39:13 --> Input Class Initialized
INFO - 2025-08-14 21:39:13 --> Language Class Initialized
ERROR - 2025-08-14 21:39:13 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:39:25 --> Config Class Initialized
INFO - 2025-08-14 21:39:25 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:25 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:25 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:25 --> URI Class Initialized
INFO - 2025-08-14 21:39:25 --> Router Class Initialized
INFO - 2025-08-14 21:39:25 --> Output Class Initialized
INFO - 2025-08-14 21:39:25 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:25 --> CSRF cookie sent
INFO - 2025-08-14 21:39:25 --> CSRF token verified
INFO - 2025-08-14 21:39:25 --> Input Class Initialized
INFO - 2025-08-14 21:39:25 --> Language Class Initialized
INFO - 2025-08-14 21:39:25 --> Loader Class Initialized
INFO - 2025-08-14 21:39:25 --> Helper loaded: url_helper
INFO - 2025-08-14 21:39:25 --> Helper loaded: form_helper
INFO - 2025-08-14 21:39:25 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:39:25 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:39:25 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:39:25 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:39:25 --> Database Driver Class Initialized
INFO - 2025-08-14 21:39:25 --> Form Validation Class Initialized
INFO - 2025-08-14 21:39:25 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:39:25 --> Controller Class Initialized
INFO - 2025-08-14 13:39:25 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:39:25 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:39:25 --> Final output sent to browser
DEBUG - 2025-08-14 13:39:25 --> Total execution time: 0.0486
INFO - 2025-08-14 21:39:45 --> Config Class Initialized
INFO - 2025-08-14 21:39:45 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:45 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:45 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:45 --> URI Class Initialized
INFO - 2025-08-14 21:39:45 --> Router Class Initialized
INFO - 2025-08-14 21:39:45 --> Output Class Initialized
INFO - 2025-08-14 21:39:45 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:45 --> CSRF cookie sent
INFO - 2025-08-14 21:39:45 --> CSRF token verified
INFO - 2025-08-14 21:39:45 --> Input Class Initialized
INFO - 2025-08-14 21:39:45 --> Language Class Initialized
INFO - 2025-08-14 21:39:45 --> Loader Class Initialized
INFO - 2025-08-14 21:39:45 --> Helper loaded: url_helper
INFO - 2025-08-14 21:39:45 --> Helper loaded: form_helper
INFO - 2025-08-14 21:39:45 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:39:45 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:39:45 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:39:45 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:39:45 --> Database Driver Class Initialized
INFO - 2025-08-14 21:39:45 --> Form Validation Class Initialized
INFO - 2025-08-14 21:39:45 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:39:45 --> Controller Class Initialized
INFO - 2025-08-14 13:39:45 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:39:45 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:39:45 --> Final output sent to browser
DEBUG - 2025-08-14 13:39:45 --> Total execution time: 0.0547
INFO - 2025-08-14 21:39:48 --> Config Class Initialized
INFO - 2025-08-14 21:39:48 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:48 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:48 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:48 --> URI Class Initialized
INFO - 2025-08-14 21:39:48 --> Router Class Initialized
INFO - 2025-08-14 21:39:48 --> Output Class Initialized
INFO - 2025-08-14 21:39:48 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:48 --> CSRF cookie sent
INFO - 2025-08-14 21:39:48 --> Input Class Initialized
INFO - 2025-08-14 21:39:48 --> Language Class Initialized
INFO - 2025-08-14 21:39:48 --> Loader Class Initialized
INFO - 2025-08-14 21:39:48 --> Helper loaded: url_helper
INFO - 2025-08-14 21:39:48 --> Helper loaded: form_helper
INFO - 2025-08-14 21:39:48 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:39:48 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:39:48 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:39:48 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:39:48 --> Database Driver Class Initialized
INFO - 2025-08-14 21:39:48 --> Form Validation Class Initialized
INFO - 2025-08-14 21:39:48 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:39:48 --> Controller Class Initialized
INFO - 2025-08-14 13:39:48 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:39:48 --> Model "Items_model" initialized
INFO - 2025-08-14 13:39:48 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:39:48 --> Final output sent to browser
DEBUG - 2025-08-14 13:39:48 --> Total execution time: 0.0597
INFO - 2025-08-14 21:39:49 --> Config Class Initialized
INFO - 2025-08-14 21:39:49 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:49 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:49 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:49 --> URI Class Initialized
INFO - 2025-08-14 21:39:49 --> Router Class Initialized
INFO - 2025-08-14 21:39:49 --> Output Class Initialized
INFO - 2025-08-14 21:39:49 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:49 --> CSRF cookie sent
INFO - 2025-08-14 21:39:49 --> CSRF token verified
INFO - 2025-08-14 21:39:49 --> Input Class Initialized
INFO - 2025-08-14 21:39:49 --> Language Class Initialized
INFO - 2025-08-14 21:39:49 --> Loader Class Initialized
INFO - 2025-08-14 21:39:49 --> Helper loaded: url_helper
INFO - 2025-08-14 21:39:49 --> Helper loaded: form_helper
INFO - 2025-08-14 21:39:49 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:39:49 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:39:49 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:39:49 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:39:49 --> Database Driver Class Initialized
INFO - 2025-08-14 21:39:49 --> Form Validation Class Initialized
INFO - 2025-08-14 21:39:49 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:39:49 --> Controller Class Initialized
INFO - 2025-08-14 13:39:49 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:39:49 --> Model "Items_model" initialized
INFO - 2025-08-14 13:39:49 --> Final output sent to browser
DEBUG - 2025-08-14 13:39:49 --> Total execution time: 0.0587
INFO - 2025-08-14 21:39:49 --> Config Class Initialized
INFO - 2025-08-14 21:39:49 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:49 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:49 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:49 --> URI Class Initialized
INFO - 2025-08-14 21:39:49 --> Router Class Initialized
INFO - 2025-08-14 21:39:49 --> Output Class Initialized
INFO - 2025-08-14 21:39:49 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:49 --> CSRF cookie sent
INFO - 2025-08-14 21:39:49 --> Input Class Initialized
INFO - 2025-08-14 21:39:49 --> Language Class Initialized
ERROR - 2025-08-14 21:39:49 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:39:53 --> Config Class Initialized
INFO - 2025-08-14 21:39:53 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:39:53 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:39:53 --> Utf8 Class Initialized
INFO - 2025-08-14 21:39:53 --> URI Class Initialized
INFO - 2025-08-14 21:39:53 --> Router Class Initialized
INFO - 2025-08-14 21:39:53 --> Output Class Initialized
INFO - 2025-08-14 21:39:53 --> Security Class Initialized
DEBUG - 2025-08-14 21:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:39:53 --> CSRF cookie sent
INFO - 2025-08-14 21:39:53 --> Input Class Initialized
INFO - 2025-08-14 21:39:53 --> Language Class Initialized
INFO - 2025-08-14 21:39:53 --> Loader Class Initialized
INFO - 2025-08-14 21:39:53 --> Helper loaded: url_helper
INFO - 2025-08-14 21:39:53 --> Helper loaded: form_helper
INFO - 2025-08-14 21:39:53 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:39:53 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:39:53 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:39:53 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:39:53 --> Database Driver Class Initialized
INFO - 2025-08-14 21:39:53 --> Form Validation Class Initialized
INFO - 2025-08-14 21:39:53 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:39:53 --> Controller Class Initialized
INFO - 2025-08-14 13:39:53 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:39:53 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:39:53 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:39:53 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:39:53 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:39:53 --> Final output sent to browser
DEBUG - 2025-08-14 13:39:53 --> Total execution time: 0.0563
INFO - 2025-08-14 21:40:45 --> Config Class Initialized
INFO - 2025-08-14 21:40:45 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:40:45 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:40:45 --> Utf8 Class Initialized
INFO - 2025-08-14 21:40:45 --> URI Class Initialized
INFO - 2025-08-14 21:40:45 --> Router Class Initialized
INFO - 2025-08-14 21:40:45 --> Output Class Initialized
INFO - 2025-08-14 21:40:45 --> Security Class Initialized
DEBUG - 2025-08-14 21:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:40:45 --> CSRF cookie sent
INFO - 2025-08-14 21:40:45 --> CSRF token verified
INFO - 2025-08-14 21:40:45 --> Input Class Initialized
INFO - 2025-08-14 21:40:45 --> Language Class Initialized
INFO - 2025-08-14 21:40:45 --> Loader Class Initialized
INFO - 2025-08-14 21:40:45 --> Helper loaded: url_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: form_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:40:45 --> Database Driver Class Initialized
INFO - 2025-08-14 21:40:45 --> Form Validation Class Initialized
INFO - 2025-08-14 21:40:45 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:40:45 --> Controller Class Initialized
INFO - 2025-08-14 13:40:45 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:40:45 --> Model "Items_model" initialized
INFO - 2025-08-14 13:40:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:40:45 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:40:45 --> Final output sent to browser
DEBUG - 2025-08-14 13:40:45 --> Total execution time: 0.0636
INFO - 2025-08-14 21:40:45 --> Config Class Initialized
INFO - 2025-08-14 21:40:45 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:40:45 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:40:45 --> Utf8 Class Initialized
INFO - 2025-08-14 21:40:45 --> URI Class Initialized
INFO - 2025-08-14 21:40:45 --> Router Class Initialized
INFO - 2025-08-14 21:40:45 --> Output Class Initialized
INFO - 2025-08-14 21:40:45 --> Security Class Initialized
DEBUG - 2025-08-14 21:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:40:45 --> CSRF cookie sent
INFO - 2025-08-14 21:40:45 --> Input Class Initialized
INFO - 2025-08-14 21:40:45 --> Language Class Initialized
INFO - 2025-08-14 21:40:45 --> Loader Class Initialized
INFO - 2025-08-14 21:40:45 --> Helper loaded: url_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: form_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:40:45 --> Database Driver Class Initialized
INFO - 2025-08-14 21:40:45 --> Form Validation Class Initialized
INFO - 2025-08-14 21:40:45 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:40:45 --> Controller Class Initialized
INFO - 2025-08-14 13:40:45 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:40:45 --> Model "Items_model" initialized
INFO - 2025-08-14 13:40:45 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:40:45 --> Final output sent to browser
DEBUG - 2025-08-14 13:40:45 --> Total execution time: 0.0545
INFO - 2025-08-14 21:40:45 --> Config Class Initialized
INFO - 2025-08-14 21:40:45 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:40:45 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:40:45 --> Utf8 Class Initialized
INFO - 2025-08-14 21:40:45 --> URI Class Initialized
INFO - 2025-08-14 21:40:45 --> Router Class Initialized
INFO - 2025-08-14 21:40:45 --> Output Class Initialized
INFO - 2025-08-14 21:40:45 --> Security Class Initialized
DEBUG - 2025-08-14 21:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:40:45 --> CSRF cookie sent
INFO - 2025-08-14 21:40:45 --> CSRF token verified
INFO - 2025-08-14 21:40:45 --> Input Class Initialized
INFO - 2025-08-14 21:40:45 --> Language Class Initialized
INFO - 2025-08-14 21:40:45 --> Loader Class Initialized
INFO - 2025-08-14 21:40:45 --> Helper loaded: url_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: form_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:40:45 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:40:45 --> Database Driver Class Initialized
INFO - 2025-08-14 21:40:45 --> Form Validation Class Initialized
INFO - 2025-08-14 21:40:45 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:40:45 --> Controller Class Initialized
INFO - 2025-08-14 13:40:45 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:40:45 --> Model "Items_model" initialized
INFO - 2025-08-14 13:40:45 --> Final output sent to browser
DEBUG - 2025-08-14 13:40:45 --> Total execution time: 0.0434
INFO - 2025-08-14 21:40:45 --> Config Class Initialized
INFO - 2025-08-14 21:40:45 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:40:45 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:40:45 --> Utf8 Class Initialized
INFO - 2025-08-14 21:40:45 --> URI Class Initialized
INFO - 2025-08-14 21:40:45 --> Router Class Initialized
INFO - 2025-08-14 21:40:45 --> Output Class Initialized
INFO - 2025-08-14 21:40:45 --> Security Class Initialized
DEBUG - 2025-08-14 21:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:40:45 --> CSRF cookie sent
INFO - 2025-08-14 21:40:45 --> Input Class Initialized
INFO - 2025-08-14 21:40:45 --> Language Class Initialized
ERROR - 2025-08-14 21:40:45 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:40:49 --> Config Class Initialized
INFO - 2025-08-14 21:40:49 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:40:49 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:40:49 --> Utf8 Class Initialized
INFO - 2025-08-14 21:40:49 --> URI Class Initialized
INFO - 2025-08-14 21:40:49 --> Router Class Initialized
INFO - 2025-08-14 21:40:49 --> Output Class Initialized
INFO - 2025-08-14 21:40:49 --> Security Class Initialized
DEBUG - 2025-08-14 21:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:40:49 --> CSRF cookie sent
INFO - 2025-08-14 21:40:49 --> Input Class Initialized
INFO - 2025-08-14 21:40:49 --> Language Class Initialized
INFO - 2025-08-14 21:40:49 --> Loader Class Initialized
INFO - 2025-08-14 21:40:49 --> Helper loaded: url_helper
INFO - 2025-08-14 21:40:49 --> Helper loaded: form_helper
INFO - 2025-08-14 21:40:49 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:40:49 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:40:49 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:40:49 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:40:49 --> Database Driver Class Initialized
INFO - 2025-08-14 21:40:49 --> Form Validation Class Initialized
INFO - 2025-08-14 21:40:49 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:40:49 --> Controller Class Initialized
INFO - 2025-08-14 13:40:49 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:40:49 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:40:49 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:40:49 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:40:49 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:40:49 --> Final output sent to browser
DEBUG - 2025-08-14 13:40:49 --> Total execution time: 0.0679
INFO - 2025-08-14 21:41:29 --> Config Class Initialized
INFO - 2025-08-14 21:41:29 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:41:29 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:41:29 --> Utf8 Class Initialized
INFO - 2025-08-14 21:41:29 --> URI Class Initialized
INFO - 2025-08-14 21:41:29 --> Router Class Initialized
INFO - 2025-08-14 21:41:29 --> Output Class Initialized
INFO - 2025-08-14 21:41:29 --> Security Class Initialized
DEBUG - 2025-08-14 21:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:41:29 --> CSRF cookie sent
INFO - 2025-08-14 21:41:29 --> CSRF token verified
INFO - 2025-08-14 21:41:29 --> Input Class Initialized
INFO - 2025-08-14 21:41:29 --> Language Class Initialized
INFO - 2025-08-14 21:41:29 --> Loader Class Initialized
INFO - 2025-08-14 21:41:29 --> Helper loaded: url_helper
INFO - 2025-08-14 21:41:29 --> Helper loaded: form_helper
INFO - 2025-08-14 21:41:29 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:41:29 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:41:29 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:41:29 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:41:29 --> Database Driver Class Initialized
INFO - 2025-08-14 21:41:29 --> Form Validation Class Initialized
INFO - 2025-08-14 21:41:29 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:41:29 --> Controller Class Initialized
INFO - 2025-08-14 13:41:29 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:41:29 --> Model "Items_model" initialized
INFO - 2025-08-14 13:41:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:41:29 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:41:29 --> Final output sent to browser
DEBUG - 2025-08-14 13:41:29 --> Total execution time: 0.0715
INFO - 2025-08-14 21:41:29 --> Config Class Initialized
INFO - 2025-08-14 21:41:29 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:41:29 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:41:29 --> Utf8 Class Initialized
INFO - 2025-08-14 21:41:29 --> URI Class Initialized
INFO - 2025-08-14 21:41:29 --> Router Class Initialized
INFO - 2025-08-14 21:41:29 --> Output Class Initialized
INFO - 2025-08-14 21:41:29 --> Security Class Initialized
DEBUG - 2025-08-14 21:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:41:29 --> CSRF cookie sent
INFO - 2025-08-14 21:41:29 --> Input Class Initialized
INFO - 2025-08-14 21:41:29 --> Language Class Initialized
INFO - 2025-08-14 21:41:29 --> Loader Class Initialized
INFO - 2025-08-14 21:41:29 --> Helper loaded: url_helper
INFO - 2025-08-14 21:41:29 --> Helper loaded: form_helper
INFO - 2025-08-14 21:41:29 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:41:29 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:41:29 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:41:29 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:41:29 --> Database Driver Class Initialized
INFO - 2025-08-14 21:41:29 --> Form Validation Class Initialized
INFO - 2025-08-14 21:41:29 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:41:29 --> Controller Class Initialized
INFO - 2025-08-14 13:41:29 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:41:29 --> Model "Items_model" initialized
INFO - 2025-08-14 13:41:29 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:41:29 --> Final output sent to browser
DEBUG - 2025-08-14 13:41:29 --> Total execution time: 0.0599
INFO - 2025-08-14 21:41:30 --> Config Class Initialized
INFO - 2025-08-14 21:41:30 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:41:30 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:41:30 --> Utf8 Class Initialized
INFO - 2025-08-14 21:41:30 --> URI Class Initialized
INFO - 2025-08-14 21:41:30 --> Router Class Initialized
INFO - 2025-08-14 21:41:30 --> Output Class Initialized
INFO - 2025-08-14 21:41:30 --> Security Class Initialized
DEBUG - 2025-08-14 21:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:41:30 --> CSRF cookie sent
INFO - 2025-08-14 21:41:30 --> CSRF token verified
INFO - 2025-08-14 21:41:30 --> Input Class Initialized
INFO - 2025-08-14 21:41:30 --> Language Class Initialized
INFO - 2025-08-14 21:41:30 --> Loader Class Initialized
INFO - 2025-08-14 21:41:30 --> Helper loaded: url_helper
INFO - 2025-08-14 21:41:30 --> Helper loaded: form_helper
INFO - 2025-08-14 21:41:30 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:41:30 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:41:30 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:41:30 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:41:30 --> Database Driver Class Initialized
INFO - 2025-08-14 21:41:30 --> Form Validation Class Initialized
INFO - 2025-08-14 21:41:30 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:41:30 --> Controller Class Initialized
INFO - 2025-08-14 13:41:30 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:41:30 --> Model "Items_model" initialized
INFO - 2025-08-14 13:41:30 --> Final output sent to browser
DEBUG - 2025-08-14 13:41:30 --> Total execution time: 0.0483
INFO - 2025-08-14 21:41:30 --> Config Class Initialized
INFO - 2025-08-14 21:41:30 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:41:30 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:41:30 --> Utf8 Class Initialized
INFO - 2025-08-14 21:41:30 --> URI Class Initialized
INFO - 2025-08-14 21:41:30 --> Router Class Initialized
INFO - 2025-08-14 21:41:30 --> Output Class Initialized
INFO - 2025-08-14 21:41:30 --> Security Class Initialized
DEBUG - 2025-08-14 21:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:41:30 --> CSRF cookie sent
INFO - 2025-08-14 21:41:30 --> Input Class Initialized
INFO - 2025-08-14 21:41:30 --> Language Class Initialized
ERROR - 2025-08-14 21:41:30 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:41:36 --> Config Class Initialized
INFO - 2025-08-14 21:41:36 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:41:36 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:41:36 --> Utf8 Class Initialized
INFO - 2025-08-14 21:41:36 --> URI Class Initialized
INFO - 2025-08-14 21:41:36 --> Router Class Initialized
INFO - 2025-08-14 21:41:36 --> Output Class Initialized
INFO - 2025-08-14 21:41:36 --> Security Class Initialized
DEBUG - 2025-08-14 21:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:41:36 --> CSRF cookie sent
INFO - 2025-08-14 21:41:36 --> Input Class Initialized
INFO - 2025-08-14 21:41:36 --> Language Class Initialized
INFO - 2025-08-14 21:41:36 --> Loader Class Initialized
INFO - 2025-08-14 21:41:36 --> Helper loaded: url_helper
INFO - 2025-08-14 21:41:36 --> Helper loaded: form_helper
INFO - 2025-08-14 21:41:36 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:41:36 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:41:36 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:41:36 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:41:36 --> Database Driver Class Initialized
INFO - 2025-08-14 21:41:36 --> Form Validation Class Initialized
INFO - 2025-08-14 21:41:36 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:41:36 --> Controller Class Initialized
INFO - 2025-08-14 13:41:36 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:41:36 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:41:36 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:41:36 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:41:36 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:41:36 --> Final output sent to browser
DEBUG - 2025-08-14 13:41:36 --> Total execution time: 0.0786
INFO - 2025-08-14 21:42:13 --> Config Class Initialized
INFO - 2025-08-14 21:42:13 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:42:13 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:42:13 --> Utf8 Class Initialized
INFO - 2025-08-14 21:42:13 --> URI Class Initialized
INFO - 2025-08-14 21:42:13 --> Router Class Initialized
INFO - 2025-08-14 21:42:13 --> Output Class Initialized
INFO - 2025-08-14 21:42:13 --> Security Class Initialized
DEBUG - 2025-08-14 21:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:42:13 --> CSRF cookie sent
INFO - 2025-08-14 21:42:13 --> CSRF token verified
INFO - 2025-08-14 21:42:13 --> Input Class Initialized
INFO - 2025-08-14 21:42:13 --> Language Class Initialized
INFO - 2025-08-14 21:42:13 --> Loader Class Initialized
INFO - 2025-08-14 21:42:13 --> Helper loaded: url_helper
INFO - 2025-08-14 21:42:13 --> Helper loaded: form_helper
INFO - 2025-08-14 21:42:13 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:42:13 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:42:13 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:42:13 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:42:13 --> Database Driver Class Initialized
INFO - 2025-08-14 21:42:13 --> Form Validation Class Initialized
INFO - 2025-08-14 21:42:13 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:42:13 --> Controller Class Initialized
INFO - 2025-08-14 13:42:13 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:42:13 --> Model "Items_model" initialized
INFO - 2025-08-14 13:42:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:42:13 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:42:13 --> Final output sent to browser
DEBUG - 2025-08-14 13:42:13 --> Total execution time: 0.0575
INFO - 2025-08-14 21:42:13 --> Config Class Initialized
INFO - 2025-08-14 21:42:13 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:42:13 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:42:13 --> Utf8 Class Initialized
INFO - 2025-08-14 21:42:13 --> URI Class Initialized
INFO - 2025-08-14 21:42:13 --> Router Class Initialized
INFO - 2025-08-14 21:42:13 --> Output Class Initialized
INFO - 2025-08-14 21:42:13 --> Security Class Initialized
DEBUG - 2025-08-14 21:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:42:13 --> CSRF cookie sent
INFO - 2025-08-14 21:42:13 --> Input Class Initialized
INFO - 2025-08-14 21:42:13 --> Language Class Initialized
INFO - 2025-08-14 21:42:13 --> Loader Class Initialized
INFO - 2025-08-14 21:42:13 --> Helper loaded: url_helper
INFO - 2025-08-14 21:42:13 --> Helper loaded: form_helper
INFO - 2025-08-14 21:42:13 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:42:13 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:42:13 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:42:13 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:42:13 --> Database Driver Class Initialized
INFO - 2025-08-14 21:42:13 --> Form Validation Class Initialized
INFO - 2025-08-14 21:42:13 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:42:13 --> Controller Class Initialized
INFO - 2025-08-14 13:42:13 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:42:13 --> Model "Items_model" initialized
INFO - 2025-08-14 13:42:13 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:42:13 --> Final output sent to browser
DEBUG - 2025-08-14 13:42:13 --> Total execution time: 0.0594
INFO - 2025-08-14 21:42:14 --> Config Class Initialized
INFO - 2025-08-14 21:42:14 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:42:14 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:42:14 --> Utf8 Class Initialized
INFO - 2025-08-14 21:42:14 --> URI Class Initialized
INFO - 2025-08-14 21:42:14 --> Router Class Initialized
INFO - 2025-08-14 21:42:14 --> Output Class Initialized
INFO - 2025-08-14 21:42:14 --> Security Class Initialized
DEBUG - 2025-08-14 21:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:42:14 --> CSRF cookie sent
INFO - 2025-08-14 21:42:14 --> CSRF token verified
INFO - 2025-08-14 21:42:14 --> Input Class Initialized
INFO - 2025-08-14 21:42:14 --> Language Class Initialized
INFO - 2025-08-14 21:42:14 --> Loader Class Initialized
INFO - 2025-08-14 21:42:14 --> Helper loaded: url_helper
INFO - 2025-08-14 21:42:14 --> Helper loaded: form_helper
INFO - 2025-08-14 21:42:14 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:42:14 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:42:14 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:42:14 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:42:14 --> Database Driver Class Initialized
INFO - 2025-08-14 21:42:14 --> Form Validation Class Initialized
INFO - 2025-08-14 21:42:14 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:42:14 --> Controller Class Initialized
INFO - 2025-08-14 13:42:14 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:42:14 --> Model "Items_model" initialized
INFO - 2025-08-14 13:42:14 --> Final output sent to browser
DEBUG - 2025-08-14 13:42:14 --> Total execution time: 0.0496
INFO - 2025-08-14 21:42:14 --> Config Class Initialized
INFO - 2025-08-14 21:42:14 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:42:14 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:42:14 --> Utf8 Class Initialized
INFO - 2025-08-14 21:42:14 --> URI Class Initialized
INFO - 2025-08-14 21:42:14 --> Router Class Initialized
INFO - 2025-08-14 21:42:14 --> Output Class Initialized
INFO - 2025-08-14 21:42:14 --> Security Class Initialized
DEBUG - 2025-08-14 21:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:42:14 --> CSRF cookie sent
INFO - 2025-08-14 21:42:14 --> Input Class Initialized
INFO - 2025-08-14 21:42:14 --> Language Class Initialized
ERROR - 2025-08-14 21:42:14 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:42:16 --> Config Class Initialized
INFO - 2025-08-14 21:42:16 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:42:16 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:42:16 --> Utf8 Class Initialized
INFO - 2025-08-14 21:42:16 --> URI Class Initialized
INFO - 2025-08-14 21:42:16 --> Router Class Initialized
INFO - 2025-08-14 21:42:16 --> Output Class Initialized
INFO - 2025-08-14 21:42:16 --> Security Class Initialized
DEBUG - 2025-08-14 21:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:42:16 --> CSRF cookie sent
INFO - 2025-08-14 21:42:16 --> Input Class Initialized
INFO - 2025-08-14 21:42:16 --> Language Class Initialized
INFO - 2025-08-14 21:42:16 --> Loader Class Initialized
INFO - 2025-08-14 21:42:16 --> Helper loaded: url_helper
INFO - 2025-08-14 21:42:16 --> Helper loaded: form_helper
INFO - 2025-08-14 21:42:16 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:42:16 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:42:16 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:42:16 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:42:16 --> Database Driver Class Initialized
INFO - 2025-08-14 21:42:16 --> Form Validation Class Initialized
INFO - 2025-08-14 21:42:16 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:42:16 --> Controller Class Initialized
INFO - 2025-08-14 13:42:16 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:42:16 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:42:16 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:42:16 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:42:16 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:42:16 --> Final output sent to browser
DEBUG - 2025-08-14 13:42:16 --> Total execution time: 0.0703
INFO - 2025-08-14 21:42:40 --> Config Class Initialized
INFO - 2025-08-14 21:42:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:42:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:42:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:42:40 --> URI Class Initialized
INFO - 2025-08-14 21:42:40 --> Router Class Initialized
INFO - 2025-08-14 21:42:40 --> Output Class Initialized
INFO - 2025-08-14 21:42:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:42:40 --> CSRF cookie sent
INFO - 2025-08-14 21:42:40 --> CSRF token verified
INFO - 2025-08-14 21:42:40 --> Input Class Initialized
INFO - 2025-08-14 21:42:40 --> Language Class Initialized
INFO - 2025-08-14 21:42:40 --> Loader Class Initialized
INFO - 2025-08-14 21:42:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:42:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:42:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:42:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:42:40 --> Controller Class Initialized
INFO - 2025-08-14 13:42:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:42:40 --> Model "Items_model" initialized
INFO - 2025-08-14 13:42:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:42:40 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:42:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:42:40 --> Total execution time: 0.0611
INFO - 2025-08-14 21:42:40 --> Config Class Initialized
INFO - 2025-08-14 21:42:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:42:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:42:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:42:40 --> URI Class Initialized
INFO - 2025-08-14 21:42:40 --> Router Class Initialized
INFO - 2025-08-14 21:42:40 --> Output Class Initialized
INFO - 2025-08-14 21:42:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:42:40 --> CSRF cookie sent
INFO - 2025-08-14 21:42:40 --> Input Class Initialized
INFO - 2025-08-14 21:42:40 --> Language Class Initialized
INFO - 2025-08-14 21:42:40 --> Loader Class Initialized
INFO - 2025-08-14 21:42:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:42:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:42:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:42:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:42:40 --> Controller Class Initialized
INFO - 2025-08-14 13:42:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:42:40 --> Model "Items_model" initialized
INFO - 2025-08-14 13:42:40 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:42:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:42:40 --> Total execution time: 0.0741
INFO - 2025-08-14 21:42:40 --> Config Class Initialized
INFO - 2025-08-14 21:42:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:42:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:42:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:42:40 --> URI Class Initialized
INFO - 2025-08-14 21:42:40 --> Router Class Initialized
INFO - 2025-08-14 21:42:40 --> Output Class Initialized
INFO - 2025-08-14 21:42:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:42:40 --> CSRF cookie sent
INFO - 2025-08-14 21:42:40 --> CSRF token verified
INFO - 2025-08-14 21:42:40 --> Input Class Initialized
INFO - 2025-08-14 21:42:40 --> Language Class Initialized
INFO - 2025-08-14 21:42:40 --> Loader Class Initialized
INFO - 2025-08-14 21:42:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:42:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:42:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:42:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:42:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:42:40 --> Controller Class Initialized
INFO - 2025-08-14 13:42:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:42:40 --> Model "Items_model" initialized
INFO - 2025-08-14 13:42:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:42:40 --> Total execution time: 0.0458
INFO - 2025-08-14 21:42:40 --> Config Class Initialized
INFO - 2025-08-14 21:42:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:42:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:42:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:42:40 --> URI Class Initialized
INFO - 2025-08-14 21:42:40 --> Router Class Initialized
INFO - 2025-08-14 21:42:40 --> Output Class Initialized
INFO - 2025-08-14 21:42:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:42:40 --> CSRF cookie sent
INFO - 2025-08-14 21:42:40 --> Input Class Initialized
INFO - 2025-08-14 21:42:40 --> Language Class Initialized
ERROR - 2025-08-14 21:42:40 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:42:42 --> Config Class Initialized
INFO - 2025-08-14 21:42:42 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:42:42 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:42:42 --> Utf8 Class Initialized
INFO - 2025-08-14 21:42:42 --> URI Class Initialized
INFO - 2025-08-14 21:42:42 --> Router Class Initialized
INFO - 2025-08-14 21:42:42 --> Output Class Initialized
INFO - 2025-08-14 21:42:42 --> Security Class Initialized
DEBUG - 2025-08-14 21:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:42:42 --> CSRF cookie sent
INFO - 2025-08-14 21:42:42 --> Input Class Initialized
INFO - 2025-08-14 21:42:42 --> Language Class Initialized
INFO - 2025-08-14 21:42:42 --> Loader Class Initialized
INFO - 2025-08-14 21:42:42 --> Helper loaded: url_helper
INFO - 2025-08-14 21:42:42 --> Helper loaded: form_helper
INFO - 2025-08-14 21:42:42 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:42:42 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:42:42 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:42:42 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:42:42 --> Database Driver Class Initialized
INFO - 2025-08-14 21:42:42 --> Form Validation Class Initialized
INFO - 2025-08-14 21:42:42 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:42:42 --> Controller Class Initialized
INFO - 2025-08-14 13:42:42 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:42:42 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:42:42 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:42:42 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:42:42 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:42:42 --> Final output sent to browser
DEBUG - 2025-08-14 13:42:42 --> Total execution time: 0.0709
INFO - 2025-08-14 21:43:16 --> Config Class Initialized
INFO - 2025-08-14 21:43:16 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:43:16 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:43:16 --> Utf8 Class Initialized
INFO - 2025-08-14 21:43:16 --> URI Class Initialized
INFO - 2025-08-14 21:43:16 --> Router Class Initialized
INFO - 2025-08-14 21:43:16 --> Output Class Initialized
INFO - 2025-08-14 21:43:16 --> Security Class Initialized
DEBUG - 2025-08-14 21:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:43:16 --> CSRF cookie sent
INFO - 2025-08-14 21:43:16 --> CSRF token verified
INFO - 2025-08-14 21:43:16 --> Input Class Initialized
INFO - 2025-08-14 21:43:16 --> Language Class Initialized
INFO - 2025-08-14 21:43:16 --> Loader Class Initialized
INFO - 2025-08-14 21:43:16 --> Helper loaded: url_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: form_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:43:16 --> Database Driver Class Initialized
INFO - 2025-08-14 21:43:16 --> Form Validation Class Initialized
INFO - 2025-08-14 21:43:16 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:43:16 --> Controller Class Initialized
INFO - 2025-08-14 13:43:16 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:43:16 --> Model "Items_model" initialized
INFO - 2025-08-14 13:43:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:43:16 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:43:16 --> Final output sent to browser
DEBUG - 2025-08-14 13:43:16 --> Total execution time: 0.0567
INFO - 2025-08-14 21:43:16 --> Config Class Initialized
INFO - 2025-08-14 21:43:16 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:43:16 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:43:16 --> Utf8 Class Initialized
INFO - 2025-08-14 21:43:16 --> URI Class Initialized
INFO - 2025-08-14 21:43:16 --> Router Class Initialized
INFO - 2025-08-14 21:43:16 --> Output Class Initialized
INFO - 2025-08-14 21:43:16 --> Security Class Initialized
DEBUG - 2025-08-14 21:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:43:16 --> CSRF cookie sent
INFO - 2025-08-14 21:43:16 --> Input Class Initialized
INFO - 2025-08-14 21:43:16 --> Language Class Initialized
INFO - 2025-08-14 21:43:16 --> Loader Class Initialized
INFO - 2025-08-14 21:43:16 --> Helper loaded: url_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: form_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:43:16 --> Database Driver Class Initialized
INFO - 2025-08-14 21:43:16 --> Form Validation Class Initialized
INFO - 2025-08-14 21:43:16 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:43:16 --> Controller Class Initialized
INFO - 2025-08-14 13:43:16 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:43:16 --> Model "Items_model" initialized
INFO - 2025-08-14 13:43:16 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:43:16 --> Final output sent to browser
DEBUG - 2025-08-14 13:43:16 --> Total execution time: 0.0687
INFO - 2025-08-14 21:43:16 --> Config Class Initialized
INFO - 2025-08-14 21:43:16 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:43:16 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:43:16 --> Utf8 Class Initialized
INFO - 2025-08-14 21:43:16 --> URI Class Initialized
INFO - 2025-08-14 21:43:16 --> Router Class Initialized
INFO - 2025-08-14 21:43:16 --> Output Class Initialized
INFO - 2025-08-14 21:43:16 --> Security Class Initialized
DEBUG - 2025-08-14 21:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:43:16 --> CSRF cookie sent
INFO - 2025-08-14 21:43:16 --> CSRF token verified
INFO - 2025-08-14 21:43:16 --> Input Class Initialized
INFO - 2025-08-14 21:43:16 --> Language Class Initialized
INFO - 2025-08-14 21:43:16 --> Loader Class Initialized
INFO - 2025-08-14 21:43:16 --> Helper loaded: url_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: form_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:43:16 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:43:16 --> Database Driver Class Initialized
INFO - 2025-08-14 21:43:16 --> Form Validation Class Initialized
INFO - 2025-08-14 21:43:16 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:43:16 --> Controller Class Initialized
INFO - 2025-08-14 13:43:16 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:43:16 --> Model "Items_model" initialized
INFO - 2025-08-14 13:43:16 --> Final output sent to browser
DEBUG - 2025-08-14 13:43:16 --> Total execution time: 0.0465
INFO - 2025-08-14 21:43:16 --> Config Class Initialized
INFO - 2025-08-14 21:43:16 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:43:16 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:43:16 --> Utf8 Class Initialized
INFO - 2025-08-14 21:43:16 --> URI Class Initialized
INFO - 2025-08-14 21:43:16 --> Router Class Initialized
INFO - 2025-08-14 21:43:16 --> Output Class Initialized
INFO - 2025-08-14 21:43:16 --> Security Class Initialized
DEBUG - 2025-08-14 21:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:43:16 --> CSRF cookie sent
INFO - 2025-08-14 21:43:16 --> Input Class Initialized
INFO - 2025-08-14 21:43:16 --> Language Class Initialized
ERROR - 2025-08-14 21:43:16 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:43:28 --> Config Class Initialized
INFO - 2025-08-14 21:43:28 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:43:28 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:43:28 --> Utf8 Class Initialized
INFO - 2025-08-14 21:43:28 --> URI Class Initialized
INFO - 2025-08-14 21:43:28 --> Router Class Initialized
INFO - 2025-08-14 21:43:28 --> Output Class Initialized
INFO - 2025-08-14 21:43:28 --> Security Class Initialized
DEBUG - 2025-08-14 21:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:43:28 --> CSRF cookie sent
INFO - 2025-08-14 21:43:28 --> Input Class Initialized
INFO - 2025-08-14 21:43:28 --> Language Class Initialized
INFO - 2025-08-14 21:43:28 --> Loader Class Initialized
INFO - 2025-08-14 21:43:28 --> Helper loaded: url_helper
INFO - 2025-08-14 21:43:28 --> Helper loaded: form_helper
INFO - 2025-08-14 21:43:28 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:43:28 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:43:28 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:43:28 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:43:28 --> Database Driver Class Initialized
INFO - 2025-08-14 21:43:28 --> Form Validation Class Initialized
INFO - 2025-08-14 21:43:28 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:43:28 --> Controller Class Initialized
INFO - 2025-08-14 13:43:28 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:43:28 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:43:28 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:43:28 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:43:28 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:43:28 --> Final output sent to browser
DEBUG - 2025-08-14 13:43:28 --> Total execution time: 0.0706
INFO - 2025-08-14 21:43:46 --> Config Class Initialized
INFO - 2025-08-14 21:43:46 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:43:46 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:43:46 --> Utf8 Class Initialized
INFO - 2025-08-14 21:43:46 --> URI Class Initialized
INFO - 2025-08-14 21:43:46 --> Router Class Initialized
INFO - 2025-08-14 21:43:46 --> Output Class Initialized
INFO - 2025-08-14 21:43:46 --> Security Class Initialized
DEBUG - 2025-08-14 21:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:43:46 --> CSRF cookie sent
INFO - 2025-08-14 21:43:46 --> CSRF token verified
INFO - 2025-08-14 21:43:46 --> Input Class Initialized
INFO - 2025-08-14 21:43:46 --> Language Class Initialized
INFO - 2025-08-14 21:43:46 --> Loader Class Initialized
INFO - 2025-08-14 21:43:46 --> Helper loaded: url_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: form_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:43:46 --> Database Driver Class Initialized
INFO - 2025-08-14 21:43:46 --> Form Validation Class Initialized
INFO - 2025-08-14 21:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:43:46 --> Controller Class Initialized
INFO - 2025-08-14 13:43:46 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:43:46 --> Model "Items_model" initialized
INFO - 2025-08-14 13:43:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:43:46 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:43:46 --> Final output sent to browser
DEBUG - 2025-08-14 13:43:46 --> Total execution time: 0.0688
INFO - 2025-08-14 21:43:46 --> Config Class Initialized
INFO - 2025-08-14 21:43:46 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:43:46 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:43:46 --> Utf8 Class Initialized
INFO - 2025-08-14 21:43:46 --> URI Class Initialized
INFO - 2025-08-14 21:43:46 --> Router Class Initialized
INFO - 2025-08-14 21:43:46 --> Output Class Initialized
INFO - 2025-08-14 21:43:46 --> Security Class Initialized
DEBUG - 2025-08-14 21:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:43:46 --> CSRF cookie sent
INFO - 2025-08-14 21:43:46 --> Input Class Initialized
INFO - 2025-08-14 21:43:46 --> Language Class Initialized
INFO - 2025-08-14 21:43:46 --> Loader Class Initialized
INFO - 2025-08-14 21:43:46 --> Helper loaded: url_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: form_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:43:46 --> Database Driver Class Initialized
INFO - 2025-08-14 21:43:46 --> Form Validation Class Initialized
INFO - 2025-08-14 21:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:43:46 --> Controller Class Initialized
INFO - 2025-08-14 13:43:46 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:43:46 --> Model "Items_model" initialized
INFO - 2025-08-14 13:43:46 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:43:46 --> Final output sent to browser
DEBUG - 2025-08-14 13:43:46 --> Total execution time: 0.0502
INFO - 2025-08-14 21:43:46 --> Config Class Initialized
INFO - 2025-08-14 21:43:46 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:43:46 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:43:46 --> Utf8 Class Initialized
INFO - 2025-08-14 21:43:46 --> URI Class Initialized
INFO - 2025-08-14 21:43:46 --> Router Class Initialized
INFO - 2025-08-14 21:43:46 --> Output Class Initialized
INFO - 2025-08-14 21:43:46 --> Security Class Initialized
DEBUG - 2025-08-14 21:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:43:46 --> CSRF cookie sent
INFO - 2025-08-14 21:43:46 --> CSRF token verified
INFO - 2025-08-14 21:43:46 --> Input Class Initialized
INFO - 2025-08-14 21:43:46 --> Language Class Initialized
INFO - 2025-08-14 21:43:46 --> Loader Class Initialized
INFO - 2025-08-14 21:43:46 --> Helper loaded: url_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: form_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:43:46 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:43:46 --> Database Driver Class Initialized
INFO - 2025-08-14 21:43:46 --> Form Validation Class Initialized
INFO - 2025-08-14 21:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:43:46 --> Controller Class Initialized
INFO - 2025-08-14 13:43:46 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:43:46 --> Model "Items_model" initialized
INFO - 2025-08-14 13:43:46 --> Final output sent to browser
DEBUG - 2025-08-14 13:43:46 --> Total execution time: 0.0444
INFO - 2025-08-14 21:43:46 --> Config Class Initialized
INFO - 2025-08-14 21:43:46 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:43:46 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:43:46 --> Utf8 Class Initialized
INFO - 2025-08-14 21:43:46 --> URI Class Initialized
INFO - 2025-08-14 21:43:46 --> Router Class Initialized
INFO - 2025-08-14 21:43:46 --> Output Class Initialized
INFO - 2025-08-14 21:43:46 --> Security Class Initialized
DEBUG - 2025-08-14 21:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:43:46 --> CSRF cookie sent
INFO - 2025-08-14 21:43:46 --> Input Class Initialized
INFO - 2025-08-14 21:43:46 --> Language Class Initialized
ERROR - 2025-08-14 21:43:46 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:43:51 --> Config Class Initialized
INFO - 2025-08-14 21:43:51 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:43:51 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:43:51 --> Utf8 Class Initialized
INFO - 2025-08-14 21:43:51 --> URI Class Initialized
INFO - 2025-08-14 21:43:51 --> Router Class Initialized
INFO - 2025-08-14 21:43:51 --> Output Class Initialized
INFO - 2025-08-14 21:43:51 --> Security Class Initialized
DEBUG - 2025-08-14 21:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:43:51 --> CSRF cookie sent
INFO - 2025-08-14 21:43:51 --> Input Class Initialized
INFO - 2025-08-14 21:43:51 --> Language Class Initialized
INFO - 2025-08-14 21:43:51 --> Loader Class Initialized
INFO - 2025-08-14 21:43:51 --> Helper loaded: url_helper
INFO - 2025-08-14 21:43:51 --> Helper loaded: form_helper
INFO - 2025-08-14 21:43:51 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:43:51 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:43:51 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:43:51 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:43:51 --> Database Driver Class Initialized
INFO - 2025-08-14 21:43:51 --> Form Validation Class Initialized
INFO - 2025-08-14 21:43:51 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:43:51 --> Controller Class Initialized
INFO - 2025-08-14 13:43:51 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:43:51 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:43:51 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:43:51 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:43:51 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:43:51 --> Final output sent to browser
DEBUG - 2025-08-14 13:43:51 --> Total execution time: 0.0630
INFO - 2025-08-14 21:44:11 --> Config Class Initialized
INFO - 2025-08-14 21:44:11 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:44:11 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:44:11 --> Utf8 Class Initialized
INFO - 2025-08-14 21:44:11 --> URI Class Initialized
INFO - 2025-08-14 21:44:11 --> Router Class Initialized
INFO - 2025-08-14 21:44:11 --> Output Class Initialized
INFO - 2025-08-14 21:44:11 --> Security Class Initialized
DEBUG - 2025-08-14 21:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:44:11 --> CSRF cookie sent
INFO - 2025-08-14 21:44:11 --> CSRF token verified
INFO - 2025-08-14 21:44:11 --> Input Class Initialized
INFO - 2025-08-14 21:44:11 --> Language Class Initialized
INFO - 2025-08-14 21:44:11 --> Loader Class Initialized
INFO - 2025-08-14 21:44:11 --> Helper loaded: url_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: form_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:44:11 --> Database Driver Class Initialized
INFO - 2025-08-14 21:44:11 --> Form Validation Class Initialized
INFO - 2025-08-14 21:44:11 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:44:11 --> Controller Class Initialized
INFO - 2025-08-14 13:44:11 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:44:11 --> Model "Items_model" initialized
INFO - 2025-08-14 13:44:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:44:11 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:44:11 --> Final output sent to browser
DEBUG - 2025-08-14 13:44:11 --> Total execution time: 0.0669
INFO - 2025-08-14 21:44:11 --> Config Class Initialized
INFO - 2025-08-14 21:44:11 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:44:11 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:44:11 --> Utf8 Class Initialized
INFO - 2025-08-14 21:44:11 --> URI Class Initialized
INFO - 2025-08-14 21:44:11 --> Router Class Initialized
INFO - 2025-08-14 21:44:11 --> Output Class Initialized
INFO - 2025-08-14 21:44:11 --> Security Class Initialized
DEBUG - 2025-08-14 21:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:44:11 --> CSRF cookie sent
INFO - 2025-08-14 21:44:11 --> Input Class Initialized
INFO - 2025-08-14 21:44:11 --> Language Class Initialized
INFO - 2025-08-14 21:44:11 --> Loader Class Initialized
INFO - 2025-08-14 21:44:11 --> Helper loaded: url_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: form_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:44:11 --> Database Driver Class Initialized
INFO - 2025-08-14 21:44:11 --> Form Validation Class Initialized
INFO - 2025-08-14 21:44:11 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:44:11 --> Controller Class Initialized
INFO - 2025-08-14 13:44:11 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:44:11 --> Model "Items_model" initialized
INFO - 2025-08-14 13:44:11 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:44:11 --> Final output sent to browser
DEBUG - 2025-08-14 13:44:11 --> Total execution time: 0.0488
INFO - 2025-08-14 21:44:11 --> Config Class Initialized
INFO - 2025-08-14 21:44:11 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:44:11 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:44:11 --> Utf8 Class Initialized
INFO - 2025-08-14 21:44:11 --> URI Class Initialized
INFO - 2025-08-14 21:44:11 --> Router Class Initialized
INFO - 2025-08-14 21:44:11 --> Output Class Initialized
INFO - 2025-08-14 21:44:11 --> Security Class Initialized
DEBUG - 2025-08-14 21:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:44:11 --> CSRF cookie sent
INFO - 2025-08-14 21:44:11 --> CSRF token verified
INFO - 2025-08-14 21:44:11 --> Input Class Initialized
INFO - 2025-08-14 21:44:11 --> Language Class Initialized
INFO - 2025-08-14 21:44:11 --> Loader Class Initialized
INFO - 2025-08-14 21:44:11 --> Helper loaded: url_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: form_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:44:11 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:44:11 --> Database Driver Class Initialized
INFO - 2025-08-14 21:44:11 --> Form Validation Class Initialized
INFO - 2025-08-14 21:44:11 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:44:11 --> Controller Class Initialized
INFO - 2025-08-14 13:44:11 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:44:11 --> Model "Items_model" initialized
INFO - 2025-08-14 13:44:11 --> Final output sent to browser
DEBUG - 2025-08-14 13:44:11 --> Total execution time: 0.0443
INFO - 2025-08-14 21:44:11 --> Config Class Initialized
INFO - 2025-08-14 21:44:11 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:44:11 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:44:11 --> Utf8 Class Initialized
INFO - 2025-08-14 21:44:11 --> URI Class Initialized
INFO - 2025-08-14 21:44:11 --> Router Class Initialized
INFO - 2025-08-14 21:44:11 --> Output Class Initialized
INFO - 2025-08-14 21:44:11 --> Security Class Initialized
DEBUG - 2025-08-14 21:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:44:11 --> CSRF cookie sent
INFO - 2025-08-14 21:44:11 --> Input Class Initialized
INFO - 2025-08-14 21:44:11 --> Language Class Initialized
ERROR - 2025-08-14 21:44:11 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:44:12 --> Config Class Initialized
INFO - 2025-08-14 21:44:12 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:44:12 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:44:12 --> Utf8 Class Initialized
INFO - 2025-08-14 21:44:12 --> URI Class Initialized
INFO - 2025-08-14 21:44:12 --> Router Class Initialized
INFO - 2025-08-14 21:44:12 --> Output Class Initialized
INFO - 2025-08-14 21:44:12 --> Security Class Initialized
DEBUG - 2025-08-14 21:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:44:12 --> CSRF cookie sent
INFO - 2025-08-14 21:44:12 --> Input Class Initialized
INFO - 2025-08-14 21:44:12 --> Language Class Initialized
INFO - 2025-08-14 21:44:12 --> Loader Class Initialized
INFO - 2025-08-14 21:44:12 --> Helper loaded: url_helper
INFO - 2025-08-14 21:44:12 --> Helper loaded: form_helper
INFO - 2025-08-14 21:44:12 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:44:12 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:44:12 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:44:12 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:44:12 --> Database Driver Class Initialized
INFO - 2025-08-14 21:44:12 --> Form Validation Class Initialized
INFO - 2025-08-14 21:44:12 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:44:12 --> Controller Class Initialized
INFO - 2025-08-14 13:44:12 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:44:12 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:44:12 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:44:12 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:44:12 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:44:12 --> Final output sent to browser
DEBUG - 2025-08-14 13:44:12 --> Total execution time: 0.0778
INFO - 2025-08-14 21:44:40 --> Config Class Initialized
INFO - 2025-08-14 21:44:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:44:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:44:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:44:40 --> URI Class Initialized
INFO - 2025-08-14 21:44:40 --> Router Class Initialized
INFO - 2025-08-14 21:44:40 --> Output Class Initialized
INFO - 2025-08-14 21:44:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:44:40 --> CSRF cookie sent
INFO - 2025-08-14 21:44:40 --> CSRF token verified
INFO - 2025-08-14 21:44:40 --> Input Class Initialized
INFO - 2025-08-14 21:44:40 --> Language Class Initialized
INFO - 2025-08-14 21:44:40 --> Loader Class Initialized
INFO - 2025-08-14 21:44:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:44:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:44:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:44:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:44:40 --> Controller Class Initialized
INFO - 2025-08-14 13:44:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:44:40 --> Model "Items_model" initialized
INFO - 2025-08-14 13:44:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:44:40 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:44:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:44:40 --> Total execution time: 0.0595
INFO - 2025-08-14 21:44:40 --> Config Class Initialized
INFO - 2025-08-14 21:44:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:44:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:44:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:44:40 --> URI Class Initialized
INFO - 2025-08-14 21:44:40 --> Router Class Initialized
INFO - 2025-08-14 21:44:40 --> Output Class Initialized
INFO - 2025-08-14 21:44:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:44:40 --> CSRF cookie sent
INFO - 2025-08-14 21:44:40 --> Input Class Initialized
INFO - 2025-08-14 21:44:40 --> Language Class Initialized
INFO - 2025-08-14 21:44:40 --> Loader Class Initialized
INFO - 2025-08-14 21:44:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:44:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:44:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:44:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:44:40 --> Controller Class Initialized
INFO - 2025-08-14 13:44:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:44:40 --> Model "Items_model" initialized
INFO - 2025-08-14 13:44:40 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:44:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:44:40 --> Total execution time: 0.0716
INFO - 2025-08-14 21:44:40 --> Config Class Initialized
INFO - 2025-08-14 21:44:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:44:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:44:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:44:40 --> URI Class Initialized
INFO - 2025-08-14 21:44:40 --> Router Class Initialized
INFO - 2025-08-14 21:44:40 --> Output Class Initialized
INFO - 2025-08-14 21:44:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:44:40 --> CSRF cookie sent
INFO - 2025-08-14 21:44:40 --> CSRF token verified
INFO - 2025-08-14 21:44:40 --> Input Class Initialized
INFO - 2025-08-14 21:44:40 --> Language Class Initialized
INFO - 2025-08-14 21:44:40 --> Loader Class Initialized
INFO - 2025-08-14 21:44:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:44:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:44:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:44:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:44:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:44:40 --> Controller Class Initialized
INFO - 2025-08-14 13:44:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:44:40 --> Model "Items_model" initialized
INFO - 2025-08-14 13:44:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:44:40 --> Total execution time: 0.0461
INFO - 2025-08-14 21:46:01 --> Config Class Initialized
INFO - 2025-08-14 21:46:01 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:46:01 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:46:01 --> Utf8 Class Initialized
INFO - 2025-08-14 21:46:01 --> URI Class Initialized
INFO - 2025-08-14 21:46:01 --> Router Class Initialized
INFO - 2025-08-14 21:46:01 --> Output Class Initialized
INFO - 2025-08-14 21:46:01 --> Security Class Initialized
DEBUG - 2025-08-14 21:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:46:01 --> CSRF cookie sent
INFO - 2025-08-14 21:46:01 --> Input Class Initialized
INFO - 2025-08-14 21:46:01 --> Language Class Initialized
INFO - 2025-08-14 21:46:01 --> Loader Class Initialized
INFO - 2025-08-14 21:46:01 --> Helper loaded: url_helper
INFO - 2025-08-14 21:46:01 --> Helper loaded: form_helper
INFO - 2025-08-14 21:46:01 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:46:01 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:46:01 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:46:01 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:46:01 --> Database Driver Class Initialized
INFO - 2025-08-14 21:46:01 --> Form Validation Class Initialized
INFO - 2025-08-14 21:46:01 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:46:01 --> Controller Class Initialized
INFO - 2025-08-14 13:46:01 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:46:01 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:46:01 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:46:01 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:46:01 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:46:01 --> Final output sent to browser
DEBUG - 2025-08-14 13:46:01 --> Total execution time: 0.0818
INFO - 2025-08-14 21:46:26 --> Config Class Initialized
INFO - 2025-08-14 21:46:26 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:46:26 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:46:26 --> Utf8 Class Initialized
INFO - 2025-08-14 21:46:26 --> URI Class Initialized
INFO - 2025-08-14 21:46:26 --> Router Class Initialized
INFO - 2025-08-14 21:46:26 --> Output Class Initialized
INFO - 2025-08-14 21:46:26 --> Security Class Initialized
DEBUG - 2025-08-14 21:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:46:26 --> CSRF cookie sent
INFO - 2025-08-14 21:46:26 --> CSRF token verified
INFO - 2025-08-14 21:46:26 --> Input Class Initialized
INFO - 2025-08-14 21:46:26 --> Language Class Initialized
INFO - 2025-08-14 21:46:26 --> Loader Class Initialized
INFO - 2025-08-14 21:46:26 --> Helper loaded: url_helper
INFO - 2025-08-14 21:46:26 --> Helper loaded: form_helper
INFO - 2025-08-14 21:46:26 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:46:26 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:46:26 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:46:26 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:46:26 --> Database Driver Class Initialized
INFO - 2025-08-14 21:46:26 --> Form Validation Class Initialized
INFO - 2025-08-14 21:46:26 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:46:26 --> Controller Class Initialized
INFO - 2025-08-14 13:46:26 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:46:26 --> Model "Items_model" initialized
INFO - 2025-08-14 13:46:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:46:26 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:46:26 --> Final output sent to browser
DEBUG - 2025-08-14 13:46:26 --> Total execution time: 0.0599
INFO - 2025-08-14 21:46:26 --> Config Class Initialized
INFO - 2025-08-14 21:46:26 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:46:26 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:46:26 --> Utf8 Class Initialized
INFO - 2025-08-14 21:46:26 --> URI Class Initialized
INFO - 2025-08-14 21:46:26 --> Router Class Initialized
INFO - 2025-08-14 21:46:26 --> Output Class Initialized
INFO - 2025-08-14 21:46:26 --> Security Class Initialized
DEBUG - 2025-08-14 21:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:46:26 --> CSRF cookie sent
INFO - 2025-08-14 21:46:26 --> Input Class Initialized
INFO - 2025-08-14 21:46:26 --> Language Class Initialized
INFO - 2025-08-14 21:46:26 --> Loader Class Initialized
INFO - 2025-08-14 21:46:26 --> Helper loaded: url_helper
INFO - 2025-08-14 21:46:26 --> Helper loaded: form_helper
INFO - 2025-08-14 21:46:26 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:46:26 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:46:26 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:46:26 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:46:26 --> Database Driver Class Initialized
INFO - 2025-08-14 21:46:26 --> Form Validation Class Initialized
INFO - 2025-08-14 21:46:26 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:46:26 --> Controller Class Initialized
INFO - 2025-08-14 13:46:26 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:46:26 --> Model "Items_model" initialized
INFO - 2025-08-14 13:46:26 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:46:26 --> Final output sent to browser
DEBUG - 2025-08-14 13:46:26 --> Total execution time: 0.0479
INFO - 2025-08-14 21:46:27 --> Config Class Initialized
INFO - 2025-08-14 21:46:27 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:46:27 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:46:27 --> Utf8 Class Initialized
INFO - 2025-08-14 21:46:27 --> URI Class Initialized
INFO - 2025-08-14 21:46:27 --> Router Class Initialized
INFO - 2025-08-14 21:46:27 --> Output Class Initialized
INFO - 2025-08-14 21:46:27 --> Security Class Initialized
DEBUG - 2025-08-14 21:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:46:27 --> CSRF cookie sent
INFO - 2025-08-14 21:46:27 --> CSRF token verified
INFO - 2025-08-14 21:46:27 --> Input Class Initialized
INFO - 2025-08-14 21:46:27 --> Language Class Initialized
INFO - 2025-08-14 21:46:27 --> Loader Class Initialized
INFO - 2025-08-14 21:46:27 --> Helper loaded: url_helper
INFO - 2025-08-14 21:46:27 --> Helper loaded: form_helper
INFO - 2025-08-14 21:46:27 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:46:27 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:46:27 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:46:27 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:46:27 --> Database Driver Class Initialized
INFO - 2025-08-14 21:46:27 --> Form Validation Class Initialized
INFO - 2025-08-14 21:46:27 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:46:27 --> Controller Class Initialized
INFO - 2025-08-14 13:46:27 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:46:27 --> Model "Items_model" initialized
INFO - 2025-08-14 13:46:27 --> Final output sent to browser
DEBUG - 2025-08-14 13:46:27 --> Total execution time: 0.0429
INFO - 2025-08-14 21:46:28 --> Config Class Initialized
INFO - 2025-08-14 21:46:28 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:46:28 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:46:28 --> Utf8 Class Initialized
INFO - 2025-08-14 21:46:28 --> URI Class Initialized
INFO - 2025-08-14 21:46:28 --> Router Class Initialized
INFO - 2025-08-14 21:46:28 --> Output Class Initialized
INFO - 2025-08-14 21:46:28 --> Security Class Initialized
DEBUG - 2025-08-14 21:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:46:28 --> CSRF cookie sent
INFO - 2025-08-14 21:46:28 --> Input Class Initialized
INFO - 2025-08-14 21:46:28 --> Language Class Initialized
INFO - 2025-08-14 21:46:28 --> Loader Class Initialized
INFO - 2025-08-14 21:46:28 --> Helper loaded: url_helper
INFO - 2025-08-14 21:46:28 --> Helper loaded: form_helper
INFO - 2025-08-14 21:46:28 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:46:28 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:46:28 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:46:28 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:46:28 --> Database Driver Class Initialized
INFO - 2025-08-14 21:46:28 --> Form Validation Class Initialized
INFO - 2025-08-14 21:46:28 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:46:28 --> Controller Class Initialized
INFO - 2025-08-14 13:46:28 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:46:28 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:46:28 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:46:28 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:46:28 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:46:28 --> Final output sent to browser
DEBUG - 2025-08-14 13:46:28 --> Total execution time: 0.0748
INFO - 2025-08-14 21:46:49 --> Config Class Initialized
INFO - 2025-08-14 21:46:49 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:46:49 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:46:49 --> Utf8 Class Initialized
INFO - 2025-08-14 21:46:49 --> URI Class Initialized
INFO - 2025-08-14 21:46:49 --> Router Class Initialized
INFO - 2025-08-14 21:46:49 --> Output Class Initialized
INFO - 2025-08-14 21:46:49 --> Security Class Initialized
DEBUG - 2025-08-14 21:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:46:49 --> CSRF cookie sent
INFO - 2025-08-14 21:46:49 --> CSRF token verified
INFO - 2025-08-14 21:46:49 --> Input Class Initialized
INFO - 2025-08-14 21:46:49 --> Language Class Initialized
INFO - 2025-08-14 21:46:49 --> Loader Class Initialized
INFO - 2025-08-14 21:46:49 --> Helper loaded: url_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: form_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:46:49 --> Database Driver Class Initialized
INFO - 2025-08-14 21:46:49 --> Form Validation Class Initialized
INFO - 2025-08-14 21:46:49 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:46:49 --> Controller Class Initialized
INFO - 2025-08-14 13:46:49 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:46:49 --> Model "Items_model" initialized
INFO - 2025-08-14 13:46:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:46:49 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:46:49 --> Final output sent to browser
DEBUG - 2025-08-14 13:46:49 --> Total execution time: 0.0596
INFO - 2025-08-14 21:46:49 --> Config Class Initialized
INFO - 2025-08-14 21:46:49 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:46:49 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:46:49 --> Utf8 Class Initialized
INFO - 2025-08-14 21:46:49 --> URI Class Initialized
INFO - 2025-08-14 21:46:49 --> Router Class Initialized
INFO - 2025-08-14 21:46:49 --> Output Class Initialized
INFO - 2025-08-14 21:46:49 --> Security Class Initialized
DEBUG - 2025-08-14 21:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:46:49 --> CSRF cookie sent
INFO - 2025-08-14 21:46:49 --> Input Class Initialized
INFO - 2025-08-14 21:46:49 --> Language Class Initialized
INFO - 2025-08-14 21:46:49 --> Loader Class Initialized
INFO - 2025-08-14 21:46:49 --> Helper loaded: url_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: form_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:46:49 --> Database Driver Class Initialized
INFO - 2025-08-14 21:46:49 --> Form Validation Class Initialized
INFO - 2025-08-14 21:46:49 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:46:49 --> Controller Class Initialized
INFO - 2025-08-14 13:46:49 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:46:49 --> Model "Items_model" initialized
INFO - 2025-08-14 13:46:49 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:46:49 --> Final output sent to browser
DEBUG - 2025-08-14 13:46:49 --> Total execution time: 0.0486
INFO - 2025-08-14 21:46:49 --> Config Class Initialized
INFO - 2025-08-14 21:46:49 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:46:49 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:46:49 --> Utf8 Class Initialized
INFO - 2025-08-14 21:46:49 --> URI Class Initialized
INFO - 2025-08-14 21:46:49 --> Router Class Initialized
INFO - 2025-08-14 21:46:49 --> Output Class Initialized
INFO - 2025-08-14 21:46:49 --> Security Class Initialized
DEBUG - 2025-08-14 21:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:46:49 --> CSRF cookie sent
INFO - 2025-08-14 21:46:49 --> CSRF token verified
INFO - 2025-08-14 21:46:49 --> Input Class Initialized
INFO - 2025-08-14 21:46:49 --> Language Class Initialized
INFO - 2025-08-14 21:46:49 --> Loader Class Initialized
INFO - 2025-08-14 21:46:49 --> Helper loaded: url_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: form_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:46:49 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:46:49 --> Database Driver Class Initialized
INFO - 2025-08-14 21:46:49 --> Form Validation Class Initialized
INFO - 2025-08-14 21:46:49 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:46:49 --> Controller Class Initialized
INFO - 2025-08-14 13:46:49 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:46:49 --> Model "Items_model" initialized
INFO - 2025-08-14 13:46:49 --> Final output sent to browser
DEBUG - 2025-08-14 13:46:49 --> Total execution time: 0.0485
INFO - 2025-08-14 21:46:54 --> Config Class Initialized
INFO - 2025-08-14 21:46:54 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:46:54 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:46:54 --> Utf8 Class Initialized
INFO - 2025-08-14 21:46:54 --> URI Class Initialized
INFO - 2025-08-14 21:46:54 --> Router Class Initialized
INFO - 2025-08-14 21:46:54 --> Output Class Initialized
INFO - 2025-08-14 21:46:54 --> Security Class Initialized
DEBUG - 2025-08-14 21:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:46:54 --> CSRF cookie sent
INFO - 2025-08-14 21:46:54 --> Input Class Initialized
INFO - 2025-08-14 21:46:54 --> Language Class Initialized
INFO - 2025-08-14 21:46:54 --> Loader Class Initialized
INFO - 2025-08-14 21:46:54 --> Helper loaded: url_helper
INFO - 2025-08-14 21:46:54 --> Helper loaded: form_helper
INFO - 2025-08-14 21:46:54 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:46:54 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:46:54 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:46:54 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:46:54 --> Database Driver Class Initialized
INFO - 2025-08-14 21:46:54 --> Form Validation Class Initialized
INFO - 2025-08-14 21:46:54 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:46:54 --> Controller Class Initialized
INFO - 2025-08-14 13:46:54 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:46:54 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:46:54 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:46:54 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:46:54 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:46:54 --> Final output sent to browser
DEBUG - 2025-08-14 13:46:54 --> Total execution time: 0.0786
INFO - 2025-08-14 21:47:19 --> Config Class Initialized
INFO - 2025-08-14 21:47:19 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:47:19 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:47:19 --> Utf8 Class Initialized
INFO - 2025-08-14 21:47:19 --> URI Class Initialized
INFO - 2025-08-14 21:47:19 --> Router Class Initialized
INFO - 2025-08-14 21:47:19 --> Output Class Initialized
INFO - 2025-08-14 21:47:19 --> Security Class Initialized
DEBUG - 2025-08-14 21:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:47:19 --> CSRF cookie sent
INFO - 2025-08-14 21:47:19 --> CSRF token verified
INFO - 2025-08-14 21:47:19 --> Input Class Initialized
INFO - 2025-08-14 21:47:19 --> Language Class Initialized
INFO - 2025-08-14 21:47:19 --> Loader Class Initialized
INFO - 2025-08-14 21:47:19 --> Helper loaded: url_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: form_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:47:19 --> Database Driver Class Initialized
INFO - 2025-08-14 21:47:19 --> Form Validation Class Initialized
INFO - 2025-08-14 21:47:19 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:47:19 --> Controller Class Initialized
INFO - 2025-08-14 13:47:19 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:47:19 --> Model "Items_model" initialized
INFO - 2025-08-14 13:47:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:47:19 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:47:19 --> Final output sent to browser
DEBUG - 2025-08-14 13:47:19 --> Total execution time: 0.0592
INFO - 2025-08-14 21:47:19 --> Config Class Initialized
INFO - 2025-08-14 21:47:19 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:47:19 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:47:19 --> Utf8 Class Initialized
INFO - 2025-08-14 21:47:19 --> URI Class Initialized
INFO - 2025-08-14 21:47:19 --> Router Class Initialized
INFO - 2025-08-14 21:47:19 --> Output Class Initialized
INFO - 2025-08-14 21:47:19 --> Security Class Initialized
DEBUG - 2025-08-14 21:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:47:19 --> CSRF cookie sent
INFO - 2025-08-14 21:47:19 --> Input Class Initialized
INFO - 2025-08-14 21:47:19 --> Language Class Initialized
INFO - 2025-08-14 21:47:19 --> Loader Class Initialized
INFO - 2025-08-14 21:47:19 --> Helper loaded: url_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: form_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:47:19 --> Database Driver Class Initialized
INFO - 2025-08-14 21:47:19 --> Form Validation Class Initialized
INFO - 2025-08-14 21:47:19 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:47:19 --> Controller Class Initialized
INFO - 2025-08-14 13:47:19 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:47:19 --> Model "Items_model" initialized
INFO - 2025-08-14 13:47:19 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:47:19 --> Final output sent to browser
DEBUG - 2025-08-14 13:47:19 --> Total execution time: 0.0450
INFO - 2025-08-14 21:47:19 --> Config Class Initialized
INFO - 2025-08-14 21:47:19 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:47:19 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:47:19 --> Utf8 Class Initialized
INFO - 2025-08-14 21:47:19 --> URI Class Initialized
INFO - 2025-08-14 21:47:19 --> Router Class Initialized
INFO - 2025-08-14 21:47:19 --> Output Class Initialized
INFO - 2025-08-14 21:47:19 --> Security Class Initialized
DEBUG - 2025-08-14 21:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:47:19 --> CSRF cookie sent
INFO - 2025-08-14 21:47:19 --> CSRF token verified
INFO - 2025-08-14 21:47:19 --> Input Class Initialized
INFO - 2025-08-14 21:47:19 --> Language Class Initialized
INFO - 2025-08-14 21:47:19 --> Loader Class Initialized
INFO - 2025-08-14 21:47:19 --> Helper loaded: url_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: form_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:47:19 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:47:19 --> Database Driver Class Initialized
INFO - 2025-08-14 21:47:19 --> Form Validation Class Initialized
INFO - 2025-08-14 21:47:19 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:47:19 --> Controller Class Initialized
INFO - 2025-08-14 13:47:19 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:47:19 --> Model "Items_model" initialized
INFO - 2025-08-14 13:47:19 --> Final output sent to browser
DEBUG - 2025-08-14 13:47:19 --> Total execution time: 0.0457
INFO - 2025-08-14 21:47:20 --> Config Class Initialized
INFO - 2025-08-14 21:47:20 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:47:20 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:47:20 --> Utf8 Class Initialized
INFO - 2025-08-14 21:47:20 --> URI Class Initialized
INFO - 2025-08-14 21:47:20 --> Router Class Initialized
INFO - 2025-08-14 21:47:20 --> Output Class Initialized
INFO - 2025-08-14 21:47:20 --> Security Class Initialized
DEBUG - 2025-08-14 21:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:47:20 --> CSRF cookie sent
INFO - 2025-08-14 21:47:20 --> Input Class Initialized
INFO - 2025-08-14 21:47:20 --> Language Class Initialized
INFO - 2025-08-14 21:47:20 --> Loader Class Initialized
INFO - 2025-08-14 21:47:20 --> Helper loaded: url_helper
INFO - 2025-08-14 21:47:20 --> Helper loaded: form_helper
INFO - 2025-08-14 21:47:20 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:47:20 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:47:20 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:47:20 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:47:20 --> Database Driver Class Initialized
INFO - 2025-08-14 21:47:21 --> Form Validation Class Initialized
INFO - 2025-08-14 21:47:21 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:47:21 --> Controller Class Initialized
INFO - 2025-08-14 13:47:21 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:47:21 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:47:21 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:47:21 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:47:21 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:47:21 --> Final output sent to browser
DEBUG - 2025-08-14 13:47:21 --> Total execution time: 0.0683
INFO - 2025-08-14 21:47:40 --> Config Class Initialized
INFO - 2025-08-14 21:47:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:47:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:47:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:47:40 --> URI Class Initialized
INFO - 2025-08-14 21:47:40 --> Router Class Initialized
INFO - 2025-08-14 21:47:40 --> Output Class Initialized
INFO - 2025-08-14 21:47:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:47:40 --> CSRF cookie sent
INFO - 2025-08-14 21:47:40 --> CSRF token verified
INFO - 2025-08-14 21:47:40 --> Input Class Initialized
INFO - 2025-08-14 21:47:40 --> Language Class Initialized
INFO - 2025-08-14 21:47:40 --> Loader Class Initialized
INFO - 2025-08-14 21:47:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:47:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:47:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:47:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:47:40 --> Controller Class Initialized
INFO - 2025-08-14 13:47:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:47:40 --> Model "Items_model" initialized
INFO - 2025-08-14 13:47:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:47:40 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:47:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:47:40 --> Total execution time: 0.0636
INFO - 2025-08-14 21:47:40 --> Config Class Initialized
INFO - 2025-08-14 21:47:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:47:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:47:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:47:40 --> URI Class Initialized
INFO - 2025-08-14 21:47:40 --> Router Class Initialized
INFO - 2025-08-14 21:47:40 --> Output Class Initialized
INFO - 2025-08-14 21:47:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:47:40 --> CSRF cookie sent
INFO - 2025-08-14 21:47:40 --> Input Class Initialized
INFO - 2025-08-14 21:47:40 --> Language Class Initialized
INFO - 2025-08-14 21:47:40 --> Loader Class Initialized
INFO - 2025-08-14 21:47:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:47:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:47:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:47:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:47:40 --> Controller Class Initialized
INFO - 2025-08-14 13:47:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:47:40 --> Model "Items_model" initialized
INFO - 2025-08-14 13:47:40 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:47:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:47:40 --> Total execution time: 0.0732
INFO - 2025-08-14 21:47:40 --> Config Class Initialized
INFO - 2025-08-14 21:47:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:47:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:47:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:47:40 --> URI Class Initialized
INFO - 2025-08-14 21:47:40 --> Router Class Initialized
INFO - 2025-08-14 21:47:40 --> Output Class Initialized
INFO - 2025-08-14 21:47:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:47:40 --> CSRF cookie sent
INFO - 2025-08-14 21:47:40 --> CSRF token verified
INFO - 2025-08-14 21:47:40 --> Input Class Initialized
INFO - 2025-08-14 21:47:40 --> Language Class Initialized
INFO - 2025-08-14 21:47:40 --> Loader Class Initialized
INFO - 2025-08-14 21:47:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:47:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:47:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:47:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:47:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:47:40 --> Controller Class Initialized
INFO - 2025-08-14 13:47:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:47:40 --> Model "Items_model" initialized
INFO - 2025-08-14 13:47:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:47:40 --> Total execution time: 0.0450
INFO - 2025-08-14 21:47:42 --> Config Class Initialized
INFO - 2025-08-14 21:47:42 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:47:42 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:47:42 --> Utf8 Class Initialized
INFO - 2025-08-14 21:47:42 --> URI Class Initialized
INFO - 2025-08-14 21:47:42 --> Router Class Initialized
INFO - 2025-08-14 21:47:42 --> Output Class Initialized
INFO - 2025-08-14 21:47:42 --> Security Class Initialized
DEBUG - 2025-08-14 21:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:47:42 --> CSRF cookie sent
INFO - 2025-08-14 21:47:42 --> Input Class Initialized
INFO - 2025-08-14 21:47:42 --> Language Class Initialized
INFO - 2025-08-14 21:47:42 --> Loader Class Initialized
INFO - 2025-08-14 21:47:42 --> Helper loaded: url_helper
INFO - 2025-08-14 21:47:42 --> Helper loaded: form_helper
INFO - 2025-08-14 21:47:42 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:47:42 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:47:42 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:47:42 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:47:42 --> Database Driver Class Initialized
INFO - 2025-08-14 21:47:42 --> Form Validation Class Initialized
INFO - 2025-08-14 21:47:42 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:47:42 --> Controller Class Initialized
INFO - 2025-08-14 13:47:42 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:47:42 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:47:42 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:47:42 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:47:42 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:47:42 --> Final output sent to browser
DEBUG - 2025-08-14 13:47:42 --> Total execution time: 0.0668
INFO - 2025-08-14 21:48:02 --> Config Class Initialized
INFO - 2025-08-14 21:48:02 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:48:02 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:48:02 --> Utf8 Class Initialized
INFO - 2025-08-14 21:48:02 --> URI Class Initialized
INFO - 2025-08-14 21:48:02 --> Router Class Initialized
INFO - 2025-08-14 21:48:02 --> Output Class Initialized
INFO - 2025-08-14 21:48:02 --> Security Class Initialized
DEBUG - 2025-08-14 21:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:48:02 --> CSRF cookie sent
INFO - 2025-08-14 21:48:02 --> CSRF token verified
INFO - 2025-08-14 21:48:02 --> Input Class Initialized
INFO - 2025-08-14 21:48:02 --> Language Class Initialized
INFO - 2025-08-14 21:48:02 --> Loader Class Initialized
INFO - 2025-08-14 21:48:02 --> Helper loaded: url_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: form_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:48:02 --> Database Driver Class Initialized
INFO - 2025-08-14 21:48:02 --> Form Validation Class Initialized
INFO - 2025-08-14 21:48:02 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:48:02 --> Controller Class Initialized
INFO - 2025-08-14 13:48:02 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:48:02 --> Model "Items_model" initialized
INFO - 2025-08-14 13:48:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:48:02 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:48:02 --> Final output sent to browser
DEBUG - 2025-08-14 13:48:02 --> Total execution time: 0.0782
INFO - 2025-08-14 21:48:02 --> Config Class Initialized
INFO - 2025-08-14 21:48:02 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:48:02 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:48:02 --> Utf8 Class Initialized
INFO - 2025-08-14 21:48:02 --> URI Class Initialized
INFO - 2025-08-14 21:48:02 --> Router Class Initialized
INFO - 2025-08-14 21:48:02 --> Output Class Initialized
INFO - 2025-08-14 21:48:02 --> Security Class Initialized
DEBUG - 2025-08-14 21:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:48:02 --> CSRF cookie sent
INFO - 2025-08-14 21:48:02 --> Input Class Initialized
INFO - 2025-08-14 21:48:02 --> Language Class Initialized
INFO - 2025-08-14 21:48:02 --> Loader Class Initialized
INFO - 2025-08-14 21:48:02 --> Helper loaded: url_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: form_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:48:02 --> Database Driver Class Initialized
INFO - 2025-08-14 21:48:02 --> Form Validation Class Initialized
INFO - 2025-08-14 21:48:02 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:48:02 --> Controller Class Initialized
INFO - 2025-08-14 13:48:02 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:48:02 --> Model "Items_model" initialized
INFO - 2025-08-14 13:48:02 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:48:02 --> Final output sent to browser
DEBUG - 2025-08-14 13:48:02 --> Total execution time: 0.0727
INFO - 2025-08-14 21:48:02 --> Config Class Initialized
INFO - 2025-08-14 21:48:02 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:48:02 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:48:02 --> Utf8 Class Initialized
INFO - 2025-08-14 21:48:02 --> URI Class Initialized
INFO - 2025-08-14 21:48:02 --> Router Class Initialized
INFO - 2025-08-14 21:48:02 --> Output Class Initialized
INFO - 2025-08-14 21:48:02 --> Security Class Initialized
DEBUG - 2025-08-14 21:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:48:02 --> CSRF cookie sent
INFO - 2025-08-14 21:48:02 --> CSRF token verified
INFO - 2025-08-14 21:48:02 --> Input Class Initialized
INFO - 2025-08-14 21:48:02 --> Language Class Initialized
INFO - 2025-08-14 21:48:02 --> Loader Class Initialized
INFO - 2025-08-14 21:48:02 --> Helper loaded: url_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: form_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:48:02 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:48:02 --> Database Driver Class Initialized
INFO - 2025-08-14 21:48:02 --> Form Validation Class Initialized
INFO - 2025-08-14 21:48:02 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:48:02 --> Controller Class Initialized
INFO - 2025-08-14 13:48:02 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:48:02 --> Model "Items_model" initialized
INFO - 2025-08-14 13:48:02 --> Final output sent to browser
DEBUG - 2025-08-14 13:48:02 --> Total execution time: 0.0483
INFO - 2025-08-14 21:48:25 --> Config Class Initialized
INFO - 2025-08-14 21:48:25 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:48:25 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:48:25 --> Utf8 Class Initialized
INFO - 2025-08-14 21:48:25 --> URI Class Initialized
INFO - 2025-08-14 21:48:25 --> Router Class Initialized
INFO - 2025-08-14 21:48:25 --> Output Class Initialized
INFO - 2025-08-14 21:48:25 --> Security Class Initialized
DEBUG - 2025-08-14 21:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:48:25 --> CSRF cookie sent
INFO - 2025-08-14 21:48:25 --> Input Class Initialized
INFO - 2025-08-14 21:48:25 --> Language Class Initialized
INFO - 2025-08-14 21:48:25 --> Loader Class Initialized
INFO - 2025-08-14 21:48:25 --> Helper loaded: url_helper
INFO - 2025-08-14 21:48:25 --> Helper loaded: form_helper
INFO - 2025-08-14 21:48:25 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:48:25 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:48:25 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:48:25 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:48:25 --> Database Driver Class Initialized
INFO - 2025-08-14 21:48:25 --> Form Validation Class Initialized
INFO - 2025-08-14 21:48:25 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:48:25 --> Controller Class Initialized
INFO - 2025-08-14 13:48:25 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:48:25 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:48:25 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:48:25 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:48:25 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:48:25 --> Final output sent to browser
DEBUG - 2025-08-14 13:48:25 --> Total execution time: 0.0572
INFO - 2025-08-14 21:48:44 --> Config Class Initialized
INFO - 2025-08-14 21:48:44 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:48:44 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:48:44 --> Utf8 Class Initialized
INFO - 2025-08-14 21:48:44 --> URI Class Initialized
INFO - 2025-08-14 21:48:44 --> Router Class Initialized
INFO - 2025-08-14 21:48:44 --> Output Class Initialized
INFO - 2025-08-14 21:48:44 --> Security Class Initialized
DEBUG - 2025-08-14 21:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:48:44 --> CSRF cookie sent
INFO - 2025-08-14 21:48:44 --> CSRF token verified
INFO - 2025-08-14 21:48:44 --> Input Class Initialized
INFO - 2025-08-14 21:48:44 --> Language Class Initialized
INFO - 2025-08-14 21:48:44 --> Loader Class Initialized
INFO - 2025-08-14 21:48:44 --> Helper loaded: url_helper
INFO - 2025-08-14 21:48:44 --> Helper loaded: form_helper
INFO - 2025-08-14 21:48:44 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:48:44 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:48:44 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:48:44 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:48:45 --> Database Driver Class Initialized
INFO - 2025-08-14 21:48:45 --> Form Validation Class Initialized
INFO - 2025-08-14 21:48:45 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:48:45 --> Controller Class Initialized
INFO - 2025-08-14 13:48:45 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:48:45 --> Model "Items_model" initialized
INFO - 2025-08-14 13:48:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:48:45 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:48:45 --> Final output sent to browser
DEBUG - 2025-08-14 13:48:45 --> Total execution time: 0.0594
INFO - 2025-08-14 21:48:45 --> Config Class Initialized
INFO - 2025-08-14 21:48:45 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:48:45 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:48:45 --> Utf8 Class Initialized
INFO - 2025-08-14 21:48:45 --> URI Class Initialized
INFO - 2025-08-14 21:48:45 --> Router Class Initialized
INFO - 2025-08-14 21:48:45 --> Output Class Initialized
INFO - 2025-08-14 21:48:45 --> Security Class Initialized
DEBUG - 2025-08-14 21:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:48:45 --> CSRF cookie sent
INFO - 2025-08-14 21:48:45 --> Input Class Initialized
INFO - 2025-08-14 21:48:45 --> Language Class Initialized
INFO - 2025-08-14 21:48:45 --> Loader Class Initialized
INFO - 2025-08-14 21:48:45 --> Helper loaded: url_helper
INFO - 2025-08-14 21:48:45 --> Helper loaded: form_helper
INFO - 2025-08-14 21:48:45 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:48:45 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:48:45 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:48:45 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:48:45 --> Database Driver Class Initialized
INFO - 2025-08-14 21:48:45 --> Form Validation Class Initialized
INFO - 2025-08-14 21:48:45 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:48:45 --> Controller Class Initialized
INFO - 2025-08-14 13:48:45 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:48:45 --> Model "Items_model" initialized
INFO - 2025-08-14 13:48:45 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:48:45 --> Final output sent to browser
DEBUG - 2025-08-14 13:48:45 --> Total execution time: 0.0702
INFO - 2025-08-14 21:48:45 --> Config Class Initialized
INFO - 2025-08-14 21:48:45 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:48:45 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:48:45 --> Utf8 Class Initialized
INFO - 2025-08-14 21:48:45 --> URI Class Initialized
INFO - 2025-08-14 21:48:45 --> Router Class Initialized
INFO - 2025-08-14 21:48:45 --> Output Class Initialized
INFO - 2025-08-14 21:48:45 --> Security Class Initialized
DEBUG - 2025-08-14 21:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:48:45 --> CSRF cookie sent
INFO - 2025-08-14 21:48:45 --> CSRF token verified
INFO - 2025-08-14 21:48:45 --> Input Class Initialized
INFO - 2025-08-14 21:48:45 --> Language Class Initialized
INFO - 2025-08-14 21:48:45 --> Loader Class Initialized
INFO - 2025-08-14 21:48:45 --> Helper loaded: url_helper
INFO - 2025-08-14 21:48:45 --> Helper loaded: form_helper
INFO - 2025-08-14 21:48:45 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:48:45 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:48:45 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:48:45 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:48:45 --> Database Driver Class Initialized
INFO - 2025-08-14 21:48:45 --> Form Validation Class Initialized
INFO - 2025-08-14 21:48:45 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:48:45 --> Controller Class Initialized
INFO - 2025-08-14 13:48:45 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:48:45 --> Model "Items_model" initialized
INFO - 2025-08-14 13:48:45 --> Final output sent to browser
DEBUG - 2025-08-14 13:48:45 --> Total execution time: 0.0459
INFO - 2025-08-14 21:48:54 --> Config Class Initialized
INFO - 2025-08-14 21:48:54 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:48:54 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:48:54 --> Utf8 Class Initialized
INFO - 2025-08-14 21:48:54 --> URI Class Initialized
INFO - 2025-08-14 21:48:54 --> Router Class Initialized
INFO - 2025-08-14 21:48:54 --> Output Class Initialized
INFO - 2025-08-14 21:48:54 --> Security Class Initialized
DEBUG - 2025-08-14 21:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:48:54 --> CSRF cookie sent
INFO - 2025-08-14 21:48:54 --> Input Class Initialized
INFO - 2025-08-14 21:48:54 --> Language Class Initialized
INFO - 2025-08-14 21:48:54 --> Loader Class Initialized
INFO - 2025-08-14 21:48:54 --> Helper loaded: url_helper
INFO - 2025-08-14 21:48:54 --> Helper loaded: form_helper
INFO - 2025-08-14 21:48:54 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:48:54 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:48:54 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:48:54 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:48:54 --> Database Driver Class Initialized
INFO - 2025-08-14 21:48:54 --> Form Validation Class Initialized
INFO - 2025-08-14 21:48:54 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:48:54 --> Controller Class Initialized
INFO - 2025-08-14 13:48:54 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:48:54 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:48:54 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:48:54 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:48:54 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:48:54 --> Final output sent to browser
DEBUG - 2025-08-14 13:48:54 --> Total execution time: 0.0717
INFO - 2025-08-14 21:49:17 --> Config Class Initialized
INFO - 2025-08-14 21:49:17 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:49:17 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:49:17 --> Utf8 Class Initialized
INFO - 2025-08-14 21:49:17 --> URI Class Initialized
INFO - 2025-08-14 21:49:17 --> Router Class Initialized
INFO - 2025-08-14 21:49:17 --> Output Class Initialized
INFO - 2025-08-14 21:49:17 --> Security Class Initialized
DEBUG - 2025-08-14 21:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:49:17 --> CSRF cookie sent
INFO - 2025-08-14 21:49:17 --> CSRF token verified
INFO - 2025-08-14 21:49:17 --> Input Class Initialized
INFO - 2025-08-14 21:49:17 --> Language Class Initialized
INFO - 2025-08-14 21:49:17 --> Loader Class Initialized
INFO - 2025-08-14 21:49:17 --> Helper loaded: url_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: form_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:49:17 --> Database Driver Class Initialized
INFO - 2025-08-14 21:49:17 --> Form Validation Class Initialized
INFO - 2025-08-14 21:49:17 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:49:17 --> Controller Class Initialized
INFO - 2025-08-14 13:49:17 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:49:17 --> Model "Items_model" initialized
INFO - 2025-08-14 13:49:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:49:17 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:49:17 --> Final output sent to browser
DEBUG - 2025-08-14 13:49:17 --> Total execution time: 0.0605
INFO - 2025-08-14 21:49:17 --> Config Class Initialized
INFO - 2025-08-14 21:49:17 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:49:17 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:49:17 --> Utf8 Class Initialized
INFO - 2025-08-14 21:49:17 --> URI Class Initialized
INFO - 2025-08-14 21:49:17 --> Router Class Initialized
INFO - 2025-08-14 21:49:17 --> Output Class Initialized
INFO - 2025-08-14 21:49:17 --> Security Class Initialized
DEBUG - 2025-08-14 21:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:49:17 --> CSRF cookie sent
INFO - 2025-08-14 21:49:17 --> Input Class Initialized
INFO - 2025-08-14 21:49:17 --> Language Class Initialized
INFO - 2025-08-14 21:49:17 --> Loader Class Initialized
INFO - 2025-08-14 21:49:17 --> Helper loaded: url_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: form_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:49:17 --> Database Driver Class Initialized
INFO - 2025-08-14 21:49:17 --> Form Validation Class Initialized
INFO - 2025-08-14 21:49:17 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:49:17 --> Controller Class Initialized
INFO - 2025-08-14 13:49:17 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:49:17 --> Model "Items_model" initialized
INFO - 2025-08-14 13:49:17 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:49:17 --> Final output sent to browser
DEBUG - 2025-08-14 13:49:17 --> Total execution time: 0.0800
INFO - 2025-08-14 21:49:17 --> Config Class Initialized
INFO - 2025-08-14 21:49:17 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:49:17 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:49:17 --> Utf8 Class Initialized
INFO - 2025-08-14 21:49:17 --> URI Class Initialized
INFO - 2025-08-14 21:49:17 --> Router Class Initialized
INFO - 2025-08-14 21:49:17 --> Output Class Initialized
INFO - 2025-08-14 21:49:17 --> Security Class Initialized
DEBUG - 2025-08-14 21:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:49:17 --> CSRF cookie sent
INFO - 2025-08-14 21:49:17 --> CSRF token verified
INFO - 2025-08-14 21:49:17 --> Input Class Initialized
INFO - 2025-08-14 21:49:17 --> Language Class Initialized
INFO - 2025-08-14 21:49:17 --> Loader Class Initialized
INFO - 2025-08-14 21:49:17 --> Helper loaded: url_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: form_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:49:17 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:49:17 --> Database Driver Class Initialized
INFO - 2025-08-14 21:49:17 --> Form Validation Class Initialized
INFO - 2025-08-14 21:49:17 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:49:17 --> Controller Class Initialized
INFO - 2025-08-14 13:49:17 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:49:17 --> Model "Items_model" initialized
INFO - 2025-08-14 13:49:17 --> Final output sent to browser
DEBUG - 2025-08-14 13:49:17 --> Total execution time: 0.0450
INFO - 2025-08-14 21:49:26 --> Config Class Initialized
INFO - 2025-08-14 21:49:26 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:49:26 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:49:26 --> Utf8 Class Initialized
INFO - 2025-08-14 21:49:26 --> URI Class Initialized
INFO - 2025-08-14 21:49:26 --> Router Class Initialized
INFO - 2025-08-14 21:49:26 --> Output Class Initialized
INFO - 2025-08-14 21:49:26 --> Security Class Initialized
DEBUG - 2025-08-14 21:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:49:26 --> CSRF cookie sent
INFO - 2025-08-14 21:49:26 --> Input Class Initialized
INFO - 2025-08-14 21:49:26 --> Language Class Initialized
INFO - 2025-08-14 21:49:26 --> Loader Class Initialized
INFO - 2025-08-14 21:49:26 --> Helper loaded: url_helper
INFO - 2025-08-14 21:49:26 --> Helper loaded: form_helper
INFO - 2025-08-14 21:49:26 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:49:26 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:49:26 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:49:26 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:49:26 --> Database Driver Class Initialized
INFO - 2025-08-14 21:49:26 --> Form Validation Class Initialized
INFO - 2025-08-14 21:49:26 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:49:26 --> Controller Class Initialized
INFO - 2025-08-14 13:49:26 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:49:26 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:49:26 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:49:26 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:49:26 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:49:26 --> Final output sent to browser
DEBUG - 2025-08-14 13:49:26 --> Total execution time: 0.0644
INFO - 2025-08-14 21:49:55 --> Config Class Initialized
INFO - 2025-08-14 21:49:55 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:49:55 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:49:55 --> Utf8 Class Initialized
INFO - 2025-08-14 21:49:55 --> URI Class Initialized
INFO - 2025-08-14 21:49:55 --> Router Class Initialized
INFO - 2025-08-14 21:49:55 --> Output Class Initialized
INFO - 2025-08-14 21:49:55 --> Security Class Initialized
DEBUG - 2025-08-14 21:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:49:55 --> CSRF cookie sent
INFO - 2025-08-14 21:49:55 --> CSRF token verified
INFO - 2025-08-14 21:49:55 --> Input Class Initialized
INFO - 2025-08-14 21:49:55 --> Language Class Initialized
INFO - 2025-08-14 21:49:55 --> Loader Class Initialized
INFO - 2025-08-14 21:49:55 --> Helper loaded: url_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: form_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:49:55 --> Database Driver Class Initialized
INFO - 2025-08-14 21:49:55 --> Form Validation Class Initialized
INFO - 2025-08-14 21:49:55 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:49:55 --> Controller Class Initialized
INFO - 2025-08-14 13:49:55 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:49:55 --> Model "Items_model" initialized
INFO - 2025-08-14 13:49:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:49:55 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:49:55 --> Final output sent to browser
DEBUG - 2025-08-14 13:49:55 --> Total execution time: 0.0562
INFO - 2025-08-14 21:49:55 --> Config Class Initialized
INFO - 2025-08-14 21:49:55 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:49:55 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:49:55 --> Utf8 Class Initialized
INFO - 2025-08-14 21:49:55 --> URI Class Initialized
INFO - 2025-08-14 21:49:55 --> Router Class Initialized
INFO - 2025-08-14 21:49:55 --> Output Class Initialized
INFO - 2025-08-14 21:49:55 --> Security Class Initialized
DEBUG - 2025-08-14 21:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:49:55 --> CSRF cookie sent
INFO - 2025-08-14 21:49:55 --> Input Class Initialized
INFO - 2025-08-14 21:49:55 --> Language Class Initialized
INFO - 2025-08-14 21:49:55 --> Loader Class Initialized
INFO - 2025-08-14 21:49:55 --> Helper loaded: url_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: form_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:49:55 --> Database Driver Class Initialized
INFO - 2025-08-14 21:49:55 --> Form Validation Class Initialized
INFO - 2025-08-14 21:49:55 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:49:55 --> Controller Class Initialized
INFO - 2025-08-14 13:49:55 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:49:55 --> Model "Items_model" initialized
INFO - 2025-08-14 13:49:55 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:49:55 --> Final output sent to browser
DEBUG - 2025-08-14 13:49:55 --> Total execution time: 0.0675
INFO - 2025-08-14 21:49:55 --> Config Class Initialized
INFO - 2025-08-14 21:49:55 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:49:55 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:49:55 --> Utf8 Class Initialized
INFO - 2025-08-14 21:49:55 --> URI Class Initialized
INFO - 2025-08-14 21:49:55 --> Router Class Initialized
INFO - 2025-08-14 21:49:55 --> Output Class Initialized
INFO - 2025-08-14 21:49:55 --> Security Class Initialized
DEBUG - 2025-08-14 21:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:49:55 --> CSRF cookie sent
INFO - 2025-08-14 21:49:55 --> CSRF token verified
INFO - 2025-08-14 21:49:55 --> Input Class Initialized
INFO - 2025-08-14 21:49:55 --> Language Class Initialized
INFO - 2025-08-14 21:49:55 --> Loader Class Initialized
INFO - 2025-08-14 21:49:55 --> Helper loaded: url_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: form_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:49:55 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:49:55 --> Database Driver Class Initialized
INFO - 2025-08-14 21:49:55 --> Form Validation Class Initialized
INFO - 2025-08-14 21:49:55 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:49:55 --> Controller Class Initialized
INFO - 2025-08-14 13:49:55 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:49:55 --> Model "Items_model" initialized
INFO - 2025-08-14 13:49:55 --> Final output sent to browser
DEBUG - 2025-08-14 13:49:55 --> Total execution time: 0.0472
INFO - 2025-08-14 21:50:05 --> Config Class Initialized
INFO - 2025-08-14 21:50:05 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:50:05 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:50:05 --> Utf8 Class Initialized
INFO - 2025-08-14 21:50:05 --> URI Class Initialized
INFO - 2025-08-14 21:50:05 --> Router Class Initialized
INFO - 2025-08-14 21:50:05 --> Output Class Initialized
INFO - 2025-08-14 21:50:05 --> Security Class Initialized
DEBUG - 2025-08-14 21:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:50:05 --> CSRF cookie sent
INFO - 2025-08-14 21:50:05 --> Input Class Initialized
INFO - 2025-08-14 21:50:05 --> Language Class Initialized
INFO - 2025-08-14 21:50:05 --> Loader Class Initialized
INFO - 2025-08-14 21:50:05 --> Helper loaded: url_helper
INFO - 2025-08-14 21:50:05 --> Helper loaded: form_helper
INFO - 2025-08-14 21:50:05 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:50:05 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:50:05 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:50:05 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:50:05 --> Database Driver Class Initialized
INFO - 2025-08-14 21:50:05 --> Form Validation Class Initialized
INFO - 2025-08-14 21:50:05 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:50:05 --> Controller Class Initialized
INFO - 2025-08-14 13:50:05 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:50:05 --> Model "Items_model" initialized
ERROR - 2025-08-14 13:50:05 --> Could not find the language line "add_unit"
ERROR - 2025-08-14 13:50:05 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:50:05 --> File loaded: C:\xampp\htdocs\application\views\items.php
INFO - 2025-08-14 13:50:05 --> Final output sent to browser
DEBUG - 2025-08-14 13:50:05 --> Total execution time: 0.0768
INFO - 2025-08-14 21:51:11 --> Config Class Initialized
INFO - 2025-08-14 21:51:11 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:51:11 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:51:11 --> Utf8 Class Initialized
INFO - 2025-08-14 21:51:11 --> URI Class Initialized
INFO - 2025-08-14 21:51:11 --> Router Class Initialized
INFO - 2025-08-14 21:51:11 --> Output Class Initialized
INFO - 2025-08-14 21:51:11 --> Security Class Initialized
DEBUG - 2025-08-14 21:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:51:11 --> CSRF cookie sent
INFO - 2025-08-14 21:51:11 --> CSRF token verified
INFO - 2025-08-14 21:51:11 --> Input Class Initialized
INFO - 2025-08-14 21:51:11 --> Language Class Initialized
INFO - 2025-08-14 21:51:11 --> Loader Class Initialized
INFO - 2025-08-14 21:51:11 --> Helper loaded: url_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: form_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:51:11 --> Database Driver Class Initialized
INFO - 2025-08-14 21:51:11 --> Form Validation Class Initialized
INFO - 2025-08-14 21:51:11 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:51:11 --> Controller Class Initialized
INFO - 2025-08-14 13:51:11 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:51:11 --> Model "Items_model" initialized
INFO - 2025-08-14 13:51:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-14 13:51:11 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:51:11 --> Final output sent to browser
DEBUG - 2025-08-14 13:51:11 --> Total execution time: 0.0576
INFO - 2025-08-14 21:51:11 --> Config Class Initialized
INFO - 2025-08-14 21:51:11 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:51:11 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:51:11 --> Utf8 Class Initialized
INFO - 2025-08-14 21:51:11 --> URI Class Initialized
INFO - 2025-08-14 21:51:11 --> Router Class Initialized
INFO - 2025-08-14 21:51:11 --> Output Class Initialized
INFO - 2025-08-14 21:51:11 --> Security Class Initialized
DEBUG - 2025-08-14 21:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:51:11 --> CSRF cookie sent
INFO - 2025-08-14 21:51:11 --> Input Class Initialized
INFO - 2025-08-14 21:51:11 --> Language Class Initialized
INFO - 2025-08-14 21:51:11 --> Loader Class Initialized
INFO - 2025-08-14 21:51:11 --> Helper loaded: url_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: form_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:51:11 --> Database Driver Class Initialized
INFO - 2025-08-14 21:51:11 --> Form Validation Class Initialized
INFO - 2025-08-14 21:51:11 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:51:11 --> Controller Class Initialized
INFO - 2025-08-14 13:51:11 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:51:11 --> Model "Items_model" initialized
INFO - 2025-08-14 13:51:11 --> File loaded: C:\xampp\htdocs\application\views\items-list.php
INFO - 2025-08-14 13:51:11 --> Final output sent to browser
DEBUG - 2025-08-14 13:51:11 --> Total execution time: 0.0515
INFO - 2025-08-14 21:51:11 --> Config Class Initialized
INFO - 2025-08-14 21:51:11 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:51:11 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:51:11 --> Utf8 Class Initialized
INFO - 2025-08-14 21:51:11 --> URI Class Initialized
INFO - 2025-08-14 21:51:11 --> Router Class Initialized
INFO - 2025-08-14 21:51:11 --> Output Class Initialized
INFO - 2025-08-14 21:51:11 --> Security Class Initialized
DEBUG - 2025-08-14 21:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:51:11 --> CSRF cookie sent
INFO - 2025-08-14 21:51:11 --> CSRF token verified
INFO - 2025-08-14 21:51:11 --> Input Class Initialized
INFO - 2025-08-14 21:51:11 --> Language Class Initialized
INFO - 2025-08-14 21:51:11 --> Loader Class Initialized
INFO - 2025-08-14 21:51:11 --> Helper loaded: url_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: form_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:51:11 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:51:11 --> Database Driver Class Initialized
INFO - 2025-08-14 21:51:11 --> Form Validation Class Initialized
INFO - 2025-08-14 21:51:11 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:51:11 --> Controller Class Initialized
INFO - 2025-08-14 13:51:11 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:51:11 --> Model "Items_model" initialized
INFO - 2025-08-14 13:51:11 --> Final output sent to browser
DEBUG - 2025-08-14 13:51:11 --> Total execution time: 0.0484
INFO - 2025-08-14 21:51:31 --> Config Class Initialized
INFO - 2025-08-14 21:51:31 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:51:31 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:51:31 --> Utf8 Class Initialized
INFO - 2025-08-14 21:51:31 --> URI Class Initialized
INFO - 2025-08-14 21:51:31 --> Router Class Initialized
INFO - 2025-08-14 21:51:31 --> Output Class Initialized
INFO - 2025-08-14 21:51:31 --> Security Class Initialized
DEBUG - 2025-08-14 21:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:51:31 --> CSRF cookie sent
INFO - 2025-08-14 21:51:31 --> Input Class Initialized
INFO - 2025-08-14 21:51:31 --> Language Class Initialized
INFO - 2025-08-14 21:51:31 --> Loader Class Initialized
INFO - 2025-08-14 21:51:31 --> Helper loaded: url_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: form_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:51:31 --> Database Driver Class Initialized
INFO - 2025-08-14 21:51:31 --> Form Validation Class Initialized
INFO - 2025-08-14 21:51:31 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:51:31 --> Controller Class Initialized
INFO - 2025-08-14 13:51:31 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:51:31 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:51:31 --> Helper loaded: sms_template_helper
ERROR - 2025-08-14 13:51:31 --> Could not find the language line "previous_due"
ERROR - 2025-08-14 13:51:31 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:51:31 --> File loaded: C:\xampp\htdocs\application\views\pos.php
INFO - 2025-08-14 13:51:31 --> Final output sent to browser
DEBUG - 2025-08-14 13:51:31 --> Total execution time: 0.0690
INFO - 2025-08-14 21:51:31 --> Config Class Initialized
INFO - 2025-08-14 21:51:31 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:51:31 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:51:31 --> Utf8 Class Initialized
INFO - 2025-08-14 21:51:31 --> URI Class Initialized
INFO - 2025-08-14 21:51:31 --> Router Class Initialized
INFO - 2025-08-14 21:51:31 --> Output Class Initialized
INFO - 2025-08-14 21:51:31 --> Security Class Initialized
DEBUG - 2025-08-14 21:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:51:31 --> CSRF cookie sent
INFO - 2025-08-14 21:51:31 --> CSRF token verified
INFO - 2025-08-14 21:51:31 --> Input Class Initialized
INFO - 2025-08-14 21:51:31 --> Language Class Initialized
INFO - 2025-08-14 21:51:31 --> Loader Class Initialized
INFO - 2025-08-14 21:51:31 --> Helper loaded: url_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: form_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:51:31 --> Database Driver Class Initialized
INFO - 2025-08-14 21:51:31 --> Form Validation Class Initialized
INFO - 2025-08-14 21:51:31 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:51:31 --> Controller Class Initialized
INFO - 2025-08-14 13:51:31 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:51:31 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:51:31 --> Final output sent to browser
DEBUG - 2025-08-14 13:51:31 --> Total execution time: 0.0444
INFO - 2025-08-14 21:51:31 --> Config Class Initialized
INFO - 2025-08-14 21:51:31 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:51:31 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:51:31 --> Utf8 Class Initialized
INFO - 2025-08-14 21:51:31 --> URI Class Initialized
INFO - 2025-08-14 21:51:31 --> Router Class Initialized
INFO - 2025-08-14 21:51:31 --> Output Class Initialized
INFO - 2025-08-14 21:51:31 --> Security Class Initialized
DEBUG - 2025-08-14 21:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:51:31 --> CSRF cookie sent
INFO - 2025-08-14 21:51:31 --> CSRF token verified
INFO - 2025-08-14 21:51:31 --> Input Class Initialized
INFO - 2025-08-14 21:51:31 --> Language Class Initialized
INFO - 2025-08-14 21:51:31 --> Loader Class Initialized
INFO - 2025-08-14 21:51:31 --> Helper loaded: url_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: form_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:51:31 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:51:31 --> Database Driver Class Initialized
INFO - 2025-08-14 21:51:31 --> Form Validation Class Initialized
INFO - 2025-08-14 21:51:31 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:51:31 --> Controller Class Initialized
INFO - 2025-08-14 13:51:31 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:51:31 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:51:31 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:51:31 --> Final output sent to browser
DEBUG - 2025-08-14 13:51:31 --> Total execution time: 0.0517
INFO - 2025-08-14 21:51:31 --> Config Class Initialized
INFO - 2025-08-14 21:51:31 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:51:31 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:51:31 --> Utf8 Class Initialized
INFO - 2025-08-14 21:51:31 --> URI Class Initialized
INFO - 2025-08-14 21:51:31 --> Router Class Initialized
INFO - 2025-08-14 21:51:31 --> Output Class Initialized
INFO - 2025-08-14 21:51:31 --> Security Class Initialized
DEBUG - 2025-08-14 21:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:51:31 --> CSRF cookie sent
INFO - 2025-08-14 21:51:31 --> Input Class Initialized
INFO - 2025-08-14 21:51:31 --> Language Class Initialized
ERROR - 2025-08-14 21:51:31 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:51:37 --> Config Class Initialized
INFO - 2025-08-14 21:51:37 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:51:37 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:51:37 --> Utf8 Class Initialized
INFO - 2025-08-14 21:51:37 --> URI Class Initialized
INFO - 2025-08-14 21:51:37 --> Router Class Initialized
INFO - 2025-08-14 21:51:37 --> Output Class Initialized
INFO - 2025-08-14 21:51:37 --> Security Class Initialized
DEBUG - 2025-08-14 21:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:51:37 --> CSRF cookie sent
INFO - 2025-08-14 21:51:37 --> CSRF token verified
INFO - 2025-08-14 21:51:37 --> Input Class Initialized
INFO - 2025-08-14 21:51:37 --> Language Class Initialized
INFO - 2025-08-14 21:51:37 --> Loader Class Initialized
INFO - 2025-08-14 21:51:37 --> Helper loaded: url_helper
INFO - 2025-08-14 21:51:37 --> Helper loaded: form_helper
INFO - 2025-08-14 21:51:37 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:51:37 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:51:37 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:51:37 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:51:37 --> Database Driver Class Initialized
INFO - 2025-08-14 21:51:37 --> Form Validation Class Initialized
INFO - 2025-08-14 21:51:37 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:51:37 --> Controller Class Initialized
INFO - 2025-08-14 13:51:37 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:51:37 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:51:37 --> Final output sent to browser
DEBUG - 2025-08-14 13:51:37 --> Total execution time: 0.0551
INFO - 2025-08-14 21:51:50 --> Config Class Initialized
INFO - 2025-08-14 21:51:50 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:51:50 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:51:50 --> Utf8 Class Initialized
INFO - 2025-08-14 21:51:50 --> URI Class Initialized
INFO - 2025-08-14 21:51:50 --> Router Class Initialized
INFO - 2025-08-14 21:51:50 --> Output Class Initialized
INFO - 2025-08-14 21:51:50 --> Security Class Initialized
DEBUG - 2025-08-14 21:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:51:50 --> CSRF cookie sent
INFO - 2025-08-14 21:51:50 --> CSRF token verified
INFO - 2025-08-14 21:51:50 --> Input Class Initialized
INFO - 2025-08-14 21:51:50 --> Language Class Initialized
INFO - 2025-08-14 21:51:50 --> Loader Class Initialized
INFO - 2025-08-14 21:51:50 --> Helper loaded: url_helper
INFO - 2025-08-14 21:51:50 --> Helper loaded: form_helper
INFO - 2025-08-14 21:51:50 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:51:50 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:51:50 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:51:50 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:51:50 --> Database Driver Class Initialized
INFO - 2025-08-14 21:51:50 --> Form Validation Class Initialized
INFO - 2025-08-14 21:51:50 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:51:50 --> Controller Class Initialized
INFO - 2025-08-14 13:51:50 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:51:50 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:51:50 --> Final output sent to browser
DEBUG - 2025-08-14 13:51:50 --> Total execution time: 0.0438
INFO - 2025-08-14 21:51:59 --> Config Class Initialized
INFO - 2025-08-14 21:51:59 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:51:59 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:51:59 --> Utf8 Class Initialized
INFO - 2025-08-14 21:51:59 --> URI Class Initialized
INFO - 2025-08-14 21:51:59 --> Router Class Initialized
INFO - 2025-08-14 21:51:59 --> Output Class Initialized
INFO - 2025-08-14 21:51:59 --> Security Class Initialized
DEBUG - 2025-08-14 21:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:51:59 --> CSRF cookie sent
INFO - 2025-08-14 21:51:59 --> Input Class Initialized
INFO - 2025-08-14 21:51:59 --> Language Class Initialized
INFO - 2025-08-14 21:51:59 --> Loader Class Initialized
INFO - 2025-08-14 21:51:59 --> Helper loaded: url_helper
INFO - 2025-08-14 21:51:59 --> Helper loaded: form_helper
INFO - 2025-08-14 21:51:59 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:51:59 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:51:59 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:51:59 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:51:59 --> Database Driver Class Initialized
INFO - 2025-08-14 21:51:59 --> Form Validation Class Initialized
INFO - 2025-08-14 21:51:59 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:51:59 --> Controller Class Initialized
INFO - 2025-08-14 13:51:59 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:51:59 --> Model "Items_model" initialized
INFO - 2025-08-14 21:52:00 --> Config Class Initialized
INFO - 2025-08-14 21:52:00 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:52:00 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:00 --> Utf8 Class Initialized
INFO - 2025-08-14 21:52:00 --> URI Class Initialized
INFO - 2025-08-14 21:52:00 --> Router Class Initialized
INFO - 2025-08-14 21:52:00 --> Output Class Initialized
INFO - 2025-08-14 21:52:00 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:00 --> CSRF cookie sent
INFO - 2025-08-14 21:52:00 --> Input Class Initialized
INFO - 2025-08-14 21:52:00 --> Language Class Initialized
ERROR - 2025-08-14 21:52:00 --> 404 Page Not Found: Theme/plugins
INFO - 2025-08-14 21:52:01 --> Config Class Initialized
INFO - 2025-08-14 21:52:01 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:52:01 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:01 --> Utf8 Class Initialized
INFO - 2025-08-14 21:52:01 --> URI Class Initialized
INFO - 2025-08-14 21:52:01 --> Router Class Initialized
INFO - 2025-08-14 21:52:01 --> Output Class Initialized
INFO - 2025-08-14 21:52:01 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:01 --> CSRF cookie sent
INFO - 2025-08-14 21:52:01 --> CSRF token verified
INFO - 2025-08-14 21:52:01 --> Input Class Initialized
INFO - 2025-08-14 21:52:01 --> Language Class Initialized
INFO - 2025-08-14 21:52:01 --> Loader Class Initialized
INFO - 2025-08-14 21:52:01 --> Helper loaded: url_helper
INFO - 2025-08-14 21:52:01 --> Helper loaded: form_helper
INFO - 2025-08-14 21:52:01 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:52:01 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:52:01 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:52:01 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:52:01 --> Database Driver Class Initialized
INFO - 2025-08-14 21:52:01 --> Form Validation Class Initialized
INFO - 2025-08-14 21:52:01 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:52:01 --> Controller Class Initialized
INFO - 2025-08-14 13:52:01 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:52:01 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:52:01 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:52:01 --> Final output sent to browser
DEBUG - 2025-08-14 13:52:01 --> Total execution time: 0.0472
INFO - 2025-08-14 21:52:07 --> Config Class Initialized
INFO - 2025-08-14 21:52:07 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:52:07 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:07 --> Utf8 Class Initialized
INFO - 2025-08-14 21:52:07 --> URI Class Initialized
INFO - 2025-08-14 21:52:07 --> Router Class Initialized
INFO - 2025-08-14 21:52:07 --> Output Class Initialized
INFO - 2025-08-14 21:52:07 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:07 --> CSRF cookie sent
INFO - 2025-08-14 21:52:07 --> Input Class Initialized
INFO - 2025-08-14 21:52:07 --> Language Class Initialized
INFO - 2025-08-14 21:52:07 --> Loader Class Initialized
INFO - 2025-08-14 21:52:07 --> Helper loaded: url_helper
INFO - 2025-08-14 21:52:07 --> Helper loaded: form_helper
INFO - 2025-08-14 21:52:07 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:52:07 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:52:07 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:52:07 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:52:07 --> Database Driver Class Initialized
INFO - 2025-08-14 21:52:07 --> Form Validation Class Initialized
INFO - 2025-08-14 21:52:07 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:52:07 --> Controller Class Initialized
INFO - 2025-08-14 13:52:07 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:52:07 --> Model "Items_model" initialized
INFO - 2025-08-14 21:52:07 --> Config Class Initialized
INFO - 2025-08-14 21:52:07 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:52:07 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:07 --> Utf8 Class Initialized
INFO - 2025-08-14 21:52:07 --> URI Class Initialized
INFO - 2025-08-14 21:52:07 --> Router Class Initialized
INFO - 2025-08-14 21:52:07 --> Output Class Initialized
INFO - 2025-08-14 21:52:07 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:07 --> CSRF cookie sent
INFO - 2025-08-14 21:52:07 --> CSRF token verified
INFO - 2025-08-14 21:52:07 --> Input Class Initialized
INFO - 2025-08-14 21:52:07 --> Language Class Initialized
INFO - 2025-08-14 21:52:07 --> Loader Class Initialized
INFO - 2025-08-14 21:52:07 --> Helper loaded: url_helper
INFO - 2025-08-14 21:52:07 --> Helper loaded: form_helper
INFO - 2025-08-14 21:52:07 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:52:07 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:52:07 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:52:07 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:52:07 --> Database Driver Class Initialized
INFO - 2025-08-14 21:52:07 --> Form Validation Class Initialized
INFO - 2025-08-14 21:52:07 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:52:07 --> Controller Class Initialized
INFO - 2025-08-14 13:52:07 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:52:07 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:52:07 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:52:07 --> Final output sent to browser
DEBUG - 2025-08-14 13:52:07 --> Total execution time: 0.0513
INFO - 2025-08-14 21:52:12 --> Config Class Initialized
INFO - 2025-08-14 21:52:12 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:52:12 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:12 --> Utf8 Class Initialized
INFO - 2025-08-14 21:52:12 --> URI Class Initialized
INFO - 2025-08-14 21:52:12 --> Router Class Initialized
INFO - 2025-08-14 21:52:12 --> Output Class Initialized
INFO - 2025-08-14 21:52:12 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:12 --> CSRF cookie sent
INFO - 2025-08-14 21:52:12 --> CSRF token verified
INFO - 2025-08-14 21:52:12 --> Input Class Initialized
INFO - 2025-08-14 21:52:12 --> Language Class Initialized
INFO - 2025-08-14 21:52:12 --> Loader Class Initialized
INFO - 2025-08-14 21:52:12 --> Helper loaded: url_helper
INFO - 2025-08-14 21:52:12 --> Helper loaded: form_helper
INFO - 2025-08-14 21:52:12 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:52:12 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:52:12 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:52:12 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:52:12 --> Database Driver Class Initialized
INFO - 2025-08-14 21:52:12 --> Form Validation Class Initialized
INFO - 2025-08-14 21:52:12 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:52:12 --> Controller Class Initialized
INFO - 2025-08-14 13:52:12 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:52:12 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:52:12 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:52:12 --> Final output sent to browser
DEBUG - 2025-08-14 13:52:12 --> Total execution time: 0.0448
INFO - 2025-08-14 21:52:14 --> Config Class Initialized
INFO - 2025-08-14 21:52:14 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:52:14 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:14 --> Utf8 Class Initialized
INFO - 2025-08-14 21:52:14 --> URI Class Initialized
INFO - 2025-08-14 21:52:14 --> Router Class Initialized
INFO - 2025-08-14 21:52:14 --> Output Class Initialized
INFO - 2025-08-14 21:52:14 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:14 --> CSRF cookie sent
INFO - 2025-08-14 21:52:14 --> CSRF token verified
INFO - 2025-08-14 21:52:14 --> Input Class Initialized
INFO - 2025-08-14 21:52:14 --> Language Class Initialized
INFO - 2025-08-14 21:52:14 --> Loader Class Initialized
INFO - 2025-08-14 21:52:14 --> Helper loaded: url_helper
INFO - 2025-08-14 21:52:14 --> Helper loaded: form_helper
INFO - 2025-08-14 21:52:14 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:52:14 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:52:14 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:52:14 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:52:14 --> Database Driver Class Initialized
INFO - 2025-08-14 21:52:14 --> Form Validation Class Initialized
INFO - 2025-08-14 21:52:14 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:52:14 --> Controller Class Initialized
INFO - 2025-08-14 13:52:14 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:52:14 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:52:14 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:52:14 --> Final output sent to browser
DEBUG - 2025-08-14 13:52:14 --> Total execution time: 0.0725
INFO - 2025-08-14 21:52:15 --> Config Class Initialized
INFO - 2025-08-14 21:52:15 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:52:15 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:15 --> Utf8 Class Initialized
INFO - 2025-08-14 21:52:15 --> URI Class Initialized
INFO - 2025-08-14 21:52:15 --> Router Class Initialized
INFO - 2025-08-14 21:52:15 --> Output Class Initialized
INFO - 2025-08-14 21:52:15 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:15 --> CSRF cookie sent
INFO - 2025-08-14 21:52:15 --> CSRF token verified
INFO - 2025-08-14 21:52:15 --> Input Class Initialized
INFO - 2025-08-14 21:52:15 --> Language Class Initialized
INFO - 2025-08-14 21:52:15 --> Loader Class Initialized
INFO - 2025-08-14 21:52:15 --> Helper loaded: url_helper
INFO - 2025-08-14 21:52:15 --> Helper loaded: form_helper
INFO - 2025-08-14 21:52:15 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:52:15 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:52:15 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:52:15 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:52:15 --> Database Driver Class Initialized
INFO - 2025-08-14 21:52:15 --> Form Validation Class Initialized
INFO - 2025-08-14 21:52:15 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:52:15 --> Controller Class Initialized
INFO - 2025-08-14 13:52:15 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:52:15 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:52:15 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:52:15 --> Final output sent to browser
DEBUG - 2025-08-14 13:52:15 --> Total execution time: 0.0651
INFO - 2025-08-14 21:52:22 --> Config Class Initialized
INFO - 2025-08-14 21:52:22 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:52:22 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:22 --> Utf8 Class Initialized
INFO - 2025-08-14 21:52:22 --> URI Class Initialized
INFO - 2025-08-14 21:52:22 --> Router Class Initialized
INFO - 2025-08-14 21:52:22 --> Output Class Initialized
INFO - 2025-08-14 21:52:22 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:22 --> CSRF cookie sent
INFO - 2025-08-14 21:52:22 --> CSRF token verified
INFO - 2025-08-14 21:52:22 --> Input Class Initialized
INFO - 2025-08-14 21:52:22 --> Language Class Initialized
INFO - 2025-08-14 21:52:22 --> Loader Class Initialized
INFO - 2025-08-14 21:52:22 --> Helper loaded: url_helper
INFO - 2025-08-14 21:52:22 --> Helper loaded: form_helper
INFO - 2025-08-14 21:52:22 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:52:22 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:52:22 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:52:22 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:52:22 --> Database Driver Class Initialized
INFO - 2025-08-14 21:52:22 --> Form Validation Class Initialized
INFO - 2025-08-14 21:52:22 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:52:22 --> Controller Class Initialized
INFO - 2025-08-14 13:52:22 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:52:22 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:52:22 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:52:22 --> Model "Sales_model" initialized
INFO - 2025-08-14 21:52:23 --> Config Class Initialized
INFO - 2025-08-14 21:52:23 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:52:23 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:23 --> Utf8 Class Initialized
INFO - 2025-08-14 21:52:23 --> URI Class Initialized
INFO - 2025-08-14 21:52:23 --> Router Class Initialized
INFO - 2025-08-14 21:52:23 --> Output Class Initialized
INFO - 2025-08-14 21:52:23 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:23 --> CSRF cookie sent
INFO - 2025-08-14 21:52:23 --> CSRF token verified
INFO - 2025-08-14 21:52:23 --> Input Class Initialized
INFO - 2025-08-14 21:52:23 --> Language Class Initialized
INFO - 2025-08-14 21:52:23 --> Loader Class Initialized
INFO - 2025-08-14 21:52:23 --> Helper loaded: url_helper
INFO - 2025-08-14 21:52:23 --> Config Class Initialized
INFO - 2025-08-14 21:52:23 --> Hooks Class Initialized
INFO - 2025-08-14 21:52:23 --> Helper loaded: form_helper
INFO - 2025-08-14 21:52:23 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:52:23 --> Helper loaded: appinfo_helper
DEBUG - 2025-08-14 21:52:23 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:23 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:52:23 --> Utf8 Class Initialized
INFO - 2025-08-14 21:52:23 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:52:23 --> URI Class Initialized
INFO - 2025-08-14 21:52:23 --> Router Class Initialized
INFO - 2025-08-14 21:52:23 --> Output Class Initialized
INFO - 2025-08-14 21:52:23 --> Database Driver Class Initialized
INFO - 2025-08-14 21:52:23 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:23 --> CSRF cookie sent
INFO - 2025-08-14 21:52:23 --> Input Class Initialized
INFO - 2025-08-14 21:52:23 --> Language Class Initialized
INFO - 2025-08-14 21:52:23 --> Form Validation Class Initialized
INFO - 2025-08-14 21:52:23 --> Loader Class Initialized
INFO - 2025-08-14 21:52:23 --> Helper loaded: url_helper
INFO - 2025-08-14 21:52:23 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:52:23 --> Controller Class Initialized
INFO - 2025-08-14 21:52:23 --> Helper loaded: form_helper
INFO - 2025-08-14 21:52:23 --> Helper loaded: custom_helper
INFO - 2025-08-14 13:52:23 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 21:52:23 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:52:23 --> Helper loaded: currency_helper
INFO - 2025-08-14 13:52:23 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:52:23 --> Final output sent to browser
DEBUG - 2025-08-14 13:52:23 --> Total execution time: 0.0453
INFO - 2025-08-14 21:52:23 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:52:23 --> Database Driver Class Initialized
INFO - 2025-08-14 21:52:23 --> Form Validation Class Initialized
INFO - 2025-08-14 21:52:23 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:52:23 --> Controller Class Initialized
INFO - 2025-08-14 21:52:23 --> Config Class Initialized
INFO - 2025-08-14 21:52:23 --> Hooks Class Initialized
INFO - 2025-08-14 13:52:23 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:52:23 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:52:23 --> Helper loaded: sms_template_helper
DEBUG - 2025-08-14 21:52:23 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:23 --> Utf8 Class Initialized
ERROR - 2025-08-14 13:52:23 --> Could not find the language line "company_address"
INFO - 2025-08-14 21:52:23 --> URI Class Initialized
INFO - 2025-08-14 21:52:23 --> Router Class Initialized
ERROR - 2025-08-14 13:52:23 --> Could not find the language line "previous_due"
INFO - 2025-08-14 13:52:23 --> Model "Qrcode_model" initialized
INFO - 2025-08-14 21:52:23 --> Output Class Initialized
INFO - 2025-08-14 21:52:23 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:23 --> CSRF cookie sent
INFO - 2025-08-14 21:52:23 --> CSRF token verified
INFO - 2025-08-14 21:52:23 --> Input Class Initialized
INFO - 2025-08-14 21:52:23 --> Language Class Initialized
INFO - 2025-08-14 21:52:23 --> Loader Class Initialized
INFO - 2025-08-14 21:52:23 --> Helper loaded: url_helper
INFO - 2025-08-14 21:52:23 --> Helper loaded: form_helper
INFO - 2025-08-14 21:52:23 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:52:23 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:52:23 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:52:23 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 13:52:23 --> File loaded: C:\xampp\htdocs\application\views\sal-invoice-pos.php
INFO - 2025-08-14 13:52:23 --> Final output sent to browser
DEBUG - 2025-08-14 13:52:23 --> Total execution time: 0.1010
INFO - 2025-08-14 21:52:23 --> Database Driver Class Initialized
INFO - 2025-08-14 21:52:23 --> Form Validation Class Initialized
INFO - 2025-08-14 21:52:23 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:52:23 --> Controller Class Initialized
INFO - 2025-08-14 13:52:23 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:52:23 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:52:23 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:52:23 --> Final output sent to browser
DEBUG - 2025-08-14 13:52:23 --> Total execution time: 0.0790
INFO - 2025-08-14 21:52:23 --> Config Class Initialized
INFO - 2025-08-14 21:52:23 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:52:23 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:52:23 --> Utf8 Class Initialized
INFO - 2025-08-14 21:52:23 --> URI Class Initialized
INFO - 2025-08-14 21:52:23 --> Router Class Initialized
INFO - 2025-08-14 21:52:23 --> Output Class Initialized
INFO - 2025-08-14 21:52:23 --> Security Class Initialized
DEBUG - 2025-08-14 21:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:52:23 --> CSRF cookie sent
INFO - 2025-08-14 21:52:23 --> Input Class Initialized
INFO - 2025-08-14 21:52:23 --> Language Class Initialized
ERROR - 2025-08-14 21:52:23 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:53:02 --> Config Class Initialized
INFO - 2025-08-14 21:53:02 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:53:02 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:53:02 --> Utf8 Class Initialized
INFO - 2025-08-14 21:53:02 --> URI Class Initialized
INFO - 2025-08-14 21:53:02 --> Router Class Initialized
INFO - 2025-08-14 21:53:02 --> Output Class Initialized
INFO - 2025-08-14 21:53:02 --> Security Class Initialized
DEBUG - 2025-08-14 21:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:53:02 --> CSRF cookie sent
INFO - 2025-08-14 21:53:02 --> CSRF token verified
INFO - 2025-08-14 21:53:02 --> Input Class Initialized
INFO - 2025-08-14 21:53:02 --> Language Class Initialized
INFO - 2025-08-14 21:53:02 --> Loader Class Initialized
INFO - 2025-08-14 21:53:02 --> Helper loaded: url_helper
INFO - 2025-08-14 21:53:02 --> Helper loaded: form_helper
INFO - 2025-08-14 21:53:02 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:53:02 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:53:02 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:53:02 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:53:02 --> Database Driver Class Initialized
INFO - 2025-08-14 21:53:02 --> Form Validation Class Initialized
INFO - 2025-08-14 21:53:02 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:53:02 --> Controller Class Initialized
INFO - 2025-08-14 13:53:02 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:53:02 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:53:02 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:53:02 --> Final output sent to browser
DEBUG - 2025-08-14 13:53:02 --> Total execution time: 0.0460
INFO - 2025-08-14 21:53:40 --> Config Class Initialized
INFO - 2025-08-14 21:53:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:53:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:53:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:53:40 --> URI Class Initialized
INFO - 2025-08-14 21:53:40 --> Router Class Initialized
INFO - 2025-08-14 21:53:40 --> Output Class Initialized
INFO - 2025-08-14 21:53:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:53:40 --> CSRF cookie sent
INFO - 2025-08-14 21:53:40 --> CSRF token verified
INFO - 2025-08-14 21:53:40 --> Input Class Initialized
INFO - 2025-08-14 21:53:40 --> Language Class Initialized
INFO - 2025-08-14 21:53:40 --> Loader Class Initialized
INFO - 2025-08-14 21:53:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:53:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:53:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:53:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:53:40 --> Controller Class Initialized
INFO - 2025-08-14 13:53:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:53:40 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:53:40 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:53:40 --> Model "Sales_model" initialized
INFO - 2025-08-14 21:53:40 --> Config Class Initialized
INFO - 2025-08-14 21:53:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:53:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:53:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:53:40 --> URI Class Initialized
INFO - 2025-08-14 21:53:40 --> Router Class Initialized
INFO - 2025-08-14 21:53:40 --> Output Class Initialized
INFO - 2025-08-14 21:53:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:53:40 --> CSRF cookie sent
INFO - 2025-08-14 21:53:40 --> CSRF token verified
INFO - 2025-08-14 21:53:40 --> Input Class Initialized
INFO - 2025-08-14 21:53:40 --> Language Class Initialized
INFO - 2025-08-14 21:53:40 --> Loader Class Initialized
INFO - 2025-08-14 21:53:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:53:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:53:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:53:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:53:40 --> Controller Class Initialized
INFO - 2025-08-14 13:53:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:53:40 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:53:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:53:40 --> Total execution time: 0.0398
INFO - 2025-08-14 21:53:40 --> Config Class Initialized
INFO - 2025-08-14 21:53:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:53:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:53:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:53:40 --> URI Class Initialized
INFO - 2025-08-14 21:53:40 --> Router Class Initialized
INFO - 2025-08-14 21:53:40 --> Output Class Initialized
INFO - 2025-08-14 21:53:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:53:40 --> CSRF cookie sent
INFO - 2025-08-14 21:53:40 --> CSRF token verified
INFO - 2025-08-14 21:53:40 --> Input Class Initialized
INFO - 2025-08-14 21:53:40 --> Language Class Initialized
INFO - 2025-08-14 21:53:40 --> Loader Class Initialized
INFO - 2025-08-14 21:53:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:53:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:53:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:53:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:53:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:53:40 --> Controller Class Initialized
INFO - 2025-08-14 13:53:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:53:40 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:53:40 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:53:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:53:40 --> Total execution time: 0.0466
INFO - 2025-08-14 21:53:40 --> Config Class Initialized
INFO - 2025-08-14 21:53:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:53:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:53:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:53:40 --> URI Class Initialized
INFO - 2025-08-14 21:53:40 --> Router Class Initialized
INFO - 2025-08-14 21:53:40 --> Output Class Initialized
INFO - 2025-08-14 21:53:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:53:40 --> CSRF cookie sent
INFO - 2025-08-14 21:53:40 --> Input Class Initialized
INFO - 2025-08-14 21:53:40 --> Language Class Initialized
ERROR - 2025-08-14 21:53:40 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:53:46 --> Config Class Initialized
INFO - 2025-08-14 21:53:46 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:53:46 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:53:46 --> Utf8 Class Initialized
INFO - 2025-08-14 21:53:46 --> URI Class Initialized
INFO - 2025-08-14 21:53:46 --> Router Class Initialized
INFO - 2025-08-14 21:53:46 --> Output Class Initialized
INFO - 2025-08-14 21:53:46 --> Security Class Initialized
DEBUG - 2025-08-14 21:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:53:46 --> CSRF cookie sent
INFO - 2025-08-14 21:53:46 --> Input Class Initialized
INFO - 2025-08-14 21:53:46 --> Language Class Initialized
INFO - 2025-08-14 21:53:46 --> Loader Class Initialized
INFO - 2025-08-14 21:53:46 --> Helper loaded: url_helper
INFO - 2025-08-14 21:53:46 --> Helper loaded: form_helper
INFO - 2025-08-14 21:53:46 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:53:46 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:53:46 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:53:46 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:53:46 --> Database Driver Class Initialized
INFO - 2025-08-14 21:53:46 --> Form Validation Class Initialized
INFO - 2025-08-14 21:53:46 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:53:46 --> Controller Class Initialized
INFO - 2025-08-14 13:53:46 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:53:46 --> Model "Sales_model" initialized
INFO - 2025-08-14 13:53:46 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:53:46 --> File loaded: C:\xampp\htdocs\application\views\sales-list.php
INFO - 2025-08-14 13:53:46 --> Final output sent to browser
DEBUG - 2025-08-14 13:53:46 --> Total execution time: 0.0503
INFO - 2025-08-14 21:53:46 --> Config Class Initialized
INFO - 2025-08-14 21:53:46 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:53:46 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:53:46 --> Utf8 Class Initialized
INFO - 2025-08-14 21:53:46 --> URI Class Initialized
INFO - 2025-08-14 21:53:46 --> Router Class Initialized
INFO - 2025-08-14 21:53:46 --> Output Class Initialized
INFO - 2025-08-14 21:53:46 --> Security Class Initialized
DEBUG - 2025-08-14 21:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:53:46 --> CSRF cookie sent
INFO - 2025-08-14 21:53:46 --> CSRF token verified
INFO - 2025-08-14 21:53:46 --> Input Class Initialized
INFO - 2025-08-14 21:53:46 --> Language Class Initialized
INFO - 2025-08-14 21:53:46 --> Loader Class Initialized
INFO - 2025-08-14 21:53:46 --> Helper loaded: url_helper
INFO - 2025-08-14 21:53:46 --> Helper loaded: form_helper
INFO - 2025-08-14 21:53:46 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:53:46 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:53:46 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:53:46 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:53:46 --> Database Driver Class Initialized
INFO - 2025-08-14 21:53:46 --> Form Validation Class Initialized
INFO - 2025-08-14 21:53:46 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:53:46 --> Controller Class Initialized
INFO - 2025-08-14 13:53:46 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:53:46 --> Model "Sales_model" initialized
INFO - 2025-08-14 13:53:46 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:53:46 --> Final output sent to browser
DEBUG - 2025-08-14 13:53:46 --> Total execution time: 0.0464
INFO - 2025-08-14 21:53:55 --> Config Class Initialized
INFO - 2025-08-14 21:53:55 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:53:55 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:53:55 --> Utf8 Class Initialized
INFO - 2025-08-14 21:53:55 --> URI Class Initialized
INFO - 2025-08-14 21:53:55 --> Router Class Initialized
INFO - 2025-08-14 21:53:55 --> Output Class Initialized
INFO - 2025-08-14 21:53:55 --> Security Class Initialized
DEBUG - 2025-08-14 21:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:53:55 --> CSRF cookie sent
INFO - 2025-08-14 21:53:55 --> Input Class Initialized
INFO - 2025-08-14 21:53:55 --> Language Class Initialized
INFO - 2025-08-14 21:53:55 --> Loader Class Initialized
INFO - 2025-08-14 21:53:55 --> Helper loaded: url_helper
INFO - 2025-08-14 21:53:55 --> Helper loaded: form_helper
INFO - 2025-08-14 21:53:55 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:53:55 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:53:55 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:53:55 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:53:55 --> Database Driver Class Initialized
INFO - 2025-08-14 21:53:55 --> Form Validation Class Initialized
INFO - 2025-08-14 21:53:55 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:53:55 --> Controller Class Initialized
INFO - 2025-08-14 13:53:55 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:53:55 --> Model "Reports_model" initialized
INFO - 2025-08-14 13:53:55 --> File loaded: C:\xampp\htdocs\application\views\components/export_btn.php
INFO - 2025-08-14 13:53:55 --> File loaded: C:\xampp\htdocs\application\views\components/export_btn.php
INFO - 2025-08-14 13:53:55 --> File loaded: C:\xampp\htdocs\application\views\components/export_btn.php
INFO - 2025-08-14 13:53:55 --> File loaded: C:\xampp\htdocs\application\views\components/export_btn.php
INFO - 2025-08-14 13:53:55 --> File loaded: C:\xampp\htdocs\application\views\components/export_btn.php
INFO - 2025-08-14 13:53:55 --> File loaded: C:\xampp\htdocs\application\views\report-profit-loss.php
INFO - 2025-08-14 13:53:55 --> Final output sent to browser
DEBUG - 2025-08-14 13:53:55 --> Total execution time: 0.0798
INFO - 2025-08-14 21:53:56 --> Config Class Initialized
INFO - 2025-08-14 21:53:56 --> Hooks Class Initialized
INFO - 2025-08-14 21:53:56 --> Config Class Initialized
INFO - 2025-08-14 21:53:56 --> Config Class Initialized
INFO - 2025-08-14 21:53:56 --> Hooks Class Initialized
INFO - 2025-08-14 21:53:56 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:53:56 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:53:56 --> Utf8 Class Initialized
DEBUG - 2025-08-14 21:53:56 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:53:56 --> Utf8 Class Initialized
DEBUG - 2025-08-14 21:53:56 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:53:56 --> Utf8 Class Initialized
INFO - 2025-08-14 21:53:56 --> URI Class Initialized
INFO - 2025-08-14 21:53:56 --> URI Class Initialized
INFO - 2025-08-14 21:53:56 --> URI Class Initialized
INFO - 2025-08-14 21:53:56 --> Router Class Initialized
INFO - 2025-08-14 21:53:56 --> Router Class Initialized
INFO - 2025-08-14 21:53:56 --> Router Class Initialized
INFO - 2025-08-14 21:53:56 --> Output Class Initialized
INFO - 2025-08-14 21:53:56 --> Output Class Initialized
INFO - 2025-08-14 21:53:56 --> Security Class Initialized
INFO - 2025-08-14 21:53:56 --> Security Class Initialized
INFO - 2025-08-14 21:53:56 --> Output Class Initialized
DEBUG - 2025-08-14 21:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:53:56 --> CSRF cookie sent
INFO - 2025-08-14 21:53:56 --> CSRF token verified
INFO - 2025-08-14 21:53:56 --> Input Class Initialized
DEBUG - 2025-08-14 21:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:53:56 --> Language Class Initialized
INFO - 2025-08-14 21:53:56 --> Security Class Initialized
INFO - 2025-08-14 21:53:56 --> CSRF cookie sent
INFO - 2025-08-14 21:53:56 --> CSRF token verified
INFO - 2025-08-14 21:53:56 --> Input Class Initialized
INFO - 2025-08-14 21:53:56 --> Language Class Initialized
DEBUG - 2025-08-14 21:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:53:56 --> CSRF cookie sent
INFO - 2025-08-14 21:53:56 --> CSRF token verified
INFO - 2025-08-14 21:53:56 --> Input Class Initialized
INFO - 2025-08-14 21:53:56 --> Language Class Initialized
INFO - 2025-08-14 21:53:56 --> Loader Class Initialized
INFO - 2025-08-14 21:53:56 --> Helper loaded: url_helper
INFO - 2025-08-14 21:53:56 --> Loader Class Initialized
INFO - 2025-08-14 21:53:56 --> Loader Class Initialized
INFO - 2025-08-14 21:53:56 --> Helper loaded: form_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: url_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: url_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: form_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: form_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:53:56 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:53:56 --> Database Driver Class Initialized
INFO - 2025-08-14 21:53:56 --> Database Driver Class Initialized
INFO - 2025-08-14 21:53:56 --> Database Driver Class Initialized
INFO - 2025-08-14 21:53:56 --> Form Validation Class Initialized
INFO - 2025-08-14 21:53:56 --> Form Validation Class Initialized
INFO - 2025-08-14 21:53:56 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:53:56 --> Controller Class Initialized
INFO - 2025-08-14 13:53:56 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:53:56 --> Model "Reports_model" initialized
INFO - 2025-08-14 21:53:56 --> Form Validation Class Initialized
INFO - 2025-08-14 13:53:56 --> Final output sent to browser
DEBUG - 2025-08-14 13:53:56 --> Total execution time: 0.0805
INFO - 2025-08-14 21:53:56 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:53:56 --> Controller Class Initialized
INFO - 2025-08-14 13:53:56 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:53:56 --> Model "Reports_model" initialized
ERROR - 2025-08-14 13:53:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 4 - Invalid query: 
						SELECT COALESCE(sum(return_qty),0) as return_qty
						FROM db_purchaseitemsreturn
						WHERE 
						item_id =
ERROR - 2025-08-14 13:53:56 --> Severity: error --> Exception: Call to a member function row() on bool C:\xampp\htdocs\application\models\Reports_model.php 1358
INFO - 2025-08-14 21:53:56 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:53:56 --> Controller Class Initialized
INFO - 2025-08-14 13:53:56 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:53:56 --> Model "Reports_model" initialized
INFO - 2025-08-14 21:54:06 --> Config Class Initialized
INFO - 2025-08-14 21:54:06 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:54:06 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:54:06 --> Utf8 Class Initialized
INFO - 2025-08-14 21:54:06 --> URI Class Initialized
INFO - 2025-08-14 21:54:06 --> Router Class Initialized
INFO - 2025-08-14 21:54:06 --> Output Class Initialized
INFO - 2025-08-14 21:54:06 --> Security Class Initialized
DEBUG - 2025-08-14 21:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:54:06 --> CSRF cookie sent
INFO - 2025-08-14 21:54:06 --> Input Class Initialized
INFO - 2025-08-14 21:54:06 --> Language Class Initialized
INFO - 2025-08-14 21:54:06 --> Loader Class Initialized
INFO - 2025-08-14 21:54:06 --> Helper loaded: url_helper
INFO - 2025-08-14 21:54:06 --> Helper loaded: form_helper
INFO - 2025-08-14 21:54:06 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:54:06 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:54:06 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:54:06 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:54:06 --> Database Driver Class Initialized
INFO - 2025-08-14 21:54:06 --> Form Validation Class Initialized
INFO - 2025-08-14 21:54:06 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:54:06 --> Controller Class Initialized
INFO - 2025-08-14 13:54:06 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:54:06 --> Model "Reports_model" initialized
INFO - 2025-08-14 13:54:06 --> File loaded: C:\xampp\htdocs\application\views\components/export_btn.php
INFO - 2025-08-14 13:54:06 --> File loaded: C:\xampp\htdocs\application\views\report-purchase-item.php
INFO - 2025-08-14 13:54:06 --> Final output sent to browser
DEBUG - 2025-08-14 13:54:06 --> Total execution time: 0.0634
INFO - 2025-08-14 21:54:10 --> Config Class Initialized
INFO - 2025-08-14 21:54:10 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:54:10 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:54:10 --> Utf8 Class Initialized
INFO - 2025-08-14 21:54:10 --> URI Class Initialized
INFO - 2025-08-14 21:54:10 --> Router Class Initialized
INFO - 2025-08-14 21:54:10 --> Output Class Initialized
INFO - 2025-08-14 21:54:10 --> Security Class Initialized
DEBUG - 2025-08-14 21:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:54:10 --> CSRF cookie sent
INFO - 2025-08-14 21:54:10 --> Input Class Initialized
INFO - 2025-08-14 21:54:10 --> Language Class Initialized
INFO - 2025-08-14 21:54:10 --> Loader Class Initialized
INFO - 2025-08-14 21:54:10 --> Helper loaded: url_helper
INFO - 2025-08-14 21:54:10 --> Helper loaded: form_helper
INFO - 2025-08-14 21:54:10 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:54:10 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:54:10 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:54:10 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:54:10 --> Database Driver Class Initialized
INFO - 2025-08-14 21:54:10 --> Form Validation Class Initialized
INFO - 2025-08-14 21:54:10 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:54:10 --> Controller Class Initialized
INFO - 2025-08-14 13:54:10 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:54:10 --> Model "Reports_model" initialized
INFO - 2025-08-14 13:54:10 --> File loaded: C:\xampp\htdocs\application\views\components/export_btn.php
INFO - 2025-08-14 13:54:10 --> File loaded: C:\xampp\htdocs\application\views\report-sales.php
INFO - 2025-08-14 13:54:10 --> Final output sent to browser
DEBUG - 2025-08-14 13:54:10 --> Total execution time: 0.0601
INFO - 2025-08-14 21:54:23 --> Config Class Initialized
INFO - 2025-08-14 21:54:23 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:54:23 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:54:23 --> Utf8 Class Initialized
INFO - 2025-08-14 21:54:23 --> URI Class Initialized
INFO - 2025-08-14 21:54:23 --> Router Class Initialized
INFO - 2025-08-14 21:54:23 --> Output Class Initialized
INFO - 2025-08-14 21:54:23 --> Security Class Initialized
DEBUG - 2025-08-14 21:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:54:23 --> CSRF cookie sent
INFO - 2025-08-14 21:54:23 --> CSRF token verified
INFO - 2025-08-14 21:54:23 --> Input Class Initialized
INFO - 2025-08-14 21:54:23 --> Language Class Initialized
INFO - 2025-08-14 21:54:23 --> Loader Class Initialized
INFO - 2025-08-14 21:54:23 --> Helper loaded: url_helper
INFO - 2025-08-14 21:54:23 --> Helper loaded: form_helper
INFO - 2025-08-14 21:54:23 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:54:23 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:54:23 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:54:23 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:54:23 --> Database Driver Class Initialized
INFO - 2025-08-14 21:54:23 --> Form Validation Class Initialized
INFO - 2025-08-14 21:54:23 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:54:23 --> Controller Class Initialized
INFO - 2025-08-14 13:54:23 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:54:23 --> Model "Reports_model" initialized
INFO - 2025-08-14 21:54:40 --> Config Class Initialized
INFO - 2025-08-14 21:54:40 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:54:40 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:54:40 --> Utf8 Class Initialized
INFO - 2025-08-14 21:54:40 --> URI Class Initialized
INFO - 2025-08-14 21:54:40 --> Router Class Initialized
INFO - 2025-08-14 21:54:40 --> Output Class Initialized
INFO - 2025-08-14 21:54:40 --> Security Class Initialized
DEBUG - 2025-08-14 21:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:54:40 --> CSRF cookie sent
INFO - 2025-08-14 21:54:40 --> Input Class Initialized
INFO - 2025-08-14 21:54:40 --> Language Class Initialized
INFO - 2025-08-14 21:54:40 --> Loader Class Initialized
INFO - 2025-08-14 21:54:40 --> Helper loaded: url_helper
INFO - 2025-08-14 21:54:40 --> Helper loaded: form_helper
INFO - 2025-08-14 21:54:40 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:54:40 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:54:40 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:54:40 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:54:40 --> Database Driver Class Initialized
INFO - 2025-08-14 21:54:40 --> Form Validation Class Initialized
INFO - 2025-08-14 21:54:40 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:54:40 --> Controller Class Initialized
INFO - 2025-08-14 13:54:40 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:54:40 --> Model "Dashboard_model" initialized
INFO - 2025-08-14 13:54:40 --> File loaded: C:\xampp\htdocs\application\views\footer.php
INFO - 2025-08-14 13:54:40 --> File loaded: C:\xampp\htdocs\application\views\dashboard.php
INFO - 2025-08-14 13:54:40 --> Final output sent to browser
DEBUG - 2025-08-14 13:54:40 --> Total execution time: 0.0647
INFO - 2025-08-14 21:54:52 --> Config Class Initialized
INFO - 2025-08-14 21:54:52 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:54:52 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:54:52 --> Utf8 Class Initialized
INFO - 2025-08-14 21:54:52 --> URI Class Initialized
INFO - 2025-08-14 21:54:52 --> Router Class Initialized
INFO - 2025-08-14 21:54:52 --> Output Class Initialized
INFO - 2025-08-14 21:54:52 --> Security Class Initialized
DEBUG - 2025-08-14 21:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:54:52 --> CSRF cookie sent
INFO - 2025-08-14 21:54:52 --> Input Class Initialized
INFO - 2025-08-14 21:54:52 --> Language Class Initialized
INFO - 2025-08-14 21:54:52 --> Loader Class Initialized
INFO - 2025-08-14 21:54:52 --> Helper loaded: url_helper
INFO - 2025-08-14 21:54:52 --> Helper loaded: form_helper
INFO - 2025-08-14 21:54:52 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:54:52 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:54:52 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:54:52 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:54:52 --> Database Driver Class Initialized
INFO - 2025-08-14 21:54:52 --> Form Validation Class Initialized
INFO - 2025-08-14 21:54:52 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:54:52 --> Controller Class Initialized
INFO - 2025-08-14 13:54:52 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:54:52 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:54:52 --> File loaded: C:\xampp\htdocs\application\views\customers-view.php
INFO - 2025-08-14 13:54:52 --> Final output sent to browser
DEBUG - 2025-08-14 13:54:52 --> Total execution time: 0.0455
INFO - 2025-08-14 21:54:52 --> Config Class Initialized
INFO - 2025-08-14 21:54:52 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:54:52 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:54:52 --> Utf8 Class Initialized
INFO - 2025-08-14 21:54:52 --> URI Class Initialized
INFO - 2025-08-14 21:54:52 --> Router Class Initialized
INFO - 2025-08-14 21:54:52 --> Output Class Initialized
INFO - 2025-08-14 21:54:52 --> Security Class Initialized
DEBUG - 2025-08-14 21:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:54:52 --> CSRF cookie sent
INFO - 2025-08-14 21:54:52 --> CSRF token verified
INFO - 2025-08-14 21:54:52 --> Input Class Initialized
INFO - 2025-08-14 21:54:52 --> Language Class Initialized
INFO - 2025-08-14 21:54:52 --> Loader Class Initialized
INFO - 2025-08-14 21:54:52 --> Helper loaded: url_helper
INFO - 2025-08-14 21:54:52 --> Helper loaded: form_helper
INFO - 2025-08-14 21:54:52 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:54:52 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:54:52 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:54:52 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:54:52 --> Database Driver Class Initialized
INFO - 2025-08-14 21:54:52 --> Form Validation Class Initialized
INFO - 2025-08-14 21:54:52 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:54:52 --> Controller Class Initialized
INFO - 2025-08-14 13:54:52 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:54:52 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:54:52 --> Final output sent to browser
DEBUG - 2025-08-14 13:54:52 --> Total execution time: 0.0414
INFO - 2025-08-14 21:55:01 --> Config Class Initialized
INFO - 2025-08-14 21:55:01 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:55:01 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:55:01 --> Utf8 Class Initialized
INFO - 2025-08-14 21:55:01 --> URI Class Initialized
INFO - 2025-08-14 21:55:01 --> Router Class Initialized
INFO - 2025-08-14 21:55:01 --> Output Class Initialized
INFO - 2025-08-14 21:55:01 --> Security Class Initialized
DEBUG - 2025-08-14 21:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:55:01 --> CSRF cookie sent
INFO - 2025-08-14 21:55:01 --> Input Class Initialized
INFO - 2025-08-14 21:55:01 --> Language Class Initialized
INFO - 2025-08-14 21:55:01 --> Loader Class Initialized
INFO - 2025-08-14 21:55:01 --> Helper loaded: url_helper
INFO - 2025-08-14 21:55:01 --> Helper loaded: form_helper
INFO - 2025-08-14 21:55:01 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:55:01 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:55:01 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:55:01 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:55:01 --> Database Driver Class Initialized
INFO - 2025-08-14 21:55:01 --> Form Validation Class Initialized
INFO - 2025-08-14 21:55:01 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:55:01 --> Controller Class Initialized
INFO - 2025-08-14 13:55:01 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:55:01 --> Model "Customers_model" initialized
ERROR - 2025-08-14 13:55:01 --> Could not find the language line "previous_due"
INFO - 2025-08-14 13:55:01 --> File loaded: C:\xampp\htdocs\application\views\customers.php
INFO - 2025-08-14 13:55:01 --> Final output sent to browser
DEBUG - 2025-08-14 13:55:01 --> Total execution time: 0.0648
INFO - 2025-08-14 21:55:11 --> Config Class Initialized
INFO - 2025-08-14 21:55:11 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:55:11 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:55:11 --> Utf8 Class Initialized
INFO - 2025-08-14 21:55:11 --> URI Class Initialized
INFO - 2025-08-14 21:55:11 --> Router Class Initialized
INFO - 2025-08-14 21:55:11 --> Output Class Initialized
INFO - 2025-08-14 21:55:11 --> Security Class Initialized
DEBUG - 2025-08-14 21:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:55:11 --> CSRF cookie sent
INFO - 2025-08-14 21:55:11 --> Input Class Initialized
INFO - 2025-08-14 21:55:11 --> Language Class Initialized
INFO - 2025-08-14 21:55:11 --> Loader Class Initialized
INFO - 2025-08-14 21:55:11 --> Helper loaded: url_helper
INFO - 2025-08-14 21:55:11 --> Helper loaded: form_helper
INFO - 2025-08-14 21:55:11 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:55:11 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:55:11 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:55:11 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:55:11 --> Database Driver Class Initialized
INFO - 2025-08-14 21:55:11 --> Form Validation Class Initialized
INFO - 2025-08-14 21:55:11 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:55:11 --> Controller Class Initialized
INFO - 2025-08-14 13:55:11 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:55:11 --> Model "Customers_model" initialized
ERROR - 2025-08-14 13:55:11 --> Could not find the language line "previous_due"
INFO - 2025-08-14 13:55:11 --> File loaded: C:\xampp\htdocs\application\views\customers.php
INFO - 2025-08-14 13:55:11 --> Final output sent to browser
DEBUG - 2025-08-14 13:55:11 --> Total execution time: 0.0666
INFO - 2025-08-14 21:55:20 --> Config Class Initialized
INFO - 2025-08-14 21:55:20 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:55:20 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:55:20 --> Utf8 Class Initialized
INFO - 2025-08-14 21:55:20 --> URI Class Initialized
INFO - 2025-08-14 21:55:20 --> Router Class Initialized
INFO - 2025-08-14 21:55:20 --> Output Class Initialized
INFO - 2025-08-14 21:55:20 --> Security Class Initialized
DEBUG - 2025-08-14 21:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:55:20 --> CSRF cookie sent
INFO - 2025-08-14 21:55:20 --> Input Class Initialized
INFO - 2025-08-14 21:55:20 --> Language Class Initialized
INFO - 2025-08-14 21:55:20 --> Loader Class Initialized
INFO - 2025-08-14 21:55:20 --> Helper loaded: url_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: form_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:55:20 --> Database Driver Class Initialized
INFO - 2025-08-14 21:55:20 --> Form Validation Class Initialized
INFO - 2025-08-14 21:55:20 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:55:20 --> Controller Class Initialized
INFO - 2025-08-14 13:55:20 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:55:20 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:55:20 --> Helper loaded: sms_template_helper
ERROR - 2025-08-14 13:55:20 --> Could not find the language line "previous_due"
ERROR - 2025-08-14 13:55:20 --> Could not find the language line "discount_type"
INFO - 2025-08-14 13:55:20 --> File loaded: C:\xampp\htdocs\application\views\pos.php
INFO - 2025-08-14 13:55:20 --> Final output sent to browser
DEBUG - 2025-08-14 13:55:20 --> Total execution time: 0.0709
INFO - 2025-08-14 21:55:20 --> Config Class Initialized
INFO - 2025-08-14 21:55:20 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:55:20 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:55:20 --> Utf8 Class Initialized
INFO - 2025-08-14 21:55:20 --> URI Class Initialized
INFO - 2025-08-14 21:55:20 --> Router Class Initialized
INFO - 2025-08-14 21:55:20 --> Output Class Initialized
INFO - 2025-08-14 21:55:20 --> Security Class Initialized
DEBUG - 2025-08-14 21:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:55:20 --> CSRF cookie sent
INFO - 2025-08-14 21:55:20 --> CSRF token verified
INFO - 2025-08-14 21:55:20 --> Input Class Initialized
INFO - 2025-08-14 21:55:20 --> Language Class Initialized
INFO - 2025-08-14 21:55:20 --> Loader Class Initialized
INFO - 2025-08-14 21:55:20 --> Helper loaded: url_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: form_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:55:20 --> Database Driver Class Initialized
INFO - 2025-08-14 21:55:20 --> Form Validation Class Initialized
INFO - 2025-08-14 21:55:20 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:55:20 --> Controller Class Initialized
INFO - 2025-08-14 13:55:20 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:55:20 --> Model "Customers_model" initialized
INFO - 2025-08-14 13:55:20 --> Final output sent to browser
DEBUG - 2025-08-14 13:55:20 --> Total execution time: 0.0432
INFO - 2025-08-14 21:55:20 --> Config Class Initialized
INFO - 2025-08-14 21:55:20 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:55:20 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:55:20 --> Utf8 Class Initialized
INFO - 2025-08-14 21:55:20 --> URI Class Initialized
INFO - 2025-08-14 21:55:20 --> Router Class Initialized
INFO - 2025-08-14 21:55:20 --> Output Class Initialized
INFO - 2025-08-14 21:55:20 --> Security Class Initialized
DEBUG - 2025-08-14 21:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:55:20 --> CSRF cookie sent
INFO - 2025-08-14 21:55:20 --> CSRF token verified
INFO - 2025-08-14 21:55:20 --> Input Class Initialized
INFO - 2025-08-14 21:55:20 --> Language Class Initialized
INFO - 2025-08-14 21:55:20 --> Loader Class Initialized
INFO - 2025-08-14 21:55:20 --> Helper loaded: url_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: form_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:55:20 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:55:20 --> Database Driver Class Initialized
INFO - 2025-08-14 21:55:20 --> Form Validation Class Initialized
INFO - 2025-08-14 21:55:20 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:55:20 --> Controller Class Initialized
INFO - 2025-08-14 13:55:20 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:55:20 --> Model "Pos_model" initialized
INFO - 2025-08-14 13:55:20 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:55:20 --> Final output sent to browser
DEBUG - 2025-08-14 13:55:20 --> Total execution time: 0.0497
INFO - 2025-08-14 21:55:20 --> Config Class Initialized
INFO - 2025-08-14 21:55:20 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:55:20 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:55:20 --> Utf8 Class Initialized
INFO - 2025-08-14 21:55:20 --> URI Class Initialized
INFO - 2025-08-14 21:55:20 --> Router Class Initialized
INFO - 2025-08-14 21:55:20 --> Output Class Initialized
INFO - 2025-08-14 21:55:20 --> Security Class Initialized
DEBUG - 2025-08-14 21:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:55:20 --> CSRF cookie sent
INFO - 2025-08-14 21:55:20 --> Input Class Initialized
INFO - 2025-08-14 21:55:20 --> Language Class Initialized
ERROR - 2025-08-14 21:55:20 --> 404 Page Not Found: Uploads/items
INFO - 2025-08-14 21:55:26 --> Config Class Initialized
INFO - 2025-08-14 21:55:26 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:55:26 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:55:26 --> Utf8 Class Initialized
INFO - 2025-08-14 21:55:26 --> URI Class Initialized
INFO - 2025-08-14 21:55:26 --> Router Class Initialized
INFO - 2025-08-14 21:55:26 --> Output Class Initialized
INFO - 2025-08-14 21:55:26 --> Security Class Initialized
DEBUG - 2025-08-14 21:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:55:26 --> CSRF cookie sent
INFO - 2025-08-14 21:55:26 --> Input Class Initialized
INFO - 2025-08-14 21:55:26 --> Language Class Initialized
INFO - 2025-08-14 21:55:26 --> Loader Class Initialized
INFO - 2025-08-14 21:55:26 --> Helper loaded: url_helper
INFO - 2025-08-14 21:55:26 --> Helper loaded: form_helper
INFO - 2025-08-14 21:55:26 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:55:26 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:55:26 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:55:26 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:55:26 --> Database Driver Class Initialized
INFO - 2025-08-14 21:55:26 --> Form Validation Class Initialized
INFO - 2025-08-14 21:55:26 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:55:26 --> Controller Class Initialized
INFO - 2025-08-14 13:55:26 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:55:26 --> Model "Sales_model" initialized
INFO - 2025-08-14 13:55:26 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:55:26 --> File loaded: C:\xampp\htdocs\application\views\sales-list.php
INFO - 2025-08-14 13:55:26 --> Final output sent to browser
DEBUG - 2025-08-14 13:55:26 --> Total execution time: 0.0678
INFO - 2025-08-14 21:55:26 --> Config Class Initialized
INFO - 2025-08-14 21:55:26 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:55:26 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:55:26 --> Utf8 Class Initialized
INFO - 2025-08-14 21:55:26 --> URI Class Initialized
INFO - 2025-08-14 21:55:26 --> Router Class Initialized
INFO - 2025-08-14 21:55:26 --> Output Class Initialized
INFO - 2025-08-14 21:55:26 --> Security Class Initialized
DEBUG - 2025-08-14 21:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:55:26 --> CSRF cookie sent
INFO - 2025-08-14 21:55:26 --> CSRF token verified
INFO - 2025-08-14 21:55:26 --> Input Class Initialized
INFO - 2025-08-14 21:55:26 --> Language Class Initialized
INFO - 2025-08-14 21:55:26 --> Loader Class Initialized
INFO - 2025-08-14 21:55:26 --> Helper loaded: url_helper
INFO - 2025-08-14 21:55:26 --> Helper loaded: form_helper
INFO - 2025-08-14 21:55:26 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:55:26 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:55:26 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:55:26 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:55:26 --> Database Driver Class Initialized
INFO - 2025-08-14 21:55:26 --> Form Validation Class Initialized
INFO - 2025-08-14 21:55:26 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:55:26 --> Controller Class Initialized
INFO - 2025-08-14 13:55:26 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:55:26 --> Model "Sales_model" initialized
INFO - 2025-08-14 13:55:26 --> Helper loaded: sms_template_helper
INFO - 2025-08-14 13:55:26 --> Final output sent to browser
DEBUG - 2025-08-14 13:55:26 --> Total execution time: 0.0433
INFO - 2025-08-14 21:55:48 --> Config Class Initialized
INFO - 2025-08-14 21:55:48 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:55:48 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:55:48 --> Utf8 Class Initialized
INFO - 2025-08-14 21:55:48 --> URI Class Initialized
INFO - 2025-08-14 21:55:48 --> Router Class Initialized
INFO - 2025-08-14 21:55:48 --> Output Class Initialized
INFO - 2025-08-14 21:55:48 --> Security Class Initialized
DEBUG - 2025-08-14 21:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:55:48 --> CSRF cookie sent
INFO - 2025-08-14 21:55:48 --> Input Class Initialized
INFO - 2025-08-14 21:55:48 --> Language Class Initialized
INFO - 2025-08-14 21:55:48 --> Loader Class Initialized
INFO - 2025-08-14 21:55:48 --> Helper loaded: url_helper
INFO - 2025-08-14 21:55:48 --> Helper loaded: form_helper
INFO - 2025-08-14 21:55:48 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:55:48 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:55:48 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:55:48 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:55:48 --> Database Driver Class Initialized
INFO - 2025-08-14 21:55:48 --> Form Validation Class Initialized
INFO - 2025-08-14 21:55:48 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:55:48 --> Controller Class Initialized
INFO - 2025-08-14 13:55:48 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:55:48 --> Model "Reports_model" initialized
INFO - 2025-08-14 13:55:48 --> File loaded: C:\xampp\htdocs\application\views\components/export_btn.php
INFO - 2025-08-14 13:55:48 --> File loaded: C:\xampp\htdocs\application\views\report-sales-item.php
INFO - 2025-08-14 13:55:48 --> Final output sent to browser
DEBUG - 2025-08-14 13:55:48 --> Total execution time: 0.0697
INFO - 2025-08-14 21:55:52 --> Config Class Initialized
INFO - 2025-08-14 21:55:52 --> Hooks Class Initialized
DEBUG - 2025-08-14 21:55:52 --> UTF-8 Support Enabled
INFO - 2025-08-14 21:55:52 --> Utf8 Class Initialized
INFO - 2025-08-14 21:55:52 --> URI Class Initialized
INFO - 2025-08-14 21:55:52 --> Router Class Initialized
INFO - 2025-08-14 21:55:52 --> Output Class Initialized
INFO - 2025-08-14 21:55:52 --> Security Class Initialized
DEBUG - 2025-08-14 21:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-14 21:55:52 --> CSRF cookie sent
INFO - 2025-08-14 21:55:52 --> CSRF token verified
INFO - 2025-08-14 21:55:52 --> Input Class Initialized
INFO - 2025-08-14 21:55:52 --> Language Class Initialized
INFO - 2025-08-14 21:55:52 --> Loader Class Initialized
INFO - 2025-08-14 21:55:52 --> Helper loaded: url_helper
INFO - 2025-08-14 21:55:52 --> Helper loaded: form_helper
INFO - 2025-08-14 21:55:52 --> Helper loaded: custom_helper
INFO - 2025-08-14 21:55:52 --> Helper loaded: appinfo_helper
INFO - 2025-08-14 21:55:52 --> Helper loaded: currency_helper
INFO - 2025-08-14 21:55:52 --> Helper loaded: foreign_currency_helper
INFO - 2025-08-14 21:55:52 --> Database Driver Class Initialized
INFO - 2025-08-14 21:55:52 --> Form Validation Class Initialized
INFO - 2025-08-14 21:55:52 --> Session: Class initialized using 'database' driver.
INFO - 2025-08-14 21:55:52 --> Controller Class Initialized
INFO - 2025-08-14 13:55:52 --> Language file loaded: language/Spanish/Spanish_lang.php
INFO - 2025-08-14 13:55:52 --> Model "Reports_model" initialized
