// Ejemplo de cómo probar el webhook de notificaciones móviles
// Ejecutar: node examples/test-mobile-webhook.js
//
// VARIABLES DE ENTORNO COMPATIBLES:
// - BACKEND_URL o API_URL: URL base da API (ex: https://api.dominio.com)
// - Si no se definens, usa http://localhost:8080

const axios = require('axios');
require('dotenv').config();

// Configuración: CAMBIAR SOLO LOS DATOS DE PRUEBA
const CONFIG = {
  baseUrl: process.env.BACKEND_URL || process.env.API_URL || 'http://localhost:8080', // Obtenidos de .env
  userEmail: 'admin@empresa.com',   // Correo electrónico del usuario
  userPassword: '123456',           // Contraseña del usuario
  webhookUrl: 'https://webhook.site/unique-id', // Usar webhook.site para probar
  deviceToken: 'test-device-123',   // Token único del dispositivo
  platform: 'android'              // android ou ios
};

class MobileWebhookTester {
  constructor(config) {
    this.config = config;
    this.token = null;
  }

  async login() {
    try {
      console.log('🔐 Iniciando sesión...');
      const response = await axios.post(`${this.config.baseUrl}/auth/login`, {
        email: this.config.userEmail,
        password: this.config.userPassword
      });

      this.token = response.data.token;
      console.log('✅ Inicio de sesión exitoso!');
      console.log(`Token: ${this.token.substring(0, 20)}...`);
      return true;
    } catch (error) {
      console.error('❌ Error de inicio de sesión:', error.response?.data || error.message);
      return false;
    }
  }

  async registerWebhook() {
    try {
      console.log('\n📱 Registrando webhook...');
      const response = await axios.post(
        `${this.config.baseUrl}/mobile-webhook/register`,
        {
          webhookUrl: this.config.webhookUrl,
          deviceToken: this.config.deviceToken,
          platform: this.config.platform
        },
        {
          headers: {
            'Authorization': `Bearer ${this.token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      console.log('✅ Webhook registrado correctamente!');
      console.log('Datos del webhook:', JSON.stringify(response.data, null, 2));
      return true;
    } catch (error) {
      console.error('❌ Error al registrar el webhook:', error.response?.data || error.message);
      return false;
    }
  }

  async listWebhooks() {
    try {
      console.log('\n📋 Listando webhooks...');
      const response = await axios.get(
        `${this.config.baseUrl}/mobile-webhook/list`,
        {
          headers: {
            'Authorization': `Bearer ${this.token}`
          }
        }
      );

      console.log('✅ Webhooks Encontrado:');
      console.log(JSON.stringify(response.data, null, 2));
      return true;
    } catch (error) {
      console.error('❌ Error al listar webhooks:', error.response?.data || error.message);
      return false;
    }
  }

  async testWebhook() {
    try {
      console.log('\n🧪 Probando webhook...');
      const response = await axios.post(
        `${this.config.baseUrl}/mobile-webhook/test`,
        {
          deviceToken: this.config.deviceToken
        },
        {
          headers: {
            'Authorization': `Bearer ${this.token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      console.log('✅ Prueba enviada correctamente.');
      console.log('Respuesta:', JSON.stringify(response.data, null, 2));
      console.log(`\n🌐 Revisa tu webhook: ${this.config.webhookUrl}`);
      return true;
    } catch (error) {
      console.error('❌ Error al intentar el webhook:', error.response?.data || error.message);
      return false;
    }
  }

  async unregisterWebhook() {
    try {
      console.log('\n🗑️ Eliminando webhook...');
      const response = await axios.delete(
        `${this.config.baseUrl}/mobile-webhook/unregister`,
        {
          headers: {
            'Authorization': `Bearer ${this.token}`,
            'Content-Type': 'application/json'
          },
          data: {
            deviceToken: this.config.deviceToken
          }
        }
      );

      console.log('✅ Webhook eliminado correctamente.');
      console.log('Respuesta:', JSON.stringify(response.data, null, 2));
      return true;
    } catch (error) {
      console.error('❌ Error al eliminar el webhook:', error.response?.data || error.message);
      return false;
    }
  }

  async runFullTest() {
    console.log('🚀 Iniciando prueba completa de webhook móvil\n');
    console.log('Configuración:');
    console.log(`- Base URL: ${this.config.baseUrl} ${process.env.BACKEND_URL || process.env.API_URL ? '(de .env)' : '(Predeterminado)'}`);
    console.log(`- Webhook URL: ${this.config.webhookUrl}`);
    console.log(`- Device Token: ${this.config.deviceToken}`);
    console.log(`- Plataforma: ${this.config.platform}\n`);

    // 1. Login
    const loginSuccess = await this.login();
    if (!loginSuccess) return;

    // 2. Registrar webhook
    const registerSuccess = await this.registerWebhook();
    if (!registerSuccess) return;

    // 3. Lista webhooks
    await this.listWebhooks();

    // 4. Prueba webhook
    await this.testWebhook();

    // 5. Aguardar um pouco
    console.log('\n⏳ Esperando 5 segundos...');
    await new Promise(resolve => setTimeout(resolve, 5000));

    // 6. Eliminar webhook (Opcional)
    const shouldRemove = process.argv.includes('--remove');
    if (shouldRemove) {
      await this.unregisterWebhook();
    } else {
      console.log('\n💡 Para eliminar el webhook, Ejecutar: node test-mobile-webhook.js --remove');
    }

    console.log('\n🎉 Prueba completada!');
  }
}

// Executar teste
const tester = new MobileWebhookTester(CONFIG);
tester.runFullTest().catch(console.error);

// Exemplo de uso:
// node examples/test-mobile-webhook.js           # Regístrate y prueba
// node examples/test-mobile-webhook.js --remove  # Elimina también el webhook
