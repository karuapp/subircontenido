# 📱 API de webhook para notificaciones móviles

Esta API permite que las aplicaciones de Android e iOS reciban notificaciones en tiempo real de nuevos mensajes de Whaticket..

## 🔗 Endpoints Base

```
Base URL: https://yourdomain.com/mobile-webhook
```

## 🔐 Autenticación

Todas las rutas requieren autenticación mediante token JWT en el encabezado.:

```
Authorization: Bearer <seu_jwt_token>
```

## 📋 Puntos de conexión disponibles

### 1. Registrar Webhook

**POST** `/mobile-webhook/register`

Registra un webhook para recibir notificaciones de mensajes..

#### Solicitud Body:
```json
{
  "webhookUrl": "https://seuapp.com/webhook/notifications",
  "deviceToken": "device_token_unico_de_app",
  "platform": "android" // ou "ios"
}
```

#### Respuesta (201):
```json
{
  "message": "Webhook Registrado correctamente.",
  "webhook": {
    "id": 1,
    "userId": 123,
    "companyId": 1,
    "webhookUrl": "https://seuapp.com/webhook/notifications",
    "deviceToken": "device_token_unico_do_app",
    "platform": "android",
    "isActive": true,
    "createdAt": "2024-12-01T10:00:00.000Z"
  }
}
```

### 2. Eliminar Webhook

**DELETE** `/mobile-webhook/unregister`

Elimina o deshabilita un webhook existente..

#### Solicitud Body:
```json
{
  "deviceToken": "device_token_unico_do_app"
}
```

#### Respuesta (200):
```json
{
  "message": "Webhook Eliminado correctamente"
}
```

### 3. Lista Webhooks

**GET** `/mobile-webhook/list`

Enumera todos los webhooks activos del usuario..

#### Respuesta (200):
```json
{
  "webhooks": [
    {
      "id": 1,
      "userId": 123,
      "companyId": 1,
      "webhookUrl": "https://yourapp.com/webhook/notifications",
      "deviceToken": "device_token_unico_do_app",
      "platform": "android",
      "isActive": true,
      "createdAt": "2024-12-01T10:00:00.000Z"
    }
  ]
}
```

### 4. Prueba Webhook

**POST** `/mobile-webhook/test`

Envía una notificación de prueba para verificar si el webhook funciona..

#### Solicitud Body:
```json
{
  "deviceToken": "device_token_unico_do_app"
}
```

#### Respuesta (200):
```json
{
  "message": "Notificación de prueba enviada correctamente."
}
```

## 📨 Formato de las notificaciones recibidas

Cuando llega un nuevo mensaje, tu webhook recibirá un POST con el siguiente formato::

### Notificación de nuevo mensaje:
```json
{
  "type": "new_message",
  "title": "Nuevo mensaje - Juan Lopez",
  "message": "Hola, necesito ayuda con mi pedido.",
  "timestamp": "2024-12-01T10:30:00.000Z",
  "companyId": 1,
  "ticketId": 456,
  "contactId": 789,
  "contactName": "Juan Lopez",
  "fromMe": false,
  "messageId": 12345,
  "queueId": 2
}
```

### Notificación de prueba:
```json
{
  "type": "test",
  "title": "Prueba de notificaciones",
  "message": "Esta es una prueba del sistema de notificaciones móviles.",
  "timestamp": "2024-12-01T10:30:00.000Z",
  "userId": 123,
  "companyId": 1
}
```

## 🔒 Filtros de seguridad.

### Por Empresa:
- Los usuarios solo reciben notificaciones de mensajes de su empresa.
- `companyId` Siempre corresponde a la empresa del usuario autenticado.

### Por Usuário:
- Si el mensaje tiene un usuario responsable específico, Sólo él recibe la notificación.
- Los mensajes sin un usuario específico se envían a todos los webhooks de la empresa

### Por tipo de mensaje:
- Solo mensajes recibidos **recibidos** (`fromMe: false`) generar notificaciones
- Los mensajes enviados por el propio usuario no generan notificaciones.

## 🛠️ Implementación en la aplicación móvil.

### 1. Registrar el webhook al iniciar sesión.:
```javascript
// Ejemplo en React Native
const registerWebhook = async () => {
  try {
    const response = await fetch('https://tudominio.com/mobile-webhook/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`
      },
      body: JSON.stringify({
        webhookUrl: 'https://tuaplicación.com/webhook/notifications',
        deviceToken: await getDeviceToken(), // Token único de dispositivo
        platform: Platform.OS // 'android' ou 'ios'
      })
    });
    
    const data = await response.json();
    console.log('Webhook registrado:', data);
  } catch (error) {
    console.error('Error al registrar el webhook:', error);
  }
};
```

### 2. Punto final en tu aplicación para recibir notificaciones:
```javascript
// Ejemplo de punto final en su servidor.
app.post('/webhook/notifications', (req, res) => {
  const notification = req.body;
  
  // Processar notificação
  if (notification.type === 'new_message') {
    // Enviar notificaciones push al dispositivo.
    sendPushNotification({
      title: notification.title,
      body: notification.message,
      data: {
        ticketId: notification.ticketId,
        contactId: notification.contactId,
        messageId: notification.messageId
      }
    });
  }
  
  res.status(200).json({ received: true });
});
```

### 3. Eliminar webhook al cerrar sesión:
```javascript
const unregisterWebhook = async () => {
  try {
    await fetch('https://tudominio.com/mobile-webhook/unregister', {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userToken}`
      },
      body: JSON.stringify({
        deviceToken: await getDeviceToken()
      })
    });
  } catch (error) {
    console.error('Error al eliminar el webhook:', error);
  }
};
```

## ⚠️ Consideraciones importantes

### Timeout:
- Los webhooks tienen un tiempo de espera de 5 segundos.
- Si el punto final no responde en 5 segundos, Se considerará un fracaso.

### Fallos:
- Después de 5 fallos consecutivos, El webhook se desactiva automáticamente.
- Puede reactivar registrándose de nuevo

### Headers de las solicitudes:
```
Content-Type: application/json
User-Agent: Whaticket-Mobile-Webhook/1.0
```

### Códigos de estado esperados:
- **200-299**: Éxito
- **Otros**: Considerado un fallo

## 🔧 Ejemplo de integración completa

```javascript
class WhatiketWebhook {
  constructor(baseUrl, token) {
    this.baseUrl = baseUrl;
    this.token = token;
  }

  async register(webhookUrl, deviceToken, platform) {
    const response = await fetch(`${this.baseUrl}/mobile-webhook/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`
      },
      body: JSON.stringify({ webhookUrl, deviceToken, platform })
    });
    return response.json();
  }

  async unregister(deviceToken) {
    const response = await fetch(`${this.baseUrl}/mobile-webhook/unregister`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`
      },
      body: JSON.stringify({ deviceToken })
    });
    return response.json();
  }

  async test(deviceToken) {
    const response = await fetch(`${this.baseUrl}/mobile-webhook/test`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`
      },
      body: JSON.stringify({ deviceToken })
    });
    return response.json();
  }
}

// Uso:
const webhook = new WhatiketWebhook('https://tudominio.com', userToken);
await webhook.register('https://tuaplicación.com/notifications', 'device123', 'android');
```

## 🚀 Próximos Passos

1. **Implementar o endpoint** en su aplicación para recibir notificaciones
2. **Registrar o webhook** cuando el usuario inicia sesión
3. **Testar** con el punto final de prueba
4. **Implementar push notifications** en su aplicación
5. **Remover webhook** cuando el usuario cierra sesión

¡Ahora tiene un sistema completo de notificaciones móviles integrado con Whaticket! 🎉
