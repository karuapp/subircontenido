-- PostgreSQL: Adiciona coluna loadingImage na tabela Companies
-- Se a coluna já existir, este comando vai dar erro (é normal)
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'Companies' AND column_name = 'loadingImage'
    ) THEN
        ALTER TABLE "Companies" ADD COLUMN "loadingImage" VARCHAR(255);
    END IF;
END $$;

-- Verifica se a coluna foi criada
SELECT column_name, data_type, is_nullable 
FROM information_schema.columns 
WHERE table_name = 'Companies' AND column_name = 'loadingImage';
