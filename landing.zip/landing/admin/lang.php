<?php
session_start();
if (!isset($_SESSION['logged'])) {
    header("Location: index.php");
    exit;
}

$langDir = __DIR__ . "/../lang/";

// Archivos disponibles
$files = [
    "es" => "es.php",
    "en" => "en.php",
    "fr" => "fr.php",
    "ptBR" => "ptBR.php"
];

// Detectar idioma seleccionado
$selected = $_GET['lang'] ?? "es";
$filePath = $langDir . $files[$selected];

if (!file_exists($filePath)) {
    die("Archivo de idioma no encontrado");
}

$data = include($filePath);

// Guardar cambios
if (isset($_POST['save'])) {
    foreach ($data as $k => $v) {
        if (isset($_POST[$k])) {
            $data[$k] = $_POST[$k];
        }
    }

    $new_content = "<?php\nreturn [\n\n";
    foreach ($data as $k => $v) {
        $new_content .= "  '" . addslashes($k) . "' => '" . addslashes($v) . "',\n";
    }
    $new_content .= "\n];\n?>";

    file_put_contents($filePath, $new_content);
    $msg = "✅ Idioma $selected guardado correctamente";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar Idiomas</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark px-3">
  <a href="index.php" class="navbar-brand">⚡️ Admin</a>
  <div>
    <a href="index.php" class="btn btn-outline-light btn-sm">Configuración</a>
    <a href="lang.php" class="btn btn-outline-light btn-sm">Editar Lenguajes</a>
    <a href="index.php?logout=1" class="btn btn-outline-light btn-sm">Salir</a>
  </div>
</nav>

<div class="container py-4">
  <h3 class="mb-3">🌐 Editor de Idiomas</h3>

  <form method="get" class="mb-4">
    <label>Selecciona idioma:</label>
    <select name="lang" onchange="this.form.submit()" class="form-select" style="width:200px;">
      <?php foreach ($files as $code => $file): ?>
        <option value="<?= $code ?>" <?= $selected==$code?"selected":"" ?>><?= strtoupper($code) ?></option>
      <?php endforeach; ?>
    </select>
  </form>

  <?php if(isset($msg)): ?>
    <div class="alert alert-success"><?= $msg ?></div>
  <?php endif; ?>

  <!-- 🔍 Buscador -->
  <div class="mb-3">
    <input type="text" id="searchInput" class="form-control" placeholder="🔍 Buscar clave o texto...">
  </div>

  <form method="post" id="langForm">
    <?php foreach ($data as $k => $v): ?>
      <div class="mb-3 lang-item">
        <label class="form-label"><strong><?= $k ?></strong></label>
        <input type="text" name="<?= $k ?>" class="form-control" value="<?= htmlspecialchars($v) ?>">
      </div>
    <?php endforeach; ?>
    <button class="btn btn-primary" name="save">💾 Guardar</button>
  </form>
</div>

<script>
// 🔍 Filtro en tiempo real
document.getElementById("searchInput").addEventListener("keyup", function() {
  let filter = this.value.toLowerCase();
  document.querySelectorAll(".lang-item").forEach(function(item) {
    let label = item.querySelector("label").innerText.toLowerCase();
    let input = item.querySelector("input").value.toLowerCase();
    if (label.includes(filter) || input.includes(filter)) {
      item.style.display = "";
    } else {
      item.style.display = "none";
    }
  });
});
</script>
</body>
</html>
