<?php
session_start();

// --- CONFIG LOGIN ---
// Usuario y contraseña predefinidos
$USER = "root";
$PASS = "Mscur@681836";

// Ruta del config
$config_file = __DIR__ . "/../config.php";

// --- LOGIN ---
if (isset($_POST['username']) && isset($_POST['password'])) {
    if ($_POST['username'] === $USER && $_POST['password'] === $PASS) {
        $_SESSION['logged'] = true;
    } else {
        $error = "Usuario o contraseña incorrectos";
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}

// --- SI NO ESTÁ LOGUEADO, MOSTRAR LOGIN ---
if (!isset($_SESSION['logged'])) {
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Login Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center vh-100">
  <div class="card shadow p-4" style="width:350px;">
    <h4 class="mb-3">🔐 Admin Login</h4>
    <?php if(isset($error)): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    <form method="post">
      <div class="mb-3">
        <label>Usuario</label>
        <input type="text" name="username" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Contraseña</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button class="btn btn-primary w-100">Ingresar</button>
    </form>
  </div>
</body>
</html>
<?php
exit;
}

// --- LEER CONFIG ---
$config = include($config_file);

// --- GUARDAR CAMBIOS ---
if (isset($_POST['save'])) {
    foreach ($config as $k => $v) {
        if (isset($_POST[$k])) {
            $config[$k] = $_POST[$k];
        }
    }

    // Generar nuevo contenido de config.php
    $new_content = "<?php\nreturn [\n\n";
    foreach ($config as $k => $v) {
        $new_content .= "    '$k' => '" . addslashes($v) . "',\n\n";
    }
    $new_content .= "];\n?>";

    file_put_contents($config_file, $new_content);
    $msg = "✅ Configuración guardada correctamente";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Admin Configuración</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark px-3">
  <span class="navbar-brand">⚡️ Panel Admin</span>
  <a href="?logout=1" class="btn btn-outline-light btn-sm">Salir</a>
</nav>

<div class="container py-4">
  <h3 class="mb-3">Editar Configuración</h3>
  <?php if(isset($msg)): ?>
    <div class="alert alert-success"><?= $msg ?></div>
  <?php endif; ?>

  <form method="post">
    <?php foreach ($config as $k => $v): ?>
      <div class="mb-3">
        <label class="form-label"><strong><?= $k ?></strong></label>
        <?php if($k === "videoyoutube"): ?>
          <select name="<?= $k ?>" class="form-select">
            <option value="true" <?= $v=="true"?"selected":"" ?>>Activado</option>
            <option value="false" <?= $v=="false"?"selected":"" ?>>Desactivado</option>
          </select>
        <?php else: ?>
          <input type="text" name="<?= $k ?>" class="form-control" value="<?= htmlspecialchars($v) ?>">
        <?php endif; ?>
      </div>
    <?php endforeach; ?>

    <h5 class="mt-4">🔗 Imágenes</h5>
    <div class="mb-3">
      <label>Favicon</label>
      <input type="text" name="favicon" class="form-control" value="images/square-logo.png">
    </div>
    <div class="mb-3">
      <label>Logo</label>
      <input type="text" name="logo" class="form-control" value="images/logo-skyblue.png">
    </div>

    <button class="btn btn-primary" name="save">💾 Guardar Cambios</button>
  </form>
</div>
</body>
</html>
