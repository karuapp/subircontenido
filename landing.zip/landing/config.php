<?php
return [


        
    'namesite' => '⚡️ Probiz',


     
    'whatsapp_number' => '00123456789',

     
    'domain' => 'https://app.probiz.chat/',

    
    'mail' => 'probiz.chat@gmail.com',

    
    'domain_app' => 'https://app.probiz.chat/',

    
    'domain_api' => 'https://api.probiz.chat/',

    
    'domain_signup' => 'https://app.probiz.chat/#/signup',




    
    'videoyoutube' =>'false',

    
    'youtubevideo' => 'https://www.youtube.com/watch?v=',




    
    'youtube' => 'https://youtube.com',

    
    'facebook' => 'https://facebook.com',

    
    'instagram' => 'https://instagram.com',

    
    'tiktok' => 'https://tiktok.com',

    'favicon' => 'images/square-logo.png',
    'logo' => 'images/logo-skyblue.png',


    'moneda' => '$',


    'plan1name' => 'Plan Básico', 
    'plan1price' => '200', 
    'plan1priceanual' => '1,500', 
    'plan1descuento' => 'Ahorra 37%', 
    'conexionesplan1' => '3 Canalaes', 
    'agentesplan1' => '10 Agentes', 


    'plan2name' => 'Plan Avanzado', 
    'plan2price' => '500', 
    'plan2priceanual' => '4,500', 
    'plan2descuento' => 'Ahorra 25%', 
    'conexionesplan2' => '5 Canalaes', 
    'agentesplan2' => '25 Agentes', 


    'plan3name' => 'Plan Premium',  
    'plan3price' => '1,000', 
    'plan3priceanual' => '9,000', 
    'plan3descuento' => 'Ahorra 25%', 
    'conexionesplan3' => '10 Canalaes', 
    'agentesplan3' => '50 Agentes', 




    
    
    
    
    
];
?>