export function capitalize(str) {
    // Comprueba que la cadena no esté vacía.
    if (str.length === 0) {
      return str;
    }
  
    // Escribe la primera letra en mayúscula y concatena el resto de la cadena.
    return str.charAt(0).toUpperCase() + str.slice(1);
  }