class FormatMask {
  // No formatea, solo devuelve números limpios
  setPhoneFormatMask(phoneToFormat) {
    if (!phoneToFormat) {
      return "";
    }

    // Devuelve solo números
    return ("" + phoneToFormat).replace(/\D/g, "");
  }

  // Elimina cualquier máscara (igual que arriba)
  removeMask(number) {
    if (!number) {
      return "";
    }

    return number.replace(/\D/g, "");
  }

  // No devuelve patrón de país
  maskPhonePattern() {
    return "Ej: 50499999999";
  }
}

export { FormatMask };