import { FormatMask } from './FormatMask';

const formatSerializedId = (serializedId) => {
  if (!serializedId) return "";

  const formatMask = new FormatMask();

  // Quita el sufijo de WhatsApp
  const number = serializedId.replace('@c.us', '');

  // Devuelve número limpio (sin formato país)
  return formatMask.setPhoneFormatMask(number);
};

export default formatSerializedId;