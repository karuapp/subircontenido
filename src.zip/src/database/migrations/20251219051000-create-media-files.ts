import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.createTable("media_files", {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      folder_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: "media_folders", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      company_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: "Companies", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      original_name: {
        type: DataTypes.STRING,
        allowNull: false
      },
      custom_name: {
        type: DataTypes.STRING,
        allowNull: true
      },
      mime_type: {
        type: DataTypes.STRING,
        allowNull: false
      },
      size: {
        type: DataTypes.BIGINT,
        allowNull: false
      },
      storage_path: {
        type: DataTypes.TEXT,
        allowNull: false
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });

    await queryInterface.sequelize.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_indexes WHERE indexname = 'media_files_folder_id_idx'
        ) THEN
          CREATE INDEX media_files_folder_id_idx ON media_files (folder_id);
        END IF;
      END$$;
    `);

    await queryInterface.sequelize.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_indexes WHERE indexname = 'media_files_company_id_idx'
        ) THEN
          CREATE INDEX media_files_company_id_idx ON media_files (company_id);
        END IF;
      END$$;
    `);
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.sequelize.query(`
      DO $$
      BEGIN
        IF EXISTS (
          SELECT 1 FROM pg_indexes WHERE indexname = 'media_files_folder_id_idx'
        ) THEN
          DROP INDEX media_files_folder_id_idx;
        END IF;
      END$$;
    `);

    await queryInterface.sequelize.query(`
      DO $$
      BEGIN
        IF EXISTS (
          SELECT 1 FROM pg_indexes WHERE indexname = 'media_files_company_id_idx'
        ) THEN
          DROP INDEX media_files_company_id_idx;
        END IF;
      END$$;
    `);

    await queryInterface.dropTable("media_files");
  }
};
