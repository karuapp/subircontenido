// @ts-nocheck
import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.createTable("projects", {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true
      },
      companyId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: "Companies", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      clientId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: "crm_clients", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "RESTRICT"
      },
      invoiceId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: { model: "Invoices", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "SET NULL"
      },
      name: {
        type: DataTypes.STRING(255),
        allowNull: false
      },
      description: {
        type: DataTypes.TEXT,
        allowNull: true
      },
      deliveryTime: {
        type: DataTypes.DATE,
        allowNull: true
      },
      warranty: {
        type: DataTypes.TEXT,
        allowNull: true
      },
      terms: {
        type: DataTypes.TEXT,
        allowNull: true
      },
      status: {
        type: DataTypes.STRING(30),
        allowNull: false,
        defaultValue: "draft"
      },
      startDate: {
        type: DataTypes.DATE,
        allowNull: true
      },
      endDate: {
        type: DataTypes.DATE,
        allowNull: true
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    });

    await queryInterface.addIndex("projects", ["companyId"]);
    await queryInterface.addIndex("projects", ["clientId"]);
    await queryInterface.addIndex("projects", ["invoiceId"]);
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.dropTable("projects");
  }
};
