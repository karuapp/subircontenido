import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    // crm_leads
    await queryInterface.addColumn("crm_leads", "contact_id", {
      type: DataTypes.BIGINT,
      references: { model: "Contacts", key: "id" },
      onUpdate: "CASCADE",
      onDelete: "SET NULL",
      allowNull: true
    });

    await queryInterface.addColumn("crm_leads", "primary_ticket_id", {
      type: DataTypes.BIGINT,
      references: { model: "Tickets", key: "id" },
      onUpdate: "CASCADE",
      onDelete: "SET NULL",
      allowNull: true
    });

    await queryInterface.addColumn("crm_leads", "converted_client_id", {
      type: DataTypes.BIGINT,
      references: { model: "crm_clients", key: "id" },
      onUpdate: "CASCADE",
      onDelete: "SET NULL",
      allowNull: true
    });

    await queryInterface.addColumn("crm_leads", "converted_at", {
      type: DataTypes.DATE,
      allowNull: true
    });

    await queryInterface.addColumn("crm_leads", "lead_status", {
      type: DataTypes.STRING(32),
      allowNull: false,
      defaultValue: "novo"
    });

    await queryInterface.addIndex("crm_leads", ["contact_id"], {
      name: "idx_crm_leads_contact_id"
    });

    await queryInterface.addIndex("crm_leads", ["lead_status"], {
      name: "idx_crm_leads_lead_status"
    });

    // crm_clients
    await queryInterface.addColumn("crm_clients", "contact_id", {
      type: DataTypes.BIGINT,
      references: { model: "Contacts", key: "id" },
      onUpdate: "CASCADE",
      onDelete: "SET NULL",
      allowNull: true
    });

    await queryInterface.addColumn("crm_clients", "primary_ticket_id", {
      type: DataTypes.BIGINT,
      references: { model: "Tickets", key: "id" },
      onUpdate: "CASCADE",
      onDelete: "SET NULL",
      allowNull: true
    });

    await queryInterface.addIndex("crm_clients", ["contact_id"], {
      name: "idx_crm_clients_contact_id"
    });

    // Tickets
    await queryInterface.addColumn("Tickets", "crm_lead_id", {
      type: DataTypes.BIGINT,
      references: { model: "crm_leads", key: "id" },
      onUpdate: "CASCADE",
      onDelete: "SET NULL",
      allowNull: true
    });

    await queryInterface.addColumn("Tickets", "crm_client_id", {
      type: DataTypes.BIGINT,
      references: { model: "crm_clients", key: "id" },
      onUpdate: "CASCADE",
      onDelete: "SET NULL",
      allowNull: true
    });

    await queryInterface.addIndex("Tickets", ["crm_lead_id"], {
      name: "idx_tickets_crm_lead_id"
    });

    await queryInterface.addIndex("Tickets", ["crm_client_id"], {
      name: "idx_tickets_crm_client_id"
    });

    // Contacts unique constraint (empresa + número)
    await queryInterface.addConstraint(
      "Contacts",
      ["companyId", "number"],
      {
        type: "unique",
        name: "contacts_company_number_unique"
      }
    );

    // crm_client_contacts pivot table
    await queryInterface.createTable("crm_client_contacts", {
      id: {
        type: DataTypes.BIGINT,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      client_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        references: { model: "crm_clients", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      contact_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        references: { model: "Contacts", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      role: {
        type: DataTypes.STRING(50)
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });

    await queryInterface.addConstraint(
      "crm_client_contacts",
      ["client_id", "contact_id"],
      {
        type: "unique",
        name: "crm_client_contacts_unique"
      }
    );

    await queryInterface.addIndex("crm_client_contacts", ["contact_id"], {
      name: "idx_client_contacts_contact"
    });
  },

  down: async (queryInterface: QueryInterface) => {
    // Drop client-contact relation table
    await queryInterface.dropTable("crm_client_contacts");

    await queryInterface.removeIndex("Tickets", "idx_tickets_crm_client_id");
    await queryInterface.removeIndex("Tickets", "idx_tickets_crm_lead_id");
    await queryInterface.removeColumn("Tickets", "crm_client_id");
    await queryInterface.removeColumn("Tickets", "crm_lead_id");

    await queryInterface.removeIndex("crm_clients", "idx_crm_clients_contact_id");
    await queryInterface.removeColumn("crm_clients", "primary_ticket_id");
    await queryInterface.removeColumn("crm_clients", "contact_id");

    await queryInterface.removeIndex("crm_leads", "idx_crm_leads_lead_status");
    await queryInterface.removeIndex("crm_leads", "idx_crm_leads_contact_id");
    await queryInterface.removeColumn("crm_leads", "lead_status");
    await queryInterface.removeColumn("crm_leads", "converted_at");
    await queryInterface.removeColumn("crm_leads", "converted_client_id");
    await queryInterface.removeColumn("crm_leads", "primary_ticket_id");
    await queryInterface.removeColumn("crm_leads", "contact_id");

    await queryInterface.removeConstraint("Contacts", "contacts_company_number_unique");
  }
};
