import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.createTable("financeiro_pagamentos", {
      id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      company_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        references: { model: "Companies", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      fatura_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        references: { model: "financeiro_faturas", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      metodo_pagamento: {
        type: DataTypes.STRING(20),
        allowNull: false
      },
      valor: {
        type: DataTypes.DECIMAL(14, 2),
        allowNull: false
      },
      data_pagamento: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      observacoes: {
        type: DataTypes.TEXT,
        allowNull: true
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });

    await queryInterface.sequelize.query(`
      ALTER TABLE financeiro_pagamentos
      ADD CONSTRAINT fk_financeiro_pagamentos_fatura
      FOREIGN KEY (fatura_id, company_id)
      REFERENCES financeiro_faturas (id, company_id)
      ON DELETE CASCADE
      ON UPDATE CASCADE
    `);

    await queryInterface.addIndex(
      "financeiro_pagamentos",
      ["company_id"],
      {
        name: "idx_financeiro_pagamentos_company"
      }
    );
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.dropTable("financeiro_pagamentos");
  }
};
