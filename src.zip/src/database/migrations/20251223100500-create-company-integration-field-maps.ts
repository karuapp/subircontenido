import { DataTypes, QueryInterface } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.createTable("company_integration_field_maps", {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true
      },
      integration_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: "company_integration_settings", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      external_field: {
        type: DataTypes.STRING,
        allowNull: false
      },
      crm_field: {
        type: DataTypes.STRING,
        allowNull: true
      },
      transform_expression: {
        type: DataTypes.TEXT,
        allowNull: true
      },
      options: {
        type: DataTypes.JSONB,
        allowNull: true
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });

    await queryInterface.addIndex(
      "company_integration_field_maps",
      ["integration_id", "external_field"],
      {
        name: "company_integration_field_maps_unique",
        unique: true
      }
    );
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.removeIndex(
      "company_integration_field_maps",
      "company_integration_field_maps_unique"
    );
    await queryInterface.dropTable("company_integration_field_maps");
  }
};
