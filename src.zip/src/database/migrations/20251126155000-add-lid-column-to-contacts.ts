import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    // Adiciona a coluna 'lid' à tabela 'Contacts'
    await queryInterface.addColumn("Contacts", "lid", {
      type: DataTypes.STRING,
      allowNull: true,
      comment: "Armazena o LID (Link ID) do WhatsApp para contatos com privacidade ativada"
    });

    // Adiciona um índice para melhorar consultas por LID
    await queryInterface.addIndex("Contacts", ["lid"], {
      name: "contacts_lid_index",
      unique: false
    });

    console.log('Coluna "lid" adicionada à tabela Contacts com sucesso');
  },

  down: async (queryInterface: QueryInterface) => {
    // Remove o índice
    await queryInterface.removeIndex("Contacts", "contacts_lid_index");
    
    // Remove a coluna
    await queryInterface.removeColumn("Contacts", "lid");
    
    console.log('Coluna "lid" removida da tabela Contacts com sucesso');
  }
};
