import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    // Tabela principal de Automações
    await queryInterface.createTable("Automations", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      companyId: {
        type: DataTypes.INTEGER,
        references: { model: "Companies", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE",
        allowNull: false
      },
      name: {
        type: DataTypes.STRING(255),
        allowNull: false
      },
      description: {
        type: DataTypes.TEXT,
        allowNull: true
      },
      triggerType: {
        type: DataTypes.STRING(50),
        allowNull: false
      },
      triggerConfig: {
        type: DataTypes.JSONB,
        defaultValue: {}
      },
      isActive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });

    // Índices para Automations
    await queryInterface.addIndex("Automations", ["companyId"], { name: "automations_company_id" });
    await queryInterface.addIndex("Automations", ["triggerType"], { name: "automations_trigger_type" });
    await queryInterface.addIndex("Automations", ["isActive"], { name: "automations_is_active" });

    // Tabela de Ações das Automações
    await queryInterface.createTable("AutomationActions", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      automationId: {
        type: DataTypes.INTEGER,
        references: { model: "Automations", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE",
        allowNull: false
      },
      actionType: {
        type: DataTypes.STRING(50),
        allowNull: false
      },
      actionConfig: {
        type: DataTypes.JSONB,
        defaultValue: {}
      },
      order: {
        type: DataTypes.INTEGER,
        defaultValue: 1
      },
      delayMinutes: {
        type: DataTypes.INTEGER,
        defaultValue: 0
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });

    // Índices para AutomationActions
    await queryInterface.addIndex("AutomationActions", ["automationId"], { name: "automation_actions_automation_id" });
    await queryInterface.addIndex("AutomationActions", ["order"], { name: "automation_actions_order" });

    // Tabela de Logs/Histórico de Execuções
    await queryInterface.createTable("AutomationLogs", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      automationId: {
        type: DataTypes.INTEGER,
        references: { model: "Automations", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE",
        allowNull: false
      },
      contactId: {
        type: DataTypes.INTEGER,
        references: { model: "Contacts", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "SET NULL",
        allowNull: true
      },
      ticketId: {
        type: DataTypes.INTEGER,
        references: { model: "Tickets", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "SET NULL",
        allowNull: true
      },
      status: {
        type: DataTypes.STRING(20),
        defaultValue: "pending"
      },
      executedAt: {
        type: DataTypes.DATE,
        allowNull: true
      },
      result: {
        type: DataTypes.JSONB,
        defaultValue: {}
      },
      error: {
        type: DataTypes.TEXT,
        allowNull: true
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });

    // Índices para AutomationLogs
    await queryInterface.addIndex("AutomationLogs", ["automationId"], { name: "automation_logs_automation_id" });
    await queryInterface.addIndex("AutomationLogs", ["contactId"], { name: "automation_logs_contact_id" });
    await queryInterface.addIndex("AutomationLogs", ["ticketId"], { name: "automation_logs_ticket_id" });
    await queryInterface.addIndex("AutomationLogs", ["status"], { name: "automation_logs_status" });
    await queryInterface.addIndex("AutomationLogs", ["executedAt"], { name: "automation_logs_executed_at" });

    // Tabela de Execuções Pendentes
    await queryInterface.createTable("AutomationExecutions", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      automationId: {
        type: DataTypes.INTEGER,
        references: { model: "Automations", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE",
        allowNull: false
      },
      automationActionId: {
        type: DataTypes.INTEGER,
        references: { model: "AutomationActions", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE",
        allowNull: false
      },
      contactId: {
        type: DataTypes.INTEGER,
        references: { model: "Contacts", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE",
        allowNull: true
      },
      ticketId: {
        type: DataTypes.INTEGER,
        references: { model: "Tickets", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "SET NULL",
        allowNull: true
      },
      scheduledAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      status: {
        type: DataTypes.STRING(20),
        defaultValue: "scheduled"
      },
      attempts: {
        type: DataTypes.INTEGER,
        defaultValue: 0
      },
      lastAttemptAt: {
        type: DataTypes.DATE,
        allowNull: true
      },
      completedAt: {
        type: DataTypes.DATE,
        allowNull: true
      },
      error: {
        type: DataTypes.TEXT,
        allowNull: true
      },
      metadata: {
        type: DataTypes.JSONB,
        defaultValue: {}
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });

    // Índices para AutomationExecutions
    await queryInterface.addIndex("AutomationExecutions", ["automationId"], { name: "automation_executions_automation_id" });
    await queryInterface.addIndex("AutomationExecutions", ["contactId"], { name: "automation_executions_contact_id" });
    await queryInterface.addIndex("AutomationExecutions", ["scheduledAt"], { name: "automation_executions_scheduled_at" });
    await queryInterface.addIndex("AutomationExecutions", ["status"], { name: "automation_executions_status" });
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.dropTable("AutomationExecutions");
    await queryInterface.dropTable("AutomationLogs");
    await queryInterface.dropTable("AutomationActions");
    await queryInterface.dropTable("Automations");
  }
};
