import { QueryInterface, DataTypes } from "sequelize";

interface ExistingTables {
  [key: string]: any;
}

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    const table = "IaWorkflows";

    const existingTables: ExistingTables = await queryInterface.showAllTables();

    if (!existingTables.includes(table)) {
      return queryInterface.createTable(table, {
        id: {
          type: DataTypes.INTEGER,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false
        },
        companyId: {
          type: DataTypes.INTEGER,
          allowNull: false
        },
        orchestratorPromptId: {
          type: DataTypes.INTEGER,
          allowNull: false
        },
        agentPromptId: {
          type: DataTypes.INTEGER,
          allowNull: false
        },
        alias: {
          type: DataTypes.STRING,
          allowNull: false
        },
        createdAt: {
          type: DataTypes.DATE(6),
          allowNull: false
        },
        updatedAt: {
          type: DataTypes.DATE(6),
          allowNull: false
        }
      });
    }
  },

  down: async (queryInterface: QueryInterface) => {
    return queryInterface.dropTable("IaWorkflows");
  }
};
