import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    // Adiciona campo userType (atendente ou profissional)
    await queryInterface.addColumn("Users", "userType", {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: "attendant" // atendente por padrão
    });

    // Adiciona campo workDays (dias de trabalho - array de dias)
    await queryInterface.addColumn("Users", "workDays", {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: "1,2,3,4,5" // Segunda a Sexta por padrão
    });

    // Adiciona campo lunchStart (início do almoço)
    await queryInterface.addColumn("Users", "lunchStart", {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    });

    // Adiciona campo lunchEnd (fim do almoço)
    await queryInterface.addColumn("Users", "lunchEnd", {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: null
    });
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.removeColumn("Users", "userType");
    await queryInterface.removeColumn("Users", "workDays");
    await queryInterface.removeColumn("Users", "lunchStart");
    await queryInterface.removeColumn("Users", "lunchEnd");
  }
};
