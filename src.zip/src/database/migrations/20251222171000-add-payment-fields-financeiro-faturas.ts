import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.addColumn("financeiro_faturas", "payment_provider", {
      type: DataTypes.STRING,
      allowNull: true
    });

    await queryInterface.addColumn("financeiro_faturas", "payment_link", {
      type: DataTypes.TEXT,
      allowNull: true
    });

    await queryInterface.addColumn("financeiro_faturas", "payment_external_id", {
      type: DataTypes.STRING,
      allowNull: true
    });
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.removeColumn("financeiro_faturas", "payment_provider");
    await queryInterface.removeColumn("financeiro_faturas", "payment_link");
    await queryInterface.removeColumn("financeiro_faturas", "payment_external_id");
  }
};
