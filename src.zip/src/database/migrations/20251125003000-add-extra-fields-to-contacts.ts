import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    const tableDesc: any = await queryInterface.describeTable("Contacts");

    if (!tableDesc.isLid) {
      await queryInterface.addColumn("Contacts", "isLid", {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
      });
    }

    if (!tableDesc.birthday) {
      await queryInterface.addColumn("Contacts", "birthday", {
        type: DataTypes.DATE,
        allowNull: true
      });
    }

    if (!tableDesc.anniversary) {
      await queryInterface.addColumn("Contacts", "anniversary", {
        type: DataTypes.DATE,
        allowNull: true
      });
    }

    if (!tableDesc.info) {
      await queryInterface.addColumn("Contacts", "info", {
        type: DataTypes.TEXT,
        allowNull: true
      });
    }

    if (!tableDesc.files) {
      await queryInterface.addColumn("Contacts", "files", {
        type: DataTypes.JSONB,
        allowNull: true
      });
    }

    if (!tableDesc.cpfCnpj) {
      await queryInterface.addColumn("Contacts", "cpfCnpj", {
        type: DataTypes.STRING(32),
        allowNull: true
      });
    }

    if (!tableDesc.address) {
      await queryInterface.addColumn("Contacts", "address", {
        type: DataTypes.STRING(255),
        allowNull: true
      });
    }
  },

  down: async (queryInterface: QueryInterface) => {
    const tableDesc: any = await queryInterface.describeTable("Contacts");
    if (tableDesc.address) await queryInterface.removeColumn("Contacts", "address");
    if (tableDesc.cpfCnpj) await queryInterface.removeColumn("Contacts", "cpfCnpj");
    if (tableDesc.files) await queryInterface.removeColumn("Contacts", "files");
    if (tableDesc.info) await queryInterface.removeColumn("Contacts", "info");
    if (tableDesc.anniversary) await queryInterface.removeColumn("Contacts", "anniversary");
    if (tableDesc.birthday) await queryInterface.removeColumn("Contacts", "birthday");
    if (tableDesc.isLid) await queryInterface.removeColumn("Contacts", "isLid");
  }
};
