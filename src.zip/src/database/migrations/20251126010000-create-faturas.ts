import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.createTable("Faturas", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      companyId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: "Companies", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      contactId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: "Contacts", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      valor: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false
      },
      descricao: {
        type: DataTypes.TEXT,
        allowNull: true
      },
      status: {
        type: DataTypes.STRING(20),
        allowNull: false,
        defaultValue: "pendente"
      },
      dataCriacao: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      dataVencimento: {
        type: DataTypes.DATE,
        allowNull: false
      },
      dataPagamento: {
        type: DataTypes.DATE,
        allowNull: true
      },
      recorrente: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
      },
      intervalo: {
        type: DataTypes.STRING(20),
        allowNull: true
      },
      proximaCobranca: {
        type: DataTypes.DATE,
        allowNull: true
      },
      limiteRecorrencias: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      recorrenciasRealizadas: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.dropTable("Faturas");
  }
};
