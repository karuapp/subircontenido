import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.createTable("financeiro_faturas", {
      id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      company_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        references: { model: "Companies", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      client_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        references: { model: "crm_clients", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      descricao: {
        type: DataTypes.STRING(255),
        allowNull: false
      },
      valor: {
        type: DataTypes.DECIMAL(14, 2),
        allowNull: false
      },
      valor_pago: {
        type: DataTypes.DECIMAL(14, 2),
        allowNull: false,
        defaultValue: 0
      },
      status: {
        type: DataTypes.STRING(20),
        allowNull: false,
        defaultValue: "aberta"
      },
      data_vencimento: {
        type: DataTypes.DATEONLY,
        allowNull: false
      },
      data_pagamento: {
        type: DataTypes.DATE,
        allowNull: true
      },
      tipo_referencia: {
        type: DataTypes.STRING(20),
        allowNull: true
      },
      referencia_id: {
        type: DataTypes.BIGINT,
        allowNull: true
      },
      tipo_recorrencia: {
        type: DataTypes.STRING(20),
        allowNull: false,
        defaultValue: "unica"
      },
      quantidade_ciclos: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      ciclo_atual: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 1
      },
      data_inicio: {
        type: DataTypes.DATEONLY,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      data_fim: {
        type: DataTypes.DATEONLY,
        allowNull: true
      },
      ativa: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      observacoes: {
        type: DataTypes.TEXT,
        allowNull: true
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });

    await queryInterface.sequelize.query(`
      ALTER TABLE financeiro_faturas
      ADD CONSTRAINT chk_financeiro_faturas_referencia
      CHECK (
        (tipo_referencia IS NULL AND referencia_id IS NULL) OR
        (tipo_referencia IS NOT NULL AND referencia_id IS NOT NULL)
      )
    `);

    await queryInterface.addIndex("financeiro_faturas", ["company_id"], {
      name: "idx_financeiro_faturas_company"
    });

    await queryInterface.addIndex(
      "financeiro_faturas",
      ["company_id", "status"],
      {
        name: "idx_financeiro_faturas_status"
      }
    );

    await queryInterface.addIndex(
      "financeiro_faturas",
      ["company_id", "tipo_recorrencia", "ativa"],
      {
        name: "idx_financeiro_faturas_recorrencia"
      }
    );

    await queryInterface.addConstraint(
      "financeiro_faturas",
      ["id", "company_id"],
      {
        type: "unique",
        name: "financeiro_faturas_id_company_unique"
      }
    );
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.removeConstraint(
      "financeiro_faturas",
      "financeiro_faturas_id_company_unique"
    );
    await queryInterface.dropTable("financeiro_faturas");
  }
};
