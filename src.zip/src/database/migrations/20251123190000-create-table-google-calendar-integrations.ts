import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: any) => {
    return queryInterface.createTable("GoogleCalendarIntegrations", {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      companyId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "Companies",
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      googleUserId: {
        type: DataTypes.STRING,
        allowNull: false
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false
      },
      accessToken: {
        type: DataTypes.TEXT,
        allowNull: false
      },
      refreshToken: {
        type: DataTypes.TEXT,
        allowNull: false
      },
      expiryDate: {
        type: DataTypes.DATE,
        allowNull: true
      },
      calendarId: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: "primary"
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
      }
    });
  },

  down: async (queryInterface: any) => {
    return queryInterface.dropTable("GoogleCalendarIntegrations");
  }
};
