import { QueryInterface } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.sequelize.query(`
      ALTER TABLE financeiro_faturas
      ADD COLUMN IF NOT EXISTS valor_pago DECIMAL(14,2) NOT NULL DEFAULT 0
    `);
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.sequelize.query(`
      ALTER TABLE financeiro_faturas
      DROP COLUMN IF EXISTS valor_pago
    `);
  }
};
