import { QueryInterface, DataTypes, Op } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.addColumn("financeiro_faturas", "checkout_token", {
      type: DataTypes.STRING(64),
      allowNull: true
    });

    await queryInterface.addIndex(
      "financeiro_faturas",
      ["checkout_token"],
      {
        name: "financeiro_faturas_checkout_token_idx",
        unique: true,
        where: {
          checkout_token: { [Op.ne]: null }
        }
      }
    );
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.removeIndex(
      "financeiro_faturas",
      "financeiro_faturas_checkout_token_idx"
    );
    await queryInterface.removeColumn("financeiro_faturas", "checkout_token");
  }
};
