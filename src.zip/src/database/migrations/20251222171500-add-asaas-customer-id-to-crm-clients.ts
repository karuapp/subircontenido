import { QueryInterface, DataTypes, Op } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.addColumn("crm_clients", "asaas_customer_id", {
      type: DataTypes.STRING,
      allowNull: true
    });

    await queryInterface.addIndex(
      "crm_clients",
      ["asaas_customer_id"],
      {
        name: "crm_clients_asaas_customer_id_idx",
        unique: true,
        where: {
          asaas_customer_id: { [Op.ne]: null }
        }
      }
    );
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.removeIndex(
      "crm_clients",
      "crm_clients_asaas_customer_id_idx"
    );
    await queryInterface.removeColumn("crm_clients", "asaas_customer_id");
  }
};
