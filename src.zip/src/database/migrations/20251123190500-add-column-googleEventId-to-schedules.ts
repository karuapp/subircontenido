import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    const tableDesc: any = await queryInterface.describeTable("Schedules");
    if (!tableDesc.googleEventId) {
      await queryInterface.addColumn("Schedules", "googleEventId", {
        type: DataTypes.STRING,
        allowNull: true
      });
    }
  },

  down: async (queryInterface: QueryInterface) => {
    const tableDesc: any = await queryInterface.describeTable("Schedules");
    if (tableDesc.googleEventId) {
      await queryInterface.removeColumn("Schedules", "googleEventId");
    }
  }
};
