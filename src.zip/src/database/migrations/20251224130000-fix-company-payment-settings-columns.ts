import { QueryInterface } from "sequelize";

const TABLE = "company_payment_settings";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.renameColumn(TABLE, "additionalData", "additional_data");
    await queryInterface.renameColumn(TABLE, "createdAt", "created_at");
    await queryInterface.renameColumn(TABLE, "updatedAt", "updated_at");
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.renameColumn(TABLE, "additional_data", "additionalData");
    await queryInterface.renameColumn(TABLE, "created_at", "createdAt");
    await queryInterface.renameColumn(TABLE, "updated_at", "updatedAt");
  }
};