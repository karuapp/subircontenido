import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.createTable("scheduled_dispatchers", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      company_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: "Companies", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
      },
      title: {
        type: DataTypes.STRING(255),
        allowNull: false
      },
      message_template: {
        type: DataTypes.TEXT,
        allowNull: false
      },
      event_type: {
        type: DataTypes.STRING(32),
        allowNull: false
      },
      whatsapp_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: { model: "Whatsapps", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "SET NULL"
      },
      start_time: {
        type: DataTypes.STRING(5),
        allowNull: false,
        defaultValue: "08:00"
      },
      send_interval_seconds: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 30
      },
      days_before_due: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      days_after_due: {
        type: DataTypes.INTEGER,
        allowNull: true
      },
      active: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      created_at: {
        allowNull: false,
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        allowNull: false,
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    });

    await queryInterface.addIndex("scheduled_dispatchers", ["company_id", "event_type"], {
      name: "scheduled_dispatchers_company_event"
    });
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.removeIndex("scheduled_dispatchers", "scheduled_dispatchers_company_event");
    await queryInterface.dropTable("scheduled_dispatchers");
  }
};
