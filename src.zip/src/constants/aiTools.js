export const TOOL_CATALOG = [
  {
    value: "send_product",
    title: "Enviar producto",
    description: "Envía tarjetas de productos registrados."
  },
  {
    value: "execute_tool",
    title: "Ejecuta integración externa.",
    description: "Accede a herramientas conectadas mediante API externas."
  },
  {
    value: "like_message",
    title: "Me gusta en el mensaje",
    description: "Reacciona al mensaje del cliente con un emoji."
  },
  {
    value: "send_contact_file",
    title: "Enviar archivo de contacto",
    description: "Comparte los archivos almacenados en el contacto."
  },
  {
    value: "send_emoji",
    title: "Enviar emoji",
    description: "Responde rápidamente con emojis predefinidos."
  },
  {
    value: "get_company_schedule",
    title: "Horario comercial",
    description: "Consulta el horario comercial registrado."
  },
  {
    value: "get_contact_schedules",
    title: "Listar citas",
    description: "Muestra las citas ya creadas para el contacto."
  },
  {
    value: "create_contact_schedule",
    title: "Crear cita",
    description: "Programa una nueva cita para el cliente."
  },
  {
    value: "update_contact_schedule",
    title: "Actualizar cita",
    description: "Edita una cita existente."
  },
  {
    value: "get_contact_info",
    title: "Ver detalles del contacto",
    description: "Devuelve la información almacenada del cliente."
  },
  {
    value: "update_contact_info",
    title: "Actualizar contacto",
    description: "Edita los campos de registro del contacto."
  },
  {
    value: "format_message",
    title: "Formatear mensaje",
    description: "Aplica variables y formato avanzado."
  },
  {
    value: "execute_command",
    title: "Ejecutar comando (Typebot)",
    description: "Ejecuta transferencias, etiquetas y terminaciones mediante JSON (# { \"queueId\":\"5\" })."
  },
  {
    value: "call_prompt_agent",
    title: "Llamar a otro prompt",
    description: "Encadena diferentes prompt como subagentes."
  },
  {
    value: "list_professionals",
    title: "Lista de profesionales",
    description: "Consulta los profesionales disponibles y sus horarios."
  },
  {
    value: "get_asaas_second_copy",
    title: "Segunda copia de la factura de Asaas",
    description: "Consulta la factura/PIX directamente en Asaas usando únicamente el CPF proporcionado."
  }
];

export const DEFAULT_SENSITIVE_TOOLS = ["create_company", "execute_tool", "get_asaas_second_copy"];
