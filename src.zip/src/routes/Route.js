import React, { useContext } from "react";
import { Route as RouterRoute, Redirect } from "react-router-dom";

import { AuthContext } from "../context/Auth/AuthContext";
import BackdropLoading from "../components/BackdropLoading";

const Route = ({ component: Component, isPrivate = false, isPublic = false, ...rest }) => {
  const { isAuth, loading } = useContext(AuthContext);

  // Rutas públicas (aterrizaje, inicio de sesión, registro, etc.): cargan al instante sin necesidad de cargar la pantalla.
  if (isPublic) {
    // Si ya ha iniciado sesión e intenta acceder a la zona de aterrizaje, inicio de sesión o registro, se le redirige al panel de control.
    if (!loading && isAuth && (rest.path === "/" || rest.path === "/login" || rest.path === "/cadastro")) {
      return <Redirect to={{ pathname: "/atendimentos", state: { from: rest.location } }} />;
    }
    return <RouterRoute {...rest} component={Component} />;
  }

  // Muestra la pantalla de carga solo para rutas privadas mientras se verifica la autenticación.
  if (loading) {
    return <BackdropLoading />;
  }

  // Usuario no registrado que intenta acceder a una ruta privada: se le redirige a la pantalla de inicio de sesión.
  if (!isAuth && isPrivate) {
    return <Redirect to={{ pathname: "/login", state: { from: rest.location } }} />;
  }

  // Usuario no registrado en una ruta sin marcar: se le redirige a la pantalla de inicio de sesión.
  if (!isAuth && !isPrivate) {
    return <Redirect to={{ pathname: "/login", state: { from: rest.location } }} />;
  }

  return <RouterRoute {...rest} component={Component} />;
};

export default Route;
