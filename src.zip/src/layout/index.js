import React, { useContext, useEffect, useMemo, useState } from "react";
import { useHistory, useLocation } from "react-router-dom";
import {
  makeStyles,
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Menu,
  MenuItem,
  Button,
  Avatar,
  Box,
  useTheme,
  useMediaQuery,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Chip,
  Badge,
  Tooltip,
} from "@material-ui/core";
import InputBase from "@material-ui/core/InputBase";

// Ícones
import MoreVertIcon from "@material-ui/icons/MoreVert";
import DashboardIcon from "@material-ui/icons/Dashboard";
import PeopleIcon from "@material-ui/icons/People";
import WhatsAppIcon from "@material-ui/icons/WhatsApp";
import SettingsIcon from "@material-ui/icons/Settings";
import ContactsIcon from "@material-ui/icons/Contacts";
import DeviceHubIcon from "@material-ui/icons/DeviceHub";
import GroupIcon from "@material-ui/icons/Group";
import SmartToyIcon from "@material-ui/icons/Android";
import ViewListIcon from "@material-ui/icons/ViewList";
import BarChartIcon from "@material-ui/icons/BarChart";
import AnnouncementIcon from "@material-ui/icons/Announcement";
import BuildIcon from "@material-ui/icons/Build";
import BusinessIcon from "@material-ui/icons/Business";
import BusinessCenterIcon from "@material-ui/icons/BusinessCenter";
import PersonAddIcon from "@material-ui/icons/PersonAdd";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import NotificationsIcon from "@material-ui/icons/Notifications";
import VolumeUpIcon from "@material-ui/icons/VolumeUp";
import RefreshIcon from "@material-ui/icons/Refresh";
import SyncIcon from "@material-ui/icons/Sync";
import ArrowBackIcon from "@material-ui/icons/ArrowBack";
import CachedIcon from "@material-ui/icons/Cached";
import NotificationsActiveIcon from "@material-ui/icons/NotificationsActive";
import ExitToAppIcon from "@material-ui/icons/ExitToApp";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
import PersonIcon from "@material-ui/icons/Person";
import PsychologyIcon from "@mui/icons-material/Psychology";
import PeopleOutlineIcon from "@mui/icons-material/PeopleOutline";
import BusinessCenterOutlinedIcon from "@mui/icons-material/BusinessCenterOutlined";
import LocalAtmIcon from "@mui/icons-material/LocalAtm";
import PlayCircleOutlineIcon from "@mui/icons-material/PlayCircleOutline";
import ViewKanbanIcon from "@mui/icons-material/ViewKanban";
import BuildCircleIcon from "@mui/icons-material/BuildCircle";
import HelpOutlineIcon from "@material-ui/icons/HelpOutline";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import LabelOutlinedIcon from "@mui/icons-material/LabelOutlined";
import FolderSpecialIcon from "@mui/icons-material/FolderSpecial";
import CloudUploadOutlinedIcon from "@mui/icons-material/CloudUploadOutlined";
import CampaignOutlinedIcon from "@mui/icons-material/CampaignOutlined";
import ChatBubbleOutlineIcon from "@mui/icons-material/ChatBubbleOutline";
import AccountTreeIcon from "@mui/icons-material/AccountTree";
import BuildOutlinedIcon from "@mui/icons-material/BuildOutlined";
import ListAltIcon from "@material-ui/icons/ListAlt";
import ScheduleIcon from "@material-ui/icons/Schedule";
import TuneIcon from "@material-ui/icons/Tune";
import MenuIcon from "@material-ui/icons/Menu";
import CloseIcon from "@material-ui/icons/Close";
import AttachMoneyIcon from "@material-ui/icons/AttachMoney";
import FolderIcon from "@material-ui/icons/Folder";
import ShareIcon from "@material-ui/icons/Share";
import ChatIcon from "@material-ui/icons/Chat";
import ExtensionIcon from "@material-ui/icons/Extension";
import FlashOnIcon from "@material-ui/icons/FlashOn";
import AttachFileIcon from "@material-ui/icons/AttachFile";
import VideoLibraryIcon from "@material-ui/icons/VideoLibrary";
import PhotoIcon from "@material-ui/icons/Photo";
import PlayCircleFilledIcon from "@material-ui/icons/PlayCircleFilled";
import QueueIcon from "@material-ui/icons/Queue";
import LabelIcon from "@material-ui/icons/Label";
import SearchIcon from "@material-ui/icons/Search";

import { AuthContext } from "../context/Auth/AuthContext";
import { usePlanPermissions } from "../context/PlanPermissionsContext";
import NotificationsVolume from "../components/NotificationsVolume";
import UserModal from "../components/UserModal";
import SearchTicketModal from "../components/SearchTicketModal";
import { getBackendUrl } from "../config";
import { i18n } from "../translate/i18n";
import f002Image from "../assets/f002.png";
import logo from "../assets/logo.png";
import ColorModeContext from "./themeContext";

const backendUrl = getBackendUrl();


const collapsedDrawerWidth = 72;
const expandedDrawerWidth = 220;

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    height: "100vh",
    backgroundColor: "#f8f9fa",
  },
  // Header Styles - Fundo transparente
  appBar: (props) => ({
    backgroundColor: "transparent !important",
    background: "transparent !important",
    color: "#3b82f6",
    boxShadow: "none !important",
    borderBottom: "none",
    zIndex: theme.zIndex.drawer + 1,
    marginLeft: props.drawerWidth,
    width: `calc(100% - ${props.drawerWidth}px)`,
    transition: "margin-left 0.2s ease, width 0.2s ease",
    [theme.breakpoints.down("md")]: {
      marginLeft: 0,
      width: "100%",
    },
  }),
  toolbar: {
    minHeight: "64px",
    padding: "0 24px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerLeft: {
    display: "flex",
    alignItems: "center",
    gap: "16px",
    flex: 1,
  },
  menuButton: {
    display: "none",
    color: "#3b82f6",
  },
  searchContainer: {
    position: "relative",
    backgroundColor: "#f3f4f6",
    borderRadius: "12px",
    border: "1px solid #e5e7eb",
    width: "100%",
    maxWidth: "400px",
    transition: "all 0.2s ease",
    "&:hover": {
      borderColor: "#3b82f6",
    },
    "&:focus-within": {
      borderColor: "#3b82f6",
      boxShadow: "0 0 0 3px rgba(59, 130, 246, 0.1)",
    },
    [theme.breakpoints.down("sm")]: {
      display: "none",
    },
  },
  mobileLogo: {
    display: "none",
    [theme.breakpoints.down("sm")]: {
      display: "flex",
      alignItems: "center",
      height: "40px",
      "& img": {
        height: "36px",
        width: "auto",
      },
    },
  },
  searchIcon: {
    padding: theme.spacing(0, 2),
    height: "100%",
    position: "absolute",
    pointerEvents: "none",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "#000000",
  },
  searchButton: (props) => ({
    position: "absolute",
    right: "4px",
    top: "50%",
    transform: "translateY(-50%)",
    backgroundColor: props.primaryColor || "#3b82f6",
    color: "#ffffff",
    borderRadius: "8px",
    padding: "8px",
    minWidth: "36px",
    height: "36px",
    "&:hover": {
      backgroundColor: props.primaryColor || "#2563eb",
      filter: "brightness(0.9)",
    },
  }),
  inputRoot: {
    color: "#3b82f6",
    width: "100%",
  },
  inputInput: {
    padding: theme.spacing(1.5, 6, 1.5, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
    transition: theme.transitions.create("width"),
    width: "100%",
    fontSize: "14px",
    color: "#3b82f6",
    "&::placeholder": {
      color: "#000000",
      opacity: 1,
    },
  },
  headerRight: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    gap: "8px",
    height: "100%",
  },
  iconButton: (props) => ({
    width: "40px",
    height: "40px",
    borderRadius: "50%",
    color: "#ffffff",
    backgroundColor: props.primaryColor || "#3b82f6",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    transition: "all 0.2s ease",
    "& .MuiSvgIcon-root": {
      fontSize: "20px",
      color: "#ffffff",
    },
    "&:hover": {
      backgroundColor: props.primaryColor || "#2563eb",
      filter: "brightness(0.9)",
      transform: "scale(1.05)",
    },
  }),
  avatar: (props) => ({
    width: "40px",
    height: "40px",
    cursor: "pointer",
    border: "2px solid #e5e7eb",
    backgroundColor: props.primaryColor || "#3b82f6",
    transition: "all 0.2s ease",
    "&:hover": {
      borderColor: props.primaryColor || "#3b82f6",
      transform: "scale(1.05)",
    },
  }),
  // Sidebar Styles - Oscuro con íconos
  drawer: (props) => ({
    width: props.drawerWidth,
    flexShrink: 0,
    [theme.breakpoints.down("md")]: {
      display: "none",
    },
  }),
  drawerPaper: (props) => ({
    width: props.drawerWidth,
    backgroundColor: props.primaryColor || "#3b82f6",
    borderRight: "none",
    borderTopRightRadius: 18,
    borderBottomRightRadius: 18,
    overflowX: "hidden",
    overflowY: "auto",
    scrollbarWidth: "none",
    transition: "width 0.2s ease, background-color 0.3s ease",
    [theme.breakpoints.down("md")]: {
      borderTopRightRadius: 0,
      borderBottomRightRadius: 0,
    },
    "&::-webkit-scrollbar": {
      display: "none",
    },
  }),
  mobileDrawer: {
    [theme.breakpoints.up("lg")]: {
      display: "none",
    },
  },
  drawerHeader: (props) => ({
    display: "flex",
    alignItems: "center",
    justifyContent: props.drawerWidth > collapsedDrawerWidth ? "flex-start" : "center",
    padding: props.drawerWidth > collapsedDrawerWidth ? "16px 12px" : "16px 0",
    minHeight: "64px",
    width: "100%",
    boxSizing: "border-box",
    backgroundColor: props.primaryColor || "#3b82f6",
  }),
  logo: (props) => ({
    display: "flex",
    alignItems: "center",
    justifyContent: props.drawerWidth > collapsedDrawerWidth ? "flex-start" : "center",
    cursor: "pointer",
    width: "100%",
  }),
  logoIcon: (props) => ({
    fontSize: props.drawerWidth > collapsedDrawerWidth ? "36px" : "32px",
    color: "#3b82f6",
    transition: "font-size 0.2s ease",
  }),
  logoText: {
    display: "none",
  },
  companyLogo: (props) => ({
    height: "36px",
    width: props.drawerWidth > collapsedDrawerWidth ? "160px" : "36px",
    objectFit: "contain",
    borderRadius: "8px",
    transition: "width 0.2s ease",
  }),
  sidebarContent: (props) => ({
    flex: 1,
    overflowY: "auto",
    overflowX: "hidden",
    padding: props.drawerWidth > collapsedDrawerWidth ? "12px 8px" : "8px 0",
    width: "100%",
    boxSizing: "border-box",
    scrollbarWidth: "none",
    "&::-webkit-scrollbar": {
      display: "none",
    },
  }),
  menuSectionLabel: (props) => ({
    display: props.drawerWidth > collapsedDrawerWidth ? "block" : "none",
    fontSize: "0.68rem",
    letterSpacing: "0.08em",
    textTransform: "uppercase",
    color: "rgba(15, 23, 42, 0.55)",
    margin: "12px 16px 4px",
  }),
  menuList: (props) => ({
    padding: 0,
    display: "flex",
    flexDirection: "column",
    alignItems: props.drawerWidth > collapsedDrawerWidth ? "stretch" : "center",
    gap: "4px",
  }),
  menuItem: (props) => ({
    padding: props.drawerWidth > collapsedDrawerWidth ? "10px 14px" : "12px",
    margin: "0",
    borderRadius: "12px",
    transition: "all 0.2s ease",
    minHeight: "auto",
    width: props.drawerWidth > collapsedDrawerWidth ? "100%" : "48px",
    height: "48px",
    display: "flex",
    alignItems: "center",
    justifyContent: props.drawerWidth > collapsedDrawerWidth ? "flex-start" : "center",
    gap: props.drawerWidth > collapsedDrawerWidth ? "12px" : 0,
    "&:hover": {
      backgroundColor: "rgba(59, 130, 246, 0.1)",
      "& .MuiListItemIcon-root": {
        color: "#000000",
      },
    },
    "&.active": {
      backgroundColor: "rgba(59, 130, 246, 0.15)",
      "& .MuiListItemIcon-root": {
        color: "#000000",
      },
    },
  }),
  menuIcon: (props) => ({
    minWidth: props.drawerWidth > collapsedDrawerWidth ? "auto" : "initial",
    color: "#ffffff",
    margin: props.drawerWidth > collapsedDrawerWidth ? "0 0 0 4px" : 0,
    "& .MuiSvgIcon-root": {
      fontSize: "22px",
    },
  }),
  menuText: (props) => ({
    display: props.drawerWidth > collapsedDrawerWidth ? "block" : "none",
    color: "#f1f5f9",
    fontSize: "14px",
    fontWeight: 500,
    letterSpacing: "0.2px",
  }),
  badge: {
    "& .MuiBadge-badge": {
      backgroundColor: "#ef4444",
      color: "#ffffff",
      fontSize: "10px",
      minWidth: "16px",
      height: "16px",
      top: "4px",
      right: "4px",
    },
  },
  menuDivider: (props) => ({
    width: props.drawerWidth > collapsedDrawerWidth ? "80%" : "32px",
    height: "1px",
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    margin: props.drawerWidth > collapsedDrawerWidth ? "12px auto" : "8px auto",
  }),
  // Content Styles
  content: (props) => ({
    flex: 1,
    overflow: "auto",
    marginTop: "64px",
    backgroundColor: "#f8f9fa",
    height: "calc(100vh - 64px)",
    transition: "width 0.2s ease",
    [theme.breakpoints.down("md")]: {
      marginTop: "64px",
    },
  }),
  // Navegación inferior móvil
  mobileBottomNav: {
    display: "none",
    [theme.breakpoints.down("sm")]: {
      display: "flex",
      position: "fixed",
      bottom: 0,
      left: 0,
      right: 0,
      height: "70px",
      backgroundColor: "#ffffff",
      borderTop: "1px solid #e5e7eb",
      justifyContent: "space-around",
      alignItems: "center",
      zIndex: theme.zIndex.drawer + 2,
      padding: "0 8px",
      paddingBottom: "env(safe-area-inset-bottom)",
      boxShadow: "0 -4px 20px rgba(0, 0, 0, 0.08)",
    },
  },
  mobileNavItem: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: "8px 12px",
    borderRadius: "12px",
    cursor: "pointer",
    transition: "all 0.2s ease",
    color: "#000000",
    minWidth: "56px",
    "&:hover": {
      backgroundColor: "rgba(59, 130, 246, 0.08)",
    },
    "&.active": {
      color: "#3b82f6",
      backgroundColor: "rgba(59, 130, 246, 0.12)",
      "& $mobileNavIcon": {
        color: "#3b82f6",
      },
      "& $mobileNavLabel": {
        color: "#3b82f6",
        fontWeight: 600,
      },
    },
  },
  mobileNavIcon: {
    fontSize: "24px",
    marginBottom: "2px",
  },
  mobileNavLabel: {
    fontSize: "10px",
    fontWeight: 500,
    textAlign: "center",
    lineHeight: 1.2,
  },
  mobileNavHomeBtn: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: "56px",
    height: "56px",
    borderRadius: "50%",
    background: "linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)",
    color: "#ffffff",
    boxShadow: "0 4px 15px rgba(59, 130, 246, 0.4)",
    marginTop: "-20px",
    cursor: "pointer",
    transition: "all 0.2s ease",
    "&:hover": {
      transform: "scale(1.05)",
      boxShadow: "0 6px 20px rgba(59, 130, 246, 0.5)",
    },
    "&:active": {
      transform: "scale(0.95)",
    },
  },
  mobileNavHomeIcon: {
    fontSize: "28px",
  },
  contentWithMobileNav: {
    [theme.breakpoints.down("sm")]: {
      paddingBottom: "-80px",
    },
  },
  hideOnMobile: {
    [theme.breakpoints.down("sm")]: {
      display: "none !important",
    },
  },
  // Menú desplegable
  dropdownMenu: {
    marginTop: "8px",
    "& .MuiPaper-root": {
      borderRadius: "12px",
      boxShadow: "0 10px 25px rgba(0, 0, 0, 0.15)",
      border: "1px solid #e5e7eb",
    },
  },
  dropdownItem: {
    padding: "12px 16px",
    fontSize: "14px",
    "&:hover": {
      backgroundColor: "#f3f4f6",
    },
  },
  dropdownIcon: {
    minWidth: "36px",
    color: "#6b7280",
  },
  divider: {
    margin: "8px 0",
    backgroundColor: "#e5e7eb",
  },
  // Estilos de banner AI SDR
  aiSdrBanner: {
    margin: "16px 12px 20px 12px",
    padding: "0",
    background: "#2a2a2a",
    borderRadius: "12px",
    color: "white",
    boxShadow: "0 4px 16px rgba(0, 0, 0, 0.2)",
    position: "relative",
    overflow: "hidden",
  },
  bannerContent: {
    padding: "16px",
    position: "relative",
    zIndex: 2,
  },
  bannerTitle: {
    fontSize: "14px",
    fontWeight: "600",
    color: "white !important",
    marginBottom: "4px",
    lineHeight: "1.3",
  },
  bannerSubtitle: {
    fontSize: "11px",
    color: "rgba(255, 255, 255, 0.7) !important",
    lineHeight: "1.4",
    fontWeight: "400",
    marginBottom: "12px",
  },
  bannerImage: {
    width: "100%",
    height: "120px",
    backgroundImage: `url(${f002Image})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    borderRadius: "8px",
    marginBottom: "12px",
    position: "relative",
    "&::after": {
      content: '""',
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: "linear-gradient(to top, rgba(0,0,0,0.3), transparent)",
      borderRadius: "8px",
    },
  },
  bannerButton: {
    width: "100%",
    padding: "10px 16px",
    background: "#ffffff",
    border: "none",
    borderRadius: "8px",
    color: "#2a2a2a",
    fontSize: "12px",
    fontWeight: "600",
    cursor: "pointer",
    transition: "all 0.2s ease",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "6px",
    "&:hover": {
      background: "#f0f0f0",
      transform: "translateY(-1px)",
    },
  },
}));

const LoggedInLayout = ({ children }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));
  const [drawerExpanded, setDrawerExpanded] = useState(() => !isMobile);
  const drawerWidth = isMobile
    ? expandedDrawerWidth
    : drawerExpanded
      ? expandedDrawerWidth
      : collapsedDrawerWidth;
  const showMenuLabels = drawerWidth > collapsedDrawerWidth || isMobile;
  const primaryColor = theme.palette.primary.main || "#3b82f6";
  const classes = useStyles({ drawerWidth, primaryColor });
  const history = useHistory();
  const location = useLocation();
  
  const { user, handleLogout, loading, isMobileSession } = useContext(AuthContext);
  const { planActive, loading: planLoading } = usePlanPermissions();
  
  const [anchorEl, setAnchorEl] = useState(null);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [profileUrl, setProfileUrl] = useState(null);
  const [volume, setVolume] = useState(localStorage.getItem("volume") || 1);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [moreMenuAnchor, setMoreMenuAnchor] = useState(null);

  useEffect(() => {
    setDrawerExpanded(!isMobile);
  }, [isMobile]);

  useEffect(() => {
    if (user?.profileImage) {
      const nextUrl = `${backendUrl}/public/company${user.companyId}/user/${user.profileImage}`;
      setProfileUrl((current) => (current !== nextUrl ? nextUrl : current));
    } else {
      setProfileUrl((current) => (current !== null ? null : current));
    }
  }, [user?.profileImage, user?.companyId]);

  // BLOQUEO DE PLANES VENCIDOS
  useEffect(() => {
    // Si aún se carga la información del plan, no haga nada.
    if (planLoading || loading) return;
    
    // Si el plan no está activo (vencido) y no se encuentra en la página financiera,
    if (!planActive && location.pathname !== "/financeiro") {
      // Redirige a la página financiera.
      history.push("/financeiro");
      
      // Muestra una alerta sobre el bloqueo.
      alert("⚠️ SU PLAN HA VENCIDO!\n\nPara continuar usando el sistema, por favor realice su pago en la página de Finanzas.");
    }
  }, [planActive, planLoading, loading, location.pathname, history]);

  const handleUserMenuClick = (event) => {
    setAnchorEl(event.currentTarget);
    setUserMenuOpen(true);
  };

  const handleUserMenuClose = () => {
    setAnchorEl(null);
    setUserMenuOpen(false);
  };

  const handleOpenUserModal = () => {
    setUserModalOpen(true);
    setUserMenuOpen(false);
  };

  const handleLogoutClick = () => {
    handleLogout();
  };

  const handleRefreshPage = () => {
    window.location.reload();
  };

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const isActivePath = (path) => {
    return location.pathname === path || location.pathname.startsWith(path + "/");
  };

  // Detectar si estás en una conversación de ticket (para ocultar el menú móvil y el encabezado)
  const isInsideTicketConversation =
    /\/tickets\/[a-zA-Z0-9-]+$/i.test(location.pathname) ||
    /\/atendimentos\/[a-zA-Z0-9-]+$/i.test(location.pathname);

  // Detectar si estás en Flow Builder (para ocultar el menú de la barra lateral)
  const isFlowBuilderPage = 
    location.pathname.startsWith("/flowbuilder/") && 
    location.pathname !== "/flowbuilder" && 
    location.pathname !== "/flowbuilder/";

const staticMenuItems = useMemo(() => {
      const items = [
        {
          title: "Panel",
          path: "/painel",
          icon: <DashboardIcon />,
          exact: true,
          roles: ["user", "admin"]
        },
        {
          title: "Informes",
          path: "/reports",
          icon: <BarChartIcon />,
          roles: ["admin"]
        },
        {
          title: "Conversaciones",
          path: "/atendimentos",
          icon: <ChatIcon />,
          roles: ["user", "admin"]
        },
        {
          title: "Kanban",
          path: "/kanban",
          icon: <ViewKanbanIcon />,
          roles: ["user", "admin"]
        },
        {
          title: "Contactos",
          path: "/contatos",
          icon: <ContactsIcon />,
          roles: ["user", "admin"]
        },
        {
          title: "Clientes",
          path: "/clientes",
          icon: <BusinessCenterIcon />,
          roles: ["user", "admin"]
        },
        {
          title: "Leads",
          path: "/leads",
          icon: <PersonAddIcon />,
          roles: ["user", "admin"]
        },
        {
          title: "Departamentos",
          path: "/departamentos",
          icon: <QueueIcon />,
          roles: ["admin"]
        },
        {
          title: "Canales",
          path: "/canais",
          icon: <DeviceHubIcon />,
          roles: ["admin"]
        },
        {
          title: "Usuarios",
          path: "/users",
          icon: <GroupIcon />,
          roles: ["admin"]
        },
        {
          title: "Pagos",
          path: "/payment-settings",
          icon: <LocalAtmIcon />,
          roles: ["admin"]
        },
        {
          title: "Sistema",
          path: "/sistema",
          icon: <BuildIcon />,
          roles: ["admin"]
        },
        {
          title: "Centro de ayuda",
          path: "/helps",
          icon: <HelpOutlineIcon />,
          roles: ["user", "admin"]
        },
      ];

      return items
        .filter(item => user.profile === "admin" || item.roles.includes("user"))
        .map(item => ({
          ...item,
          disabled: !planActive && location.pathname !== "/financeiro"
        }));
    }, [planActive, location.pathname, user.profile]);

  const MenuItemWithTooltip = ({ path, icon, title, exact = false, disabled = false }) => {
    const isActive = exact
      ? location.pathname === path
      : location.pathname === path || location.pathname.startsWith(path + "/");

    const handleClick = (event) => {
      if (disabled) {
        event.preventDefault();
        // Muestra una alerta al intentar acceder con un plan vencido.
        alert("⚠️ ¡ACCESO BLOQUEADO!\n\nSu plan ha vencido. Para acceder a esta función, realice su pago en la página de Finanzas.");
        return;
      }
      if (!isActive) {
        history.push(path);
      }
    };

    const item = (
      <ListItem
        button
        disabled={disabled}
        onClick={handleClick}
        className={`${classes.menuItem} ${isActive ? "active" : ""}`}
      >
        <ListItemIcon className={classes.menuIcon}>{icon}</ListItemIcon>
        {showMenuLabels && (
          <ListItemText
            primary={title}
            classes={{ primary: classes.menuText }}
          />
        )}
      </ListItem>
    );

    if (showMenuLabels) {
      return item;
    }

    return (
      <Tooltip title={title} placement="right" arrow>
        {item}
      </Tooltip>
    );
  };

  const DrawerContent = () => (
    <div>
      <div className={classes.drawerHeader}>
        <Tooltip title="Painel" placement="right">
          <div className={classes.logo} onClick={() => history.push("/painel")}>
            {(theme.appLogoLight || theme.calculatedLogoLight?.()) ? (
              <img
                src={theme.calculatedLogoLight ? theme.calculatedLogoLight() : theme.appLogoLight}
                alt="Logo"
                className={classes.companyLogo}
              />
            ) : (
              <DashboardIcon className={classes.logoIcon} />
            )}
          </div>
        </Tooltip>
      </div>

      <div className={classes.sidebarContent}>
        <List className={classes.menuList}>
          <div className={classes.menuSectionLabel}>Secciones principales</div>
          {staticMenuItems.map((item) => (
            <MenuItemWithTooltip key={item.path} {...item} />
          ))}
        </List>
      </div>
    </div>
  );

  return (
    <div className={classes.root}>
      {/* Sidebar Desktop */}
      <Drawer
        className={classes.drawer}
        variant="permanent"
        onMouseEnter={() => {
          if (!isMobile) setDrawerExpanded(true);
        }}
        onMouseLeave={() => {
          if (!isMobile) setDrawerExpanded(false);
        }}
        classes={{
          paper: classes.drawerPaper,
        }}
      >
        <DrawerContent />
      </Drawer>

      {/* Sidebar Mobile */}
      <Drawer
        className={classes.mobileDrawer}
        variant="temporary"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        ModalProps={{
          keepMounted: true,
        }}
        classes={{
          paper: classes.drawerPaper,
        }}
      >
        <DrawerContent />
      </Drawer>

      {/* Header - Sempre visível */}
      <AppBar position="fixed" color="transparent" elevation={0} className={classes.appBar}>
        <Toolbar className={classes.toolbar}>
          {/* Sección izquierda */}
          <div className={classes.headerLeft}>
            {/* Botón Atrás - Visible solo en el Generador de flujos */}
            {isFlowBuilderPage && (
              <IconButton
                className={classes.menuButton}
                onClick={() => history.push("/flowbuilders")}
                edge="start"
                title="Volver a la lista de flujos"
              >
                <ArrowBackIcon />
              </IconButton>
            )}
            
            {/* Botón de menú móvil: oculto en el generador de streams */}
            {!isFlowBuilderPage && (
              <IconButton
                className={classes.menuButton}
                onClick={handleDrawerToggle}
                edge="start"
              >
                <MenuIcon />
              </IconButton>
            )}

            {/* Buscar: oculto en el móvil */}
            <div 
              className={classes.searchContainer}
              onClick={() => setSearchModalOpen(true)}
              style={{ cursor: "pointer" }}
            >
              <div className={classes.searchIcon}>
                <SearchIcon />
              </div>
              <InputBase
                placeholder="Buscar conversaciones..."
                classes={{
                  root: classes.inputRoot,
                  input: classes.inputInput,
                }}
                readOnly
                style={{ cursor: "pointer" }}
              />
              <Button className={classes.searchButton}>
                <SearchIcon style={{ fontSize: 18 }} />
              </Button>
            </div>

            {/* Logotipo: visible solo en el móvil */}
            <div className={classes.mobileLogo}>
              {(theme.appLogoLight || theme.calculatedLogoLight?.()) ? (
                <img 
                  src={theme.calculatedLogoLight ? theme.calculatedLogoLight() : theme.appLogoLight} 
                  alt="Logo" 
                />
              ) : (
                <img src={logo} alt="Logo" />
              )}
            </div>
          </div>

          {/* Sección derecha*/}
          <div className={classes.headerRight}>
            {/* Botón Actualizar */}
            <IconButton
              className={classes.iconButton}
              onClick={handleRefreshPage}
              title="Actualizar"
            >
              <CachedIcon />
            </IconButton>

            {/* Volume */}
            <div className={classes.iconButton}>
              <NotificationsVolume setVolume={setVolume} volume={volume} />
            </div>

            {/* Avatar de usuario */}
            <Avatar
              className={classes.avatar}
              src={profileUrl}
              onClick={handleUserMenuClick}
            >
              {!profileUrl && <PersonIcon />}
            </Avatar>
          </div>
        </Toolbar>
      </AppBar>

      {/* Menú de usuario */}
      <Menu
        anchorEl={anchorEl}
        open={userMenuOpen}
        onClose={handleUserMenuClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        className={classes.dropdownMenu}
      >
        <MenuItem onClick={handleOpenUserModal} className={classes.dropdownItem}>
          <ListItemIcon className={classes.dropdownIcon}>
            <AccountCircleIcon />
          </ListItemIcon>
          <ListItemText primary="Mi perfil" />
        </MenuItem>
        
        <Divider className={classes.divider} />
        
        <MenuItem onClick={handleLogoutClick} className={classes.dropdownItem}>
          <ListItemIcon className={classes.dropdownIcon}>
            <ExitToAppIcon />
          </ListItemIcon>
          <ListItemText primary={isMobileSession ? "Salir de la app" : "Salir"} />
        </MenuItem>
      </Menu>

      {/* Modal de usuario */}
      {userModalOpen && (
        <UserModal
          open={userModalOpen}
          onClose={() => setUserModalOpen(false)}
          onImageUpdate={(newProfileUrl) => setProfileUrl(newProfileUrl)}
          userId={user?.id}
        />
      )}

      {/* Modal de búsqueda de conversaciones */}
      <SearchTicketModal
        open={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
      />

      {/* Contenido principal */}
      <main className={`${classes.content} ${!isInsideTicketConversation && !isFlowBuilderPage ? classes.contentWithMobileNav : ""}`}>
        {children}
      </main>

      {/* Menú móvil fijo - Oculto en el escritorio, en las conversaciones de tickets y en el Generador de flujos */}
      {!isInsideTicketConversation && !isFlowBuilderPage && (
        <div className={classes.mobileBottomNav}>
          {/* Botón 1 - Panel de control */}
          <div
            className={`${classes.mobileNavItem} ${isActivePath("/painel") ? "active" : ""}`}
            onClick={() => history.push("/painel")}
          >
            <DashboardIcon className={classes.mobileNavIcon} />
            <span className={classes.mobileNavLabel}>Dashboard</span>
          </div>

          {/* Botón 2 - Contactos */}
          <div
            className={`${classes.mobileNavItem} ${isActivePath("/contatos") ? "active" : ""}`}
            onClick={() => history.push("/contatos")}
          >
            <ContactsIcon className={classes.mobileNavIcon} />
            <span className={classes.mobileNavLabel}>Contactos</span>
          </div>

          {/* Botón Inicio (Centro) - Tickets */}
          <div
            className={classes.mobileNavHomeBtn}
            onClick={() => history.push("/atendimentos")}
          >
            <ChatIcon className={classes.mobileNavHomeIcon} />
          </div>

          {/* Botón 4 - Canales */}
          <div
            className={`${classes.mobileNavItem} ${isActivePath("/canais") ? "active" : ""}`}
            onClick={() => history.push("/canais")}
          >
            <DeviceHubIcon className={classes.mobileNavIcon} />
            <span className={classes.mobileNavLabel}>Canales</span>
          </div>

                  {/* Botón 5 - Menú adicional */}
                  <div
                    className={`${classes.mobileNavItem}`}
                    onClick={(e) => setMoreMenuAnchor(e.currentTarget)}
                  >
                    <MenuIcon className={classes.mobileNavIcon} />
                    <span className={classes.mobileNavLabel}>Menu</span>
                  </div>

                  <Menu
                    anchorEl={moreMenuAnchor}
                    open={Boolean(moreMenuAnchor)}
                    onClose={() => setMoreMenuAnchor(null)}
                    anchorOrigin={{ vertical: "top", horizontal: "center" }}
                    transformOrigin={{ vertical: "bottom", horizontal: "center" }}
                  >
                    <MenuItem
                      onClick={() => {
                        history.push("/reports");
                        setMoreMenuAnchor(null);
                      }}
                    >
                      <BarChartIcon fontSize="small" style={{ marginRight: 8 }} />
                      Informes
                    </MenuItem>

                    <MenuItem
                      onClick={() => {
                        history.push("/helps");
                        setMoreMenuAnchor(null);
                      }}
                    >
                      <HelpOutlineIcon fontSize="small" style={{ marginRight: 8 }} />
                      Centro de ayuda
                    </MenuItem>

                    {user.profile === "admin" && (
                      <MenuItem
                        onClick={() => {
                          history.push("/canais");
                          setMoreMenuAnchor(null);
                        }}
                      >
                        <DeviceHubIcon fontSize="small" style={{ marginRight: 8 }} />
                        Canales
                      </MenuItem>
                    )}
                  </Menu>
                  {/* fin Botón 5 */}
        </div>
      )}
    </div>
  );
};

export default LoggedInLayout;