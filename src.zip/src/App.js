import React, { useState, useEffect, useMemo } from "react";
import api from "./services/api";
import "react-toastify/dist/ReactToastify.css";
import { QueryClient, QueryClientProvider } from "react-query";
import { es } from "@material-ui/core/locale";
import { createTheme, ThemeProvider } from "@material-ui/core/styles";
import { useMediaQuery } from "@material-ui/core";
import ColorModeContext from "./layout/themeContext";
import { ActiveMenuProvider } from "./context/ActiveMenuContext";
import Favicon from "react-favicon";
import { getBackendUrl } from "./config";
import Routes from "./routes";
import defaultLogoLight from "./assets/logo.png";
import defaultLogoDark from "./assets/logo-black.png";
import defaultLogoFavicon from "./assets/favicon.ico";
import useSettings from "./hooks/useSettings";

const queryClient = new QueryClient();

const App = () => {
  const [locale, setLocale] = useState();
  const appColorLocalStorage =
    localStorage.getItem("primaryColorLight") ||
    localStorage.getItem("primaryColorDark") ||
    "#065183";
  const appNameLocalStorage = localStorage.getItem("appName") || "WhatsApp - CRM";
  const prefersDarkMode = useMediaQuery("(prefers-color-scheme: dark)");
  const preferredTheme = window.localStorage.getItem("preferredTheme");

  const [mode, setMode] = useState(
    preferredTheme ? preferredTheme : prefersDarkMode ? "dark" : "light"
  );
  const [primaryColorLight, setPrimaryColorLight] = useState(appColorLocalStorage);
  const [primaryColorDark, setPrimaryColorDark] = useState(appColorLocalStorage);
  const [appLogoLight, setAppLogoLight] = useState(defaultLogoLight);
  const [appLogoDark, setAppLogoDark] = useState(defaultLogoDark);
  const [appLogoFavicon, setAppLogoFavicon] = useState(defaultLogoFavicon);
  const [appName, setAppName] = useState(appNameLocalStorage);
  const [trialDays, setTrialDays] = useState(7); // ✅ Estado declarado antes de useMemo
  const { getPublicSetting } = useSettings();

  // Carga trialDays desde el backend
  useEffect(() => {
    const backendUrl = getBackendUrl();
    fetch(`${backendUrl}/public-settings/trialDays?token=wtV`)
      .then((res) => res.json())
      .then((data) => {
        if (data) setTrialDays(parseInt(data) || 7);
      })
      .catch((err) => console.log("Error al cargar trialDays:", err));
  }, []);

  // Contexto de color y configuración global
  const colorMode = useMemo(
    () => ({
      toggleColorMode: () => {
        setMode((prevMode) => {
          const newMode = prevMode === "light" ? "dark" : "light";
          window.localStorage.setItem("preferredTheme", newMode);
          return newMode;
        });
      },
      primaryColorLight,
      primaryColorDark,
      setPrimaryColorLight,
      setPrimaryColorDark,
      setAppLogoLight,
      setAppLogoDark,
      setAppLogoFavicon,
      setAppName,
      setTrialDays, // ✅ para poder actualizar trialDays desde otros componentes
      appLogoLight,
      appLogoDark,
      appLogoFavicon,
      appName,
      trialDays,
      mode,
    }),
    [
      appLogoLight,
      appLogoDark,
      appLogoFavicon,
      appName,
      mode,
      trialDays,
      primaryColorLight,
      primaryColorDark
    ]
  );

  // Tema Material UI
  const theme = useMemo(
    () =>
      createTheme(
        {
          typography: {
            fontFamily: [
              '"Inter"',
              '"Roboto"',
              '"Segoe UI"',
              '"Helvetica Neue"',
              "Arial",
              "sans-serif",
            ].join(","),
            h1: { fontSize: "2.125rem", fontWeight: 600, letterSpacing: "-0.01562em" },
            h2: { fontSize: "1.5rem", fontWeight: 600, letterSpacing: "-0.00833em" },
            h3: { fontSize: "1.25rem", fontWeight: 500, letterSpacing: "0em" },
            h4: { fontSize: "1.125rem", fontWeight: 500, letterSpacing: "0.00735em" },
            h5: { fontSize: "1rem", fontWeight: 500, letterSpacing: "0em" },
            h6: { fontSize: "0.875rem", fontWeight: 500, letterSpacing: "0.0075em" },
            body1: { fontSize: "1rem", fontWeight: 400, letterSpacing: "0.00938em", lineHeight: 1.5 },
            body2: { fontSize: "0.875rem", fontWeight: 400, letterSpacing: "0.01071em", lineHeight: 1.43 },
            button: { fontSize: "0.875rem", fontWeight: 500, letterSpacing: "0.02857em", textTransform: "none" },
            caption: { fontSize: "0.75rem", fontWeight: 400, letterSpacing: "0.03333em" },
            overline: { fontSize: "0.625rem", fontWeight: 400, letterSpacing: "0.08333em", textTransform: "uppercase" },
          },
          scrollbarStyles: {
            "&::-webkit-scrollbar": { width: "8px", height: "8px" },
            "&::-webkit-scrollbar-thumb": {
              boxShadow: "inset 0 0 6px rgba(0, 0, 0, 0.3)",
              backgroundColor: mode === "light" ? primaryColorLight : primaryColorDark,
            },
          },
          scrollbarStylesSoft: {
            "&::-webkit-scrollbar": { width: "8px" },
            "&::-webkit-scrollbar-thumb": { backgroundColor: mode === "light" ? "#F3F3F3" : "#333333" },
          },
          palette: {
            type: mode,
            primary: { main: mode === "light" ? primaryColorLight : primaryColorDark },
            textPrimary: mode === "light" ? primaryColorLight : primaryColorDark,
            borderPrimary: mode === "light" ? primaryColorLight : primaryColorDark,
            dark: { main: mode === "light" ? "#333333" : "#F3F3F3" },
            light: { main: mode === "light" ? "#F3F3F3" : "#333333" },
            fontColor: mode === "light" ? primaryColorLight : primaryColorDark,
            tabHeaderBackground: mode === "light" ? "#EEE" : "#666",
            optionsBackground: mode === "light" ? "#fafafa" : "#333",
            fancyBackground: mode === "light" ? "#fafafa" : "#333",
            total: mode === "light" ? "#fff" : "#222",
            messageIcons: mode === "light" ? "grey" : "#F3F3F3",
            inputBackground: mode === "light" ? "#FFFFFF" : "#333",
            barraSuperior: mode === "light" ? primaryColorLight : "#666",
          },
          mode,
          appLogoLight,
          appLogoDark,
          appLogoFavicon,
          appName,
          calculatedLogoDark: () => (appLogoDark === defaultLogoDark && appLogoLight !== defaultLogoLight ? appLogoLight : appLogoDark),
          calculatedLogoLight: () => (appLogoDark !== defaultLogoDark && appLogoLight === defaultLogoLight ? appLogoDark : appLogoLight),
        },
        locale
      ),
    [appLogoLight, appLogoDark, appLogoFavicon, appName, locale, mode, primaryColorDark, primaryColorLight]
  );

  // Guardar tema en localStorage
  useEffect(() => {
    window.localStorage.setItem("preferredTheme", mode);
  }, [mode]);

  // Cargar configuraciones desde backend
  useEffect(() => {
    const loadSetting = async () => {
      try {
        const primaryLight = await getPublicSetting("primaryColorLight");
        setPrimaryColorLight(primaryLight || "#0000FF");

        const primaryDark = await getPublicSetting("primaryColorDark");
        setPrimaryColorDark(primaryDark || "#39ACE7");

        const logoLight = await getPublicSetting("appLogoLight");
        setAppLogoLight(logoLight ? getBackendUrl() + "/public/" + logoLight : defaultLogoLight);

        const logoDark = await getPublicSetting("appLogoDark");
        setAppLogoDark(logoDark ? getBackendUrl() + "/public/" + logoDark : defaultLogoDark);

        const favicon = await getPublicSetting("appLogoFavicon");
        setAppLogoFavicon(favicon ? getBackendUrl() + "/public/" + favicon : defaultLogoFavicon);

        const name = await getPublicSetting("appName");
        setAppName(name || "WhaTitan Express Lite");
      } catch (error) {
        console.log("Error al cargar configuraciones:", error);
      }
    };
    loadSetting();
  }, [getPublicSetting]);

  // Actualizar variable CSS
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--primaryColor", mode === "light" ? primaryColorLight : primaryColorDark);
  }, [primaryColorLight, primaryColorDark, mode]);

  // Actualizar título de la página
  useEffect(() => {
    if (appName) document.title = appName;
  }, [appName]);

  // Guardar versión del frontend
  useEffect(() => {
    async function fetchVersionData() {
      try {
        const response = await api.get("/version");
        window.localStorage.setItem("frontendVersion", response.data.version);
      } catch (error) {
        console.log("Error fetching data", error);
      }
    }
    fetchVersionData();
  }, []);

  return (
    <>
      <Favicon url={appLogoFavicon && appLogoFavicon !== defaultLogoFavicon ? appLogoFavicon : defaultLogoFavicon} />
      <ColorModeContext.Provider value={{ colorMode }}>
        <ThemeProvider theme={theme}>
          <QueryClientProvider client={queryClient}>
            <ActiveMenuProvider>
              <Routes />
            </ActiveMenuProvider>
          </QueryClientProvider>
        </ThemeProvider>
      </ColorModeContext.Provider>
    </>
  );
};

export default App;