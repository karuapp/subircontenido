import { Request, Response } from "express";

import CreateMediaFolderService from "../../services/MediaLibrary/Folders/CreateMediaFolderService";
import ListMediaFoldersService from "../../services/MediaLibrary/Folders/ListMediaFoldersService";
import UpdateMediaFolderService from "../../services/MediaLibrary/Folders/UpdateMediaFolderService";
import DeleteMediaFolderService from "../../services/MediaLibrary/Folders/DeleteMediaFolderService";
import ListMediaFilesService from "../../services/MediaLibrary/Files/ListMediaFilesService";
import UploadMediaFileService from "../../services/MediaLibrary/Files/UploadMediaFileService";
import UpdateMediaFileService from "../../services/MediaLibrary/Files/UpdateMediaFileService";
import DeleteMediaFileService from "../../services/MediaLibrary/Files/DeleteMediaFileService";

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { search } = req.query;

  const folders = await ListMediaFoldersService({
    companyId,
    searchParam: search as string
  });

  return res.json(folders);
};

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { name, description } = req.body;

  const folder = await CreateMediaFolderService({
    name,
    description,
    companyId
  });

  return res.status(201).json(folder);
};

export const update = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { folderId } = req.params;
  const { name, description } = req.body;

  const folder = await UpdateMediaFolderService({
    folderId: Number(folderId),
    companyId,
    name,
    description
  });

  return res.json(folder);
};

export const remove = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { folderId } = req.params;

  await DeleteMediaFolderService({
    folderId: Number(folderId),
    companyId
  });

  return res.status(204).send();
};

export const listFiles = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { folderId } = req.params;

  const files = await ListMediaFilesService({
    folderId: Number(folderId),
    companyId
  });

  return res.json(files);
};

export const uploadFile = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { folderId } = req.params;
  const file = req.file;

  const mediaFile = await UploadMediaFileService({
    folderId: Number(folderId),
    companyId,
    file
  });

  return res.status(201).json(mediaFile);
};

export const updateFile = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { fileId } = req.params;
  const { customName } = req.body;

  const file = await UpdateMediaFileService({
    fileId: Number(fileId),
    companyId,
    customName
  });

  return res.json(file);
};

export const deleteFile = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const { fileId } = req.params;

  await DeleteMediaFileService({
    fileId: Number(fileId),
    companyId
  });

  return res.status(204).send();
};
