import { Request, Response } from "express";
import * as Yup from "yup";
import { getIO } from "../libs/socket";
import { isEmpty, isNil } from "lodash";
import CheckSettingsHelper from "../helpers/CheckSettings";
import AppError from "../errors/AppError";

import CreateUserService from "../services/UserServices/CreateUserService";
import ListUsersService from "../services/UserServices/ListUsersService";
import UpdateUserService from "../services/UserServices/UpdateUserService";
import ShowUserService from "../services/UserServices/ShowUserService";
import DeleteUserService from "../services/UserServices/DeleteUserService";
import SimpleListService from "../services/UserServices/SimpleListService";
import CreateCompanyService from "../services/CompanyService/CreateCompanyService";
import { SendMail } from "../helpers/SendMail";
import { SendMailWithSettings, replaceVariables } from "../helpers/SendMailWithSettings";
import { useDate } from "../utils/useDate";
import Setting from "../models/Setting";
import Plan from "../models/Plan";
import ShowCompanyService from "../services/CompanyService/ShowCompanyService";
import { getWbot } from "../libs/wbot";
import FindCompaniesWhatsappService from "../services/CompanyService/FindCompaniesWhatsappService";
import User from "../models/User";

import { head } from "lodash";
import ToggleChangeWidthService from "../services/UserServices/ToggleChangeWidthService";
import APIShowEmailUserService from "../services/UserServices/APIShowEmailUserService";

const publicSignupSchema = Yup.object().shape({
  companyName: Yup.string()
    .trim()
    .min(2, "ERR_COMPANY_INVALID_NAME")
    .required("ERR_COMPANY_INVALID_NAME"),
  name: Yup.string()
    .trim()
    .min(2, "ERR_USER_INVALID_NAME")
    .required("ERR_USER_INVALID_NAME"),
  email: Yup.string()
    .trim()
    .email("ERR_INVALID_EMAIL")
    .required("ERR_INVALID_EMAIL"),
  password: Yup.string()
    .min(6, "ERR_INVALID_PASSWORD")
    .matches(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]+$/, "ERR_INVALID_PASSWORD")
    .required("ERR_INVALID_PASSWORD"),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref("password"), null], "ERR_PASSWORD_CONFIRMATION")
    .required("ERR_PASSWORD_CONFIRMATION"),
  phone: Yup.string()
    .min(10, "ERR_INVALID_PHONE")
    .required("ERR_INVALID_PHONE"),
  type: Yup.string()
    .oneOf(["pf", "pj"], "ERR_INVALID_TYPE")
    .default("pf"),
  document: Yup.string()
    .when("type", {
      is: "pf",
      then: Yup.string()
        .matches(/^\d{11}$/, "ERR_INVALID_CPF")
        .required("ERR_CPF_REQUIRED"),
      otherwise: Yup.string()
        .matches(/^\d{14}$/, "ERR_INVALID_CNPJ")
        .required("ERR_CNPJ_REQUIRED")
    }),
  segment: Yup.string().optional(),
  planId: Yup.number()
    .typeError("ERR_INVALID_PLAN")
    .positive("ERR_INVALID_PLAN")
    .integer("ERR_INVALID_PLAN")
    .required("ERR_INVALID_PLAN")
});

type IndexQuery = {
  searchParam: string;
  pageNumber: string;
};

const formatPhoneToWhatsappJid = (rawPhone?: string): string | null => {
const formatWhatsappJid = (rawPhone: string): string | null => {
  if (!rawPhone) return null;

  // Quita todo excepto números
  let digits = rawPhone.replace(/\D/g, "");
  if (!digits) return null;

  // Evita códigos país duplicados tipo 5555..., 504504...
  digits = digits.replace(/^(\d{1,3})\1+/, "$1");

  return `${digits}@s.whatsapp.net`;
};



export const index = async (req: Request, res: Response): Promise<Response> => {
  const { searchParam, pageNumber } = req.query as IndexQuery;
  const { companyId, profile } = req.user;

  const { users, count, hasMore } = await ListUsersService({
    searchParam,
    pageNumber,
    companyId,
    profile
  });

  return res.json({ users, count, hasMore });
};

export const store = async (req: Request, res: Response): Promise<Response> => {
  const {
    email,
    password,
    name,
    companyName,
    phone,
    profile,
    companyId: bodyCompanyId,
    queueIds,
    planId,
    startWork,
    endWork,
    whatsappId,
    allTicket,
    defaultTheme,
    defaultMenu,
    allowGroup,
    allHistoric,
    allUserChat,
    userClosePendingTicket,
    showDashboard,
    defaultTicketsManagerWidth = 550,
    allowRealTime,
    allowConnections,
    confirmPassword,
    status,
    dueDate: bodyDueDate,
    recurrence: bodyRecurrence,
    campaignsEnabled,
    document,
    type,
    segment
  } = req.body;
  let userCompanyId: number | null = null;

  const normalizedEmail = (email || "").trim().toLowerCase();
  if (!normalizedEmail) {
    throw new AppError("ERR_EMAIL_REQUIRED", 400);
  }

  if (!password || String(password).trim().length === 0) {
    throw new AppError("ERR_PASSWORD_REQUIRED", 400);
  }

  const sanitizedPhone = typeof phone === "string" ? phone.replace(/\D/g, "") : "";

  if (req.url === "/signup") {
    try {
      await publicSignupSchema.validate(
        {
          companyName,
          name,
          email: normalizedEmail,
          password,
          confirmPassword,
          phone: sanitizedPhone,
          type,
          document,
          segment,
          planId
        },
        { abortEarly: false }
      );
    } catch (error: any) {
      const errMap: Record<string, string> = {
        "ERR_INVALID_TYPE": "Tipo no válido. Utilice 'pf' para persona física o 'pj' para persona jurídica.",
        "ERR_INVALID_CPF": "CPF no válido. Debe contener 11 dígitos.",
        "ERR_INVALID_CNPJ": "CNPJ no válido. Debe contener 14 dígitos.",
        "ERR_CPF_REQUIRED": "CPF obligatorio para personas físicas.",
        "ERR_CNPJ_REQUIRED": "CNPJ obligatorio para personas jurídicas.",
        "ERR_INVALID_SEGMENT": "Segmento no válido. Elija una de las opciones disponibles.",
        "ERR_SEGMENT_REQUIRED": "Segmento obligatorio.",
        "ERR_COMPANY_INVALID_NAME": "Nombre de empresa no válido (mínimo 2 caracteres).",
        "ERR_USER_INVALID_NAME": "Nombre de usuario no válido (mínimo 2 caracteres).",
        "ERR_INVALID_EMAIL": "Correo electrónico no válido.",
        "ERR_INVALID_PASSWORD": "Contraseña no válida (mínimo 6 caracteres, con letras y números).",
        "ERR_PASSWORD_CONFIRMATION": "La confirmación de la contraseña no coincide.",
        "ERR_INVALID_PHONE": "Número de teléfono no válido (mínimo 10 dígitos).",
        "ERR_INVALID_PLAN": "Plan no válido."
      };
      throw new AppError(errMap[error.errors?.[0]] || "ERR_INVALID_SIGNUP_DATA");
    }
  }

  const generatedCompanyName =
    (companyName && companyName.trim()) ||
    (normalizedEmail.includes("@") ? normalizedEmail.split("@")[0] : "") ||
    `empresa-${Date.now()}`;
  const resolvedCompanyName =
    generatedCompanyName.length >= 2 ? generatedCompanyName : `empresa-${Date.now()}`;
  const resolvedUserName = (name && name.trim()) || resolvedCompanyName;

  const parsedPlanId = Number(planId);
  const envPlanId = process.env.DEFAULT_PLAN_ID ? Number(process.env.DEFAULT_PLAN_ID) : undefined;
  const resolvedPlanId = !Number.isNaN(parsedPlanId) && parsedPlanId > 0
    ? parsedPlanId
    : envPlanId && !Number.isNaN(envPlanId) && envPlanId > 0
      ? envPlanId
      : 1;

  const { dateToClient } = useDate();

  if (req.user !== undefined) {
    const { companyId: cId } = req.user;
    userCompanyId = cId;
  }

  if (
    req.url === "/signup" &&
    (await CheckSettingsHelper("userCreation")) === "disabled"
  ) {
    throw new AppError("ERR_USER_CREATION_DISABLED", 403);
  } else if (req.url !== "/signup" && req.user.profile !== "admin") {
    throw new AppError("ERR_NO_PERMISSION", 403);
  }

  if (process.env.DEMO === "ON") {
    throw new AppError("ERR_NO_PERMISSION", 403);
  }

  // const companyUser = bodyCompanyId || userCompanyId;
  const companyUser = userCompanyId;

  if (!companyUser) {

    // Busca dias de teste configurados
    let trialDays = 7;
    try {
      const trialDaysSetting = await Setting.findOne({
        where: { companyId: 1, key: "trialDays" }
      });
      if (trialDaysSetting?.value) {
        trialDays = parseInt(trialDaysSetting.value) || 7;
      }
    } catch (e) {
      console.log("Error fetching trialDays setting, using default 7");
    }

    const trialExpirationDate = new Date();
    trialExpirationDate.setDate(trialExpirationDate.getDate() + trialDays);

    const date = trialExpirationDate.toISOString().split("T")[0];

      const resolvedStatus =
      typeof status === "boolean"
        ? status
        : status === "t" || status === "true" || status === "1" || status === 1 || status === "active" || status === "on";

    const resolvedDueDate = bodyDueDate || date;
    const resolvedRecurrence = bodyRecurrence || "MENSAL";
    const resolvedCampaignsEnabled =
      typeof campaignsEnabled === "boolean" ? campaignsEnabled : true;

    const companyData = {
      name: resolvedCompanyName,
      email: normalizedEmail,
      phone: sanitizedPhone,
      planId: resolvedPlanId,
      status: resolvedStatus !== undefined ? resolvedStatus : true,
      dueDate: resolvedDueDate,
      recurrence: resolvedRecurrence,
      document: document || "",
      paymentMethod: "",
      password: password,
      companyUserName: resolvedUserName,
      startWork: startWork,
      endWork: endWork,
      defaultTheme: "light",
      defaultMenu: "closed",
      allowGroup: false,
      allHistoric: false,
      userClosePendingTicket: "enabled",
      showDashboard: "disabled",
      defaultTicketsManagerWidth: 550,
      allowRealTime: "disabled",
      allowConnections: "disabled",
      campaignsEnabled: resolvedCampaignsEnabled,
      type: type || "pf",
      segment: segment || "outros"
    };

    const user = await CreateCompanyService(companyData);

    const frontendUrl = process.env.FRONTEND_URL || "";

    // Busca nome do plano
    let planName = "Plan Estándar";
    try {
      const plan = await Plan.findByPk(resolvedPlanId);
      if (plan) {
        planName = plan.name;
      }
    } catch (e) {
      console.log("Error al obtener el nombre del plan");
    }

    // Busca nome do sistema
    let appName = "Sistema";
    try {
      const appNameSetting = await Setting.findOne({
        where: { companyId: 1, key: "appName" }
      });
      if (appNameSetting?.value) {
        appName = appNameSetting.value;
      }
    } catch (e) {
      console.log("Error al obtener appName");
    }

    // Variáveis para substituição nas mensagens
    const messageVariables: Record<string, string> = {
      nome: name || resolvedUserName,
      email: normalizedEmail,
      empresa: resolvedCompanyName,
      telefone: sanitizedPhone,
      plano: planName,
      senha: password,
      diasTeste: String(trialDays),
      dataVencimento: dateToClient(date),
      link: frontendUrl,
      sistema: appName
    };

    // Busca textos personalizados de boas-vindas
    let welcomeEmailText = "";
    let welcomeWhatsappText = "";
    try {
      const welcomeSettings = await Setting.findAll({
        where: { companyId: 1, key: ["welcomeEmailText", "welcomeWhatsappText"] }
      });
      welcomeEmailText = welcomeSettings.find(s => s.key === "welcomeEmailText")?.value || "";
      welcomeWhatsappText = welcomeSettings.find(s => s.key === "welcomeWhatsappText")?.value || "";
    } catch (e) {
      console.log("Error al obtener la configuración del mensaje de bienvenida");
    }

    // Envia email de boas-vindas
    try {
      let emailBody = "";
      let emailSubject = `Bienvenido a ${appName}!`;

      if (welcomeEmailText) {
        // Usa texto personalizado
        emailBody = replaceVariables(welcomeEmailText, messageVariables);
      } else {
        // Usa texto padrão
        emailBody = `Hola ${name}, Este es un correo electrónico sobre su registro. ${resolvedCompanyName}!<br><br>
        Aquí encontrará los datos de su empresa (prueba válida para ${trialDays} dias):<br><br>
        Nombre: ${resolvedCompanyName}<br>
        Email: ${normalizedEmail}<br>
        Contraseña: ${password}<br>
        Válido hasta: ${dateToClient(date)}${frontendUrl ? `<br><br>
        Enlace para acceder a la plataforma: <a href="${frontendUrl}" target="_blank">${frontendUrl}</a>` : ""}`;
      }

      await SendMailWithSettings({
        to: normalizedEmail,
        subject: emailSubject,
        html: emailBody.replace(/\n/g, '<br>')
      });
      console.log("Correo de bienvenida enviado correctamente");
    } catch (error) {
      console.log('No pude enviar el correo.:', error);
      // Fallback para método antigo
      try {
        const _email = {
          to: normalizedEmail,
          subject: `Usuario y contraseña de la empresa ${resolvedCompanyName}`,
          text: `Hola ${name}, Este es un correo electrónico sobre el registro de la empresa. ${resolvedCompanyName}!<br><br>
          Aquí están los datos de su empresa (prueba válida para ${trialDays} dias):<br><br>
          Nombre: ${resolvedCompanyName}<br>
          Email: ${normalizedEmail}<br>
          Contraseña: ${password}<br>
          Válido hasta: ${dateToClient(date)}${frontendUrl ? `<br><br>
          Enlace para acceder a la plataforma: <a href="${frontendUrl}" target="_blank">${frontendUrl}</a>` : ""}`
        };
        await SendMail(_email);
      } catch (fallbackError) {
        console.log('El correo electrónico de respaldo también falló');
      }
    }

    // Envia WhatsApp de boas-vindas
    try {
      const company = await ShowCompanyService(1);
      const whatsappCompany = await FindCompaniesWhatsappService(company.id);
      const firstWhatsapp = whatsappCompany.whatsapps[0];

      const phoneJid = formatPhoneToWhatsappJid(phone);

      if (
        firstWhatsapp?.status === "CONNECTED" &&
        phoneJid
      ) {
        const wbot = getWbot(firstWhatsapp.id);

        let whatsappBody = "";
        if (welcomeWhatsappText) {
          // Usa texto personalizado
          whatsappBody = replaceVariables(welcomeWhatsappText, messageVariables);
        } else {
          // Usa texto padrão
          whatsappBody = `Hola ${name}, Este es un mensaje sobre el registro para ${resolvedCompanyName}!\n\nPrueba válida para ${trialDays} dias. 
          Aquí tienes los datos de tu empresa::\n\n
          Nombre: ${resolvedCompanyName}\n
          Email: ${normalizedEmail}\n
          Contraseña: ${password}\n
          Válido hasta: ${dateToClient(date)}${frontendUrl ? `\n\n
          Enlace para acceder a la plataforma: ${frontendUrl}` : ""}`;
        }

        const sendOptions: any = { createChat: false };

        await wbot.sendMessage(phoneJid, { text: whatsappBody }, sendOptions);
        console.log("WhatsApp de bienvenida enviado correctamente");
      }
    } catch (error) {
      console.log('No pude enviar el mensaje de WhatsApp:', error);
    }

    return res.status(200).json(user);
  }

  if (companyUser) {
    const user = await CreateUserService({
      email,
      password,
      name,
      profile,
      companyId: companyUser,
      queueIds,
      startWork,
      endWork,
      whatsappId,
      allTicket,
      defaultTheme,
      defaultMenu,
      allowGroup,
      allHistoric,
      allUserChat,
      userClosePendingTicket,
      showDashboard,
      defaultTicketsManagerWidth,
      allowRealTime,
      allowConnections
    });

    const io = getIO();
    io.of(userCompanyId.toString())
      .emit(`company-${userCompanyId}-user`, {
        action: "create",
        user
      });

    return res.status(200).json(user);
  }
};

// export const store = async (req: Request, res: Response): Promise<Response> => {
//   const {
//     email,
//     password,
//     name,
//     profile,
//     companyId: bodyCompanyId,
//     queueIds
//   } = req.body;
//   let userCompanyId: number | null = null;

//   if (req.user !== undefined) {
//     const { companyId: cId } = req.user;
//     userCompanyId = cId;
//   }

//   if (
//     req.url === "/signup" &&
//     (await CheckSettingsHelper("userCreation")) === "disabled"
//   ) {
//     throw new AppError("ERR_USER_CREATION_DISABLED", 403);
//   } else if (req.url !== "/signup" && req.user.profile !== "admin") {
//     throw new AppError("ERR_NO_PERMISSION", 403);
//   }

//   const user = await CreateUserService({
//     email,
//     password,
//     name,
//     profile,
//     companyId: bodyCompanyId || userCompanyId,
//     queueIds
//   });

//   const io = getIO();
//   io.of(String(companyId))
//  .emit(`company-${userCompanyId}-user`, {
//     action: "create",
//     user
//   });

//   return res.status(200).json(user);
// };

export const show = async (req: Request, res: Response): Promise<Response> => {
  const { userId } = req.params;
  const { companyId } = req.user;

  const user = await ShowUserService(userId, companyId);

  return res.status(200).json(user);
};

export const showEmail = async (req: Request, res: Response): Promise<Response> => {
  const { email } = req.params;

  const user = await APIShowEmailUserService(email);

  return res.status(200).json(user);
};

export const update = async (
  req: Request,
  res: Response
): Promise<Response> => {

  // if (req.user.profile !== "admin") {
  //   throw new AppError("ERR_NO_PERMISSION", 403);
  // }

  if (process.env.DEMO === "ON") {
    throw new AppError("ERR_NO_PERMISSION", 403);
  }

  const { id: requestUserId, companyId } = req.user;
  const { userId } = req.params;
  const userData = req.body;

  const user = await UpdateUserService({
    userData,
    userId,
    companyId,
    requestUserId: +requestUserId
  });


  const io = getIO();
  io.of(String(companyId))
    .emit(`company-${companyId}-user`, {
      action: "update",
      user
    });

  return res.status(200).json(user);
};

export const remove = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { userId } = req.params;
  const { companyId, id, profile } = req.user;

  if (profile !== "admin") {
    throw new AppError("ERR_NO_PERMISSION", 403);
  }

  if (process.env.DEMO === "ON") {
    throw new AppError("ERR_NO_PERMISSION", 403);
  }

  const user = await User.findOne({
    where: { id: userId }
  });

  if (companyId !== user.companyId) {
    return res.status(400).json({ error: "¡No tienes permiso para acceder a este recurso!" });
  } else {
    await DeleteUserService(userId, companyId);

    const io = getIO();
    io.of(String(companyId))
      .emit(`company-${companyId}-user`, {
        action: "delete",
        userId
      });

    return res.status(200).json({ message: "Usuario eliminado" });
  }

};

export const list = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.query;
  const { companyId: userCompanyId } = req.user;

  const users = await SimpleListService({
    companyId: companyId ? +companyId : userCompanyId
  });

  return res.status(200).json(users);
};

export const mediaUpload = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { userId } = req.params;
  const { companyId } = req.user;
  const files = req.files as Express.Multer.File[];
  const file = head(files);

  try {
    let user = await User.findByPk(userId);
    user.profileImage = file.filename.replace('/', '-');

    await user.save();

    user = await ShowUserService(userId, companyId);
    
    const io = getIO();
    io.of(String(companyId))
      .emit(`company-${companyId}-user`, {
        action: "update",
        user
      });


    return res.status(200).json({ user, message: "Imagen actualizada" });
  } catch (err: any) {
    throw new AppError(err.message);
  }
};

export const toggleChangeWidht = async (req: Request, res: Response): Promise<Response> => {
  var { userId } = req.params;
  const { defaultTicketsManagerWidth } = req.body;

  const { companyId } = req.user;
  const user = await ToggleChangeWidthService({ userId, defaultTicketsManagerWidth });

  const io = getIO();
  io.of(String(companyId))
    .emit(`company-${companyId}-user`, {
      action: "update",
      user
    });

  return res.status(200).json(user);
};