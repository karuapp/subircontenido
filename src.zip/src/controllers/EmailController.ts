import { Request, Response } from "express";
import { SendMail } from "../helpers/SendMail";

export const sendCrmEmail = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { nome, email, telefone, empresa, segmento, mensagem } = req.body;

    // Crear correo electrónico HTML
    const htmlContent = `
      <h2>Nueva solicitud de CRM personalizada</h2>
      <p><strong>Nombre:</strong> ${nome}</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Número de teléfono:</strong> ${telefone}</p>
      <p><strong>Empresa:</strong> ${empresa}</p>
      <p><strong>Segmento:</strong> ${segmento}</p>
      <p><strong>Mensaje:</strong></p>
      <p>${mensagem}</p>
      <hr>
      <p><small>Enviado mediante formulario del panel</small></p>
    `;

    // Usar la función SendMail existente
    await SendMail({
      to: "manueldavilawhatitancrm@gmail.com",
      subject: `Solicitud CRM - ${empresa}`,
      html: htmlContent
    });

    return res.status(200).json({ message: "Correo electrónico enviado correctamente!" });
  } catch (error) {
    console.error("Error al enviar el correo electrónico:", error);
    return res.status(500).json({ error: "Error al enviar el correo electrónico" });
  }
};
