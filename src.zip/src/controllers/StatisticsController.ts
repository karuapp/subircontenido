// src/controllers/StatisticsController.ts
import { Request, Response } from "express";
import TicketsQueuesService from "../services/Statistics/TicketsQueuesService";
import ContactsReportService from "../services/Statistics/ContactsReportService";
import AppError from "../errors/AppError";

// --- Tipos de Query para DashTicketsQueues ---
type IndexQuery = {
  dateStart: string;
  dateEnd: string;
  status: string[];
  queuesIds: string[];
  showAll?: string; // opcional
};

// --- Tipo de Request que TicketsQueuesService espera ---
type TicketsQueuesRequest = {
  showAll: boolean | "true";
  dateStart: string;
  endDate: string;
  status: string[];
  queuesIds: string[];
  userId: string;
  companyId: number;
};

// --- Tipos de Query para ContactsReport ---
type tContactReportQuery = {
  startDate: string;
  endDate: string;
  tags?: number[] | string[];
  wallets?: number[] | string[];
  searchParam?: string;
};

// --- Tipo de Request que ContactsReportService espera ---
type ContactsReportRequest = {
  startDate: string;
  endDate: string;
  tags?: number[] | string[];
  wallets?: number[] | string[];
  companyId: number;
  profile: string;
  userId: number;
  searchParam?: string;
};

// --- Controlador DashTicketsQueues ---
export const DashTicketsQueues = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { companyId, profile, id: userId } = req.user;
  const { dateStart, dateEnd, status, queuesIds } = req.query as IndexQuery;

  // Validación mínima
  if (!dateStart || !dateEnd) {
    throw new AppError("ERR_INVALID_DATE_RANGE", 400);
  }

  const tickets = await TicketsQueuesService({
    showAll: profile === "admin" ? "true" : false,
    dateStart,
    endDate: dateEnd,
    status,
    queuesIds,
    userId: +userId,
    companyId: +companyId
  } as TicketsQueuesRequest);

  return res.status(200).json(tickets);
};

// --- Controlador ContactsReport ---
export const ContactsReport = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { companyId, profile, id: userId } = req.user;
  const { startDate, endDate, tags, wallets, searchParam } =
    req.query as tContactReportQuery;

  // Validación mínima
  if (!startDate || !endDate) {
    throw new AppError("ERR_INVALID_DATE_RANGE", 400);
  }

  const tickets = await ContactsReportService({
    startDate,
    endDate,
    tags,
    wallets,
    companyId: +companyId,
    profile,
    userId: +userId,
    searchParam
  } as ContactsReportRequest);

  return res.status(200).json(tickets);
};