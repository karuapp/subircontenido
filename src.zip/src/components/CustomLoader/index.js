import React, { useState, useEffect } from 'react';
import { CircularProgress } from '@material-ui/core';
import { openApi } from '../../services/api';

// Cache global para evitar múltiplas chamadas
let cachedLoadingImage = null;
let loadingImagePromise = null;

const CustomLoader = ({ 
  size = 30,
  color = '#9c27b0',
  text = '',
  style = {}
}) => {
  const [loadingImage, setLoadingImage] = useState(cachedLoadingImage);

  useEffect(() => {
    // Si ya tenemos una caché, la usamos inmediatamente.
    if (cachedLoadingImage !== null) {
      setLoadingImage(cachedLoadingImage);
      return;
    }

    // Si una promesa ya está en proceso, la reutilizamos.
    if (loadingImagePromise) {
      loadingImagePromise.then(img => {
        setLoadingImage(img);
      });
      return;
    }

    // Obtenemos la imagen de carga de la configuración pública (no se requiere autenticación).
    console.log('[CustomLoader] Buscando appLogoLoading da API...');
    loadingImagePromise = openApi.get('/public-settings/appLogoLoading', {
      params: { token: 'wtV' }
    })
      .then(({ data }) => {
        console.log('[CustomLoader] Respuesta de API:', data);
        // La API devuelve el valor directamente.
        cachedLoadingImage = data || '';
        console.log('[CustomLoader] Imagen en cache:', cachedLoadingImage);
        return cachedLoadingImage;
      })
      .catch(err => {
        console.error('[CustomLoader] Error al cargar la imagen de loading:', err);
        cachedLoadingImage = '';
        return '';
      })
      .finally(() => {
        loadingImagePromise = null;
      });

    loadingImagePromise.then(img => {
      setLoadingImage(img);
    });
  }, []);

  if (loadingImage) {
    return (
      <img 
        src={`${process.env.REACT_APP_BACKEND_URL}/public/${loadingImage}`}
        alt="Loading..."
        style={{
          width: size,
          height: size,
          objectFit: 'contain',
          ...style
        }}
      />
    );
  }

  // Regreso al CircularProgress estándar
  return <CircularProgress size={size} style={{ color, ...style }} />;
};

export default CustomLoader;
