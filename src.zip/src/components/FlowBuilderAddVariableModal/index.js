import React, { useEffect, useMemo, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Typography,
  MenuItem,
  Paper,
  Tabs,
  Tab,
} from "@material-ui/core";
import { Autocomplete } from "@material-ui/lab";
import { makeStyles } from "@material-ui/core/styles";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";
import MessageVariablesPicker from "../MessageVariablesPicker";

const useStyles = makeStyles((theme) => ({
  section: {
    padding: theme.spacing(2),
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    backgroundColor: "#fff",
    marginBottom: theme.spacing(2),
  },
  sectionTitle: {
    fontWeight: 600,
    fontSize: "0.95rem",
    color: "#111827",
    marginBottom: theme.spacing(1.5),
  },
  helperText: {
    fontSize: "0.75rem",
    color: "#6b7280",
  },
  tabs: {
    marginBottom: theme.spacing(1.5),
  },
  codeField: {
    fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
  },
}));

const defaultData = {
  variableName: "",
  valueType: "custom",
  editorMode: "text",
  customValue: "",
};

const valueTypeOptions = [
  { value: "custom", label: "Personalizado (valor personalizado)" },
  { value: "empty", label: "Vacío (borrar valor)" },
  { value: "append", label: "Añadir valor(es)" },
  { value: "environment", label: "Nombre del entorno" },
  { value: "device", label: "Tipo de dispositivo" },
  { value: "transcript", label: "Transcripción" },
  { value: "resultId", label: "Resultado ID" },
  { value: "now", label: "Ahora" },
];

const valueTypeDescription = {
  custom: "Definir manualmente qué se guardará (texto o código).",
  empty: "Restablece el contenido de la variable.",
  append: "Añade el valor introducido al contenido actual.",
  environment: "Almacena el nombre del entorno (p. ej., producción).",
  device: "Almacena el tipo de dispositivo del usuario.",
  transcript: "Almacena la transcripción de la sesión actual.",
  resultId: "Almacena el ID del resultado de la sesión.",
  now: "Guarda la fecha y hora actuales.",
};

const FlowBuilderAddVariableModal = ({
  open,
  onSave,
  data,
  onUpdate,
  close,
}) => {
  const classes = useStyles();
  const [activeModal, setActiveModal] = useState(false);
  const [labels, setLabels] = useState({ title: "", btn: "" });
  const [formData, setFormData] = useState(defaultData);
  const [availableVariables, setAvailableVariables] = useState([]);

  const mergedData = useMemo(() => {
    if (!data?.data?.variableConfig) return defaultData;
    return {
      ...defaultData,
      ...data.data.variableConfig,
    };
  }, [data]);

  useEffect(() => {
    if (open === "edit") {
      setLabels({ title: "Editar variable", btn: "Guardar" });
      setFormData(mergedData);
      setActiveModal(true);
    } else if (open === "create") {
      setLabels({ title: "Añadir variable", btn: "Añadir" });
      setFormData(defaultData);
      setActiveModal(true);
    } else {
      setActiveModal(false);
    }
  }, [open, mergedData]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem("variables");
      if (!stored) {
        setAvailableVariables([]);
        return;
      }
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) {
        const sanitized = parsed
          .filter((item) => typeof item === "string")
          .map((item) => item.trim())
          .filter(Boolean);
        setAvailableVariables([...new Set(sanitized)]);
      } else {
        setAvailableVariables([]);
      }
    } catch (error) {
      setAvailableVariables([]);
    }
  }, [open]);

  const persistVariableName = (name) => {
    if (!name) return;
    try {
      const stored = localStorage.getItem("variables");
      const vars = stored ? JSON.parse(stored) : [];
      const sanitized = Array.isArray(vars) ? vars : [];
      if (!sanitized.includes(name)) {
        localStorage.setItem("variables", JSON.stringify([...sanitized, name]));
      }
    } catch (error) {
      localStorage.setItem("variables", JSON.stringify([name]));
    }
  };

  const handleClose = () => {
    close(null);
    setActiveModal(false);
  };

  const handleFieldChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleInsertVariable = (variable) => {
    if (
      formData.valueType !== "custom" ||
      formData.editorMode !== "text" ||
      !variable
    ) {
      return;
    }
    setFormData((prev) => ({
      ...prev,
      customValue: `${prev.customValue || ""}${variable}`,
    }));
  };

  const handleSave = () => {
    const variableName = formData.variableName.trim();
    if (!variableName) return;
    const payload = {
      variableConfig: {
        ...formData,
        variableName,
      },
    };

    if (open === "edit" && typeof onUpdate === "function") {
      onUpdate({
        ...data,
        data: {
          ...data.data,
          ...payload,
        },
      });
    } else if (open === "create" && typeof onSave === "function") {
      onSave(payload);
    }

    persistVariableName(variableName);
    handleClose();
  };

  const disabled = !formData.variableName.trim();

  return (
    <Dialog open={activeModal} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle>{labels.title}</DialogTitle>
      <DialogContent dividers>
        <Paper className={classes.section} elevation={0}>
          <Typography className={classes.sectionTitle}>
            Variável do fluxo
          </Typography>
          <Autocomplete
            freeSolo
            options={availableVariables}
            value={formData.variableName}
            onInputChange={(event, value) => handleFieldChange("variableName", value)}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Nombre de la variable"
                placeholder="ej: emailCliente"
                variant="outlined"
                margin="dense"
              />
            )}
          />
          <Typography className={classes.helperText}>
            Busque o cree una nueva variable. El nombre debe ser único dentro del flujo..
          </Typography>
        </Paper>

        <Paper className={classes.section} elevation={0}>
          <Typography className={classes.sectionTitle}>
            Valor que se guardará.
          </Typography>
          <TextField
            select
            label="Tipo de valor."
            fullWidth
            variant="outlined"
            margin="dense"
            value={formData.valueType}
            onChange={(event) => handleFieldChange("valueType", event.target.value)}
          >
            {valueTypeOptions.map((option) => (
              <MenuItem key={option.value} value={option.value}>
                {option.label}
              </MenuItem>
            ))}
          </TextField>
          <Typography className={classes.helperText}>
            {valueTypeDescription[formData.valueType]}
          </Typography>

          {formData.valueType === "custom" && (
            <>
              <Tabs
                value={formData.editorMode}
                onChange={(event, value) => handleFieldChange("editorMode", value)}
                indicatorColor="primary"
                textColor="primary"
                className={classes.tabs}
              >
                <Tab label="Texto" value="text" />
                <Tab label="Código" value="code" />
              </Tabs>
              <TextField
                label={formData.editorMode === "text" ? "Contenido" : "Código"}
                multiline
                rows={formData.editorMode === "text" ? 5 : 8}
                variant="outlined"
                margin="dense"
                value={formData.customValue}
                onChange={(event) => handleFieldChange("customValue", event.target.value)}
                fullWidth
                placeholder={
                  formData.editorMode === "text"
                    ? "Olá {{nome}}, tudo certo?"
                    : "// Escribe el código para generar el valor"
                }
                InputProps={{
                  className: formData.editorMode === "code" ? classes.codeField : undefined,
                }}
              />
              {formData.editorMode === "text" && (
                <MessageVariablesPicker onClick={handleInsertVariable} />
              )}
            </>
          )}
        </Paper>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={handleClose}
          startIcon={<CancelIcon />}
        >
          Cancelar
        </Button>
        <Button
          color="primary"
          variant="contained"
          startIcon={<SaveIcon />}
          onClick={handleSave}
          disabled={disabled}
        >
          {labels.btn}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default FlowBuilderAddVariableModal;
