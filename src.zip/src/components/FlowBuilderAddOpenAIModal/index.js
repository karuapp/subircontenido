import React, { useState, useEffect, useRef, useMemo } from "react";
import * as Yup from "yup";
import { Formik, Form, Field } from "formik";
import { makeStyles } from "@material-ui/core/styles";
import { green } from "@material-ui/core/colors";
import Button from "@material-ui/core/Button";
import { MenuItem, FormControl, InputLabel, Select, Typography, Box, Chip, Tooltip } from "@material-ui/core";
import { Visibility, VisibilityOff } from "@material-ui/icons";
import { InputAdornment, IconButton } from "@material-ui/core";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import api from "../../services/api";
import toastError from "../../errors/toastError";
import { i18n } from "../../translate/i18n";
import TextField from "@material-ui/core/TextField";
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';
import { Grid } from "@material-ui/core";
import { TOOL_CATALOG, DEFAULT_SENSITIVE_TOOLS } from "../../constants/aiTools";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
  },
  textField: {
    marginRight: theme.spacing(1),
    flex: 1,
  },
  extraAttr: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  btnWrapper: {
    position: "relative",
  },
  buttonProgress: {
    color: green[500],
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -12,
    marginLeft: -12,
  },
  buttonGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: "10px",
    padding: "20px",
  },
  customButton: {
    backgroundColor: "#4CAF50",
    color: "white",
    padding: "15px 20px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "16px",
    "&:hover": {
      backgroundColor: "#45a049",
    },
  },
  dialogTitle: {
    backgroundColor: "#3f51b5",
    color: "white",
    textAlign: "center",
    fontSize: "24px",
    fontWeight: "bold",
  },
  closeButton: {
    backgroundColor: "#f44336",
    color: "white",
    "&:hover": {
      backgroundColor: "#d32f2f",
    },
  },
  popupButtonGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, 1fr)",
    gap: "10px",
    padding: "20px",
  },
}));

const DialogflowSchema = Yup.object().shape({
  name: Yup.string()
    .min(2, "¡Demasiado corto!")
    .max(50, "¡Demasiado largo!")
    .required("Obligatorio"),
});

const FlowBuilderOpenAIModal = ({ open, onSave, data, onUpdate, close }) => {
  const classes = useStyles();
  const isMounted = useRef(true);

  const handleToggleApiKey = () => {
    setShowApiKey(!showApiKey);
  };

  const initialState = {
    name: "",
    iaMode: "system",
    iaId: "default",
  };

  const [showApiKey, setShowApiKey] = useState(false); // Se conserva solo por compatibilidad, no se utiliza.
  const [selectedVoice, setSelectedVoice] = useState("texto"); // Se conserva solo por compatibilidad, no se utiliza.
  const [activeModal, setActiveModal] = useState(false);
  const [integration, setIntegration] = useState(initialState);
  const [labels, setLabels] = useState({
    title: "Añadir agente de IA al flujo",
    btn: "Añadir",
  });
  const [popupOpen, setPopupOpen] = useState(false);
  const [prompts, setPrompts] = useState([]);

  const toolMap = useMemo(() => {
    const map = {};
    TOOL_CATALOG.forEach(tool => {
      map[tool.value] = tool;
    });
    return map;
  }, []);

  useEffect(() => {
    if (open === "edit") {
      setLabels({
        title: "Editar agente de IA en el flujo",
        btn: "Guardar",
      });
      const current = data?.data?.typebotIntegration || {};
      setIntegration({
        name: current.name || "",
        iaMode: current.iaMode || "system",
        iaId: current.iaId || "default",
      });
      setActiveModal(true);
    } else if (open === "create") {
      setLabels({
        title: "Añadir agente de IA al flujo",
        btn: "Guardar",
      });
      setIntegration(initialState);
      setActiveModal(true);
    }

    if (open === "edit" || open === "create") {
      api
        .get("/prompt")
        .then(({ data }) => {
          const list = Array.isArray(data?.prompts) ? data.prompts : [];
          setPrompts(list);

          if (open === "create" && list.length > 0) {
            setIntegration(prev => ({
              ...prev,
              iaId: list[0].id,
            }));
          }
        })
        .catch(toastError);
    }

    return () => {
      isMounted.current = false;
    };
  }, [open]);

  const handleClose = () => {
    close(null);
    setActiveModal(false);
  };

  const handleChangeVoice = (e) => {
    setSelectedVoice(e.target.value);
  };

  const handleSavePrompt = (values) => {
    const promptMeta = prompts.find(
      prompt => String(prompt.id) === String(values.iaId)
    );

    const payload = {
      name: values.name,
      iaMode: "system",
      iaId: values.iaId,
      promptName: promptMeta?.name || "",
      toolsEnabled: promptMeta?.toolsEnabled || []
    };

    if (open === "edit") {
      handleClose();
      onUpdate({
        ...data,
        data: { typebotIntegration: payload },
      });
    } else if (open === "create") {
      handleClose();
      onSave({
        typebotIntegration: payload,
      });
    }
  };

  const buttons = [
    "Clínica médica", "Salón de belleza", "Tiendas de ropa", "Bufete de abogados",
    "Asistencia técnica", "Tiendas de electrónica", "Tienda de regalos",
    "Reparto de gasolina", "Empresa de contabilidad", "Tienda de dulces",
    "Cursos"
  ];

  const handlePopupOpen = () => {
    setPopupOpen(true);
  };

  const handlePopupClose = () => {
    setPopupOpen(false);
  };

  const handleButtonClick = (button, setFieldValue) => {
    let prompt = "";

    switch (button) {
      case "Clínica Médica":
        prompt = `
[Saludo automático según horario.]
"¡Buenos días! Bienvenido a la Clínica WhaTitan, especializada en salud masculina. Para comenzar, ¿podría decirme su nombre completo y edad? Así podré ofrecerle atención personalizada."

[Después de recoger su nombre y edad,]
"Gracias, [Nome]! ¿Cómo puedo ayudarle? ¿Desea programar una cita o tiene alguna pregunta sobre nuestros servicios?"

[Si el paciente pregunta por los médicos,]
"¡Claro! Aquí están los profesionales disponibles actualmente en la Clínica WhaTitan.:

Dr. Marcos - Cardiólogo

Dr. Carlos - Médico General

Dra. Márcia - Psicóloga

¿Desea saber más sobre alguna especialidad o los honorarios de su consulta?"

[Si el paciente pregunta por los honorarios,]
"¡Con gusto! Los honorarios de la consulta son::

Cardiólogo: 600.00

Médico General: 40.,00

Psicólogo: 350.00

¿Qué especialidad le gustaría programar?"

[Tras elegir la especialidad y el profesional]
"¡Bien, [Nome]! Consultaré la disponibilidad. ¿Qué día y hora prefiere dentro de nuestro horario de atención (de lunes a viernes, de 8:30 a. m. a 7:30 p. m.)?"

[Tras elegir el día y la hora]
"¡Con gusto le ayudaré! Su cita con [Especialidad/Profesional] está programada para el [fecha] a las [hora]. Nuestra dirección es Rua Macaira, 400, Bairro Aquário, Vinhedo/SP. Le recomiendo llegar 10 minutos antes."

[Cierre cordial]
"Gracias por elegir la Clínica KMENU. Estamos aquí para cuidar de su salud. Si tiene alguna pregunta, ¡no dude en preguntar! ¡Esperamos verle en su cita, [Nombre]! ¡Cuídese mucho!"
        `;
        break;

      case "Salón":
        prompt = `
[Saludo automático según horario]
"¡Hola! Bienvenido a Salón Belleza Total. ¿Cómo puedo ayudarte hoy? ¿Te gustaría programar una cita para un corte de pelo, coloración u otro servicio?"

[Si el cliente pregunta por nuestros servicios]
"¡Por supuesto! Ofrecemos los siguientes servicios:

- Corte de pelo: 50.00
- Coloración: 120.00
- Manicura y pedicura: 40.00
- Tratamientos capilares: 80.00

¿Qué servicio te gustaría agendar?"

[Después de elegir el servicio,]
"¡Perfecto! ¿Qué día y hora te gustaría agendar? Nuestro horario es de martes a sábado, de 9:00 a 18:00."

[Después de seleccionar el día y la hora]
"¡su cita se ha programado correctamente! Esperamos verle el [fecha] a las [hora]. Nuestra dirección es Rua das Flores, 123, Centro. Si tiene alguna pregunta, no dude en preguntar."
        `;
        break;

      case "Tiendas de ropa":
        prompt = `
[Saludo automático según horario]
"¡Hola! Bienvenido a Fashion Style Store. Tenemos una amplia variedad de ropa, zapatos y accesorios. ¿Cómo puedo ayudarte hoy?"

[Si el cliente pregunta por promociones]
"Tenemos varias promociones increíbles esta semana:

- Camisetas desde 29.90
- Jeans con 30% de descuento
- Zapatillas con hasta 50% de descuento

¿Desea saber más sobre un producto?"

[Si el cliente pregunta por las tallas]
"Disponemos de todas las tallas, desde la S hasta la XL. ¿Puedo ayudarle a encontrar la talla ideal?"

[Cordial cierre]
"¡Gracias por elegir Fashion Style! Esperamos que encuentre lo que busca. Si tiene alguna pregunta, ¡estamos a su disposición!"
        `;
        break;

      case "Bufete de abogados":
        prompt = `
[Saludo automático según la hora]
"¡Buenos días! Bienvenido al Bufete de Abogados Justice & Law. ¿Cómo puedo ayudarle hoy? ¿Desea programar una consulta o tiene alguna pregunta legal?"

[Si el cliente pregunta sobre nuestras áreas de práctica:]
"Nos especializamos en las siguientes áreas::

- Derecho Civil
- Derecho Laboral
- Derecho de Familia
- Derecho Mercantil

¿En qué área necesita ayuda?"

[Si el cliente pregunta sobre nuestros honorarios:]
"Los honorarios varían según el tipo de servicio. Para las consultas iniciales, cobramos 300.00. ¿Puedo programar una cita?"

[Después de elegir el día y la hora:]
"Su consulta ha sido programada para el [fecha] a las [hora]. Nuestra dirección es Avenida Principal, 456, Sala 101. ¡Esperamos verlo!"
        `;
        break;

      case "Asistencia Técnica":
        prompt = `
[Saludo automático según horario]
"¡Hola! Bienvenido a la Asistencia Técnica EletroPlus. ¿Cómo puedo ayudarle hoy? ¿Necesita reparar algún dispositivo electrónico?"

[Si el cliente pregunta por nuestros servicios]
"Ofrecemos asistencia para::

- Celulares y tablets
- Computadoras y portátiles
- Electrodomésticos
- Televisores y monitores

¿Qué dispositivo necesita reparación?"

[Si el cliente pregunta por los plazos]
"El tiempo de reparación varía según el problema, pero generalmente es de 3 a 7 días hábiles. ¿Puedo programar una evaluación?"

[Después de elegir el día y la hora]
"¡Perfecto! Su evaluación ha sido programada para el [fecha] a las [hora]. Nuestra dirección es Rua da Tecnologia, 789. ¡Esperamos verlo!"
        `;
        break;

      case "Tiendas de electrónica":
        prompt = `
[Saludo automático según la hora]
"¡Hola! Bienvenido a EletroTech. Tenemos los mejores productos electrónicos a los mejores precios. ¿Cómo puedo ayudarle?"

[Si el cliente pregunta por productos, ]
"Tenemos una amplia variedad de productos, incluyendo:

- Teléfonos inteligentes
- Portátiles
- Televisores y monitores
- Accesorios

¿Quieres saber más sobre algún producto específico?"

[Si el cliente pregunta por la garantía]
"Todos nuestros productos tienen 1 año de garantía. ¿Puedo ayudarle con algo más?"

[Cordial cierre]
"¡Gracias por elegir EletroTech! Esperamos que encuentre lo que busca. Si tiene alguna pregunta, ¡estamos a su disposición!"
        `;
        break;

      case "Tienda de regalos":
        prompt = `
[Saludo automático según la hora]
"¡Hola! Bienvenido a la Tienda de Regalos Especiales. Tenemos una variedad de regalos para toda ocasión. ¿Cómo puedo ayudarle?"

[Si el cliente pregunta por productos:]
"Tenemos regalos para::

- Cumpleaños
- Bodas
- Ocasiones especiales
- Regalos de empresa

¿Desea obtener más información sobre algún producto?"

[Si el cliente pregunta sobre la entrega]
"Ofrecemos entrega a domicilio en un plazo de 1 a 3 días hábiles. ¿Puedo ayudarle con algo más?"

[Cordial cierre]
"¡Gracias por elegir Special Gifts! Esperamos que encuentre el regalo perfecto. Si tiene alguna pregunta, estamos a su disposición."
        `;
        break;

      case "Entrega de gas":
        prompt = `
[Saludo automático según horario]
"¡Hola! Bienvenido a Gas Express. ¿Cómo puedo ayudarle? ¿Necesita entrega de gas o tiene alguna pregunta?"

[Si el cliente pregunta por precios]
"El precio de una bombona de 13 kg es de 80.00 y el de 45 kg es de 200.00. El envío es gratuito para pedidos superiores a 100.00."

[Si el cliente pregunta por los plazos de entrega:]
"Entregamos en 2 horas en la zona centro. Para otras regiones, el plazo de entrega puede variar. ¿Puedo recoger su pedido?"

[Tras la confirmación del pedido:]
"¡Su pedido ha sido registrado! Entregaremos el gas a la dirección [dirección] en [plazo]. ¡Gracias por elegir Gás Express!"
        `;
        break;

      case "Contabilidad":
        prompt = `
[Saludo automático según horario]
"¡Buenos días! Bienvenido a la Oficina de Contabilidad de Contabilize. ¿Cómo puedo ayudarle? ¿Necesita servicios de contabilidad o tiene alguna pregunta?"

[Si el cliente pregunta por nuestros servicios:]
"Ofrecemos los siguientes servicios::

- Creación de empresa
- Preparación de declaración de la renta
- Asesoría financiera
- Procesamiento de nóminas

¿Qué servicio necesita?"

[Si el cliente pregunta por los precios: ]
"Los precios varían según el servicio. Para la creación de una empresa, cobramos R$500.00. ¿Puedo programar una consulta?"

[Después de seleccionar el día y la hora]
"Su cita ha sido programada para el [fecha] a las [hora]. Nuestra dirección es Rua dos Contadores, 101. ¡Le esperamos!"
        `;
        break;

      case "Pastelería":
        prompt = `
[Saludo automático según horario]
"¡Hola! Bienvenidos a la Panadería Doce Sabor. Tenemos una variedad de dulces y postres caseros. ¿En qué puedo ayudarles?"

[Si el cliente pregunta por los productos]
"Tenemos:

- Pasteles personalizados
- Dulces para fiestas
- Tartas y postres
- Dulces dietéticos y sin azúcar

¿Te gustaría pedir algo?"

[Si el cliente pregunta por los plazos]
"Para pedidos, el plazo mínimo de entrega es de 2 días. ¿Puedo tomar nota de su pedido?"

[Tras la confirmación del pedido]
"¡Tu pedido ha sido registrado! Lo entregaremos en [dirección] el [fecha]. ¡Gracias por elegir Doce Sabor!"
        `;
        break;

      case "Cursos":
        prompt = `
[Saludo automático según horario]
"¡Hola! Bienvenido a la Escuela de Cursos Profesionales. ¿Cómo puedo ayudarte? ¿Te gustaría inscribirte en un curso o tienes alguna pregunta?"

[Si el cliente pregunta por cursos]
"Ofrecemos cursos en las siguientes áreas:

- Tecnologías de la información
- Marketing digital
- Diseño gráfico
- Administración

¿En qué curso estás interesado?"

[Si el cliente pregunta por los precios]
"Los precios varían según el curso. Para más información, ¿puedo programar una visita o llamar?"

[Después de elegir el día y la hora]
"¡Perfecto! Su visita está programada para el [fecha] a las [hora]. Nuestra dirección es Rua do Conhecimento, 202. ¡Esperamos verlo!"
        `;
        break;

      default:
        prompt = "";
    }

    setFieldValue("prompt", prompt.trim());
    handlePopupClose();
  };

  return (
    <div className={classes.root}>
      <Dialog
        open={activeModal}
        onClose={handleClose}
        fullWidth
        maxWidth="md"
        scroll="paper"
      >
        <DialogTitle className={classes.dialogTitle}>
          {labels.title}
        </DialogTitle>
        <Formik
          initialValues={integration}
          enableReinitialize={true}
          onSubmit={(values, actions) => {
            setTimeout(() => {
              handleSavePrompt(values);
              actions.setSubmitting(false);
            }, 400);
          }}
        >
          {({ isSubmitting, values }) => (
            <Form style={{ width: "100%" }}>
              <DialogContent dividers>
                <Field
                  as={TextField}
                  label="Nombre del bloque"
                  name="name"
                  margin="dense"
                  fullWidth
                />

                <Field
                  as={TextField}
                  select
                  label="IA utilizada"
                  name="iaId"
                  margin="dense"
                  fullWidth
                  helperText="Seleccione qué IA (Prompt) se utilizará en este bloque."
                >
                  {prompts.map(prompt => (
                    <MenuItem key={prompt.id} value={prompt.id}>
                      {prompt.name}
                    </MenuItem>
                  ))}
                </Field>

                <Box mt={1.5}>
                  <Typography variant="body2" color="textSecondary">
                    Herramientas habilitadas:
                  </Typography>
                  <Box display="flex" flexWrap="wrap" mt={0.5} gap={8}>
                    {(() => {
                      const selectedPrompt = prompts.find(
                        prompt => String(prompt.id) === String(values.iaId)
                      );
                      if (!selectedPrompt) {
                        return (
                          <Typography variant="caption" color="textSecondary">
                            Seleccione una solicitud para ver las herramientas permitidas.
                          </Typography>
                        );
                      }
                      const tools = selectedPrompt.toolsEnabled || [];
                      if (!tools.length) {
                        return (
                          <Typography variant="caption" color="textSecondary">
                            No hay herramientas habilitadas para esta solicitud.
                          </Typography>
                        );
                      }
                      return tools.map(toolName => {
                        const meta = toolMap[toolName];
                        const isSensitive = DEFAULT_SENSITIVE_TOOLS.includes(toolName);
                        return (
                          <Tooltip
                            key={`${selectedPrompt.id}-${toolName}`}
                            title={meta?.description || toolName}
                            arrow
                          >
                            <Chip
                              size="small"
                              label={meta?.title || toolName}
                              style={{
                                fontSize: "0.65rem",
                                fontWeight: 600,
                                textTransform: "uppercase",
                                backgroundColor: isSensitive ? "#fee2e2" : "#e0f2fe",
                                color: isSensitive ? "#b91c1c" : "#075985"
                              }}
                            />
                          </Tooltip>
                        );
                      });
                    })()}
                  </Box>
                </Box>
              </DialogContent>
              <DialogActions>
                <Button
                  onClick={handleClose}
                  color="secondary"
                  startIcon={<CancelIcon />}
                >
                  {i18n.t("promptModal.buttons.cancel")}
                </Button>
                <Button
                  type="submit"
                  color="primary"
                  variant="contained"
                  startIcon={<SaveIcon />}
                  className={classes.btnWrapper}
                  disabled={isSubmitting}
                >
                  {open === "create" ? "Añadir" : "Editar"}
                </Button>
              </DialogActions>
            </Form>
          )}
        </Formik>
      </Dialog>
    </div>
  );
};

export default FlowBuilderOpenAIModal;