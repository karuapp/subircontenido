import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Box,
  Typography
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { toast } from "react-toastify";
import {
  createSliderBanner,
  updateSliderBanner
} from "../../services/sliderHomeService";

const useStyles = makeStyles((theme) => ({
  previewWrapper: {
    marginTop: theme.spacing(2),
    width: "100%",
    borderRadius: 12,
    overflow: "hidden",
    border: `1px dashed ${theme.palette.divider}`,
    padding: theme.spacing(1.5),
    textAlign: "center",
  },
  previewImage: {
    width: "100%",
    borderRadius: 8,
    maxHeight: 240,
    objectFit: "cover",
  },
  uploadInput: {
    marginTop: theme.spacing(2),
  }
}));

const SliderBannerModal = ({ open, onClose, banner, onSuccess }) => {
  const classes = useStyles();
  const [name, setName] = useState("");
  const [imageFile, setImageFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setName(banner?.name || "");
    setPreviewUrl(banner?.image || "");
    setImageFile(null);
  }, [banner]);

  const handleImageChange = (event) => {
    const file = event.target.files?.[0];
    if (!file) {
      setImageFile(null);
      return;
    }
    setImageFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const getImageUrl = (path) => {
    if (!path) return "";
    if (path.startsWith("http")) return path;
    const baseUrl = process.env.REACT_APP_BACKEND_URL?.replace(/\/$/, "");
    return baseUrl ? `${baseUrl}/${path}` : path;
  };

  const handleSubmit = async () => {
    if (!name.trim()) {
      toast.error("Introduce el nombre del banner");
      return;
    }
    if (!banner && !imageFile) {
      toast.error("Selecciona una imagen PNG para el banner");
      return;
    }

    setSaving(true);
    try {
      if (banner) {
        await updateSliderBanner(banner.id, { name, image: imageFile || undefined });
        toast.success("¡Banner actualizado correctamente!");
      } else {
        await createSliderBanner({ name, image: imageFile });
        toast.success("¡Banner creado correctamente!");
      }
      if (onSuccess) {
        onSuccess();
      }
      onClose();
    } catch (error) {
      console.error("Error al guardar el banner:", error);
      toast.error("No se puede guardar el banner");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>{banner ? "Editar banner" : "Nuevo banner"}</DialogTitle>
      <DialogContent>
        <TextField
          label="Nombre del banner"
          value={name}
          onChange={(e) => setName(e.target.value)}
          fullWidth
          margin="normal"
        />

        <Box className={classes.uploadInput}>
          <input type="file" accept="image/*" onChange={handleImageChange} />
          <Typography variant="caption" color="textSecondary">
            Recomendado: imágenes horizontales en formato PNG o JPG.
          </Typography>
        </Box>

        {previewUrl && (
          <Box className={classes.previewWrapper}>
            <img
              src={imageFile ? previewUrl : getImageUrl(previewUrl)}
              alt="Vista previa"
              className={classes.previewImage}
            />
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={saving}>
          Cancelar
        </Button>
        <Button color="primary" variant="contained" onClick={handleSubmit} disabled={saving}>
          {banner ? "Guardar" : "Registrarse"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default SliderBannerModal;
