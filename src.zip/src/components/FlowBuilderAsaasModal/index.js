import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Typography,
  Box,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { Receipt } from "@mui/icons-material";

const useStyles = makeStyles((theme) => ({
  dialog: {
    "& .MuiDialog-paper": {
      borderRadius: 16,
      minWidth: 450,
    },
  },
  dialogTitle: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    padding: "20px 24px",
    borderBottom: "1px solid #e5e7eb",
  },
  iconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    background: "linear-gradient(135deg, #10b981, #059669)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    boxShadow: "0 4px 12px rgba(16, 185, 129, 0.25)",
  },
  titleText: {
    fontSize: 18,
    fontWeight: 700,
    color: "#111827",
  },
  subtitle: {
    fontSize: 12,
    color: "#6b7280",
    marginTop: 2,
  },
  dialogContent: {
    padding: "24px",
  },
  field: {
    marginBottom: 20,
  },
  label: {
    fontSize: 13,
    fontWeight: 600,
    color: "#374151",
    marginBottom: 8,
    display: "block",
  },
  helpText: {
    fontSize: 11,
    color: "#6b7280",
    marginTop: 6,
  },
  dialogActions: {
    padding: "16px 24px",
    borderTop: "1px solid #e5e7eb",
    gap: 12,
  },
  cancelButton: {
    textTransform: "none",
    fontWeight: 600,
    color: "#6b7280",
    "&:hover": {
      backgroundColor: "#f3f4f6",
    },
  },
  saveButton: {
    textTransform: "none",
    fontWeight: 600,
    backgroundColor: "#10b981",
    color: "#ffffff",
    borderRadius: 8,
    padding: "8px 20px",
    "&:hover": {
      backgroundColor: "#059669",
    },
  },
  infoBox: {
    backgroundColor: "#f0fdf4",
    borderRadius: 10,
    padding: 16,
    border: "1px solid #bbf7d0",
    marginBottom: 20,
  },
  infoTitle: {
    fontSize: 13,
    fontWeight: 600,
    color: "#166534",
    marginBottom: 8,
  },
  infoText: {
    fontSize: 12,
    color: "#15803d",
    lineHeight: 1.5,
  },
}));

const FlowBuilderAsaasModal = ({ open, onSave, data, onUpdate, close }) => {
  const classes = useStyles();
  const [message, setMessage] = useState("Proporcione su CPF para que podamos recuperar su comprobante de pago.:");
  const [errorMessage, setErrorMessage] = useState("Lo sentimos, no encontramos ningún comprobante de pago pendiente para este CPF..");
  const [successMessage, setSuccessMessage] = useState("¡Encontramos su comprobante de pago! Enviando los datos....");

  useEffect(() => {
    if (open === "edit" && data?.data) {
      setMessage(data.data.message || "Proporcione su CPF para que podamos recuperar su comprobante de pago.:");
      setErrorMessage(data.data.errorMessage || "Lo sentimos, no encontramos ningún comprobante de pago pendiente para este CPF..");
      setSuccessMessage(data.data.successMessage || "¡Encontramos su comprobante de pago! Enviando los datos....");
    } else if (open === "create") {
      setMessage("Proporcione su CPF para que podamos recuperar su comprobante de pago.:");
      setErrorMessage("Lo sentimos, no encontramos ningún comprobante de pago pendiente para este CPF..");
      setSuccessMessage("¡Encontramos su comprobante de pago! Enviando los datos....");
    }
  }, [open, data]);

  const handleSave = () => {
    const nodeData = {
      message,
      errorMessage,
      successMessage,
    };

    if (open === "edit") {
      onUpdate({
        ...data,
        data: nodeData,
      });
    } else {
      onSave(nodeData);
    }
    handleClose();
  };

  const handleClose = () => {
    setMessage("Proporcione su CPF para que podamos recuperar su comprobante de pago.:");
    setErrorMessage("Lo sentimos, no pudimos encontrar ningún comprobante de pago pendiente para este CPF..");
    setSuccessMessage("¡Encontramos su comprobante de pago! Enviando los datos....");
    close();
  };

  return (
    <Dialog
      open={open === "create" || open === "edit"}
      onClose={handleClose}
      className={classes.dialog}
      maxWidth="sm"
      fullWidth
    >
      <div className={classes.dialogTitle}>
        <div className={classes.iconWrapper}>
          <Receipt sx={{ color: "#ffffff", fontSize: 22 }} />
        </div>
        <div>
          <Typography className={classes.titleText}>
            2ª Vía Boleto (Comprobante de Pago) - Asaas
          </Typography>
          <Typography className={classes.subtitle}>
            Recuperación Automática de Comprobantes de Pago por CPF 
          </Typography>
        </div>
      </div>

      <DialogContent className={classes.dialogContent}>
        <Box className={classes.infoBox}>
          <Typography className={classes.infoTitle}>
            ¿Cómo funciona?
          </Typography>
          <Typography className={classes.infoText}>
            Este nodo solicita el CPF del cliente y lo recupera automáticamente de Asaas.
            La factura pendiente más reciente. Si la encuentra, envíe el PDF de la factura  
            y el código QR PIX para el pago.
          </Typography>
        </Box>

        <div className={classes.field}>
          <label className={classes.label}>Mensaje de solicitud de CPF</label>
          <TextField
            fullWidth
            multiline
            rows={2}
            variant="outlined"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Ingrese el mensaje para solicitar el CPF..."
          />
          <Typography className={classes.helpText}>
            Este mensaje se enviará para solicitar el CPF del cliente.
          </Typography>
        </div>

        <div className={classes.field}>
          <label className={classes.label}>Mensaje de éxito</label>
          <TextField
            fullWidth
            multiline
            rows={2}
            variant="outlined"
            value={successMessage}
            onChange={(e) => setSuccessMessage(e.target.value)}
            placeholder="Mensaje cuando se encuentra el comprobante de pago..."
          />
          <Typography className={classes.helpText}>
            Enviada antes de enviar o boleto e QR Code PIX
          </Typography>
        </div>

        <div className={classes.field}>
          <label className={classes.label}>Mensaje de error</label>
          <TextField
            fullWidth
            multiline
            rows={2}
            variant="outlined"
            value={errorMessage}
            onChange={(e) => setErrorMessage(e.target.value)}
            placeholder="Mensaje que se muestra cuando no se encuentra ningún comprobante de pago..."
          />
          <Typography className={classes.helpText}>
            Se envía cuando no hay ningún comprobante de pago pendiente o el CPF  no es válido.
          </Typography>
        </div>
      </DialogContent>

      <DialogActions className={classes.dialogActions}>
        <Button onClick={handleClose} className={classes.cancelButton}>
          Cancelar
        </Button>
        <Button
          onClick={handleSave}
          className={classes.saveButton}
          variant="contained"
        >
          {open === "edit" ? "Actualizar" : "Agregar"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default FlowBuilderAsaasModal;
