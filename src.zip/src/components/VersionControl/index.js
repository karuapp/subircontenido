import React, { useState, useContext, useEffect } from "react";
import api from "../../services/api";
import Button from "@material-ui/core/Button";
import { useDate } from "../../hooks/useDate";
import { AuthContext } from "../../context/Auth/AuthContext";

const packageVersion = require("../../../package.json").version;

const VersionControl = () => {
  const { returnDays } = useDate();
  const { user, socket } = useContext(AuthContext);
  const [storedVersion] = useState(window.localStorage.getItem("version") || "0.0.0");

  const handleUpdateVersion = async () => {
    window.localStorage.setItem("version", packageVersion);

    // Solo conservé la versión actual para guardarla en la base de datos. 
    const { data } = await api.post("/version", {
      version: packageVersion,
    });

    // Borra la caché del navegador. 
    caches.keys().then(function (names) {
      for (let name of names) caches.delete(name);
    });

    // Retrasa el proceso para asegurarte de que se haya borrado la caché.
    setTimeout(() => {
      window.location.reload(true); // Recarga la página.
    }, 1000);
  };

  return (
   <div>
      <Button
       variant="contained"
         size="small"
          style={{
            backgroundColor: "red",
            color: "white",
            fontWeight: "bold",
            right: "15px",
          }}
          onClick={handleUpdateVersion}
        >
          {returnDays(user?.company?.dueDate) === 0 ? `¡Tu licencia vence hoy! Haz clic aquí para actualizar.` : `¡Tu licencia vence en  ${returnDays(user?.company?.dueDate)} días! Haz clic aquí para actualizar.`}
        </Button>
    {/*  {storedVersion !== packageVersion && (
        <Button
       variant="contained"
         size="small"
          style={{
            backgroundColor: "red",
            color: "white",
            fontWeight: "bold",
            right: "15px",
          }}
          onClick={handleUpdateVersion}
        >
          Haga clic aquí para actualizar a la nueva versión.
        </Button>
     )} */}
    </div> 
  );
};

export default VersionControl;
