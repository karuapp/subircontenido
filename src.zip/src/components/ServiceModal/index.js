import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  FormControlLabel,
  Switch
} from "@material-ui/core";
import { toast } from "react-toastify";

import {
  createServico,
  updateServico
} from "../../services/servicosService";

const ServiceModal = ({ open, onClose, service, onSuccess }) => {
  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [valorOriginal, setValorOriginal] = useState("");
  const [possuiDesconto, setPossuiDesconto] = useState(false);
  const [valorComDesconto, setValorComDesconto] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (service) {
      setNome(service.nome || "");
      setDescricao(service.descricao || "");
      setValorOriginal(service.valorOriginal || "");
      setPossuiDesconto(Boolean(service.possuiDesconto));
      setValorComDesconto(service.valorComDesconto || "");
    } else {
      setNome("");
      setDescricao("");
      setValorOriginal("");
      setPossuiDesconto(false);
      setValorComDesconto("");
    }
  }, [service]);

  const handleSubmit = async () => {
    if (!nome.trim()) {
      toast.error("Introduce el nombre del servicio");
      return;
    }

    if (!valorOriginal) {
      toast.error("Introduce el precio original");
      return;
    }

    if (possuiDesconto && !valorComDesconto) {
      toast.error("Introduce el precio con descuento");
      return;
    }

    const payload = {
      nome,
      descricao,
      valorOriginal: parseFloat(valorOriginal),
      possuiDesconto,
      valorComDesconto: possuiDesconto ? parseFloat(valorComDesconto) : null
    };

    setSaving(true);
    try {
      if (service) {
        await updateServico(service.id, payload);
        toast.success("¡Servicio actualizado correctamente!");
      } else {
        await createServico(payload);
        toast.success("¡Servicio creado correctamente!");
      }
      if (onSuccess) {
        onSuccess();
      }
      onClose();
    } catch (err) {
      console.error(err);
      toast.error("Error al guardar el servicio");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>{service ? "Editar servicio" : "Nuevo servicio"}</DialogTitle>
      <DialogContent>
        <TextField
          label="Nombre"
          value={nome}
          onChange={(e) => setNome(e.target.value)}
          fullWidth
          margin="normal"
        />
        <TextField
          label="Descripción"
          value={descricao}
          onChange={(e) => setDescricao(e.target.value)}
          fullWidth
          multiline
          rows={3}
          margin="normal"
        />
        <TextField
          label="Precio original"
          type="number"
          value={valorOriginal}
          onChange={(e) => setValorOriginal(e.target.value)}
          fullWidth
          margin="normal"
        />
        <FormControlLabel
          control={
            <Switch
              checked={possuiDesconto}
              onChange={(e) => setPossuiDesconto(e.target.checked)}
              color="primary"
            />
          }
          label="Precio con descuento"
        />
        {possuiDesconto && (
          <TextField
            label="Precio con descuento"
            type="number"
            value={valorComDesconto}
            onChange={(e) => setValorComDesconto(e.target.value)}
            fullWidth
            margin="normal"
          />
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={saving}>Cancelar</Button>
        <Button color="primary" variant="contained" onClick={handleSubmit} disabled={saving}>
          {service ? "Guardar" : "Registrarse"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ServiceModal;
