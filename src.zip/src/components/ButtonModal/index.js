import React, { useRef, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import MenuItem from "@material-ui/core/MenuItem";
import Select from "@material-ui/core/Select";
import { Grid } from "@material-ui/core";
import api from "../../services/api";
import toastError from "../../errors/toastError";

const useStyles = makeStyles((theme) => ({
  formControl: {
    marginBottom: theme.spacing(2),
    minWidth: 300,
  },
  inputFile: {
    display: 'none',  
  },
  buttonFile: {
    marginBottom: theme.spacing(2),
  },
  dialogTitleWrapper: {
    position: 'relative',
  },
  primaryBar: {
    position: 'absolute',
    top: 0,                
    left: 0,
    right: 0,
    height: '100%',          
    backgroundColor: theme.palette.primary.main,  
    zIndex: 1,              
  },
  dialogTitle: {
    position: 'relative',    
    zIndex: 2,               
    color: 'white',          
  },
}));

const ButtonModal = ({ modalOpen, onClose, ticketId }) => {
  const classes = useStyles();
  const isMounted = useRef(true);
  const [loading, setLoading] = useState(false);
  const [selectedOption, setSelectedOption] = useState("");
  const [inputList, setInputList] = useState([{ option: "" }]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [buttonText, setButtonText] = useState("");
  const [copyText, setCopyText] = useState("");
  const [sendCALL, setSendCall] = useState("");
  const [sendURL, setSendURL] = useState("");
  const [imageBase64, setImageBase64] = useState('');
  const [sendKey, setsendKey] = useState('');
  const [sendkey_type, setsendkey_type] = useState('');
  const [sendvalue, setsendvalue] = useState('');
  const [sendmerchant_name, setsendmerchant_name] = useState('');


  const handleSelectChange = (event) => {
    setSelectedOption(event.target.value);
  };

  const handleAddOption = () => {
    setInputList([...inputList, { option: "" }]);
  };

  const handleRemoveOption = (index) => {
    setInputList((prev) => prev.filter((_, i) => i !== index));
  };

  const handleInputChange = (index, event) => {
    const updatedInputs = [...inputList];
    updatedInputs[index].option = event.target.value;
    setInputList(updatedInputs);
  };

  const handleUploadListMessage = async (title, description, inputList, ticketId) => {
    setLoading(true);

    if (!ticketId || isNaN(ticketId)) {
      console.error('ID de ticket no válido:', ticketId);
      toastError('ID de ticket no válido.');
      setLoading(false);
      return;
    }

    try {
      const sections = [
        {
          title: title || 'Opciones',
          rows: inputList.map((input, index) => ({
            title: input.option,
            rowId: (index + 1).toString(),
          })),
        },
      ];

      const listMessage = {
        title: `${title}\n`,
        text: `${description}\n`,
        buttonText: 'Haga clic aquí',
        sections: sections,
      };
      if (isMounted.current) {
        await api.post(`/messages/lista/${ticketId}`, listMessage);
      }
    } catch (err) {
      toastError(err);
    } finally {
      if (isMounted.current) {
        setLoading(false);
      }
    }
  };

  const handleUploadCopy = async (title, description, buttonText, copyText, imageBase64, ticketId) => {
    setLoading(true);

    if (!ticketId || isNaN(ticketId)) {
      console.error('ID de ticket no válido:', ticketId);
      toastError('ID de ticket no válido.');
      setLoading(false);
      return;
    }

    try {
      const payload = {
        image: imageBase64 ? imageBase64.replace(/^data:image\/[a-zA-Z]+;base64,/, '') : '', // Eliminar prefijo
        title: title,
        description: description,
        buttonText: buttonText,
        copyText: copyText,
      };

      console.log('PAYLOAD:', payload);
      if (isMounted.current) {
        await api.post(`/messages/copy/${ticketId}`, payload); // Enviar mensaje a la API
      }
    } catch (err) {
      toastError(err);
    } finally {
      if (isMounted.current) {
        setLoading(false);
      }
    }
  };

  const handleUploadCALL = async (title, description, buttonText, sendCALL, imageBase64, ticketId) => {
    setLoading(true);

    if (!ticketId || isNaN(ticketId)) {
      console.error('ID de ticket no válido:', ticketId);
      toastError('ID de ticket no válido.');
      setLoading(false);
      return;
    }

    try {
      const payload = {
        image: imageBase64 ? imageBase64.replace(/^data:image\/[a-zA-Z]+;base64,/, '') : '', // Eliminar prefijo
        title: title, // Título del mensaje
        description: description, // Descripción del mensaje
        buttonText: buttonText, // Texto del botón
        copyText: sendCALL,
      };

      if (isMounted.current) {
        await api.post(`/messages/call/${ticketId}`, payload); // Enviar mensaje a la API
      }
    } catch (err) {
      toastError(err);
    } finally {
      if (isMounted.current) {
        setLoading(false);
      }
    }
  };

  const handleUploadURL = async (title, description, buttonText, sendURL, imageBase64, ticketId) => {
    setLoading(true);

    if (!ticketId || isNaN(ticketId)) {
      console.error('ID de ticket no válido:', ticketId);
      toastError('ID de ticket no válido.');
      setLoading(false);
      return;
    }

    try {
      const payload = {
        image: imageBase64 ? imageBase64.replace(/^data:image\/[a-zA-Z]+;base64,/, '') : '', // Eliminar prefijo
        title: title || 'Copiar botón', // Título del mensaje
        description: description || 'Estos botones son geniales', // Descripción del mensaje
        buttonText: buttonText || 'Botón Copiar', // Texto del botón
        copyText: sendURL || 'Texto predeterminado para copiar', // Texto para copiar
      };

      if (isMounted.current) {
        await api.post(`/messages/URL/${ticketId}`, payload); // Enviar el mensaje a la API
      }
    } catch (err) {
      toastError(err);
    } finally {
      if (isMounted.current) {
        setLoading(false);
      }
    }
  };

const handleUploadPIX = async (title, sendvalue, sendkey_type, sendmerchant_name, sendKey, ticketId) => {
  setLoading(true);

  try {
    const payload = {
      title: title,
      sendvalue: sendvalue,
      sendkey_type: sendkey_type, 
      sendmerchant_name: sendmerchant_name,
      sendKey: sendKey,
    };

    if (isMounted.current) {
      await api.post(`/messages/PIX/${ticketId}`, payload); 
    }
  } catch (err) {
    toastError(err);
  } finally {
    if (isMounted.current) {
      setLoading(false);
    }
  }
};




  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageBase64(reader.result);
        //  console.log('Image Base64:', reader.result); // Log the Base64 string
      };
      reader.readAsDataURL(file);
    }
  };


  const createMessage = async () => {
    console.log('createMessage llamada');

    try {
      if (selectedOption === "Lista") {
        await handleUploadListMessage(title, description, inputList, ticketId);
      } else if (selectedOption === "Copia") {
        await handleUploadCopy(title, description, buttonText, copyText, imageBase64, ticketId);
      } else if (selectedOption === "Llámame") {
        await handleUploadCALL(title, description, buttonText, sendCALL, imageBase64, ticketId);
      } else if (selectedOption === "URL") {
        await handleUploadURL(title, description, buttonText, sendURL, imageBase64, ticketId);
      } else if (selectedOption === "PIX") {
        await handleUploadPIX(title, sendvalue, sendkey_type, sendmerchant_name, sendKey, ticketId);
      } else {
        let listMessage = null;
        switch (selectedOption) {
          default:
            console.error('Opción no seleccionada o mensaje no generado.');
            return;
        }
      }

      // Cierra el modal después de procesar el mensaje
      onClose();

    } catch (error) {
      toastError('Error al procesar el mensaje');
    }
  };



  const renderContent = () => {
    switch (selectedOption) {

      case "Lista":
        return (
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Título"
                variant="outlined"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Descripción"
                variant="outlined"
                multiline
                rows={5}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              {inputList.map((input, index) => (
                <Grid container key={index} spacing={1} alignItems="center">
                  <Grid item xs={10}>
                    <TextField
                      fullWidth
                      label={`Opción ${index + 1}`}
                      value={input.option}
                      onChange={(e) => handleInputChange(index, e)}
                      variant="outlined"
                      style={{ marginBottom: "8px" }}
                    />
                  </Grid>
                  <Grid item xs={2}>
                    <Button
                      variant="contained"
                      color="secondary"
                      onClick={() => handleRemoveOption(index)}
                    >
                      X
                    </Button>
                  </Grid>
                </Grid>
              ))}
              <Button onClick={handleAddOption} color="primary">
                Añadir nueva opción
              </Button>
            </Grid>
          </Grid>
        );
      case "URL":
        return (
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <input
                accept="image/*"
                className={classes.inputFile} // Asegúrese de que esta clase esté definida
                id="input-file" // Un ID único
                type="file"
                onChange={handleImageChange}
              />
              <label htmlFor="input-file">
                <Button
                  variant="contained"
                  color="primary"
                  component="span"
                  className={classes.buttonFile} // Asegúrese de que esta clase esté definida
                >
                  Imagen
                </Button>
              </label>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Título"
                variant="outlined"
                value={title}
                onChange={(e) => setTitle(e.target.value)}  // Campo para el título
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Mensaje"
                variant="outlined"
                multiline
                rows={5}
                value={description}
                onChange={(e) => setDescription(e.target.value)}  // Campo para el mensaje
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Texto del botón"
                variant="outlined"
                value={buttonText}
                onChange={(e) => setButtonText(e.target.value)}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="URL"
                variant="outlined"
                value={sendURL}
                onChange={(e) => setSendURL(e.target.value)}
              />
            </Grid>
          </Grid>
        );
      case "Copia":
        return (
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <input
                accept="image/*"
                className={classes.inputFile} // Asegúrese de que esta clase esté definida
                id="input-file" // Un ID único
                type="file"
                onChange={handleImageChange}
              />
              <label htmlFor="input-file"> {/* La etiqueta debe hacer referencia al ID correcto */}
                <Button
                  variant="contained"
                  color="primary"
                  component="span"
                  className={classes.buttonFile} // Asegúrese de que esta clase esté definida
                >
                  Imagen
                </Button>
              </label>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Título"
                variant="outlined"
                value={title}
                onChange={(e) => setTitle(e.target.value)}  // Campo para el título
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Mensaje"
                variant="outlined"
                multiline
                rows={5}
                value={description}
                onChange={(e) => setDescription(e.target.value)}  // Campo para el mensaje
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Texto del botón"
                variant="outlined"
                value={buttonText}
                onChange={(e) => setButtonText(e.target.value)}  // Campo para el texto del botón
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Texto para copiar"
                variant="outlined"
                multiline
                rows={4}
                value={copyText}
                onChange={(e) => setCopyText(e.target.value)}  // Campo para el texto para copiar
              />
            </Grid>
          </Grid>
        );
      case "Llámame":
        return (
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <input
                accept="image/*"
                className={classes.inputFile}
                id="input-file"
                type="file"
                onChange={handleImageChange}
              />
              <label htmlFor="input-file">
                <Button
                  variant="contained"
                  color="primary"
                  component="span"
                  className={classes.buttonFile}
                >
                  Imagen
                </Button>
              </label>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Título"
                variant="outlined"
                value={title}
                onChange={(e) => setTitle(e.target.value)} // Campo para el título
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Mensaje"
                variant="outlined"
                multiline
                rows={5}
                value={description}
                onChange={(e) => setDescription(e.target.value)} // Campo para el mensaje
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Texto del botón"
                variant="outlined"
                value={buttonText}
                onChange={(e) => setButtonText(e.target.value)} // Campo para el texto del botón
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Número de teléfono"
                variant="outlined"
                defaultValue="5511999999999"
                value={sendCALL}
                onChange={(e) => setSendCall(e.target.value)} // Campo para el número de teléfono
              />
            </Grid>
          </Grid>
        );
      case "PIX":
        return (
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Título"
                variant="outlined"
                value={title}
                onChange={(e) => setTitle(e.target.value)} //Campo para el título
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Valor"
                variant="outlined"
                value={sendvalue}
                onChange={(e) => setsendvalue(e.target.value)} // Ajuste del valor
              />
            </Grid>
            <Grid item xs={12}>
              <Select
                fullWidth
                className={classes.formControl}
                value={sendkey_type}
                onChange={(e) => setsendkey_type(e.target.value)} // Actualización del estado sendkey_type
                displayEmpty
              >
                <MenuItem value="" disabled>
                  Tipo de clave
                </MenuItem>
                <MenuItem value="CNPJ">CNPJ</MenuItem>
                <MenuItem value="CPF">CPF</MenuItem>
                <MenuItem value="PHONE">Número de teléfono</MenuItem>
                <MenuItem value="EMAIL">E-mail</MenuItem>
                <MenuItem value="EVP">Clave aleatoria</MenuItem>
              </Select>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Nombre"
                variant="outlined"
                value={sendmerchant_name}
                onChange={(e) => setsendmerchant_name(e.target.value)} // Campo para o nome
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Clave PIX"
                variant="outlined"
                value={sendKey}
                onChange={(e) => setsendKey(e.target.value)} // Campo para la clave PIX
              />
            </Grid>
          </Grid>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog open={modalOpen} onClose={onClose} maxWidth="sm" fullWidth>

      {/* Contenedor que contiene el título y la barra */}
      <div className={classes.dialogTitleWrapper}>
        {/* BBarra de color detrás del título */}
        <div className={classes.primaryBar}></div>

        {/* Título con posicionamiento relativo */}
        <DialogTitle className={classes.dialogTitle}>
          Seleccionar una opción
        </DialogTitle>
      </div>

      <DialogContent>
        <Select
          fullWidth
          className={classes.formControl}
          value={selectedOption}
          onChange={handleSelectChange}
          displayEmpty
        >
          <MenuItem value="" disabled>
            Selecione
          </MenuItem>
          <MenuItem value="Lista">Lista</MenuItem>
          <MenuItem value="URL">URL</MenuItem>
          <MenuItem value="Copia">Copiar</MenuItem>
          <MenuItem value="Me Ligue">Llámame</MenuItem>
          <MenuItem value="PIX">PIX</MenuItem>
        </Select>

        {/* Representa el contenido según la opción seleccionada */}
        {renderContent()}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} color="secondary">
          Cancelar
        </Button>
        <Button color="primary" onClick={() => createMessage()}>
          Confirmar
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ButtonModal;
