import React, { useEffect, useMemo, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Grid,
  Typography,
  Divider,
  Switch,
  FormControlLabel,
  Paper,
  MenuItem,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";
import MessageVariablesPicker from "../MessageVariablesPicker";

const useStyles = makeStyles((theme) => ({
  section: {
    padding: theme.spacing(2),
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    backgroundColor: "#fff",
    marginBottom: theme.spacing(2),
  },
  sectionTitle: {
    fontWeight: 600,
    fontSize: "0.9rem",
    marginBottom: theme.spacing(1.5),
    color: "#111827",
  },
  helperText: {
    fontSize: "0.75rem",
    color: "#6b7280",
  },
  actions: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    flexWrap: "wrap",
    gap: theme.spacing(2),
  },
}));

const defaultData = {
  connection: {
    connectionName: "",
    fromEmail: "",
    host: "",
    port: "587",
    username: "",
    password: "",
    useTLS: true,
  },
  message: {
    to: "",
    replyTo: "",
    cc: "",
    bcc: "",
    subject: "",
    customContent: false,
    contentMode: "html",
    content: "",
    attachmentsVariable: "",
  },
};

const FlowBuilderAddSmtpModal = ({ open, onSave, data, onUpdate, close }) => {
  const classes = useStyles();
  const [activeModal, setActiveModal] = useState(false);
  const [labels, setLabels] = useState({ title: "", btn: "" });
  const [formData, setFormData] = useState(defaultData);
  const [focusedField, setFocusedField] = useState("message.content");

  const mergedData = useMemo(() => {
    if (!data?.data) return defaultData;
    
    console.log("SMTP Modal - Data recebida:", data);
    console.log("SMTP Modal - data.data:", data.data);
    console.log("SMTP Modal - smtpConfig:", data.data?.smtpConfig);
    console.log("SMTP Modal - emailConfig:", data.data?.emailConfig);
    
    // Tentar diferentes caminhos onde os dados podem estar
    const smtpConfig = data.data?.smtpConfig || data.smtpConfig || {};
    const emailConfig = data.data?.emailConfig || data.emailConfig || {};
    
    console.log("SMTP Modal - smtpConfig final:", smtpConfig);
    console.log("SMTP Modal - emailConfig final:", emailConfig);
    
    return {
      connection: { ...defaultData.connection, ...smtpConfig },
      message: { ...defaultData.message, ...emailConfig },
    };
  }, [data]);

  useEffect(() => {
    if (open === "edit") {
      setLabels({ title: "Editar envio SMTP", btn: "Guardar" });
      setFormData(mergedData);
      setActiveModal(true);
    } else if (open === "create") {
      setLabels({ title: "Añadir envio SMTP", btn: "Añadir" });
      setFormData(defaultData);
      setActiveModal(true);
    } else {
      setActiveModal(false);
    }
  }, [open, mergedData]);

  const handleClose = () => {
    close(null);
    setActiveModal(false);
  };

  const handleChange = (section, field) => (event) => {
    const value =
      event.target.type === "checkbox" ? event.target.checked : event.target.value;
    setFormData((prev) => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value,
      },
    }));
  };

  const handleInsertVariable = (variable) => {
    if (!focusedField) return;
    const [section, field] = focusedField.split(".");
    if (!section || !field) return;
    setFormData((prev) => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: `${prev[section][field] || ""}${variable}`,
      },
    }));
  };

  const handleSave = () => {
    const payload = {
      smtpConfig: formData.connection,
      emailConfig: formData.message,
    };

    if (open === "edit" && typeof onUpdate === "function") {
      onUpdate({
        ...data,
        data: {
          ...data.data,
          ...payload,
        },
      });
    } else if (open === "create" && typeof onSave === "function") {
      onSave(payload);
    }
    handleClose();
  };

  const textFieldProps = (section, field, extra = {}) => ({
    fullWidth: true,
    variant: "outlined",
    margin: "dense",
    value: formData[section][field],
    onChange: handleChange(section, field),
    onFocus: () => setFocusedField(`${section}.${field}`),
    ...extra,
  });

  return (
    <Dialog open={activeModal} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle>{labels.title}</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <Paper className={classes.section} elevation={0}>
              <Typography className={classes.sectionTitle}>
                Conexión SMTP
              </Typography>
              <TextField
                label="Nombre de la conexión"
                placeholder="Finanzas - Gmail"
                {...textFieldProps("connection", "connectionName")}
              />
              <TextField
                label="Remitente (from)"
                placeholder="contacto@empresa.com"
                {...textFieldProps("connection", "fromEmail")}
              />
              <TextField
                label="Host SMTP"
                placeholder="smtp.gmail.com"
                {...textFieldProps("connection", "host")}
              />
              <TextField
                label="Puerto"
                placeholder="587"
                {...textFieldProps("connection", "port")}
              />
              <TextField
                label="Nombre de usuario"
                placeholder="contato@empresa.com"
                {...textFieldProps("connection", "username")}
              />
              <TextField
                label="Contraseña"
                type="password"
                {...textFieldProps("connection", "password")}
              />
              <FormControlLabel
                control={
                  <Switch
                    color="primary"
                    checked={formData.connection.useTLS}
                    onChange={handleChange("connection", "useTLS")}
                  />
                }
                label="Usar TLS/SSL"
              />
              <Typography className={classes.helperText}>
                Los datos anteriores solo se almacenarán en este flujo.
              </Typography>
            </Paper>
          </Grid>

          <Grid item xs={12} md={6}>
            <Paper className={classes.section} elevation={0}>
              <Typography className={classes.sectionTitle}>
                Destinatarios
              </Typography>
              <TextField
                label="Para (To)"
                placeholder="email@cliente.com, {{email}}"
                {...textFieldProps("message", "to")}
              />
              <TextField
                label="Respuesta a (Reply-To)"
                placeholder="soporte@empresa.com"
                {...textFieldProps("message", "replyTo")}
              />
              <TextField
                label="Cc"
                placeholder="directiva@empresa.com"
                {...textFieldProps("message", "cc")}
              />
              <TextField
                label="Bcc"
                placeholder="auditoria@empresa.com"
                {...textFieldProps("message", "bcc")}
              />
              <Typography className={classes.helperText}>
                Separe los correos electrónicos con comas. Puede usar variables de 
                flujo (ex: {"{{email}}"}).
              </Typography>
            </Paper>

            <Paper className={classes.section} elevation={0}>
              <Typography className={classes.sectionTitle}>
                Contenido
              </Typography>
              <TextField
                label="Asunto"
                placeholder="Su solicitud {{pedido}} Fue aprobado."
                {...textFieldProps("message", "subject")}
              />
              <FormControlLabel
                control={
                  <Switch
                    color="primary"
                    checked={formData.message.customContent}
                    onChange={handleChange("message", "customContent")}
                  />
                }
                label="Contenido personalizado."
              />
              <TextField
                label="Modo do conteúdo"
                select
                {...textFieldProps("message", "contentMode")}
              >
                <MenuItem value="text">Texto (text/plain)</MenuItem>
                <MenuItem value="html">HTML (text/html)</MenuItem>
              </TextField>
              <TextField
                label="Cuerpo del correo electrónico"
                multiline
                rows={6}
                placeholder="<h1>Hola {{name}}</h1><p><strong>Tu pedido {{pedido}} ¡Fue Aprobado!</strong></p><br><p>Acceso: <a href='https://sistema.com'>Panel</a></p>"
                {...textFieldProps("message", "content")}
              />
              <Typography className={classes.helperText}>
                {formData.message.contentMode === "html" 
                  ? "Usar etiquetas HTML: &lt;b&gt;negrito&lt;/b&gt;, &lt;br&gt; quebra linha, &lt;h1&gt;título&lt;/h&gt;, etc."
                  : "Modo texto: sin formato HTML."
                }
              </Typography>
              <TextField
                label="Variable con archivos adjuntos"
                placeholder="{{anexos}}"
                {...textFieldProps("message", "attachmentsVariable")}
              />
            </Paper>
          </Grid>
        </Grid>

        <Divider style={{ margin: "16px 0" }} />

        <MessageVariablesPicker onClick={handleInsertVariable} />
      </DialogContent>
      <DialogActions className={classes.actions}>
        <Typography className={classes.helperText}>
          Toda la información se guarda dentro de este flujo.
        </Typography>
        <div>
          <Button
            onClick={handleClose}
            startIcon={<CancelIcon />}
            style={{ marginRight: 8 }}
          >
            Cancelar
          </Button>
          <Button
            color="primary"
            variant="contained"
            startIcon={<SaveIcon />}
            onClick={handleSave}
          >
            {labels.btn}
          </Button>
        </div>
      </DialogActions>
    </Dialog>
  );
};

export default FlowBuilderAddSmtpModal;
