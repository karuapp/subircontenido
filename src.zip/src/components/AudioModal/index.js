 import React, { useRef, useEffect, useState } from "react";
import { IconButton, Slider, Avatar } from "@material-ui/core";
import { PlayArrow, Pause, Speed, VolumeUp, VolumeOff } from "@material-ui/icons";
import styled, { keyframes } from "styled-components";

const LS_NAME = 'audioMessageRate';

// CContenedor principal del reproductor: diseño horizontal similar al de WhatsApp
const PlayerContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  background: transparent;
  padding: 0;
  width: 100%;
  max-width: 300px;
`;

// Avatar de usuario
const UserAvatar = styled(Avatar)`
  width: 32px;
  height: 32px;
`;

// Botón de reproducción/pausa estilizado
const PlayPauseButton = styled(IconButton)`
  background-color: transparent;
  padding: 4px;
  color: #00a884;

  &:hover {
    background-color: rgba(0, 168, 132, 0.1);
  }

  .MuiSvgIcon-root {
    font-size: 28px;
  }
`;

// Contenedor de barra de progreso y tiempo
const ProgressContainer = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
`;

// Barra de progreso estilizada
const ProgressBar = styled(Slider)`
  color: #00a884;
  padding: 0 !important;
  height: 4px;

  .MuiSlider-thumb {
    width: 10px;
    height: 10px;
    background-color: #00a884;
    display: none;
  }

  .MuiSlider-track {
    background-color: #00a884;
    height: 4px;
    border-radius: 2px;
  }

  .MuiSlider-rail {
    background-color: rgba(0, 168, 132, 0.2);
    height: 4px;
    border-radius: 2px;
  }

  &:hover .MuiSlider-thumb {
    display: block;
  }
`;

// Visualización de la hora
const TimeDisplay = styled.div`
  font-size: 11px;
  color: #667781;
  font-weight: 400;
  text-align: right;
`;

// Función para formatear la hora en mm:ss
const formatTime = (time) => {
  const minutes = Math.floor(time / 60);
  const seconds = Math.floor(time % 60);
  return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
};

const AudioModal = ({ url, avatarUrl, userName }) => {
    const audioRef = useRef(null);
    const [audioRate, setAudioRate] = useState(parseFloat(localStorage.getItem(LS_NAME) || "1"));
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [volume, setVolume] = useState(1);
    const [isMuted, setIsMuted] = useState(false);
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;

    // Actualiza la velocidad de reproducción en el almacenamiento local
    useEffect(() => {
        audioRef.current.playbackRate = audioRate;
        localStorage.setItem(LS_NAME, audioRate);
    }, [audioRate]);

    // Actualiza la hora actual y la duración del audio
    useEffect(() => {
        const audio = audioRef.current;

        const updateTime = () => setCurrentTime(audio.currentTime);
        const updateDuration = () => setDuration(audio.duration);
        const handlePlay = () => setIsPlaying(true);
        const handlePause = () => setIsPlaying(false);
        const handleEnded = () => setIsPlaying(false);

        audio.addEventListener('timeupdate', updateTime);
        audio.addEventListener('loadedmetadata', updateDuration);
        audio.addEventListener('play', handlePlay);
        audio.addEventListener('pause', handlePause);
        audio.addEventListener('ended', handleEnded);

        return () => {
            audio.removeEventListener('timeupdate', updateTime);
            audio.removeEventListener('loadedmetadata', updateDuration);
            audio.removeEventListener('play', handlePlay);
            audio.removeEventListener('pause', handlePause);
            audio.removeEventListener('ended', handleEnded);
        };
    }, []);

    // Alternar entre reproducción y pausa
    const togglePlayPause = () => {
        if (isPlaying) {
            audioRef.current.pause();
        } else {
            audioRef.current.play();
        }
    };

    // Alternar velocidad de reproducción
    const toggleRate = () => {
        const rates = [0.5, 1, 1.5, 2];
        const currentIndex = rates.indexOf(audioRate);
        const newRate = rates[(currentIndex + 1) % rates.length];
        setAudioRate(newRate);
    };

    // Actualizar volumen
    const handleVolumeChange = (event, newValue) => {
        setVolume(newValue);
        audioRef.current.volume = newValue;
        setIsMuted(newValue === 0);
    };

    // Alternar entre silenciar y activar
    const toggleMute = () => {
        if (isMuted) {
            audioRef.current.volume = volume;
        } else {
            audioRef.current.volume = 0;
        }
        setIsMuted(!isMuted);
    };

    // Actualizar la duración del audio arrastrando la barra de progreso
    const handleSeek = (event, newValue) => {
        audioRef.current.currentTime = newValue;
        setCurrentTime(newValue);
    };

    // Obtener la fuente de audio (compatible con iOS)
    const getAudioSource = () => {
        let sourceUrl = url;

        if (isIOS) {
            sourceUrl = sourceUrl.replace(".ogg", ".mp3");
        }

        return (
            <source src={sourceUrl} type={isIOS ? "audio/mp3" : "audio/ogg"} />
        );
    };

    return (
        <PlayerContainer>
            <UserAvatar src={avatarUrl} alt={userName}>
                {!avatarUrl && userName?.charAt(0).toUpperCase()}
            </UserAvatar>
            <PlayPauseButton onClick={togglePlayPause}>
                {isPlaying ? <Pause /> : <PlayArrow />}
            </PlayPauseButton>
            <ProgressContainer>
                <ProgressBar
                    value={currentTime}
                    max={duration}
                    onChange={handleSeek}
                    aria-labelledby="audio-seek-slider"
                />
                <TimeDisplay>
                    {formatTime(currentTime)} / {formatTime(duration)}
                </TimeDisplay>
            </ProgressContainer>
            <audio ref={audioRef} style={{ display: "none" }}>
                {getAudioSource()}
            </audio>
        </PlayerContainer>
    );
};

export default AudioModal;