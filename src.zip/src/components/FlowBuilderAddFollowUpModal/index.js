import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  Button,
  DialogActions,
  TextField,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  Typography,
  Box,
  Chip,
  IconButton,
} from "@material-ui/core";
import { Close as CloseIcon } from "@material-ui/icons";
import { makeStyles } from "@material-ui/core/styles";
import { toast } from "react-toastify";
import api from "../../services/api";
import toastError from "../../errors/toastError";

const useStyles = makeStyles((theme) => ({
  dialogContent: {
    padding: theme.spacing(3),
    minWidth: "500px",
  },
  formControl: {
    marginTop: theme.spacing(2),
    minWidth: "100%",
  },
  chipContainer: {
    display: "flex",
    flexWrap: "wrap",
    gap: theme.spacing(1),
    marginTop: theme.spacing(1),
  },
  chipInput: {
    marginTop: theme.spacing(1),
  },
  previewBox: {
    backgroundColor: "#f3f4f6",
    padding: theme.spacing(2),
    borderRadius: theme.spacing(1),
    marginTop: theme.spacing(2),
  },
}));

const ACTION_TYPES = [
  { value: "sendMessageFlow", label: "Enviar mensaje" },
  { value: "addTag", label: "Añadir etiqueta(s)" },
  { value: "addTagKanban", label: "Añadir etiqueta Kanban" },
  { value: "transferQueue", label: "Transferir a departamento" },
  { value: "closeTicket", label: "Cerrar ticket" },
  { value: "transferFlow", label: "Transferir a otro flujo" },
  { value: "sendMessageFlowWithMenu", label: "Enviar mensaje con menú" },
];

const FlowBuilderAddFollowUpModal = ({ open, onClose, onSave, initialData }) => {
  const classes = useStyles();
  const [delayMinutes, setDelayMinutes] = useState(initialData?.delayMinutes || 15);
  const [actionType, setActionType] = useState(initialData?.action?.type || "sendMessageFlow");
  const [messageText, setMessageText] = useState(initialData?.action?.payload?.text || "");
  const [tags, setTags] = useState(initialData?.action?.payload?.tags || []);
  const [tagInput, setTagInput] = useState("");
  const [kanbanTags, setKanbanTags] = useState(initialData?.action?.payload?.kanbanTags || []);
  const [selectedKanbanTag, setSelectedKanbanTag] = useState(initialData?.action?.payload?.kanbanTagId || "");
  const [queueId, setQueueId] = useState(initialData?.action?.payload?.queueId || "");
  const [flowId, setFlowId] = useState(initialData?.action?.payload?.flowId || "");
  const [flows, setFlows] = useState([]);
  const [allTags, setAllTags] = useState([]);
  const [kanbanTagList, setKanbanTagList] = useState([]);
  const [queues, setQueues] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Buscar flows
        const { data: flowsData } = await api.get("/flowbuilder");
        setFlows(flowsData.flows || []);

        // Buscar tags normais (kanban: 0)
        const { data: normalTagsData } = await api.get("/tags/list", { params: { kanban: 0 } });
        setAllTags(normalTagsData || []);

        // Buscar tags kanban (kanban: 1)
        const { data: kanbanTagsData } = await api.get("/tags/list", { params: { kanban: 1 } });
        setKanbanTagList(kanbanTagsData || []);

        // Buscar filas
        const { data: queuesData } = await api.get("/queue");
        setQueues(queuesData || []);
      } catch (err) {
        toastError(err);
      }
    };
    fetchData();
  }, []);

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleDeleteTag = (tagToDelete) => {
    setTags(tags.filter((tag) => tag !== tagToDelete));
  };

  const handleSave = () => {
    const payload = {};
    switch (actionType) {
      case "sendMessageFlow":
      case "sendMessageFlowWithMenu":
        if (!messageText.trim()) {
          toast.error("Escribe el texto del mensaje");
          return;
        }
        payload.text = messageText.trim();
        break;
      case "addTag":
        if (tags.length === 0) {
          toast.error("Agrega al menos una etiqueta");
          return;
        }
        payload.tags = tags;
        break;
      case "addTagKanban":
        if (!selectedKanbanTag) {
          toast.error("Selecciona una etiqueta Kanban");
          return;
        }
        payload.kanbanTagId = selectedKanbanTag;
        break;
      case "transferQueue":
        if (!queueId) {
          toast.error("Selecciona un departamento");
          return;
        }
        payload.queueId = queueId;
        break;
      case "closeTicket":
        // sem payload adicional
        break;
      case "transferFlow":
        if (!flowId) {
          toast.error("Selecciona un flujo");
          return;
        }
        payload.flowId = flowId;
        break;
      default:
        break;
    }

    onSave({
      delayMinutes,
      action: {
        type: actionType,
        payload,
      },
    });
    onClose();
  };

  const renderActionFields = () => {
    switch (actionType) {
      case "sendMessageFlow":
      case "sendMessageFlowWithMenu":
        return (
          <TextField
            fullWidth
            multiline
            rows={4}
            label="Texto del mensaje"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            variant="outlined"
            className={classes.formControl}
          />
        );
      case "addTag":
        return (
          <Box className={classes.formControl}>
            <FormControl fullWidth variant="outlined">
              <InputLabel>Etiquetas disponibles</InputLabel>
              <Select
                multiple
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                label="Etiquetas disponibles"
                renderValue={(selected) => (
                  <div className={classes.chipContainer}>
                    {selected.map((value) => {
                      const tag = allTags.find(t => t.id === value);
                      return (
                        <Chip
                          key={value}
                          label={tag?.name || value}
                          style={{ backgroundColor: tag?.color || '#999', color: 'white' }}
                          size="small"
                        />
                      );
                    })}
                  </div>
                )}
              >
                {allTags.map((tag) => (
                  <MenuItem key={tag.id} value={tag.id}>
                    <Box display="flex" alignItems="center">
                      <Box
                        width={12}
                        height={12}
                        borderRadius="50%"
                        backgroundColor={tag.color || '#999'}
                        marginRight={1}
                      />
                      {tag.name}
                    </Box>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>
        );
      case "addTagKanban":
        return (
          <FormControl fullWidth variant="outlined" className={classes.formControl}>
            <InputLabel>Etiqueta Kanban</InputLabel>
            <Select value={selectedKanbanTag} onChange={(e) => setSelectedKanbanTag(e.target.value)} label="Etiqueta Kanban">
              <MenuItem value="">Seleccionar...</MenuItem>
              {kanbanTagList.map((tag) => (
                <MenuItem key={tag.id} value={tag.id}>
                  <Box display="flex" alignItems="center">
                    <Box
                      width={12}
                      height={12}
                      borderRadius="50%"
                      backgroundColor={tag.color || '#06b6d4'}
                      marginRight={1}
                    />
                    {tag.name}
                  </Box>
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        );
      case "transferQueue":
        return (
          <FormControl fullWidth variant="outlined" className={classes.formControl}>
            <InputLabel>Departamento de destino</InputLabel>
            <Select value={queueId} onChange={(e) => setQueueId(e.target.value)} label="Departamento de destino">
              <MenuItem value="">Seleccionar...</MenuItem>
              {queues.map((queue) => (
                <MenuItem key={queue.id} value={queue.id}>
                  <Box display="flex" alignItems="center">
                    <Box
                      width={12}
                      height={12}
                      borderRadius="50%"
                      backgroundColor={queue.color || '#999'}
                      marginRight={1}
                    />
                    {queue.name}
                  </Box>
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        );
      case "transferFlow":
        return (
          <FormControl fullWidth variant="outlined" className={classes.formControl}>
            <InputLabel>Flujo de destino</InputLabel>
            <Select value={flowId} onChange={(e) => setFlowId(e.target.value)} label="Flujo de destino">
              <MenuItem value="">Seleccionar...</MenuItem>
              {flows.map((flow) => (
                <MenuItem key={flow.id} value={flow.id}>
                  {flow.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        );
      case "closeTicket":
        return (
          <Typography variant="body2" color="textSecondary" className={classes.formControl}>
            Esta acción cerrará automáticamente el ticket después del retraso.
          </Typography>
        );
      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        {initialData ? "Editar Follow-up" : "Configurar Follow-up"}
        <IconButton
          aria-label="close"
          onClick={onClose}
          style={{ position: "absolute", right: 8, top: 8 }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent className={classes.dialogContent}>
        <TextField
          fullWidth
          label="Retraso (minutos)"
          type="number"
          value={delayMinutes}
          onChange={(e) => setDelayMinutes(Number(e.target.value))}
          variant="outlined"
          className={classes.formControl}
        />

        <FormControl fullWidth variant="outlined" className={classes.formControl}>
          <InputLabel>Tipo de acción</InputLabel>
          <Select value={actionType} onChange={(e) => setActionType(e.target.value)} label="Tipo de acción">
            {ACTION_TYPES.map((type) => (
              <MenuItem key={type.value} value={type.value}>
                {type.label}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        {renderActionFields()}

        <Box className={classes.previewBox}>
          <Typography variant="subtitle2">Vista previa</Typography>
          <Typography variant="body2">
            Después <strong>{delayMinutes} min</strong>, Se ejecutará: <strong>{ACTION_TYPES.find(t => t.value === actionType)?.label}</strong>
            {actionType === "sendMessageFlow" && messageText && (
              <><br />Mensaje: "{messageText}"</>
            )}
            {actionType === "addTag" && tags.length > 0 && (
              <><br />Etiquetas: {tags.join(", ")}</>
            )}
            {actionType === "transferFlow" && flowId && (
              <><br />Flujo: {flows.find(f => f.id === flowId)?.name}</>
            )}
          </Typography>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancelar</Button>
        <Button onClick={handleSave} color="primary" variant="contained">
          {initialData ? "Guardar edición" : "Guardar"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default FlowBuilderAddFollowUpModal;
