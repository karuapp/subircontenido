export default {
  formId: 'checkoutForm',
  formField: {
    firstName: {
      name: 'firstName',
      label: 'Nombre completo*',
      requiredErrorMsg: 'Nombre completo obligatorio'
    },
    lastName: {
      name: 'lastName',
      label: 'Apellido*',
      requiredErrorMsg: 'Apellido obligatorio'
    },
    address1: {
      name: 'address2',
      label: 'Dirección*',
      requiredErrorMsg: 'Dirección obligatoria'
    },

    city: {
      name: 'city',
      label: 'Ciudad*',
      requiredErrorMsg: 'Ciudad obligatoria'
    },
    state: {
      name: 'state',
      label: 'Estado*',
      requiredErrorMsg: 'Ciudad obligatoria'
    },
    zipcode: {
      name: 'zipcode',
      label: 'CPF/CNPJ*',
      requiredErrorMsg: 'Código postal obligatorio',
      invalidErrorMsg: 'Formato de código postal no válido'
    },
    country: {
      name: 'country',
      label: 'País*',
      requiredErrorMsg: 'País obligatorio'
    },
    useAddressForPaymentDetails: {
      name: 'useAddressForPaymentDetails',
      label: 'Utilice esta dirección para los detalles del pago'
    },
    nameOnCard: {
      name: 'nameOnCard',
      label: 'Nombre en la tarjeta*',
      requiredErrorMsg: 'Nombre en la tarjeta obligatorio'
    },
    cardNumber: {
      name: 'cardNumber',
      label: 'Número de tarjeta*',
      requiredErrorMsg: 'Número de tarjeta obligatorio',
      invalidErrorMsg: 'Número de tarjeta inválido (p. ej., 411111111111)'
    },
    expiryDate: {
      name: 'expiryDate',
      label: 'Fecha de caducidad',
      requiredErrorMsg: 'La fecha de caducidad es obligatoria',
      invalidErrorMsg: 'La fecha de caducidad no es válida'
    },
    cvv: {
      name: 'cvv',
      label: 'CVV*',
      requiredErrorMsg: 'Se requiere CVV',
      invalidErrorMsg: 'El CVV no es válido (p. ej., 357)'
    }
  }
};
