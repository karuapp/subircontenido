import React from 'react';
import { Typography, Grid, Card, CardContent, Button } from '@material-ui/core';
import moment from 'moment';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';

export default function ReviewOrder({ invoice, onPay }) {
  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Detalhes da Fatura
      </Typography>
      
      <Card style={{ marginBottom: 16 }}>
        <CardContent>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2" color="textSecondary">
                Descripción
              </Typography>
              <Typography variant="body1">
                {invoice?.detail || 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2" color="textSecondary">
                Valor
              </Typography>
              <Typography variant="h6" color="primary">
                {invoice?.value ? invoice.value.toLocaleString('es', { style: 'currency', currency: 'USD' }) : 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2" color="textSecondary">
                Fecha de vencimiento
              </Typography>
              <Typography variant="body1">
                {invoice?.dueDate ? moment(invoice.dueDate).format('DD/MM/YYYY') : 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2" color="textSecondary">
                Estado
              </Typography>
              <Typography variant="body1" style={{ 
                color: invoice?.status === 'paid' ? 'green' : 'orange',
                fontWeight: 'bold'
              }}>
                {invoice?.status === 'paid' ? 'Pagado' : 'Abierto'}
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      <Card style={{ marginBottom: 16 }}>
        <CardContent>
          <Typography variant="subtitle1" gutterBottom>
            Información del pago
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Al hacer clic en "PAGAR" serás redirigido a la pasarela de pago. 
            para completar la transacción de forma segura.
          </Typography>
        </CardContent>
      </Card>

      <Grid container justify="flex-end">
        <Button
          variant="contained"
          color="primary"
          size="large"
          startIcon={<AttachMoneyIcon />}
          onClick={onPay}
          disabled={invoice?.status === 'paid'}
        >
          {invoice?.status === 'paid' ? 'YA PAGADO' : 'PAGAR'}
        </Button>
      </Grid>
    </React.Fragment>
  );
}
