import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Grid,
  Typography,
  Divider,
  Switch,
  FormControlLabel,
  Paper,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
  IconButton,
  Box,
  Chip,
  CircularProgress,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Cancel";
import AddIcon from "@mui/icons-material/Add";
import DeleteIcon from "@mui/icons-material/Delete";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorIcon from "@mui/icons-material/Error";
import MessageVariablesPicker from "../MessageVariablesPicker";
import { toast } from "react-toastify";
import api from "../../services/api";
import useAuth from "../../hooks/useAuth.js";

const useStyles = makeStyles((theme) => ({
  section: {
    padding: theme.spacing(2),
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    backgroundColor: "#fff",
    marginBottom: theme.spacing(2),
  },
  sectionTitle: {
    fontWeight: 600,
    fontSize: "0.9rem",
    marginBottom: theme.spacing(1.5),
    color: "#111827",
  },
  helperText: {
    fontSize: "0.75rem",
    color: "#6b7280",
  },
  actions: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    flexWrap: "wrap",
    gap: theme.spacing(2),
  },
  keyValueRow: {
    display: "flex",
    gap: theme.spacing(1),
    alignItems: "center",
    marginBottom: theme.spacing(1),
  },
  keyField: {
    flex: 1,
  },
  valueField: {
    flex: 2,
  },
  testButton: {
    marginTop: theme.spacing(1),
    height: "40px",
  },
  testResult: {
    marginTop: theme.spacing(1),
  },
  authSection: {
    padding: theme.spacing(2),
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    backgroundColor: "#f8fafc",
    marginBottom: theme.spacing(2),
  },
  alertPaper: {
    padding: theme.spacing(2),
    borderRadius: 8,
    marginBottom: theme.spacing(2),
    display: 'flex',
    alignItems: 'center',
    gap: theme.spacing(1),
  },
  alertSuccess: {
    backgroundColor: '#f0f9ff',
    border: '1px solid #bae6fd',
    color: '#0c4a6e',
  },
  alertWarning: {
    backgroundColor: '#fffbeb',
    border: '1px solid #fed7aa',
    color: '#92400e',
  },
  alertError: {
    backgroundColor: '#fef2f2',
    border: '1px solid #fecaca',
    color: '#991b1b',
  },
}));

const defaultData = {
  sheetsConfig: {
    spreadsheetId: "",
    spreadsheetName: "",
    sheetName: "",
    range: "A:Z",
  },
  operation: "list",
  searchColumn: "",
  searchValue: "",
  rowData: {},
  outputVariable: "",
  variables: [],
};

const operations = [
  { value: "list", label: "📋 Listar filas", description: "Enumera datos de la hoja de cálculo" },
  { value: "add", label: "➕ Añadir fila", description: "Añade una nueva fila" },
  { value: "edit", label: "✏️ Editar fila", description: "Edita una fila existente" },
  { value: "delete", label: "🗑️ Eliminar fila", description: "Elimina una fila" },
  { value: "search", label: "🔍 Buscar datos", description: "Busca valores específicos" },
];

const FlowBuilderGoogleSheetsModal = ({ open, onSave, data, onUpdate, close }) => {
  const classes = useStyles();
  const { user } = useAuth();
  const companyId = user?.companyId;
  const [activeModal, setActiveModal] = useState(false);
  const [labels, setLabels] = useState({ title: "", btn: "" });
  const [formData, setFormData] = useState(defaultData);
  const [focusedField, setFocusedField] = useState("");
  const [loading, setLoading] = useState(false);
  const [testLoading, setTestLoading] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authUrl, setAuthUrl] = useState("");
  const [isCheckingAuth, setIsCheckingAuth] = useState(false);
  const authPollingRef = useRef(null);

  const mergedData = useMemo(() => {
    if (!data?.data) return defaultData;
    
    console.log("GoogleSheets Modal - Fecha de recepción:", data);
    
    return {
      sheetsConfig: { ...defaultData.sheetsConfig, ...(data.data.sheetsConfig || {}) },
      operation: data.data.operation || "list",
      searchColumn: data.data.searchColumn || "",
      searchValue: data.data.searchValue || "",
      rowData: data.data.rowData || {},
      outputVariable: data.data.outputVariable || "",
      variables: data.data.variables || [],
    };
  }, [data]);

  useEffect(() => {
    if (open === "edit") {
      setLabels({ title: "Editar Google Sheets", btn: "Guardar" });
      setFormData(mergedData);
      setActiveModal(true);
      checkAuthStatus({ showToast: false }); // Verificar el estado de autenticación
    } else if (open === "create") {
      setLabels({ title: "Añadir Google Sheets", btn: "Añadir" });
      setFormData(defaultData);
      setActiveModal(true);
      checkAuthStatus({ showToast: false }); // Verificar el estado de autenticación
    } else {
      setActiveModal(false);
    }
  }, [open, mergedData]);

  useEffect(() => {
    return () => {
      stopAuthPolling();
    };
  }, []);

  const handleClose = () => {
    close(null);
    setActiveModal(false);
    stopAuthPolling();
  };

  const handleChange = (section, field) => (event) => {
    const value = event.target.type === "checkbox" ? event.target.checked : event.target.value;
    setFormData((prev) => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value,
      },
    }));
  };

  const handleChangeDirect = (field) => (event) => {
    const value = event.target.type === "checkbox" ? event.target.checked : event.target.value;
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleRowDataChange = (key, value) => {
    setFormData((prev) => ({
      ...prev,
      rowData: {
        ...prev.rowData,
        [key]: value,
      },
    }));
  };

  const addRowDataField = () => {
    const newKey = `campo_${Object.keys(formData.rowData).length + 1}`;
    handleRowDataChange(newKey, "");
  };

  const removeRowDataField = (key) => {
    const newRowData = { ...formData.rowData };
    delete newRowData[key];
    setFormData((prev) => ({
      ...prev,
      rowData: newRowData,
    }));
  };

  const handleInsertVariable = (variable) => {
    if (!focusedField) return;
    
    if (focusedField.startsWith("rowData.")) {
      const key = focusedField.replace("rowData.", "");
      handleRowDataChange(key, (formData.rowData[key] || "") + variable);
    } else if (focusedField === "searchValue") {
      setFormData((prev) => ({
        ...prev,
        searchValue: prev.searchValue + variable,
      }));
    }
  };

  // Função para testar conexão
  const handleTestConnection = async () => {
    if (!formData.sheetsConfig.spreadsheetId) {
      toast.error("Ingresar el ID de la hoja de cálculo");
      return;
    }

    setTestLoading(true);
    setTestResult(null);

    try {
      const response = await api.post("/google-sheets/test", {
        companyId,
        spreadsheetId: formData.sheetsConfig.spreadsheetId,
        sheetName: formData.sheetsConfig.sheetName || "Sheet1",
      });

      setTestResult({
        success: true,
        message: `Conexión exitosa a la hoja de cálculo: ${response.data.spreadsheetName}`,
        data: response.data,
      });
      
      toast.success("¡Conexión probada!");
    } catch (error) {
      setTestResult({
        success: false,
        message: error.response?.data?.error || "Error al probar la conexión",
      });
      
      toast.error("Error al probar la conexión");
    } finally {
      setTestLoading(false);
    }
  };

  const stopAuthPolling = () => {
    if (authPollingRef.current) {
      clearInterval(authPollingRef.current);
      authPollingRef.current = null;
    }
  };

  // Função para autenticar com Google
  const handleAuthenticate = async () => {
    try {
      const response = await api.post("/google-sheets/auth", {
        companyId
      });
      setAuthUrl(response.data.authUrl);
      setIsCheckingAuth(true);

      // Abrir URL em nova janela
      window.open(response.data.authUrl, "_blank", "width=500,height=600");

      toast.info("Complete la autenticación en la ventana abierta.");

      if (!authPollingRef.current) {
        authPollingRef.current = setInterval(() => {
          checkAuthStatus();
        }, 4000);
      }
    } catch (error) {
      setIsCheckingAuth(false);
      toast.error("Error al iniciar la autenticación.");
    }
  };

  // Verificar status da autenticação
  const checkAuthStatus = async ({ showToast = true } = {}) => {
    try {
      const response = await api.get("/google-sheets/auth-status", {
        params: { companyId }
      });

      setIsAuthenticated(response.data.authenticated);

      if (response.data.authenticated) {
        stopAuthPolling();
        setIsCheckingAuth(false);
        if (showToast) {
          toast.success("¡Autenticado con Hojas de Cálculo de Google!");
        }
      } else if (showToast) {
        toast.info("Aún esperando la autenticación de Google.");
      }
    } catch (error) {
      console.error("Error al verificar el estado de la autenticación.:", error);
    }
  };

  const handleSave = () => {
    // Validações básicas
    if (!formData.sheetsConfig.spreadsheetId) {
      toast.error("Seleccione una hoja de cálculo.");
      return;
    }

    if (!formData.sheetsConfig.sheetName) {
      toast.error("Introduzca el nombre de la hoja.");
      return;
    }

    if ((formData.operation === "add" || formData.operation === "edit") && Object.keys(formData.rowData).length === 0) {
      toast.error("Agregue al menos un campo de datos.");
      return;
    }

    if ((formData.operation === "search" || formData.operation === "delete") && (!formData.searchColumn || !formData.searchValue)) {
      toast.error("Introduzca la columna y el valor que desea buscar.");
      return;
    }

    const nodeData = {
      sheetsConfig: formData.sheetsConfig,
      operation: formData.operation,
      searchColumn: formData.searchColumn,
      searchValue: formData.searchValue,
      rowData: formData.rowData,
      outputVariable: formData.outputVariable,
      variables: formData.variables,
    };

    if (open === "edit") {
      onUpdate(data.id, nodeData);
    } else {
      onSave(nodeData);
    }
    
    handleClose();
  };

  const textFieldProps = (section, field) => ({
    value: formData[section]?.[field] || "",
    onChange: handleChange(section, field),
    onFocus: () => setFocusedField(`${section}.${field}`),
    variant: "outlined",
    size: "small",
    fullWidth: true,
    className: classes.textField,
  });

  const currentOperation = operations.find(op => op.value === formData.operation);

  return (
    <Dialog open={activeModal} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle>{labels.title}</DialogTitle>
      <DialogContent>
        <Grid container spacing={2}>
          {/* Sección de autenticación */}
          <Grid item xs={12}>
            <Paper className={classes.authSection} elevation={0}>
              <Typography className={classes.sectionTitle}>
                🔐 Autenticación de Google
              </Typography>
              
              {isAuthenticated ? (
              <Paper className={`${classes.alertPaper} ${classes.alertSuccess}`}>
                <CheckCircleIcon style={{ color: '#0c4a6e' }} />
                <Typography variant="body2">
                  Autenticado con Hojas de cálculo de Google
                </Typography>
              </Paper>
            ) : (
              <Box>
                <Paper className={`${classes.alertPaper} ${classes.alertWarning}`} style={{ marginBottom: 16 }}>
                  <ErrorIcon style={{ color: '#92400e' }} />
                  <Typography variant="body2">
                    Debe autenticarse con Google para usar esta integración.
                    {isCheckingAuth && " • Verificando la autenticación...."}
                  </Typography>
                </Paper>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleAuthenticate}
                  startIcon={<span style={{ fontSize: "16px" }}>🔗</span>}
                  fullWidth
                >
                  Conectar con Google
                </Button>
                {isCheckingAuth && (
                  <Typography variant="caption" color="textSecondary" style={{ display: "block", marginTop: 8 }}>
                    Una vez que termines de autenticarte en la ventana abierta, realizaremos la verificación nuevamente de forma automática.
                  </Typography>
                )}
              </Box>
            )}
            </Paper>
          </Grid>

          {/* Configuración de la hoja de cálculo */}
          <Grid item xs={12}>
            <Paper className={classes.section} elevation={0}>
              <Typography className={classes.sectionTitle}>
                📊 Configuração da Planilha
              </Typography>
              <TextField
                label="ID de la hoja de cálculo"
                placeholder="1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms"
                {...textFieldProps("sheetsConfig", "spreadsheetId")}
              />
              <TextField
                label="Nombre de la hoja de cálculo"
                placeholder="Mi hoja de cálculo"
                {...textFieldProps("sheetsConfig", "spreadsheetName")}
              />
              <TextField
                label="Nombre de la pestaña"
                placeholder="Sheet1"
                {...textFieldProps("sheetsConfig", "sheetName")}
              />
              <TextField
                label="Rango (opcional)"
                placeholder="A:Z"
                {...textFieldProps("sheetsConfig", "range")}
              />
              
              {/* Botón de prueba */}
              <Button
                variant="outlined"
                color="primary"
                onClick={handleTestConnection}
                disabled={
                  testLoading ||
                  !formData.sheetsConfig.spreadsheetId ||
                  !isAuthenticated ||
                  isCheckingAuth
                }
                startIcon={testLoading ? <CircularProgress size={16} /> : <span>🧪</span>}
                className={classes.testButton}
                fullWidth
              >
                {testLoading ? "Prueba..." : "Probar conexión"}
              </Button>

              {!isAuthenticated && (
                <Typography className={classes.helperText} style={{ marginTop: 8 }}>
                  Autentiquese antes de probar la conexión.
                </Typography>
              )}
              
              {/* Resultado de la prueba */}
              {testResult && (
                <Paper 
                  className={`${classes.alertPaper} ${classes.testResult} ${testResult.success ? classes.alertSuccess : classes.alertError}`}
                >
                  {testResult.success ? <CheckCircleIcon /> : <ErrorIcon />}
                  <Typography variant="body2">
                    {testResult.message}
                  </Typography>
                </Paper>
              )}
              
              <Typography className={classes.helperText}>
                El ID de la hoja de cálculo está en URL: /d/SPREADSHEET_ID/edit
              </Typography>
            </Paper>
          </Grid>

          {/* Operación */}
          <Grid item xs={12}>
            <Paper className={classes.section} elevation={0}>
              <Typography className={classes.sectionTitle}>
                ⚙️ Operación
              </Typography>
              <FormControl fullWidth variant="outlined" size="small">
                <InputLabel>Seleccionar la operación</InputLabel>
                <Select
                  value={formData.operation}
                  onChange={handleChangeDirect("operation")}
                  label="Seleccionar la operación"
                >
                  {operations.map((op) => (
                    <MenuItem key={op.value} value={op.value}>
                      <Box>
                        <Typography variant="body2">{op.label}</Typography>
                        <Typography variant="caption" color="textSecondary">
                          {op.description}
                        </Typography>
                      </Box>
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Paper>
          </Grid>

          {/* Configuración específica de la operación */}
          {(formData.operation === "search" || formData.operation === "delete") && (
            <Grid item xs={12}>
              <Paper className={classes.section} elevation={0}>
                <Typography className={classes.sectionTitle}>
                  🔍 Configuración de búsqueda
                </Typography>
                <TextField
                  label="Columna de búsqueda"
                  placeholder="email"
                  {...textFieldProps("", "searchColumn")}
                />
                <TextField
                  label="Valor de búsqueda"
                  placeholder="{{email}}"
                  {...textFieldProps("", "searchValue")}
                />
                <Typography className={classes.helperText}>
                  Usar variables de flujo: {"{{name}}"}, {"{{email}}"}, etc.
                </Typography>
              </Paper>
            </Grid>
          )}

          {(formData.operation === "add" || formData.operation === "edit") && (
            <Grid item xs={12}>
              <Paper className={classes.section} elevation={0}>
                <Typography className={classes.sectionTitle}>
                  📝 Datos de fila
                </Typography>
                {Object.entries(formData.rowData).map(([key, value], index) => (
                  <div key={key} className={classes.keyValueRow}>
                    <TextField
                      label="Columna"
                      placeholder="nome"
                      value={key}
                      onChange={(e) => {
                        const newKey = e.target.value;
                        const newRowData = { ...formData.rowData };
                        delete newRowData[key];
                        newRowData[newKey] = value;
                        setFormData(prev => ({ ...prev, rowData: newRowData }));
                      }}
                      className={classes.keyField}
                      size="small"
                    />
                    <TextField
                      label="Valor"
                      placeholder="{{name}}"
                      value={value}
                      onChange={(e) => handleRowDataChange(key, e.target.value)}
                      onFocus={() => setFocusedField(`rowData.${key}`)}
                      className={classes.valueField}
                      size="small"
                    />
                    <IconButton
                      onClick={() => removeRowDataField(key)}
                      size="small"
                    >
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </div>
                ))}
                <Button
                  startIcon={<AddIcon />}
                  onClick={addRowDataField}
                  variant="outlined"
                  size="small"
                  style={{ marginTop: 8 }}
                >
                  Añadir campo
                </Button>
                <Typography className={classes.helperText}>
                  Usar variables de flujo en valores: {"{{name}}"}, {"{{email}}"}, etc.
                </Typography>
              </Paper>
            </Grid>
          )}

          {/* Variable de salida */}
          <Grid item xs={12}>
            <Paper className={classes.section} elevation={0}>
              <Typography className={classes.sectionTitle}>
                📤 Variable de salida
              </Typography>
              <TextField
                label="Nombre de la variable"
                placeholder="dados_planilha"
                {...textFieldProps("", "outputVariable")}
              />
              <Typography className={classes.helperText}>
                Los datos devueltos se almacenarán en esta variable para su uso posterior..
              </Typography>
            </Paper>
          </Grid>
        </Grid>

        <Divider style={{ margin: "16px 0" }} />

        <MessageVariablesPicker onClick={handleInsertVariable} />
      </DialogContent>
      <DialogActions className={classes.actions}>
        <Typography className={classes.helperText}>
          Configure la integración con Hojas de cálculo de Google para manipular hojas de cálculo..
        </Typography>
        <div>
          <Button
            onClick={handleClose}
            startIcon={<CancelIcon />}
            style={{ marginRight: 8 }}
          >
            Cancelar
          </Button>
          <Button
            color="primary"
            variant="contained"
            startIcon={<SaveIcon />}
            onClick={handleSave}
          >
            {labels.btn}
          </Button>
        </div>
      </DialogActions>
    </Dialog>
  );
};

export default FlowBuilderGoogleSheetsModal;
