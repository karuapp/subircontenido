import api from "./api";

export const eventTypeOptions = [
  {
    value: "birthday",
    label: "Recordatorio de cumpleaños del cliente",
    description: "Envía un mensaje automático el día del cumpleaños del cliente."
  },
  {
    value: "invoice_reminder",
    label: "Recordatorio de factura",
    description: "Envía recordatorios antes de la fecha de vencimiento de la factura."
  },
  {
    value: "invoice_overdue",
    label: "Cobro de facturas vencidas",
    description: "Envía mensajes cuando una factura vence."
  }
];

export const listScheduledDispatchers = async params => {
  const { data } = await api.get("/scheduled-dispatchers", { params });
  return data;
};

export const getScheduledDispatcher = async id => {
  const { data } = await api.get(`/scheduled-dispatchers/${id}`);
  return data;
};

export const createScheduledDispatcher = async payload => {
  const { data } = await api.post("/scheduled-dispatchers", payload);
  return data;
};

export const updateScheduledDispatcher = async (id, payload) => {
  const { data } = await api.put(`/scheduled-dispatchers/${id}`, payload);
  return data;
};

export const deleteScheduledDispatcher = async id => {
  const { data } = await api.delete(`/scheduled-dispatchers/${id}`);
  return data;
};

export const toggleScheduledDispatcher = async (id, active) => {
  const { data } = await api.patch(`/scheduled-dispatchers/${id}/toggle`, {
    active
  });
  return data;
};

export default {
  listScheduledDispatchers,
  getScheduledDispatcher,
  createScheduledDispatcher,
  updateScheduledDispatcher,
  deleteScheduledDispatcher,
  toggleScheduledDispatcher,
  eventTypeOptions
};
