import api from "./api";

export const getAutomations = async (params = {}) => {
  const { data } = await api.get("/automations", { params });
  return data;
};

export const getAutomation = async (id) => {
  const { data } = await api.get(`/automations/${id}`);
  return data;
};

export const createAutomation = async (automationData) => {
  const { data } = await api.post("/automations", automationData);
  return data;
};

export const updateAutomation = async (id, automationData) => {
  const { data } = await api.put(`/automations/${id}`, automationData);
  return data;
};

export const deleteAutomation = async (id) => {
  const { data } = await api.delete(`/automations/${id}`);
  return data;
};

export const toggleAutomation = async (id, isActive) => {
  const { data } = await api.patch(`/automations/${id}/toggle`, { isActive });
  return data;
};

// Tipos de gatilhos disponíveis
export const triggerTypes = [
  { value: "birthday", label: "Cumpleaños del contacto", icon: "🎂" },
  { value: "anniversary", label: "Fecha de aniversario", icon: "🎉" },
  { value: "kanban_stage", label: "Entrada en la fase Kanban", icon: "📋" },
  { value: "kanban_time", label: "Tiempo en la fase Kanban", icon: "⏱️" },
  { value: "tag_added", label: "Etiqueta añadida", icon: "🏷️" },
  { value: "tag_removed", label: "Etiqueta eliminada", icon: "🏷️" },
  { value: "ticket_created", label: "Nuevo ticket creado", icon: "🎫" },
  { value: "ticket_closed", label: "Ticket cerrado", icon: "✅" },
  { value: "no_response", label: "Sin respuesta", icon: "⏰" },
  { value: "scheduled", label: "Programación recurrente", icon: "📅" }
];

// Tipos de ações disponíveis
export const actionTypes = [
  { value: "send_message", label: "Enviar mensaje", icon: "💬" },
  { value: "send_media", label: "Enviar multimedia", icon: "📎" },
  { value: "add_tag", label: "Añadir etiqueta", icon: "🏷️" },
  { value: "remove_tag", label: "Eliminar etiqueta", icon: "🗑️" },
  { value: "move_kanban", label: "Mover a Kanban", icon: "📋" },
  { value: "transfer_queue", label: "Transferir a departamento", icon: "📁" },
  { value: "transfer_user", label: "Transferir a agente", icon: "👤" },
  { value: "close_ticket", label: "Cerrar ticket", icon: "✅" },
  { value: "create_ticket", label: "Crear ticket", icon: "🎫" },
  { value: "webhook", label: "Llamar a webhook", icon: "🔗" },
  { value: "wait", label: "Esperar", icon: "⏳" }
];

export default {
  getAutomations,
  getAutomation,
  createAutomation,
  updateAutomation,
  deleteAutomation,
  toggleAutomation,
  triggerTypes,
  actionTypes
};
