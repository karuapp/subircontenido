// Configuración de EmailJS
// Para configurar:
// 1. Accede a https://www.emailjs.com/
// 2. Crea una cuenta gratuita
// 3. Configura un servicio de correo electrónico (Gmail, Outlook, etc.)
// 4. Crea una plantilla de correo electrónico
// 5. Reemplaza los valores a continuación

export const EMAILJS_CONFIG = {
  // Tu clave pública de EmailJS
  PUBLIC_KEY: 'vIgIchutKD0N3YXL2',
  
  // ID del servicio de correo electrónico configurado
  SERVICE_ID: 'service_hglqehv',
  
  // ID de la plantilla de correo electrónico creada
  TEMPLATE_ID: 'template_up3na9j',
  
  // Correo electrónico de destino (donde recibirás las solicitudes)
  TO_EMAIL: 'advancedlocate@gmail.com'
};

// Plantilla sugerida para EmailJS:
/*
Asunto: {{subject}}

Nueva solicitud de CRM personalizada:

Nombre: {{from_name}}
Email: {{from_email}}
Número de teléfono: {{phone}}
Empresa: {{company}}
Segmento: {{segment}}

Mensaje:
{{message}}

---
Enviado mediante formulario del panel de control
*/
