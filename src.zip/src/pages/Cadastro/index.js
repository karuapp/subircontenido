import React, { useState, useEffect } from "react";
import qs from 'query-string';
import * as Yup from "yup";
import { useHistory, Link as RouterLink } from "react-router-dom";
import usePlans from "../../hooks/usePlans";
import { getBackendUrl } from "../../config";
import { toast } from "react-toastify";
import { Formik, Form, Field } from "formik";
import {
    IconButton,
    InputAdornment,
    TextField,
    Button,
    Box,
    Typography,
    CssBaseline,
    FormControlLabel,
    Checkbox,
    Dialog,
    DialogContent,
    DialogTitle,
    CircularProgress,
    Fade,
    useMediaQuery,
    useTheme,
    Card,
    CardContent,
    MenuItem,
} from "@material-ui/core";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import SaveIcon from '@mui/icons-material/Save';
import LoginIcon from '@mui/icons-material/Login';
import BusinessIcon from '@mui/icons-material/Business';
import PersonIcon from '@mui/icons-material/Person';
import EmailIcon from '@mui/icons-material/Email';
import LockIcon from '@mui/icons-material/Lock';
import PhoneIcon from '@mui/icons-material/Phone';
import CardMembershipIcon from '@mui/icons-material/CardMembership';
import DescriptionIcon from '@mui/icons-material/Description';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { makeStyles } from "@material-ui/core/styles";
import { openApi } from "../../services/api";
import toastError from "../../errors/toastError";
import moment from "moment";
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import wallfundo from "../../assets/f002.png";
import api from "../../services/api";

// Función para validar el CPF (Número de Registro Fiscal de Personas Físicas)
const isValidCPF = (cpf) => {
  cpf = cpf.replace(/[^\d]/g, '');
  if (cpf.length !== 11) return false;
  if (/^(\d)\1+$/.test(cpf)) return false;
  
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cpf.charAt(i)) * (10 - i);
  }
  let remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cpf.charAt(9))) return false;
  
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cpf.charAt(i)) * (11 - i);
  }
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cpf.charAt(10))) return false;
  
  return true;
};

// Función para validar el CNPJ (Número de Registro Fiscal de Personas Jurídicas)
const isValidCNPJ = (cnpj) => {
  cnpj = cnpj.replace(/[^\d]/g, '');
  if (cnpj.length !== 14) return false;
  if (/^(\d)\1+$/.test(cnpj)) return false;
  
  let size = cnpj.length - 2;
  let numbers = cnpj.substring(0, size);
  const digits = cnpj.substring(size);
  let sum = 0;
  let pos = size - 7;
  
  for (let i = size; i >= 1; i--) {
    sum += parseInt(numbers.charAt(size - i)) * pos--;
    if (pos < 2) pos = 9;
  }
  
  let result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
  if (result !== parseInt(digits.charAt(0))) return false;
  
  size = size + 1;
  numbers = cnpj.substring(0, size);
  sum = 0;
  pos = size - 7;
  
  for (let i = size; i >= 1; i--) {
    sum += parseInt(numbers.charAt(size - i)) * pos--;
    if (pos < 2) pos = 9;
  }
  
  result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
  if (result !== parseInt(digits.charAt(1))) return false;
  
  return true;
};

// Segmentos disponibles
const segments = [
  { value: "varejo", label: "Comercio minorista", icon: "🛍️" },
  { value: "servicos", label: "Servicios", icon: "🔧" },
  { value: "tecnologia", label: "Tecnología", icon: "💻" },
  { value: "saude", label: "Salud", icon: "🏥" },
  { value: "educacao", label: "Educación", icon: "📚" },
  { value: "alimentos", label: "Alimentación", icon: "🍔" },
  { value: "moda", label: "Moda", icon: "👗" },
  { value: "automotivo", label: "Automoción", icon: "🚗" },
  { value: "imobiliario", label: "Inmobiliaria", icon: "🏠" },
  { value: "entretenimento", label: "Entretenimiento", icon: "🎮" },
  { value: "financeiro", label: "Finanzas", icon: "💰" },
  { value: "outros", label: "Otros", icon: "📦" },
];

const useStyles = makeStyles((theme) => ({
  root: {
    minHeight: "100vh",
    display: "flex",
    background: "linear-gradient(135deg, #2d3748 0%, #1a202c 100%)",
    [theme.breakpoints.down("sm")]: {
      flexDirection: "column",
    },
  },
  
  leftPanel: (props) => ({
    flex: 1,
    backgroundImage: `linear-gradient(135deg, rgba(0,0,0,0.75), rgba(0,0,0,0.85)), url(${props.backgroundImage || wallfundo})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: theme.spacing(8),
    color: "#fff",
    position: "relative",
    overflow: "hidden",
    "&::after": {
      content: '""',
      position: "absolute",
      inset: 0,
      backgroundImage: "radial-gradient(rgba(255,255,255,0.08) 1px, transparent 1px)",
      backgroundSize: "24px 24px",
      opacity: 0.6,
    },
    "& > *": {
      position: "relative",
      zIndex: 1,
    },
  }),

  leftPanelCard: {
    backgroundColor: "rgba(255, 255, 255, 0.08)",
    borderRadius: 20,
    padding: theme.spacing(5),
    maxWidth: 520,
    textAlign: "left",
    border: "1px solid rgba(255,255,255,0.2)",
    boxShadow: "0 20px 40px rgba(0,0,0,0.35)",
  },

  leftPanelTitle: {
    fontSize: "2.5rem",
    fontWeight: 700,
    marginBottom: theme.spacing(2),
    lineHeight: 1.2,
  },

  leftPanelSubtitle: {
    fontSize: "1.1rem",
    opacity: 0.9,
    marginBottom: theme.spacing(3),
  },

  leftPanelList: {
    listStyle: "none",
    padding: 0,
    margin: 0,
  },

  leftPanelListItem: {
    display: "flex",
    alignItems: "center",
    marginBottom: theme.spacing(2),
    fontSize: "1rem",
    "& svg": {
      marginRight: theme.spacing(1),
      fontSize: "1.2rem",
    },
  },

  rightPanel: {
    flex: 1,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: theme.spacing(4),
    [theme.breakpoints.down("sm")]: {
      padding: theme.spacing(2),
    },
  },

  signupCard: {
    maxWidth: 500,
    width: "100%",
    borderRadius: 20,
    boxShadow: "0 20px 40px rgba(0,0,0,0.1)",
    overflow: "hidden",
    backgroundColor: "rgba(255, 255, 255, 0.95)",
    backdropFilter: "blur(10px)",
  },

  stepper: {
    padding: theme.spacing(2, 0),
    backgroundColor: "transparent",
    marginBottom: theme.spacing(2),
  },

  stepContent: {
    padding: theme.spacing(3),
  },

  inputField: {
    backgroundColor: "#f8fafc",
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    transition: "all 0.2s ease-in-out",
    "&:hover": {
      borderColor: "#d1d5db",
      backgroundColor: "#f1f5f9",
    },
    "&:focus-within": {
      borderColor: "#3b82f6",
      backgroundColor: "#fff",
      boxShadow: "0 0 0 3px rgba(59, 130, 246, 0.1)",
    },
    "& .MuiOutlinedInput-root": {
      borderRadius: 12,
      "& fieldset": {
        border: "none",
      },
      "&:hover fieldset": {
        border: "none",
      },
      "&.Mui-focused fieldset": {
        border: "none",
      },
    },
  },

  submitButton: {
    width: "100%",
    height: "48px",
    borderRadius: "12px",
    backgroundColor: theme.palette.primary.main,
    color: "white",
    fontSize: "1rem",
    fontWeight: 600,
    textTransform: "none",
    marginTop: theme.spacing(2),
    boxShadow: `0 4px 12px ${theme.palette.primary.main}66`,
    transition: "all 0.3s ease-in-out",
    "&:hover": {
      backgroundColor: theme.palette.primary.dark || theme.palette.primary.main,
      boxShadow: `0 6px 16px ${theme.palette.primary.main}80`,
      transform: "translateY(-2px)",
    },
    "&:disabled": {
      backgroundColor: "#9ca3af",
      boxShadow: "none",
      transform: "none",
    },
  },

  backButton: {
    marginRight: theme.spacing(1),
  },

  phoneInputContainer: {
    backgroundColor: "#f8fafc",
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    padding: theme.spacing(1),
    transition: "all 0.2s ease-in-out",
    "&:hover": {
      borderColor: "#d1d5db",
      backgroundColor: "#f1f5f9",
    },
    "&:focus-within": {
      borderColor: "#3b82f6",
      backgroundColor: "#fff",
      boxShadow: "0 0 0 3px rgba(59, 130, 246, 0.1)",
    },
  },

  phoneInput: {
    backgroundColor: "transparent",
    border: "none",
    outline: "none",
    width: "100%",
    color: "#1f2937",
    fontSize: "0.95rem",
  },

  termsCheckbox: {
    marginTop: theme.spacing(2),
    "& .MuiFormControlLabel-label": {
      fontSize: "0.85rem",
      color: "#6b7280",
      fontWeight: 500,
    },
  },

  progressContainer: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: theme.spacing(4),
    textAlign: "center",
  },

  progressText: {
    marginTop: theme.spacing(2),
    color: theme.palette.primary.main,
    fontWeight: 600,
  },

  planCard: {
    "&:hover": {
      transform: "translateY(-2px)",
      boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    },
  },

  segmentCard: {
    "&:hover": {
      transform: "translateY(-2px)",
      boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    },
  },

  carouselContainer: {
    position: "relative",
    overflow: "hidden",
    padding: theme.spacing(2, 0),
  },

  carouselWrapper: {
    display: "flex",
    transition: "transform 0.3s ease",
    scrollSnapType: "x mandatory",
    scrollBehavior: "smooth",
    cursor: "grab",
    userSelect: "none",
    "&:active": {
      cursor: "grabbing",
    },
    "&::-webkit-scrollbar": {
      height: 6,
    },
    "&::-webkit-scrollbar-track": {
      background: "#f1f1f1",
      borderRadius: 3,
    },
    "&::-webkit-scrollbar-thumb": {
      background: "#3b82f6",
      borderRadius: 3,
    },
  },

  carouselItem: {
    flex: "0 0 auto",
    scrollSnapAlign: "start",
    marginRight: theme.spacing(2),
    "&:last-child": {
      marginRight: 0,
    },
  },

  planCarouselItem: {
    width: "280px",
  },

  segmentCarouselItem: {
    width: "140px",
  },

  carouselNav: {
    position: "absolute",
    top: "50%",
    transform: "translateY(-50%)",
    backgroundColor: "rgba(255,255,255,0.9)",
    border: "1px solid #e5e7eb",
    borderRadius: "50%",
    width: 40,
    height: 40,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    zIndex: 10,
    transition: "all 0.2s ease",
    boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
    "&:hover": {
      backgroundColor: "#fff",
      boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
    },
  },

  carouselNavLeft: {
    left: -20,
  },

  carouselNavRight: {
    right: -20,
  },
}));

const SignUpSchema = Yup.object().shape({
  name: Yup.string()
    .min(2, "Nombre demasiado corto")
    .required("Nombre obligatorio"),
  email: Yup.string()
    .email("E-mail inválido")
    .required("E-mail es obligatorio"),
  password: Yup.string()
    .min(6, "Contraseña demasiado corta")
    .matches(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]+$/, "La contraseña debe contener letras y números")
    .required("Se requiere contraseña"),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref("password"), null], "Las contraseñas no coinciden")
    .required("Se requiere confirmación de contraseña"),
  phone: Yup.string()
    .min(10, "Número de teléfono demasiado corto")
    .required("Número de teléfono requerido"),
  companyName: Yup.string()
    .min(2, "Nombre de la empresa demasiado corto")
    .required("Nombre de la empresa requerido"),
  type: Yup.string()
    .oneOf(["pf", "pj"], "Tipo no válido")
    .required("Tipo requerido"),
  document: Yup.string()
    .when("type", {
      is: "pf",
      then: Yup.string()
        .test("cpf", "CPF inválido", (value) => !value || isValidCPF(value))
        .required("CPF requerido"),
      otherwise: Yup.string()
        .test("cnpj", "CNPJ inválido", (value) => !value || isValidCNPJ(value))
        .required("CNPJ Es obligatorio.")
    }),
  segment: Yup.string(),
  planId: Yup.number()
    .required("El plan es obligatorio.")
});

const QuizForm = ({ values, errors, touched, setFieldValue, nextStep, prevStep, step, totalSteps, handleSubmit, isSubmitting, plans, trialDays, loading }) => {
  const classes = useStyles();
  const [showPassword, setShowPassword] = useState(false);

  // Carousel scroll functions
  const scrollCarousel = (direction, carouselClass) => {
    const carousel = document.querySelector(carouselClass);
    if (!carousel) return;
    
    const scrollAmount = 300; // pixels to scroll
    if (direction === 'left') {
      carousel.scrollLeft -= scrollAmount;
    } else {
      carousel.scrollLeft += scrollAmount;
    }
  };

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleNextStep = (e) => {
    if (e) e.preventDefault();
    
    if (step === totalSteps - 1) {
      // Último paso: deja que Formik handleSubmit se encargue del proceso.
      return;
    }
    
    // Siguiente paso:
    nextStep(values);
  };

  const renderStepContent = () => {
    switch (step) {
      case 0:
        return (
          <Fade in={true}>
            <Box className={classes.stepContent}>
              <Typography variant="h5" gutterBottom>
                👋 ¡Comencemos! ¿Cómo te llamas?
              </Typography>
              <Field
                as={TextField}
                name="name"
                variant="outlined"
                fullWidth
                placeholder="Tu nombre completo"
                error={touched.name && Boolean(errors.name)}
                helperText={touched.name && errors.name}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <PersonIcon style={{ color: "#9ca3af" }} />
                    </InputAdornment>
                  ),
                }}
                className={classes.inputField}
              />
            </Box>
          </Fade>
        );

      case 1:
        return (
          <Fade in={true}>
            <Box className={classes.stepContent}>
              <Typography variant="h5" gutterBottom>
                📧 ¿Cuál es tu mejor dirección de correo electrónico?
              </Typography>
              <Field
                as={TextField}
                name="email"
                variant="outlined"
                fullWidth
                placeholder="tu@email.com"
                error={touched.email && Boolean(errors.email)}
                helperText={touched.email && errors.email}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <EmailIcon style={{ color: "#9ca3af" }} />
                    </InputAdornment>
                  ),
                }}
                className={classes.inputField}
              />
            </Box>
          </Fade>
        );

      case 2:
        return (
          <Fade in={true}>
            <Box className={classes.stepContent}>
              <Typography variant="h5" gutterBottom>
                🔐 Crea una contraseña segura
              </Typography>
              <Field
                as={TextField}
                name="password"
                type={showPassword ? "text" : "password"}
                variant="outlined"
                fullWidth
                placeholder="Mínimo 6 caracteres"
                error={touched.password && Boolean(errors.password)}
                helperText={touched.password && errors.password}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockIcon style={{ color: "#9ca3af" }} />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={toggleShowPassword}
                        edge="end"
                      >
                        {showPassword ? <Visibility /> : <VisibilityOff />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
                className={classes.inputField}
              />
              <Field
                as={TextField}
                name="confirmPassword"
                type={showPassword ? "text" : "password"}
                variant="outlined"
                fullWidth
                placeholder="Confirme sua senha"
                error={touched.confirmPassword && Boolean(errors.confirmPassword)}
                helperText={touched.confirmPassword && errors.confirmPassword}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockIcon style={{ color: "#9ca3af" }} />
                    </InputAdornment>
                  ),
                }}
                className={classes.inputField}
                style={{ marginTop: 16 }}
              />
            </Box>
          </Fade>
        );

      case 3:
        return (
          <Fade in={true}>
            <Box className={classes.stepContent}>
              <Typography variant="h5" gutterBottom>
                📱 Tu número de teléfono de contacto
              </Typography>
              <div className={classes.phoneInputContainer}>
                <Field name="phone">
                  {({ field }) => (
                    <PhoneInput
                      {...field}
                      international
                      defaultCountry="HN"
                      onChange={(value) => setFieldValue('phone', value)}
                      className={classes.phoneInput}
                      placeholder="50499999999"
                      inputStyle={{
                        backgroundColor: "transparent",
                        border: "none",
                        outline: "none",
                        width: "100%",
                        color: "#1f2937",
                        fontSize: "0.95rem",
                      }}
                    />
                  )}
                </Field>
              </div>
              {touched.phone && errors.phone && (
                <Typography color="error" variant="caption" style={{ marginTop: 8 }}>
                  {errors.phone}
                </Typography>
              )}
            </Box>
          </Fade>
        );

      case 4:
        return (
          <Fade in={true}>
            <Box className={classes.stepContent}>
              <Typography variant="h5" gutterBottom>
                🏢 ¿Es usted una persona física o jurídica?
              </Typography>
              <Box display="flex" gap={2} mt={2}>
                <Box
                  className={classes.inputField}
                  style={{ 
                    flex: 1, 
                    padding: 16, 
                    textAlign: "center",
                    cursor: "pointer",
                    border: values.type === 'pf' ? "2px solid #3b82f6" : "1px solid #e5e7eb",
                    backgroundColor: values.type === 'pf' ? "#dbeafe" : "#f8fafc"
                  }}
                  onClick={() => setFieldValue('type', 'pf')}
                >
                  <PersonIcon style={{ fontSize: 32, color: "#3b82f6", marginBottom: 8 }} />
                  <Typography style={{ fontWeight: 500 }}>
                    Particular
                  </Typography>
                </Box>
                <Box
                  className={classes.inputField}
                  style={{ 
                    flex: 1, 
                    padding: 16, 
                    textAlign: "center",
                    cursor: "pointer",
                    border: values.type === 'pj' ? "2px solid #3b82f6" : "1px solid #e5e7eb",
                    backgroundColor: values.type === 'pj' ? "#dbeafe" : "#f8fafc"
                  }}
                  onClick={() => setFieldValue('type', 'pj')}
                >
                  <BusinessIcon style={{ fontSize: 32, color: "#3b82f6", marginBottom: 8 }} />
                  <Typography style={{ fontWeight: 500 }}>
                    Persona jurídica
                  </Typography>
                </Box>
              </Box>
              {touched.type && errors.type && (
                <Typography color="error" variant="caption" style={{ marginTop: 8 }}>
                  {errors.type}
                </Typography>
              )}
            </Box>
          </Fade>
        );

      case 5:
        return (
          <Fade in={true}>
            <Box className={classes.stepContent}>
              <Typography variant="h5" gutterBottom>
                📋 {values.type === 'pf' ? 'Su CPF' : 'Su CNPJ'}
              </Typography>
              <Field
                as={TextField}
                name="document"
                variant="outlined"
                fullWidth
                placeholder={values.type === 'pf' ? '000.000.000-00' : '00.000.000/0000-00'}
                error={touched.document && Boolean(errors.document)}
                helperText={touched.document && errors.document}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <DescriptionIcon style={{ color: "#9ca3af" }} />
                    </InputAdornment>
                  ),
                }}
                className={classes.inputField}
              />
            </Box>
          </Fade>
        );

      case 6:
        return (
          <Fade in={true}>
            <Box className={classes.stepContent}>
              <Typography variant="h5" gutterBottom>
                🏭 Nombre de tu empresa
              </Typography>
              <Field
                as={TextField}
                name="companyName"
                variant="outlined"
                fullWidth
                placeholder="Nombre de la empresa"
                error={touched.companyName && Boolean(errors.companyName)}
                helperText={touched.companyName && errors.companyName}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <BusinessIcon style={{ color: "#9ca3af" }} />
                    </InputAdornment>
                  ),
                }}
                className={classes.inputField}
              />
            </Box>
          </Fade>
        );

      case 7:
        return (
          <Fade in={true}>
            <Box className={classes.stepContent}>
              <Typography variant="h5" gutterBottom>
                💳 Elige tu plan
              </Typography>
              <Field
                as={TextField}
                name="planId"
                variant="outlined"
                fullWidth
                select
                error={touched.planId && Boolean(errors.planId)}
                helperText={touched.planId && errors.planId}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <CardMembershipIcon style={{ color: "#9ca3af" }} />
                    </InputAdornment>
                  ),
                }}
                className={classes.inputField}
              >
                {plans.map((plan) => (
                  <MenuItem key={plan.id} value={plan.id}>
                    <Box display="flex" justifyContent="space-between" alignItems="center" width="100%">
                      <Box>
                        <Typography variant="body1" fontWeight={600} color="#1f2937">
                          {plan.name}
                        </Typography>
                        <Typography variant="body2" color="#6b7280">
                          {plan.users || 3} Usuarios • Conexiones ilimitadas
                        </Typography>
                      </Box>
                      <Typography variant="h6" color="#3b82f6" fontWeight={700}>
                        ${plan.value || plan.amount || plan.price || '0'}
                        <Typography component="span" variant="caption" color="#6b7280">
                          /{plan.recurrence === 'MENSAL' ? 'mês' : 'ano'}
                        </Typography>
                      </Typography>
                    </Box>
                  </MenuItem>
                ))}
              </Field>
              
              <Box mt={2} p={2} bgcolor="#f0f9ff" borderRadius={8} border="1px solid #3b82f6">
                <Typography variant="body2" color="#1e40af" style={{ lineHeight: 1.4 }}>
                  <CheckCircleIcon style={{ fontSize: 16, marginRight: 4, verticalAlign: "middle" }} />
                  <strong>Aviso importante:</strong> No se le cobrará ahora. La facturación comenzará solo después de los {trialDays} días de prueba gratuita.
                </Typography>
              </Box>
            </Box>
          </Fade>
        );

      default:
        return null;
    }
  };

  return (
    <Form>
      <Box mb={3}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
          <Typography variant="body2" color="#6b7280">
            Etapa {step + 1} de {totalSteps}
          </Typography>
          <Typography variant="body2" color="#3b82f6" fontWeight={600}>
            {Math.round(((step + 1) / totalSteps) * 100)}%
          </Typography>
        </Box>
        <Box
          height={8}
          bgcolor="#e5e7eb"
          borderRadius={4}
          overflow="hidden"
        >
          <Box
            height="100%"
            bgcolor="#3b82f6"
            borderRadius={4}
            transition="width 0.3s ease"
            width={`${((step + 1) / totalSteps) * 100}%`}
          />
        </Box>
      </Box>
      
      {renderStepContent()}
      <Box display="flex" justifyContent="space-between" mt={3}>
        <Button
          disabled={step === 0}
          onClick={prevStep}
          className={classes.backButton}
        >
          Voltar
        </Button>
        <Button
          type={step === totalSteps - 1 ? "submit" : "button"}
          variant="contained"
          onClick={step < totalSteps - 1 ? handleNextStep : undefined}
          color="primary"
          className={classes.submitButton}
          disabled={isSubmitting}
        >
          {step === totalSteps - 1 ? (isSubmitting ? "Cadastrando..." : "Finalizar") : "Siguiente"}
        </Button>
      </Box>
    </Form>
  );
};

const SignUp = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const history = useHistory();
  const [backgroundImage, setBackgroundImage] = useState(wallfundo);
  const [trialDays, setTrialDays] = useState(7);
  const classes = useStyles({ backgroundImage });
  
  const [currentStep, setCurrentStep] = useState(0);
  const [agreeToTerms, setAgreeToTerms] = useState(false);
  const [processingModalOpen, setProcessingModalOpen] = useState(false);
  const [processingText, setProcessingText] = useState("Realización de registro...");
  const { getPlanList } = usePlans();
  const [loading, setLoading] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [termsModalOpen, setTermsModalOpen] = useState(false);
  
  const params = qs.parse(window.location.search);
  const companyId = params.companyId ?? null;
  const initialState = { 
    name: "", 
    email: "", 
    password: "", 
    confirmPassword: "", 
    phone: "", 
    companyId, 
    companyName: "", 
    planId: 1, 
    document: "",
    type: "pf",
    segment: ""
  };

  const [plans, setPlans] = useState([]);
  const steps = [
    "Nome",
    "Email",
    "Senha",
    "Telefone",
    "Tipo",
    "Documento",
    "Empresa",
    "Plano"
  ];

  // Busca imagem de fundo do backend
  useEffect(() => {
    const backendUrl = getBackendUrl();
    
    fetch(`${backendUrl}/public-settings/termsImage?token=wtV`)
      .then(res => res.json())
      .then(data => {
        if (data) {
          setBackgroundImage(`${backendUrl}/public/${data}`);
        }
      })
      .catch((err) => console.log("Error al buscar termsImage:", err));

    fetch(`${backendUrl}/public-settings/trialDays?token=wtV`)
      .then(res => res.json())
      .then(data => {
        if (data) {
          setTrialDays(parseInt(data) || 7);
        }
      })
      .catch((err) => console.log("Error al buscar trialDays:", err));
  }, []);

  useEffect(() => {
    let isMounted = true;
    
    const fetchData = async () => {
      try {
        setLoading(true);
        const planList = await getPlanList();
        
        if (isMounted) {
          const publicPlans = planList.filter(plan => plan.isPublic === true);
          console.log("Planes encontrados:", publicPlans);
          setPlans(publicPlans);

          if (params.planId) {
            const preselected = publicPlans.find(plan => String(plan.id) === String(params.planId));
            if (preselected) {
              setSelectedPlan(preselected);
            }
          } else if (publicPlans.length > 0) {
            setSelectedPlan(publicPlans[0]);
          }
        }
      } catch (error) {
        console.error("Error al cargar planes:", error);
        // Fallback: criar planos padrão
        if (isMounted) {
          const defaultPlans = [
            {
              id: 1,
              name: "Plan Básico",
              value: 97,
              recurrence: "MENSAL",
              users: 3,
              isPublic: true
            },
            {
              id: 2,
              name: "Plan Profesional",
              value: 197,
              recurrence: "MENSAL",
              users: 5,
              isPublic: true
            },
            {
              id: 3,
              name: "Plan Empresarial",
              value: 397,
              recurrence: "MENSAL",
              users: 10,
              isPublic: true
            }
          ];
          console.log("Usando planes fallback:", defaultPlans);
          setPlans(defaultPlans);
          setSelectedPlan(defaultPlans[0]);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };
    
    fetchData();
    
    return () => {
      isMounted = false;
    };
  }, [params.planId, getPlanList]);

  const dueDate = moment().add(trialDays, "day").format();

  // Add drag scroll functionality to carousels
  useEffect(() => {
    const addDragScroll = (selector) => {
      const carousel = document.querySelector(selector);
      if (!carousel) return;
      
      let isDown = false;
      let startX;
      let scrollLeft;
      
      carousel.addEventListener('mousedown', (e) => {
        isDown = true;
        carousel.style.cursor = 'grabbing';
        startX = e.pageX - carousel.offsetLeft;
        scrollLeft = carousel.scrollLeft;
      });
      
      carousel.addEventListener('mouseleave', () => {
        isDown = false;
        carousel.style.cursor = 'grab';
      });
      
      carousel.addEventListener('mouseup', () => {
        isDown = false;
        carousel.style.cursor = 'grab';
      });
      
      carousel.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - carousel.offsetLeft;
        const walk = (x - startX) * 2;
        carousel.scrollLeft = scrollLeft - walk;
      });
    };

    // Initialize drag scroll after component mounts
    setTimeout(() => {
      addDragScroll('.carouselWrapper');
    }, 100);
  }, []);

  const handleSignUp = async (values) => {
    console.log("handleSignUp called with values:", values);
    console.log("agreeToTerms:", agreeToTerms);
    
    // Ensure planId is set
    const finalPlanId = values.planId || selectedPlan?.id || plans[0]?.id || 1;
    console.log("finalPlanId:", finalPlanId);
    
    if (!agreeToTerms) {
      toast.error("Debe aceptar los términos para continuar.");
      return;
    }

    setProcessingModalOpen(true);
    setProcessingText("Validando datos...");
    
    const stages = [
      "Creando cuenta...",
      "Configurando el entorno...",
      "Completando registro..."
    ];
    
    for (let i = 0; i < stages.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 700));
      setProcessingText(stages[i]);
    }
    
    const dataToSend = {
      ...values,
      planId: finalPlanId,
      phone: values.phone ? values.phone.replace(/\D/g, '') : '',
      recurrence: "MENSAL",
      dueDate: dueDate,
      status: "t",
      campaignsEnabled: true
    };
    
    try {
        // 1. Criar conta
        await openApi.post("/auth/signup", dataToSend);
        
        // 2. Mostrar sucesso
        setProcessingText("Concluindo...");
        await new Promise(resolve => setTimeout(resolve, 1000));
        setProcessingModalOpen(false);
        
        // 3. Mostrar popup de sucesso com botão para login
        toast.success(
          <div>
            <Typography variant="body1" style={{ fontWeight: 600 }}>
              🎉 ¡Registro exitoso!
            </Typography>
            <Typography variant="body2" style={{ marginTop: 8 }}>
              Su cuenta ha sido creada. Inicie sesión para acceder al sistema.
            </Typography>
            <Button
              variant="contained"
              color="primary"
              size="small"
              style={{ marginTop: 12 }}
              onClick={() => history.push("/login")}
            >
              Iniciar sesión
            </Button>
          </div>,
          {
            position: "top-center",
            autoClose: false,
            closeOnClick: false,
            draggable: false,
          }
        );
        
      } catch (err) {
        setProcessingModalOpen(false);
        toastError(err);
      }
  };

  const nextStep = (values) => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const leftPanelContent = {
    title: "Crea la experiencia de atención al cliente perfecta.",
    subtitle: "Automatice flujos de trabajo, conecte canales y ofrezca experiencias únicas al cliente.",
    features: [
      "Experiencias inteligentes con IA.",
      "Campañas y mensajes multicanal.",
      "Información en tiempo real para su equipo."
    ]
  };

  return (
    <>
      <CssBaseline />
      <div className={classes.root}>
        {!isMobile && (
          <div 
            className={classes.leftPanel}
            style={{ 
              backgroundImage: `linear-gradient(135deg, rgba(0,0,0,0.75), rgba(0,0,0,0.85)), url(${backgroundImage})` 
            }}
          >
            <div className={classes.leftPanelCard}>
              <Typography className={classes.leftPanelTitle}>
                {leftPanelContent.title}
              </Typography>
              <Typography className={classes.leftPanelSubtitle}>
                {leftPanelContent.subtitle}
              </Typography>
              <ul className={classes.leftPanelList}>
                {leftPanelContent.features.map((feature) => (
                  <li key={feature} className={classes.leftPanelListItem}>
                    <CheckCircleIcon style={{ color: "#10b981" }} />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        <div className={classes.rightPanel}>
          <Card className={classes.signupCard}>
            <CardContent>
              <Typography variant="h4" align="center" gutterBottom style={{ fontWeight: 700, color: "#1f2937" }}>
                Crea tu cuenta
              </Typography>
              
              <Formik
                initialValues={initialState}
                validationSchema={SignUpSchema}
                onSubmit={handleSignUp}
              >
                {({ values, errors, touched, setFieldValue, handleSubmit, isSubmitting }) => (
                  <Form>
                    <QuizForm
                      values={values}
                      errors={errors}
                      touched={touched}
                      setFieldValue={setFieldValue}
                      nextStep={() => nextStep(values)}
                      prevStep={prevStep}
                      step={currentStep}
                      totalSteps={steps.length}
                      handleSubmit={handleSubmit}
                      isSubmitting={isSubmitting}
                      plans={plans}
                      trialDays={trialDays}
                      loading={loading}
                    />

                    {currentStep === steps.length - 1 && (
                      <FormControlLabel
                        className={classes.termsCheckbox}
                        control={
                          <Checkbox
                            checked={agreeToTerms}
                            onChange={(e) => setAgreeToTerms(e.target.checked)}
                            name="agreeToTerms"
                            color="primary"
                          />
                        }
                        label={
                          <span>
                            Eu concordo com os{" "}
                            <span
                              onClick={() => setTermsModalOpen(true)}
                              style={{ color: "#3b82f6", textDecoration: "underline", cursor: "pointer", fontWeight: 600 }}
                            >
                              Términos y condiciones
                            </span>
                          </span>
                        }
                      />
                    )}
                  </Form>
                )}
              </Formik>
              
              <Button
                fullWidth
                variant="outlined"
                component={RouterLink}
                to="/login"
                startIcon={<LoginIcon />}
                style={{ marginTop: 16 }}
              >
                Ya tengo una cuenta
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Modal de Termos de Uso */}
      <Dialog open={termsModalOpen} onClose={() => setTermsModalOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Términos y Condiciones de Uso</DialogTitle>
            <DialogContent dividers>

            <Typography variant="h6" gutterBottom><strong>1. ACEPTACIÓN DE LOS TÉRMINOS</strong></Typography>
            <Typography paragraph>
            Al registrarse, acceder o utilizar la Plataforma, el Usuario declara haber leído, comprendido y aceptado estos Términos y Condiciones. Si no está de acuerdo con alguno de los puntos aquí establecidos, deberá abstenerse de utilizar el servicio.
            </Typography>

            <Typography variant="h6" gutterBottom><strong>2. OBJETO DEL SERVICIO</strong></Typography>
            <Typography paragraph>
            La Plataforma proporciona herramientas tecnológicas para la gestión y automatización de comunicaciones y procesos comerciales. La Plataforma no participa, controla ni supervisa el contenido de las comunicaciones enviadas por los Usuarios.
            </Typography>

            <Typography variant="h6" gutterBottom><strong>3. USO LÍCITO Y RESPONSABILIDAD DEL USUARIO</strong></Typography>
            <Typography paragraph>
            El Usuario se compromete a utilizar la Plataforma de manera lícita, ética y conforme a la legislación vigente en su país y en el país de sus destinatarios.
            </Typography>
            <Typography paragraph>
            Queda estrictamente prohibido utilizar la Plataforma para:
            </Typography>
            <Typography component="ul">
              <li>Realizar actividades fraudulentas, engañosas o de estafa.</li>
              <li>Enviar comunicaciones masivas no solicitadas (spam).</li>
              <li>Suplantar identidad de personas físicas o jurídicas.</li>
              <li>Distribuir contenido ilegal, difamatorio, amenazante o ilícito.</li>
              <li>Promover actividades criminales o productos/servicios prohibidos por ley.</li>
              <li>Vulnerar derechos de terceros, incluyendo privacidad y propiedad intelectual.</li>
            </Typography>
            <Typography paragraph>
            El Usuario asume total responsabilidad civil, penal y administrativa por el contenido y uso que realice de la Plataforma.
            </Typography>

            <Typography variant="h6" gutterBottom><strong>4. CUMPLIMIENTO NORMATIVO</strong></Typography>
            <Typography paragraph>
            El Usuario es el único responsable de cumplir con todas las leyes aplicables en materia de protección de datos, comunicaciones comerciales, consentimiento de usuarios y normativa digital vigente en su jurisdicción.
            </Typography>
            <Typography paragraph>
            La Plataforma actúa únicamente como proveedor tecnológico y no como emisor del contenido generado por el Usuario.
            </Typography>

            <Typography variant="h6" gutterBottom><strong>5. SUSPENSIÓN Y TERMINACIÓN</strong></Typography>
            <Typography paragraph>
            La Plataforma podrá suspender o cancelar el acceso del Usuario de forma inmediata y sin previo aviso si detecta actividades que puedan infringir la ley o estos Términos.
            </Typography>
            <Typography paragraph>
            La suspensión no genera derecho a reembolso ni indemnización alguna.
            </Typography>

            <Typography variant="h6" gutterBottom><strong>6. LIMITACIÓN DE RESPONSABILIDAD</strong></Typography>
            <Typography paragraph>
            La Plataforma se proporciona “tal cual” y “según disponibilidad”, sin garantías de funcionamiento ininterrumpido o libre de errores.
            </Typography>
            <Typography paragraph>
            En ningún caso la Plataforma será responsable por:
            </Typography>
            <Typography component="ul">
              <li>Bloqueos, suspensiones o restricciones impuestas por terceros.</li>
              <li>Pérdida de datos, ingresos o clientes.</li>
              <li>Daños directos o indirectos derivados del uso indebido del sistema.</li>
            </Typography>

            <Typography variant="h6" gutterBottom><strong>7. INDEMNIZACIÓN</strong></Typography>
            <Typography paragraph>
            El Usuario se compromete a indemnizar y mantener indemne a la Plataforma, sus propietarios y colaboradores frente a cualquier reclamación, demanda, multa o procedimiento legal derivado del uso indebido del servicio.
            </Typography>

            <Typography variant="h6" gutterBottom><strong>8. PROPIEDAD INTELECTUAL</strong></Typography>
            <Typography paragraph>
            El software, diseño, estructura, código y funcionalidades de la Plataforma son propiedad exclusiva del titular del servicio. Queda prohibida su copia, modificación, distribución o ingeniería inversa sin autorización expresa.
            </Typography>

            <Typography variant="h6" gutterBottom><strong>9. MODIFICACIONES</strong></Typography>
            <Typography paragraph>
            La Plataforma podrá modificar estos Términos en cualquier momento. El uso continuado del servicio implicará la aceptación de dichas modificaciones.
            </Typography>

            <Typography variant="h6" gutterBottom><strong>10. LEGISLACIÓN APLICABLE</strong></Typography>
            <Typography paragraph>
            Estos Términos se regirán por la legislación aplicable en la jurisdicción del titular de la Plataforma, sin perjuicio de las normas imperativas que resulten aplicables al Usuario.
            </Typography>

          <Box mt={3}>
            <Button 
              fullWidth 
              variant="contained" 
              color="primary" 
              onClick={() => setTermsModalOpen(false)}
            >
              Cerrar
            </Button>
          </Box>
        </DialogContent>
      </Dialog>

      {/* Método de procesamiento */}
      <Dialog open={processingModalOpen} maxWidth="sm" fullWidth>
        <DialogContent>
          <div className={classes.progressContainer}>
            <CircularProgress size={48} />
            <Typography variant="h6" className={classes.progressText}>
              {processingText}
            </Typography>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default SignUp;
