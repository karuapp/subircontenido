import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography,
  MenuItem
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  formContainer: {
    maxWidth: 600
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiProjetosPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("Esta empresa no tiene permiso para acceder a esta página.!");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
  }, []);

  const getProjectsEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/projects`;

  const postmanRequests = [
    {
      name: "Listar proyectos",
      method: "GET",
      url: getProjectsEndpoint(),
      description: "Devuelve los proyectos registrados en la empresa."
    },
    {
      name: "Buscar proyecto por ID",
      method: "GET",
      url: `${getProjectsEndpoint()}/1`,
      description: "Reemplaza el ID al final de la URL para buscar un proyecto específico."
    },
    {
      name: "Crear proyecto",
      method: "POST",
      url: getProjectsEndpoint(),
      description: "Crea un nuevo proyecto.",
      body: {
        name: "Proyecto de sitio web",
        description: "Desarrollo de sitio web institucional",
        clientId: 1,
        status: "active",
        startDate: "2026-01-01",
        endDate: "2026-03-01",
        userIds: [1, 2]
      }
    },
    {
      name: "Actualizar proyecto",
      method: "PUT",
      url: `${getProjectsEndpoint()}/1`,
      description: "Cambie el ID para actualizar el proyecto deseado.",
      body: {
        name: "Proyecto de sitio web (editado)",
        status: "completed"
      }
    },
    {
      name: "Eliminar proyecto",
      method: "DELETE",
      url: `${getProjectsEndpoint()}/1`,
      description: "Elimina permanentemente el proyecto y sus tareas."
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListProjects = async (token, status) => {
    try {
      const params = status ? `?status=${status}` : "";
      const { data } = await axios.get(`${getProjectsEndpoint()}${params}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult("Lista de proyectos", data);
      toast.success("¡Proyectos subidos!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowProject = async (token, projectId) => {
    try {
      const { data } = await axios.get(`${getProjectsEndpoint()}/${projectId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Proyecto ${projectId}`, data);
      toast.success("¡Proyecto cargado!");
    } catch (err) {
      toastError(err);
    }
  };

  const buildProjectPayload = (values) => {
    const payload = {
      name: values.name,
      description: values.description || null,
      clientId: values.clientId ? Number(values.clientId) : null,
      status: values.status || "draft",
      startDate: values.startDate || null,
      endDate: values.endDate || null,
      deliveryTime: values.deliveryTime || null,
      warranty: values.warranty || null,
      terms: values.terms || null
    };

    if (values.userIds) {
      try {
        payload.userIds = JSON.parse(values.userIds);
      } catch (error) {
        throw new Error("JSON Inválido en userIds.");
      }
    }

    return payload;
  };

  const handleCreateProject = async (values) => {
    try {
      const payload = buildProjectPayload(values);
      const { data } = await axios.post(getProjectsEndpoint(), payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Proyecto creado", data);
      toast.success("¡Proyecto creado correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleUpdateProject = async (values) => {
    try {
      const payload = buildProjectPayload(values);
      const { data } = await axios.put(`${getProjectsEndpoint()}/${values.projectId}`, payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Proyecto actualizado", data);
      toast.success("¡Proyecto actualizado correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleDeleteProject = async (values) => {
    try {
      await axios.delete(`${getProjectsEndpoint()}/${values.projectId}`, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Proyecto eliminado", { id: values.projectId, deleted: true });
      toast.success("¡Proyecto eliminado!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListAndShowForm = () => (
    <Formik
      initialValues={{ token: "", projectId: "", status: "" }}
      onSubmit={(values) => handleListProjects(values.token, values.status)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="ID del proyecto (opcional)"
                name="projectId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Estado (filtro)"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
              >
                <MenuItem value="">Todos</MenuItem>
                <MenuItem value="draft">Borrador</MenuItem>
                <MenuItem value="active">Activo</MenuItem>
                <MenuItem value="paused">En pausa</MenuItem>
                <MenuItem value="completed">Completado</MenuItem>
                <MenuItem value="cancelled">Cancelado</MenuItem>
              </Field>
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar todo"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.projectId) {
                    toast.error("Ingrese el ID del proyecto para buscar.");
                    return;
                  }
                  handleShowProject(values.token, values.projectId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        name: "",
        description: "",
        clientId: "",
        status: "draft",
        startDate: "",
        endDate: "",
        userIds: ""
      }}
      onSubmit={async (values, actions) => {
        await handleCreateProject(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Nombre del proyecto"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Descripción"
                name="description"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Cliente ID"
                name="clientId"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Estado"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
              >
                <MenuItem value="draft">Borrador</MenuItem>
                <MenuItem value="active">Activo</MenuItem>
                <MenuItem value="paused">En pausa</MenuItem>
                <MenuItem value="completed">Completado</MenuItem>
                <MenuItem value="cancelled">Cancelado</MenuItem>
              </Field>
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label='Usuarios (JSON array)'
                name="userIds"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2]'
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Fecha de inicio"
                name="startDate"
                type="date"
                variant="outlined"
                margin="dense"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Fecha de finalización"
                name="endDate"
                type="date"
                variant="outlined"
                margin="dense"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear proyecto"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        projectId: "",
        name: "",
        description: "",
        clientId: "",
        status: "",
        startDate: "",
        endDate: "",
        userIds: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateProject(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Proyecto ID"
                name="projectId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Descripción"
                name="description"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Estado"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
              >
                <MenuItem value="">No cambiar</MenuItem>
                <MenuItem value="draft">Borrador</MenuItem>
                <MenuItem value="active">Activo</MenuItem>
                <MenuItem value="paused">En pausa</MenuItem>
                <MenuItem value="completed">Completado</MenuItem>
                <MenuItem value="cancelled">Cancelado</MenuItem>
              </Field>
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Cliente ID"
                name="clientId"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label='Usuarios (JSON array)'
                name="userIds"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2]'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar proyecto"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderDeleteForm = () => (
    <Formik
      initialValues={{ token: "", projectId: "" }}
      onSubmit={async (values, actions) => {
        await handleDeleteProject(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Proyecto ID"
                name="projectId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                color="secondary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Eliminar proyecto"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de Proyectos</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Gestionar proyectos mediante API externa.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Volver a tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Resumen</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar proyectos:</b> GET {getProjectsEndpoint()}</li>
            <li><b>Buscar proyecto:</b> GET {getProjectsEndpoint()}/:id</li>
            <li><b>Crear proyecto:</b> POST {getProjectsEndpoint()}</li>
            <li><b>Actualizar proyecto:</b> PUT {getProjectsEndpoint()}/:id</li>
            <li><b>Eliminar proyecto:</b> DELETE {getProjectsEndpoint()}/:id</li>
          </ul>
          Enviar siempre el header <code>Authorization: Bearer {"{token}"}</code>.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="whatsapp - API de Projetos"
        requests={postmanRequests}
        filename="whatsapp-api-proyectos.json"
        helperText="Ingrese el token y haga clic en Descargar para importar a Postman."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Ver proyectos</Typography>
        <Typography color="textSecondary">
          Ingrese el token para ver todos los proyectos o agregue un ID de proyecto para buscar uno específico.
        </Typography>
        {renderListAndShowForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. Crear proyecto</Typography>
        <Typography color="textSecondary">
          Campo obligatorio: <b>name</b>. Os demais campos são opcionais.
        </Typography>
        {renderCreateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Actualizar proyecto</Typography>
        <Typography color="textSecondary">
          Introducir el <b>Proyecto ID</b> y envía los campos que deseas actualizar.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">4. Eliminar proyecto</Typography>
        <Typography color="textSecondary">
          Eliminar el proyecto y todas las tareas asociadas.
        </Typography>
        {renderDeleteForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">Resultado de la última prueba.</Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiProjetosPage;
