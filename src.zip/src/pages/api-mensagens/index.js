import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";

import { i18n } from "../../translate/i18n";
import {
  Box,
  Button,
  CircularProgress,
  Grid,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import toastError from "../../errors/toastError";
import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  elementMargin: {
    padding: theme.spacing(2)
  },
  formContainer: {
    maxWidth: 500
  },
  textRight: {
    textAlign: "right"
  }
}));

const ApiMensagensPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [formMessageTextData] = useState({
    token: "",
    number: "",
    body: "",
    userId: "",
    queueId: ""
  });
  const [formMessageMediaData] = useState({
    token: "",
    number: "",
    medias: "",
    body: "",
    userId: "",
    queueId: ""
  });
  const [file, setFile] = useState({});

  useEffect(() => {
    async function fetchData() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página! Te estamos redirigiendo.");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getEndpoint = () => {
    return process.env.REACT_APP_BACKEND_URL + "/api/messages/send";
  };

  const postmanRequests = [
    {
      name: "Enviar mensaje de texto",
      method: "POST",
      url: getEndpoint(),
      description: "Envía un mensaje de texto simple al número proporcionado.",
      body: {
        number: "001234567890",
        body: "¡Hola! Este es un mensaje de prueba.",
        userId: 1,
        queueId: 1,
        noRegister: true
      }
    },
    {
      name: "Enviar mensaje con contenido multimedia",
      method: "POST",
      url: getEndpoint(),
      description: "Envía contenido multimedia (imagen, PDF, etc.). El archivo debe adjuntarse mediante datos del formulario.",
      bodyMode: "formdata",
      formData: [
        { key: "number", value: "001234567890", type: "text" },
        { key: "body", value: "Archivo de prueba", type: "text" },
        { key: "userId", value: "1", type: "text" },
        { key: "queueId", value: "1", type: "text" },
        { key: "noRegister", value: "true", type: "text" },
        { key: "medias", src: "/ruta/para/archivo.jpg", type: "file" }
      ]
    }
  ];

  const handleSendTextMessage = async (values) => {
    const { number, body, userId, queueId } = values;
    const data = { number, body, userId, queueId, noRegister: true };
    try {
      await axios.request({
        url: getEndpoint(),
        method: "POST",
        data,
        headers: {
          "Content-type": "application/json",
          Authorization: `Bearer ${values.token}`
        }
      });
      toast.success("Mensaje enviado correctamente");
    } catch (err) {
      toastError(err);
    }
  };

  const handleSendMediaMessage = async (values) => {
    try {
      const firstFile = file[0];
      const data = new FormData();
      data.append("number", values.number);
      data.append("body", values.body ? values.body : firstFile.name);
      data.append("userId", values.userId);
      data.append("queueId", values.queueId);
      data.append("noRegister", "true");
      data.append("medias", firstFile);
      await axios.request({
        url: getEndpoint(),
        method: "POST",
        data,
        headers: {
          "Content-type": "multipart/form-data",
          Authorization: `Bearer ${values.token}`
        }
      });
      toast.success("Mensaje enviado correctamente");
    } catch (err) {
      toastError(err);
    }
  };

  const renderFormMessageText = () => (
    <Formik
      initialValues={formMessageTextData}
      enableReinitialize={true}
      onSubmit={(values, actions) => {
        setTimeout(async () => {
          await handleSendTextMessage(values);
          actions.setSubmitting(false);
          actions.resetForm();
        }, 400);
      }}
      className={classes.elementMargin}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label={i18n.t("messagesAPI.textMessage.token")}
                name="token"
                autoFocus
                variant="outlined"
                margin="dense"
                fullWidth
                className={classes.textField}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label={i18n.t("messagesAPI.textMessage.number")}
                name="number"
                variant="outlined"
                margin="dense"
                fullWidth
                className={classes.textField}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label={i18n.t("messagesAPI.textMessage.body")}
                name="body"
                variant="outlined"
                margin="dense"
                fullWidth
                className={classes.textField}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label={i18n.t("messagesAPI.textMessage.userId")}
                name="userId"
                variant="outlined"
                margin="dense"
                fullWidth
                className={classes.textField}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label={i18n.t("messagesAPI.textMessage.queueId")}
                name="queueId"
                variant="outlined"
                margin="dense"
                fullWidth
                className={classes.textField}
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                style={{
                  color: "white",
                  backgroundColor: "#FFA500",
                  boxShadow: "none",
                  borderRadius: "5px"
                }}
                variant="contained"
                className={classes.btnWrapper}
              >
                {isSubmitting ? (
                  <CircularProgress size={24} className={classes.buttonProgress} />
                ) : (
                  "Enviar"
                )}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderFormMessageMedia = () => (
    <Formik
      initialValues={formMessageMediaData}
      enableReinitialize={true}
      onSubmit={(values, actions) => {
        setTimeout(async () => {
          await handleSendMediaMessage(values);
          actions.setSubmitting(false);
          actions.resetForm();
          document.getElementById("api-mensagens-medias").files = null;
          document.getElementById("api-mensagens-medias").value = null;
        }, 400);
      }}
      className={classes.elementMargin}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label={i18n.t("messagesAPI.mediaMessage.token")}
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                className={classes.textField}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label={i18n.t("messagesAPI.mediaMessage.number")}
                name="number"
                variant="outlined"
                margin="dense"
                fullWidth
                className={classes.textField}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label={i18n.t("messagesAPI.textMessage.body")}
                name="body"
                variant="outlined"
                margin="dense"
                fullWidth
                className={classes.textField}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label={i18n.t("messagesAPI.textMessage.userId")}
                name="userId"
                variant="outlined"
                margin="dense"
                fullWidth
                className={classes.textField}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label={i18n.t("messagesAPI.textMessage.queueId")}
                name="queueId"
                variant="outlined"
                margin="dense"
                fullWidth
                className={classes.textField}
              />
            </Grid>
            <Grid item xs={12}>
              <input
                type="file"
                name="medias"
                id="api-mensagens-medias"
                required
                onChange={(e) => setFile(e.target.files)}
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                style={{
                  color: "white",
                  backgroundColor: "#437db5",
                  boxShadow: "none",
                  borderRadius: "5px"
                }}
                variant="contained"
                className={classes.btnWrapper}
              >
                {isSubmitting ? (
                  <CircularProgress size={24} className={classes.buttonProgress} />
                ) : (
                  "Enviar"
                )}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de mensajes</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Utilice los tokens generados para probar el envío de mensajes de texto y multimedia.
          </Typography>
        </div>
        <Button
          startIcon={<ReplyIcon />}
          variant="outlined"
          onClick={() => history.push("/messages-api")}
        >
          Voltar
        </Button>
      </Box>

      <ApiPostmanDownload
        collectionName="WhatsApp - API de mensajería"
        requests={postmanRequests}
        filename="whatsapp-api-mensajes.json"
        helperText="Introduce el token y haz clic en Descargar para importar los ejemplos a Postman."
      />
      <Box className="container" style={{ color: "rgba(255,255,255,0.8)" }}>
        <Typography variant="h6" gutterBottom>
          Resumen
        </Typography>
        <Typography variant="body2" gutterBottom>
          Usa tokens de cuenta para enviar mensajes de texto o multimedia a tus contactos de WhatsApp.
          Recuerde mantener el header <code>Authorization: Bearer {"{token}"}</code> en todas las solicitudes
        </Typography>
        <Box component="div" mt={2}>
          <ul style={{ lineHeight: 1.6 }}>
            <li>
              <b>Enviar texto:</b> POST {getEndpoint()} &mdash; Content-Type <code>application/json</code>
            </li>
            <li>
              <b>Enviar archivos multimedia:</b> POST {getEndpoint()} &mdash; Content-Type <code>multipart/form-data</code>
            </li>
            <li>
              Campos básicos: <code>number</code>, <code>body</code>, <code>userId</code>, <code>queueId</code>, <code>noRegister</code>
            </li>
          </ul>
        </Box>
      </Box>

      <Typography variant="h6" color="primary" className={classes.elementMargin}>
        {i18n.t("messagesAPI.API.methods.title")}
      </Typography>
      <Typography component="div">
        <ol>
          <li>{i18n.t("messagesAPI.API.methods.messagesText")}</li>
          <li>{i18n.t("messagesAPI.API.methods.messagesMidia")}</li>
        </ol>
      </Typography>

      <Typography variant="h6" color="primary" className={classes.elementMargin}>
        {i18n.t("messagesAPI.API.instructions.title")}
      </Typography>
      <Typography className={classes.elementMargin} component="div">
        <b>{i18n.t("messagesAPI.API.instructions.comments")}</b>
        <br />
        <ul>
          <li>{i18n.t("messagesAPI.API.instructions.comments1")}</li>
          <li>
            {i18n.t("messagesAPI.API.instructions.comments2")}
            <ul>
              <li>{i18n.t("messagesAPI.API.instructions.codeCountry")}</li>
              <li>{i18n.t("messagesAPI.API.instructions.code")}</li>
              <li>{i18n.t("messagesAPI.API.instructions.number")}</li>
            </ul>
          </li>
          <li>
            Los archivos subidos con la extensión  <b>.bin</b> o tipo
            <b> application/octet-stream</b> se convertirán automáticamente y se enviarán como <b>PDF</b>.
          </li>
        </ul>
      </Typography>

      <Typography variant="h6" color="primary" className={classes.elementMargin}>
        {i18n.t("messagesAPI.API.text.title")}
      </Typography>
      <Grid container>
        <Grid item xs={12} sm={6}>
          <Typography className={classes.elementMargin} component="div">
            <p>{i18n.t("messagesAPI.API.text.instructions")}</p>
            <b>Endpoint: </b> {getEndpoint()} <br />
            <b>Método: </b> POST <br />
            <b>Headers: </b> Authorization Bearer (token registrado) y Content-Type (application/json) <br />
            <b>Body: </b> {"{"} <br />
            "number": "001234567890" <br />
            "body": "Mensaje" <br />
            "userId": ID Usuario o "" <br />
            "queueId": ID Departamento o "" <br />
            "sendSignature": Firma en mensaje - true/false <br />
            "closeTicket": Cerrar ticket - true/false <br />
            {"}"}
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography className={classes.elementMargin}>
            <b>Prueba de envio</b>
          </Typography>
          {renderFormMessageText()}
        </Grid>
      </Grid>

      <Typography variant="h6" color="primary" className={classes.elementMargin}>
        {i18n.t("messagesAPI.API.media.title")}
      </Typography>
      <Grid container>
        <Grid item xs={12} sm={6}>
          <Typography className={classes.elementMargin} component="div">
            <p>{i18n.t("messagesAPI.API.media.instructions")}</p>
            <b>Endpoint: </b> {getEndpoint()} <br />
            <b>Método: </b> POST <br />
            <b>Headers: </b> Authorization Bearer (token registrado) e Content-Type (multipart/form-data) <br />
            <b>FormData: </b> <br />
            <ul>
              <li>
                <b>number: </b> 001234567890
              </li>
              <li>
                <b>body:</b> Message
              </li>
              <li>
                <b>userId:</b> ID usuario o ""
              </li>
              <li>
                <b>queueId:</b> ID del departamento o ""
              </li>
              <li>
                <b>medias: </b> archivo
              </li>
              <li>
                Si el archivo es <b>.bin</b> ou <b>application/octet-stream</b>,
                se convertirá automáticamente a <b>PDF</b> antes del envío.
              </li>
              <li>
                <b>sendSignature:</b> Firmar mensaje true/false
              </li>
              <li>
                <b>closeTicket:</b> Cerrar ticket true/false
              </li>
            </ul>
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography className={classes.elementMargin}>
            <b>Prueba de envío</b>
          </Typography>
          {renderFormMessageMedia()}
        </Grid>
      </Grid>
    </Paper>
  );
};

export default ApiMensagensPage;
