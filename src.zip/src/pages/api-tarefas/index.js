import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography,
  MenuItem
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  formContainer: {
    maxWidth: 600
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiTarefasPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página!");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
  }, []);

  const getTasksEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/project-tasks`;

  const postmanRequests = [
    {
      name: "Lista de tareas",
      method: "GET",
      url: getTasksEndpoint(),
      description: "Devuelve las tareas registradas. Utilice ?projectId=X para filtrar por proyecto."
    },
    {
      name: "Buscar tarea por ID",
      method: "GET",
      url: `${getTasksEndpoint()}/1`,
      description: "Reemplace el ID al final de la URL para buscar una tarea específica."
    },
    {
      name: "Crear tarea",
      method: "POST",
      url: getTasksEndpoint(),
      description: "Crea una nueva tarea en un proyecto.",
      body: {
        projectId: 1,
        title: "Desarrollar página de inicio",
        description: "Crea un diseño de página de inicio adaptable.",
        status: "pending",
        dueDate: "2026-02-15",
        assignedUserIds: [1, 2]
      }
    },
    {
      name: "Actualizar tarea",
      method: "PUT",
      url: `${getTasksEndpoint()}/1`,
      description: "Cambie el ID para actualizar la tarea deseada.",
      body: {
        title: "Desarrollar página de inicio (editado)",
        status: "completed"
      }
    },
    {
      name: "Eliminar tarea",
      method: "DELETE",
      url: `${getTasksEndpoint()}/1`,
      description: "Elimina permanentemente la tarea especificada."
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListTasks = async (token, projectId, status) => {
    try {
      const params = new URLSearchParams();
      if (projectId) params.append("projectId", projectId);
      if (status) params.append("status", status);
      const queryString = params.toString() ? `?${params.toString()}` : "";
      
      const { data } = await axios.get(`${getTasksEndpoint()}${queryString}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult("Lista de tareas", data);
      toast.success("¡Tareas cargadas!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowTask = async (token, taskId) => {
    try {
      const { data } = await axios.get(`${getTasksEndpoint()}/${taskId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Tarea ${taskId}`, data);
      toast.success("¡Tarea cargada!");
    } catch (err) {
      toastError(err);
    }
  };

  const buildTaskPayload = (values) => {
    const payload = {
      projectId: values.projectId ? Number(values.projectId) : undefined,
      title: values.title,
      description: values.description || null,
      status: values.status || "pending",
      order: values.order ? Number(values.order) : 0,
      startDate: values.startDate || null,
      dueDate: values.dueDate || null
    };

    if (values.assignedUserIds) {
      try {
        payload.assignedUserIds = JSON.parse(values.assignedUserIds);
      } catch (error) {
        throw new Error("JSON no válido en assignedUserIds.");
      }
    }

    return payload;
  };

  const handleCreateTask = async (values) => {
    try {
      const payload = buildTaskPayload(values);
      const { data } = await axios.post(getTasksEndpoint(), payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Tarea creada", data);
      toast.success("¡Tarea creada correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleUpdateTask = async (values) => {
    try {
      const payload = buildTaskPayload(values);
      delete payload.projectId; // El proyecto no se puede modificar.
      const { data } = await axios.put(`${getTasksEndpoint()}/${values.taskId}`, payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Tarea actualizada.", data);
      toast.success("¡Tarea actualizada correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleDeleteTask = async (values) => {
    try {
      await axios.delete(`${getTasksEndpoint()}/${values.taskId}`, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Tarea eliminada.", { id: values.taskId, deleted: true });
      toast.success("¡Tarea eliminada!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListAndShowForm = () => (
    <Formik
      initialValues={{ token: "", taskId: "", projectId: "", status: "" }}
      onSubmit={(values) => handleListTasks(values.token, values.projectId, values.status)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Tarea ID (opcional)"
                name="taskId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Proyecto ID (filtro)"
                name="projectId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                select
                label="Estado (filtro)"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
              >
                <MenuItem value="">Todos</MenuItem>
                <MenuItem value="pending">Pendiente</MenuItem>
                <MenuItem value="in_progress">En curso</MenuItem>
                <MenuItem value="review">En revisión</MenuItem>
                <MenuItem value="completed">Completado</MenuItem>
                <MenuItem value="cancelled">Cancelado</MenuItem>
              </Field>
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar todo"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.taskId) {
                    toast.error("Introduzca el ID de la tarea para buscar.");
                    return;
                  }
                  handleShowTask(values.token, values.taskId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        projectId: "",
        title: "",
        description: "",
        status: "pending",
        order: "",
        startDate: "",
        dueDate: "",
        assignedUserIds: ""
      }}
      onSubmit={async (values, actions) => {
        await handleCreateTask(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Proyecto ID"
                name="projectId"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Título de la tarea"
                name="title"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Descripción"
                name="description"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Estado"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
              >
                <MenuItem value="pending">Pendiente</MenuItem>
                <MenuItem value="in_progress">En curso</MenuItem>
                <MenuItem value="review">En revisión</MenuItem>
                <MenuItem value="completed">Completado</MenuItem>
                <MenuItem value="cancelled">Cancelado</MenuItem>
              </Field>
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Orden"
                name="order"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label='Usuarios (JSON array)'
                name="assignedUserIds"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2]'
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Fecha de inicio"
                name="startDate"
                type="date"
                variant="outlined"
                margin="dense"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Fecha de vencimiento"
                name="dueDate"
                type="date"
                variant="outlined"
                margin="dense"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear tarea"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        taskId: "",
        title: "",
        description: "",
        status: "",
        order: "",
        startDate: "",
        dueDate: "",
        assignedUserIds: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateTask(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Tarea ID"
                name="taskId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Título"
                name="title"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Descripción"
                name="description"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Estado"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
              >
                <MenuItem value="">No cambiar</MenuItem>
                <MenuItem value="pending">Pendiente</MenuItem>
                <MenuItem value="in_progress">En progreso</MenuItem>
                <MenuItem value="review">En revisión</MenuItem>
                <MenuItem value="completed">Completado</MenuItem>
                <MenuItem value="cancelled">Cancelado</MenuItem>
              </Field>
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Orden"
                name="order"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label='Usuarios (JSON array)'
                name="assignedUserIds"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2]'
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Fecha de inicio"
                name="startDate"
                type="date"
                variant="outlined"
                margin="dense"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Fecha límite"
                name="dueDate"
                type="date"
                variant="outlined"
                margin="dense"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar tarea"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderDeleteForm = () => (
    <Formik
      initialValues={{ token: "", taskId: "" }}
      onSubmit={async (values, actions) => {
        await handleDeleteTask(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Tarea ID"
                name="taskId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                color="secondary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Eliminar tarea"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de tareas del proyecto</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Gestiona las tareas del proyecto mediante una API externa.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Volver a tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Resumen</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar tareas:</b> GET {getTasksEndpoint()}</li>
            <li><b>Buscar tarea:</b> GET {getTasksEndpoint()}/:id</li>
            <li><b>Crear tarea:</b> POST {getTasksEndpoint()}</li>
            <li><b>Actualizar tarea:</b> PUT {getTasksEndpoint()}/:id</li>
            <li><b>Eliminar tarea:</b> DELETE {getTasksEndpoint()}/:id</li>
          </ul>
          Enviar siempre header <code>Authorization: Bearer {"{token}"}</code>.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="whatsapp - API de Tareas"
        requests={postmanRequests}
        filename="whatsapp-api-tareas.json"
        helperText="Introduce el token y haz clic en Descargar para importarlo a Postman."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Ver tareas</Typography>
        <Typography color="textSecondary">
          Introduce el token para listar. Usa el ID del proyecto y el estado para filtrar.
        </Typography>
        {renderListAndShowForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. Crear tarea</Typography>
        <Typography color="textSecondary">
          Campos obligatorios: <b>projectId</b> y <b>title</b>.
        </Typography>
        {renderCreateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Actualizar tarea</Typography>
        <Typography color="textSecondary">
          Introduzca el <b>Task ID</b> y envía los campos que deseas actualizar.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">4. Eliminar tarea </Typography>
        <Typography color="textSecondary">
          Eliminar la tarea permanentemente. 
        </Typography>
        {renderDeleteForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">Resultado de la última prueba </Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiTarefasPage;
