import React, { useState, useEffect, useContext, useMemo } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  elementMargin: {
    padding: theme.spacing(2)
  },
  formContainer: {
    maxWidth: 520
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiTagsPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página!");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getTagsEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/tags`;

  const postmanRequests = useMemo(
    () => [
      {
        name: "Etiquetas de lista",
        method: "GET",
        url: getTagsEndpoint(),
        description: "Devuelve la lista de etiquetas registradas, con compatibilidad con paginación y filtros."
      },
      {
        name: "Buscar etiqueta por ID",
        method: "GET",
        url: `${getTagsEndpoint()}/1`,
        description: "Reemplaza el ID al final de la URL para buscar una etiqueta específica."
      },
      {
        name: "Crear etiqueta",
        method: "POST",
        url: getTagsEndpoint(),
        description: "Crea una nueva etiqueta (kanban, colores y carriles opcionales).",
        body: {
          name: "Nuevos clientes potenciales",
          color: "#5F72BE",
          kanban: 0
        }
      },
      {
        name: "Actualizar etiqueta",
        method: "PUT",
        url: `${getTagsEndpoint()}/1`,
        description: "Actualiza los atributos de una etiqueta existente.",
        body: {
          name: "Nuevos clientes potenciales (calificados)",
          color: "#6B8DD6",
          kanban: 0
        }
      },
      {
        name: "Eliminar etiqueta",
        method: "DELETE",
        url: `${getTagsEndpoint()}/1`,
        description: "Elimina permanentemente la etiqueta especificada en la ruta."
      }
    ],
    []
  );

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const cleanContact = (contact = {}) => ({
    id: contact.id,
    name: contact.name,
    number: contact.number,
    email: contact.email,
    profilePicUrl: contact.profilePicUrl,
    channel: contact.channel
  });

  const cleanTag = (tag = {}) => ({
    id: tag.id,
    name: tag.name,
    color: tag.color,
    kanban: tag.kanban,
    timeLane: tag.timeLane,
    nextLaneId: tag.nextLaneId,
    rollbackLaneId: tag.rollbackLaneId,
    greetingMessageLane: tag.greetingMessageLane,
    contactCount: tag.contacts ? tag.contacts.length : undefined,
    contacts: tag.contacts ? tag.contacts.map(cleanContact) : undefined
  });

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const buildTagPayload = (values) => {
    const payload = {
      name: values.name,
      color: values.color || "#A4CCCC",
      kanban: values.kanban ? Number(values.kanban) : 0,
      greetingMessageLane: values.greetingMessageLane || ""
    };

    const numericFields = ["timeLane", "nextLaneId", "rollbackLaneId"];
    numericFields.forEach((field) => {
      if (values[field] !== "" && values[field] !== null && values[field] !== undefined) {
        payload[field] = Number(values[field]);
      }
    });

    return payload;
  };

  const handleListTags = async (values) => {
    try {
      const params = {};

      if (values.searchParam) params.searchParam = values.searchParam;
      if (values.pageNumber) params.pageNumber = values.pageNumber;
      if (values.limit) params.limit = values.limit;
      if (values.kanban) params.kanban = values.kanban;

      const { data } = await axios.get(getTagsEndpoint(), {
        headers: { Authorization: `Bearer ${values.token}` },
        params
      });
      const cleanPayload = {
        count: data.count,
        hasMore: data.hasMore,
        tags: (data.tags || []).map(cleanTag)
      };
      saveResult("Lista de etiquetas", cleanPayload);
      toast.success("¡Etiquetas cargadas!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowTag = async (token, tagId) => {
    try {
      const { data } = await axios.get(`${getTagsEndpoint()}/${tagId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Etiqueta ${tagId}`, cleanTag(data));
      toast.success("¡Etiqueta cargada!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleCreateTag = async (values) => {
    try {
      const payload = buildTagPayload(values);
      const { data } = await axios.post(getTagsEndpoint(), payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Etiqueta creada", cleanTag(data));
      toast.success("Etiqueta creada correctamente.");
    } catch (err) {
      toastError(err);
    }
  };

  const handleUpdateTag = async (values) => {
    try {
      const payload = buildTagPayload(values);
      const { data } = await axios.put(`${getTagsEndpoint()}/${values.tagId}`, payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Etiqueta actualizada.", cleanTag(data));
      toast.success("Etiqueta actualizada correctamente.");
    } catch (err) {
      toastError(err);
    }
  };

  const handleDeleteTag = async (values) => {
    try {
      await axios.delete(`${getTagsEndpoint()}/${values.tagId}`, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Etiqueta eliminada.", { id: values.tagId, deleted: true });
      toast.success("Etiqueta eliminada.");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListAndShowForm = () => (
    <Formik
      initialValues={{
        token: "",
        tagId: "",
        searchParam: "",
        pageNumber: "",
        limit: "",
        kanban: ""
      }}
      onSubmit={async (values, actions) => {
        await handleListTags(values);
        actions.setSubmitting(false);
      }}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="ID de etiqueta (opcional)"
                name="tagId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Buscar"
                name="searchParam"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="Nombre o color"
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Página"
                name="pageNumber"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Límite"
                name="limit"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Kanban (0 o 1)"
                name="kanban"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Etiquetas de lista"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.tagId) {
                    toast.error("Ingrese el ID de la etiqueta para buscar un registro.");
                    return;
                  }
                  handleShowTag(values.token, values.tagId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        name: "",
        color: "",
        kanban: "",
        timeLane: "",
        nextLaneId: "",
        greetingMessageLane: "",
        rollbackLaneId: ""
      }}
      onSubmit={async (values, actions) => {
        await handleCreateTag(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Color (hex)"
                name="color"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="#A4CCCC"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Kanban (0 o 1)"
                name="kanban"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="0"
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Tiempo en el carril (minutos)"
                name="timeLane"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Siguiente columna ID"
                name="nextLaneId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Rollback columna ID"
                name="rollbackLaneId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de saludo"
                name="greetingMessageLane"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear etiqueta"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        tagId: "",
        name: "",
        color: "",
        kanban: "",
        timeLane: "",
        nextLaneId: "",
        greetingMessageLane: "",
        rollbackLaneId: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateTag(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Etiqueta ID"
                name="tagId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Color"
                name="color"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Kanban"
                name="kanban"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Tiempo"
                name="timeLane"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Siguiente columna ID"
                name="nextLaneId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Rollback Columna ID"
                name="rollbackLaneId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de saludo"
                name="greetingMessageLane"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar etiqueta"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderDeleteForm = () => (
    <Formik
      initialValues={{
        token: "",
        tagId: ""
      }}
      onSubmit={async (values, actions) => {
        await handleDeleteTag(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Etiqueta ID"
                name="tagId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Eliminar etiqueta"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <div>
          <Typography variant="h5" gutterBottom>
            API de Tags
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Registra y organiza etiquetas externas para segmentar contactos y flujos Kanban.
          </Typography>
        </div>
        <Button
          startIcon={<ReplyIcon />}
          variant="outlined"
          onClick={() => history.push("/messages-api")}
        >
          Volver a la documentación
        </Button>
      </Box>
      <Divider />

      <ApiPostmanDownload
        collectionName="whatsapp - API de Etiquetas"
        requests={postmanRequests}
        filename="whatsapp-api-etiquetas.json"
        helperText="Ingrese el token y haga clic en "Descargar" para importarlo a Postman."
      />
      <Box className={classes.elementMargin}>
        <Typography variant="h6" gutterBottom>
          Resumen
        </Typography>
        <Typography color="textSecondary">
          Cree etiquetas para organizar contactos y pipelines Kanban usando los tokens de esta cuenta.
        </Typography>
        <Box mt={2} component="div" color="textSecondary">
          <ul>
            <li><b>Etiquetas de lista:</b> GET {getTagsEndpoint()}</li>
            <li><b>Buscar etiqueta:</b> GET {getTagsEndpoint()}/:id</li>
            <li><b>Crear etiqueta:</b> POST {getTagsEndpoint()}</li>
            <li><b>Actualizar etiqueta:</b> PUT {getTagsEndpoint()}/:id</li>
            <li><b>Eliminar etiqueta:</b> DELETE {getTagsEndpoint()}/:id</li>
          </ul>
          Enviar siempre header <code>Authorization: Bearer {"{token}"}</code> con un token activo generado en la página API.
        </Box>
      </Box>
      <Box className={classes.elementMargin}>
        <Typography variant="h6" gutterBottom>
          Lista de etiquetas
        </Typography>
        {renderListAndShowForm()}
      </Box>
      <Box className={classes.elementMargin}>
        <Typography variant="h6" gutterBottom>
          Crear etiqueta
        </Typography>
        {renderCreateForm()}
      </Box>
      <Box className={classes.elementMargin}>
        <Typography variant="h6" gutterBottom>
          Actualizar etiqueta
        </Typography>
        {renderUpdateForm()}
      </Box>
      <Box className={classes.elementMargin}>
        <Typography variant="h6" gutterBottom>
          Eliminar etiqueta
        </Typography>
        {renderDeleteForm()}
      </Box>
      {testResult && (
        <Box className={classes.elementMargin}>
          <Typography variant="h6" gutterBottom>
            Resultado
          </Typography>
          <Paper className={classes.resultBox}>
            <Typography variant="body1" gutterBottom>
              {testResult.title}
            </Typography>
            <Typography variant="body2" gutterBottom>
              {testResult.payload}
            </Typography>
            <Typography variant="body2" gutterBottom>
              {testResult.timestamp}
            </Typography>
          </Paper>
        </Box>
      )}
    </Paper>
  );
};

export default ApiTagsPage;
