import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  formContainer: {
    maxWidth: 520
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiServicosPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página!");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getServicesEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/services`;

  const postmanRequests = [
    {
      name: "Listar servicios",
      method: "GET",
      url: getServicesEndpoint(),
      description: "Devuelve los servicios externos registrados."
    },
    {
      name: "Buscar servicio por ID",
      method: "GET",
      url: `${getServicesEndpoint()}/1`,
      description: "Reemplaza el ID al final de la URL para buscar un servicio específico."
    },
    {
      name: "Crear servicio",
      method: "POST",
      url: getServicesEndpoint(),
      description: "Crea un nuevo servicio externo.",
      body: {
        nome: "Consultoría Premium",
        descricao: "Sesión de consultoría de 1 hora",
        valorOriginal: 250.0,
        possuiDesconto: true,
        valorComDesconto: 199.9
      }
    },
    {
      name: "Actualizar servicio",
      method: "PUT",
      url: `${getServicesEndpoint()}/1`,
      description: "Cambia el ID para actualizar el servicio deseado.",
      body: {
        nome: "Consultoría Premium (actualizada)",
        possuiDesconto: false
      }
    },
    {
      name: "Eliminar servicio",
      method: "DELETE",
      url: `${getServicesEndpoint()}/1`,
      description: "Elimina permanentemente el servicio especificado en la ruta."
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const cleanService = (service) => ({
    id: service.id,
    nome: service.nome,
    descricao: service.descricao,
    valorOriginal: Number(service.valorOriginal || 0),
    possuiDesconto: Boolean(service.possuiDesconto),
    valorComDesconto: service.valorComDesconto ? Number(service.valorComDesconto) : null,
    createdAt: service.createdAt,
    updatedAt: service.updatedAt
  });

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListServices = async (token) => {
    try {
      const { data } = await axios.get(getServicesEndpoint(), {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult("Lista de servicios", {
        ...data,
        services: data.services?.map(cleanService)
      });
      toast.success("¡Servicios cargados!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowService = async (token, serviceId) => {
    try {
      const { data } = await axios.get(`${getServicesEndpoint()}/${serviceId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Servicio ${serviceId}`, cleanService(data));
      toast.success("¡Servicio cargado!");
    } catch (err) {
      toastError(err);
    }
  };

  const buildServicePayload = (values) => {
    const payload = {
      nome: values.nome,
      descricao: values.descricao || null,
      valorOriginal: values.valorOriginal ? Number(values.valorOriginal) : undefined,
      possuiDesconto: values.possuiDesconto === "true" || values.possuiDesconto === true,
      valorComDesconto: values.valorComDesconto ? Number(values.valorComDesconto) : null
    };

    if (!values.nome) {
      throw new Error("El nombre es obligatorio.");
    }
    if (!values.valorOriginal) {
      throw new Error("El valor original es obligatorio.");
    }

    return payload;
  };

  const handleCreateService = async (values) => {
    try {
      const payload = buildServicePayload(values);
      const { data } = await axios.post(getServicesEndpoint(), payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Servicio creado", cleanService(data));
      toast.success("¡Servicio creado correctamente!");
    } catch (err) {
      if (err.message?.includes("obrigatório")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleUpdateService = async (values) => {
    try {
      const payload = {
        ...buildServicePayload(values),
        possuiDesconto:
          values.possuiDesconto === "" ? undefined : values.possuiDesconto === "true" || values.possuiDesconto === true,
        valorComDesconto: values.valorComDesconto
          ? Number(values.valorComDesconto)
          : values.valorComDesconto === ""
            ? undefined
            : null
      };

      const { data } = await axios.put(`${getServicesEndpoint()}/${values.serviceId}`, payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Servicio actualizado", cleanService(data));
      toast.success("¡Servicio actualizado correctamente!");
    } catch (err) {
      if (err.message?.includes("obrigatório")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleDeleteService = async (values) => {
    try {
      await axios.delete(`${getServicesEndpoint()}/${values.serviceId}`, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Servicio eliminado", { id: values.serviceId, deleted: true });
      toast.success("¡Servicio eliminado!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListAndShowForm = () => (
    <Formik
      initialValues={{ token: "", serviceId: "" }}
      onSubmit={(values) => handleListServices(values.token)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="ID de servicio (opcional para búsqueda)"
                name="serviceId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar todos"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.serviceId) {
                    toast.error("Ingrese el ID de servicio para buscar un registro.");
                    return;
                  }
                  handleShowService(values.token, values.serviceId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        nome: "",
        descricao: "",
        valorOriginal: "",
        possuiDesconto: "false",
        valorComDesconto: ""
      }}
      onSubmit={async (values, actions) => {
        await handleCreateService(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre"
                name="nome"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Valor original"
                name="valorOriginal"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Descripción"
                name="descricao"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="¿Hay algún descuento? (true/false)"
                name="possuiDesconto"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="false"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Precio con descuento"
                name="valorComDesconto"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear servicio"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        serviceId: "",
        nome: "",
        descricao: "",
        valorOriginal: "",
        possuiDesconto: "",
        valorComDesconto: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateService(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Servicio ID"
                name="serviceId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Nombre"
                name="nome"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Precio original"
                name="valorOriginal"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Descripción"
                name="descricao"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="¿Hay algún descuento? (true/false)"
                name="possuiDesconto"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Precio con descuento"
                name="valorComDesconto"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "actualización del Servicio"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderDeleteForm = () => (
    <Formik
      initialValues={{ token: "", serviceId: "" }}
      onSubmit={async (values, actions) => {
        await handleDeleteService(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Servicio ID"
                name="serviceId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                color="secondary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Eliminar servicio"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de Servicios</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Genere, consulte y sincronice servicios externos utilizando los tokens de esta cuenta.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Voltar para tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Resumen</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar servicios:</b> GET {getServicesEndpoint()}</li>
            <li><b>Buscar servicio:</b> GET {getServicesEndpoint()}/:id</li>
            <li><b>Crear servicio:</b> POST {getServicesEndpoint()}</li>
            <li><b>Actualizar servicio:</b> PUT {getServicesEndpoint()}/:id</li>
            <li><b>Eliminar servicio:</b> DELETE {getServicesEndpoint()}/:id</li>
          </ul>
          Enviar siempre header <code>Authorization: Bearer {"{token}"}</code> con un token activo generado en la página API.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="whatsapp - API de Servicios"
        requests={postmanRequests}
        filename="whatsapp-api-servicios.json"
        helperText="Introduce el token y haz clic en Descargar para importarlo a Postman.."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Ver servicios</Typography>
        <Typography color="textSecondary">
          Introduce solo el token para ver todos los servicios o añade un ID de servicio para buscar un registro específico.
        </Typography>
        {renderListAndShowForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. Crear servicio</Typography>
        <Typography color="textSecondary">
          Campos mínimos: <b>nombre</b>, <b>valorOriginal</b>. Utilice los campos de descuento cuando sea necesario.
        </Typography>
        {renderCreateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Actualizar servicio</Typography>
        <Typography color="textSecondary">
          Ingrese el <b>Servicio ID</b> Devuelto por la creación/publicación, y envíe los campos que desee actualizar.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">4. Eliminar servicio</Typography>
        <Typography color="textSecondary">
          Esta operación elimina el registro de forma permanente. Úselo con precaución.
        </Typography>
        {renderDeleteForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">Resultado de la última prueba</Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiServicosPage;
