import React, { useEffect, useMemo, useState } from "react";
import {
  Box,
  Typography,
  Paper,
  Grid,
  TextField,
  MenuItem,
  Switch,
  FormControlLabel,
  Button,
  IconButton,
  Tooltip,
  Divider,
  CircularProgress,
  Chip,
  Tabs,
  Tab
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import RefreshIcon from "@material-ui/icons/Refresh";
import AddIcon from "@material-ui/icons/Add";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";
import SaveIcon from "@material-ui/icons/Save";
import CodeIcon from "@material-ui/icons/Code";
import { toast } from "react-toastify";

import {
  deleteCompanyIntegration,
  listCompanyIntegrations,
  upsertCompanyIntegration,
  upsertIntegrationFieldMaps
} from "../../services/companyIntegrationSettings";
import toastError from "../../errors/toastError";

const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3),
    minHeight: "100vh",
    backgroundColor: "#f5f7fb",
    display: "flex",
    flexDirection: "column",
    gap: theme.spacing(3)
  },
  header: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: theme.spacing(2)
  },
  card: {
    padding: theme.spacing(3),
    borderRadius: 16
  },
  integrationList: {
    display: "flex",
    flexDirection: "column",
    gap: theme.spacing(1.5)
  },
  integrationItem: {
    padding: theme.spacing(2),
    borderRadius: 14,
    border: "1px solid #e2e8f0",
    backgroundColor: "#fff",
    cursor: "pointer",
    transition: "border-color 0.2s ease, box-shadow 0.2s ease",
    "&:hover": {
      borderColor: theme.palette.primary.main,
      boxShadow: "0 10px 30px rgba(15,23,42,0.08)"
    },
    "&.active": {
      borderColor: theme.palette.primary.main,
      boxShadow: "0 10px 30px rgba(15,23,42,0.12)"
    }
  },
  fieldMapsContainer: {
    display: "flex",
    flexDirection: "column",
    gap: theme.spacing(2)
  },
  fieldMapRow: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr 80px",
    gap: theme.spacing(1),
    alignItems: "center",
    [theme.breakpoints.down("xs")]: {
      gridTemplateColumns: "1fr",
      "& > div:last-child": {
        display: "flex",
        justifyContent: "flex-end"
      }
    }
  },
  tokenBox: {
    padding: theme.spacing(2),
    borderRadius: 12,
    backgroundColor: "#f8fafc",
    border: "1px solid #e2e8f0",
    fontFamily: "monospace",
    wordBreak: "break-all",
    fontSize: "0.85rem"
  },
  testOutput: {
    padding: theme.spacing(2),
    borderRadius: 12,
    border: "1px solid #e2e8f0",
    backgroundColor: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "monospace",
    minHeight: 160,
    overflow: "auto"
  },
  tabs: {
    marginTop: theme.spacing(2)
  }
}));

const PROVIDER_OPTIONS = [
  { value: "custom", label: "Custom API" },
  { value: "wordpress", label: "WordPress / Woo" },
  { value: "shopify", label: "Shopify" },
  { value: "n8n", label: "n8n Webhook" }
];

const CRM_FIELD_OPTIONS = [
  "name",
  "email",
  "phone",
  "document",
  "address",
  "city",
  "state",
  "zipCode",
  "notes"
];

const DEFAULT_FORM = {
  id: null,
  name: "",
  provider: "custom",
  baseUrl: "",
  apiKey: "",
  apiSecret: "",
  webhookSecret: "",
  metadata: "",
  active: true
};

const DEFAULT_TEST_PAYLOAD = `{
  "nome": "Maria lopez",
  "email": "maria@ejemplo.com",
  "telefone": "+001234567890",
  "cpf": "123.456.789-00",
  "endereco": "direccion, 123"
}`;

const IntegrationSettings = () => {
  const classes = useStyles();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(DEFAULT_FORM);
  const [fieldMaps, setFieldMaps] = useState([]);
  const [testPayload, setTestPayload] = useState(DEFAULT_TEST_PAYLOAD);
  const [testResult, setTestResult] = useState("");
  const [tab, setTab] = useState(0);

  const editing = Boolean(form.id);

  const sortedRecords = useMemo(
    () => [...records].sort((a, b) => a.name.localeCompare(b.name)),
    [records]
  );

  const fetchRecords = async () => {
    try {
      setLoading(true);
      const data = await listCompanyIntegrations();
      setRecords(Array.isArray(data) ? data : []);
    } catch (err) {
      toastError(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecords();
  }, []);

  const handleChange = field => event => {
    let value;
    if (field === "active") {
      value = event.target.checked;
    } else {
      value = event.target.value;
    }
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const resetForm = () => {
    setForm(DEFAULT_FORM);
    setFieldMaps([]);
    setTestResult("");
    setTab(0);
  };

  const handleEdit = integration => {
    setForm({
      id: integration.id,
      name: integration.name,
      provider: integration.provider || "custom",
      baseUrl: integration.baseUrl || "",
      apiKey: integration.apiKey || "",
      apiSecret: integration.apiSecret || "",
      webhookSecret: integration.webhookSecret || "",
      metadata: integration.metadata
        ? JSON.stringify(integration.metadata, null, 2)
        : "",
      active: integration.active
    });
    setFieldMaps(
      (integration.fieldMaps || []).map(map => ({
        id: map.id,
        externalField: map.externalField,
        crmField: map.crmField || "",
        transformExpression: map.transformExpression || "",
        options: map.options || {}
      }))
    );
    setTestResult("");
    setTab(0);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSubmit = async () => {
    if (!form.name) {
      toast.error("Proporcione el nombre de la integración.");
      return;
    }

    let parsedMetadata;
    if (form.metadata) {
      try {
        parsedMetadata = JSON.parse(form.metadata);
      } catch (err) {
        toast.error("JSON de metadatos no válido.");
        return;
      }
    }

    try {
      setSaving(true);
      const payload = await upsertCompanyIntegration({
        id: form.id,
        name: form.name,
        provider: form.provider,
        baseUrl: form.baseUrl,
        apiKey: form.apiKey,
        apiSecret: form.apiSecret,
        webhookSecret: form.webhookSecret,
        metadata: parsedMetadata,
        active: form.active
      });

      toast.success(editing ? "Integración actualizada." : "Integración creada.");
      setForm(prev => ({ ...prev, id: payload.id }));
      if (!editing) {
        fetchRecords();
      } else {
        setRecords(prev =>
          prev.map(item => (item.id === payload.id ? payload : item))
        );
      }
    } catch (err) {
      toastError(err);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async integration => {
    if (!window.confirm("¿Desea eliminar esta integración?")) return;
    try {
      await deleteCompanyIntegration(integration.id);
      toast.success("Integración eliminada.");
      if (form.id === integration.id) {
        resetForm();
      }
      fetchRecords();
    } catch (err) {
      toastError(err);
    }
  };

  const handleAddFieldMap = () => {
    setFieldMaps(prev => [
      ...prev,
      {
        tempId: Math.random().toString(36).substring(2, 9),
        externalField: "",
        crmField: "",
        transformExpression: ""
      }
    ]);
  };

  const handleChangeFieldMap = (index, field, value) => {
    setFieldMaps(prev => {
      const copy = [...prev];
      copy[index] = {
        ...copy[index],
        [field]: value
      };
      return copy;
    });
  };

  const handleRemoveFieldMap = index => {
    setFieldMaps(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleSaveFieldMaps = async () => {
    if (!form.id) {
      toast.error("Guarde la integración antes de asignar los campos.");
      return;
    }

    try {
      const payload = fieldMaps.map(map => ({
        id: map.id,
        externalField: map.externalField,
        crmField: map.crmField || null,
        transformExpression: map.transformExpression || null
      }));

      const data = await upsertIntegrationFieldMaps(form.id, payload);
      setFieldMaps(
        data.map(map => ({
          id: map.id,
          externalField: map.externalField,
          crmField: map.crmField || "",
          transformExpression: map.transformExpression || ""
        }))
      );
      toast.success("Asignación guardada.");
      fetchRecords();
    } catch (err) {
      toastError(err);
    }
  };

  const applyMapping = () => {
    if (!fieldMaps.length) {
      toast.info("Agregue al menos una asignación.");
      return;
    }
    try {
      const payload = JSON.parse(testPayload);
      const output = {};

      fieldMaps.forEach(map => {
        if (!map.crmField) return;
        const value = payload[map.externalField];
        if (typeof value !== "undefined") {
          output[map.crmField] = value;
        }
      });

      setTestResult(JSON.stringify(output, null, 2));
    } catch (err) {
      toast.error("JSON de prueba no válido.");
    }
  };

  const handleTabChange = (_, value) => setTab(value);

  return (
    <Box className={classes.root}>
      <Box className={classes.header}>
        <Box>
          <Typography variant="h5" gutterBottom>
            Conectores de clientes
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Configure integrações externas, personalize o mapeamento dos campos e teste o fluxo antes de liberar para produção.
          </Typography>
        </Box>
        <Box display="flex" alignItems="center" gap={8}>
          <Tooltip title="Atualizar lista">
            <span>
              <IconButton onClick={fetchRecords} disabled={loading}>
                <RefreshIcon />
              </IconButton>
            </span>
          </Tooltip>
          <Tooltip title="Nueva integración">
            <span>
              <Button
                startIcon={<AddIcon />}
                variant="contained"
                color="primary"
                onClick={resetForm}
              >
                Nuevo conector
              </Button>
            </span>
          </Tooltip>
        </Box>
      </Box>

      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Paper className={classes.card} elevation={0}>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography variant="h6">Integraciones</Typography>
              {loading && <CircularProgress size={18} />}
            </Box>
            <Divider style={{ margin: "16px 0" }} />
            <Box className={classes.integrationList}>
              {sortedRecords.length === 0 && !loading && (
                <Typography variant="body2" color="textSecondary">
                  Aún no hay integraciones registradas.
                </Typography>
              )}
              {sortedRecords.map(integration => (
                <Box
                  key={integration.id}
                  className={`${classes.integrationItem} ${
                    form.id === integration.id ? "active" : ""
                  }`}
                  onClick={() => handleEdit(integration)}
                >
                  <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Box>
                      <Typography variant="subtitle1">{integration.name}</Typography>
                      <Typography variant="caption" color="textSecondary">
                        {integration.provider || "Custom"}
                      </Typography>
                    </Box>
                    <Chip
                      size="small"
                      label={integration.active ? "Activo" : "Inactivo"}
                      style={{
                        backgroundColor: integration.active ? "#ecfdf5" : "#fee2e2",
                        color: integration.active ? "#047857" : "#b91c1c",
                        fontWeight: 600
                      }}
                    />
                  </Box>
                  {integration.baseUrl && (
                    <Box mt={1} className={classes.tokenBox}>
                      {integration.baseUrl}
                    </Box>
                  )}
                  <Box display="flex" justifyContent="flex-end" gap={8} mt={1}>
                    <Button
                      size="small"
                      color="primary"
                      onClick={e => {
                        e.stopPropagation();
                        handleEdit(integration);
                      }}
                    >
                      Editar
                    </Button>
                    <Tooltip title="Excluir">
                      <IconButton
                        size="small"
                        onClick={e => {
                          e.stopPropagation();
                          handleDelete(integration);
                        }}
                      >
                        <DeleteOutlineIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Box>
              ))}
            </Box>
          </Paper>
        </Grid>

        <Grid item xs={12} md={8}>
          <Paper className={classes.card} elevation={0}>
            <Typography variant="h6" gutterBottom>
              {editing ? "Editar integración" : "Nueva integración"}
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <TextField
                  label="Nombre"
                  fullWidth
                  variant="outlined"
                  value={form.name}
                  onChange={handleChange("name")}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  select
                  label="Proveedor"
                  fullWidth
                  variant="outlined"
                  value={form.provider}
                  onChange={handleChange("provider")}
                >
                  {PROVIDER_OPTIONS.map(option => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  label="Base URL"
                  fullWidth
                  variant="outlined"
                  value={form.baseUrl}
                  onChange={handleChange("baseUrl")}
                  placeholder="https://api.exemplo.com"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  label="API Key"
                  fullWidth
                  variant="outlined"
                  value={form.apiKey}
                  onChange={handleChange("apiKey")}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  label="API Secret"
                  fullWidth
                  variant="outlined"
                  value={form.apiSecret}
                  onChange={handleChange("apiSecret")}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  label="Webhook Secret"
                  fullWidth
                  variant="outlined"
                  value={form.webhookSecret}
                  onChange={handleChange("webhookSecret")}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={form.active}
                      onChange={handleChange("active")}
                      color="primary"
                    />
                  }
                  label="Integración activa"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  label="Metadata (JSON)"
                  fullWidth
                  multiline
                  rows={3}
                  variant="outlined"
                  value={form.metadata}
                  onChange={handleChange("metadata")}
                  placeholder='{"region":"hn","customField":"valor"}'
                />
              </Grid>
            </Grid>
            <Box mt={3} display="flex" justifyContent="flex-end" gap={16}>
              {editing && (
                <Button onClick={resetForm} disabled={saving}>
                  Cancelar
                </Button>
              )}
              <Button
                color="primary"
                variant="contained"
                onClick={handleSubmit}
                startIcon={<SaveIcon />}
                disabled={saving}
              >
                {saving ? "Guardando..." : "Guardar integración"}
              </Button>
            </Box>
          </Paper>

          <Paper className={classes.card} elevation={0} style={{ marginTop: 24 }}>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography variant="h6">Mapeo de campos</Typography>
              <Button
                startIcon={<AddIcon />}
                variant="outlined"
                color="primary"
                onClick={handleAddFieldMap}
                disabled={!editing}
              >
                Adicionar campo
              </Button>
            </Box>
            <Typography variant="body2" color="textSecondary" paragraph>
              Define cómo se guardará en el CRM cada campo enviado a través de la API externa. Puedes reutilizar campos existentes o guardar información específica en el campo de notas.
            </Typography>

            <Box className={classes.fieldMapsContainer}>
              {fieldMaps.length === 0 && (
                <Typography variant="body2" color="textSecondary">
                  No hay mapeo configurado.
                </Typography>
              )}

              {fieldMaps.map((map, index) => (
                <Box key={map.id || map.tempId || index} className={classes.fieldMapRow}>
                  <TextField
                    label="Campo externo"
                    variant="outlined"
                    value={map.externalField}
                    onChange={event =>
                      handleChangeFieldMap(index, "externalField", event.target.value)
                    }
                  />
                  <TextField
                    select
                    label="Campo en CRM"
                    variant="outlined"
                    value={map.crmField}
                    onChange={event =>
                      handleChangeFieldMap(index, "crmField", event.target.value)
                    }
                  >
                    <MenuItem value="">— Ignorar —</MenuItem>
                    {CRM_FIELD_OPTIONS.map(option => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                    <MenuItem value="notes">Notas</MenuItem>
                  </TextField>
                  <Box display="flex" justifyContent="center">
                    <Tooltip title="Remover linha">
                      <IconButton onClick={() => handleRemoveFieldMap(index)}>
                        <DeleteOutlineIcon />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Box>
              ))}
            </Box>
            <Box mt={2} display="flex" justifyContent="flex-end">
              <Button
                variant="contained"
                color="primary"
                onClick={handleSaveFieldMaps}
                disabled={!editing || fieldMaps.length === 0}
                startIcon={<SaveIcon />}
              >
                Guardar asignación
              </Button>
            </Box>
          </Paper>

          <Paper className={classes.card} elevation={0} style={{ marginTop: 24 }}>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Typography variant="h6">Laboratorio/Prueba</Typography>
              <Chip icon={<CodeIcon />} label="sandbox" size="small" color="primary" />
            </Box>
            <Typography variant="body2" color="textSecondary">
              Pegue la carga útil recibida de su sitio web, aplique la asignación y valide que los datos lleguen correctamente antes de liberar la integración a los clientes.
            </Typography>

            <Tabs
              value={tab}
              onChange={handleTabChange}
              indicatorColor="primary"
              textColor="primary"
              className={classes.tabs}
            >
              <Tab label="Entrada externa" />
              <Tab label="Resultado (vista previa)" />
            </Tabs>

            {tab === 0 && (
              <TextField
                multiline
                rows={8}
                variant="outlined"
                fullWidth
                value={testPayload}
                onChange={event => setTestPayload(event.target.value)}
                style={{ marginTop: 16 }}
              />
            )}

            {tab === 1 && (
              <Box className={classes.testOutput}>
                {testResult || "Ejecutar una prueba para ver el resultado."}
              </Box>
            )}

            <Box mt={2} display="flex" gap={16} justifyContent="flex-end">
              <Button onClick={() => setTestPayload(DEFAULT_TEST_PAYLOAD)}>Restablecer ejemplo</Button>
              <Button
                variant="contained"
                color="primary"
                onClick={applyMapping}
                disabled={!fieldMaps.length}
              >
                Ejecutar prueba
              </Button>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default IntegrationSettings;
