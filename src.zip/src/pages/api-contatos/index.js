import React, { useState, useEffect, useContext } from "react";

import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  elementMargin: {
    padding: theme.spacing(2)
  },
  formContainer: {
    maxWidth: 520
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiContatosPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página!");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getContactsEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/contacts`;

  const postmanRequests = [
    {
      name: "Listar contactos",
      method: "GET",
      url: getContactsEndpoint(),
      description: "Devuelve los contactos paginados de la empresa autenticada."
    },
    {
      name: "Buscar contacto por ID",
      method: "GET",
      url: `${getContactsEndpoint()}/1`,
      description: "Reemplaza el ID al final de la URL para buscar un contacto específico."
    },
    {
      name: "Crear contacto",
      method: "POST",
      url: getContactsEndpoint(),
      description: "Crea un contacto con etiquetas opcionales y campos adicionales.",
      body: {
        name: "Cliente Maria",
        number: "001234567890",
        email: "cliente@example.com",
        tags: ["VIP", "Lead quente"],
        extraInfo: [
          { name: "cpf", value: "000.000.000-00" }
        ]
      }
    },
    {
      name: "Actualizar contacto",
      method: "PUT",
      url: `${getContactsEndpoint()}/1`,
      description: "Cambia el ID al final de la URL para actualizar un contacto existente.",
      body: {
        name: "Cliente Maria (actualizado)",
        email: "nuevo-email@example.com",
        tags: ["Lead quente"]
      }
    },
    {
      name: "Eliminar contacto",
      method: "DELETE",
      url: `${getContactsEndpoint()}/1`,
      description: "Elimina permanentemente el contacto especificado en la ruta."
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const cleanContact = (contact) => ({
    id: contact.id,
    name: contact.name,
    number: contact.number,
    email: contact.email,
    tags: contact.tags?.map((tag) => ({
      id: tag.id,
      name: tag.name,
      color: tag.color
    })),
    extraInfo: contact.extraInfo,
    channel: contact.channel
  });

  const saveFormattedResult = (title, payload) => {
    saveResult(title, {
      ...payload,
      contacts: payload.contacts?.map(cleanContact),
      contact: payload.contact ? cleanContact(payload.contact) : undefined
    });
  };

  const handleListContacts = async (token) => {
    try {
      const { data } = await axios.get(getContactsEndpoint(), {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveFormattedResult("Lista de contactos", {
        ...data,
        contacts: data.contacts
      });
      toast.success("¡Contactos cargados!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowContact = async (token, contactId) => {
    try {
      const { data } = await axios.get(`${getContactsEndpoint()}/${contactId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveFormattedResult(`Contacto ${contactId}`, { contact: data });
      toast.success("¡Contacto cargado!");
    } catch (err) {
      toastError(err);
    }
  };

  const buildContactPayload = (values) => {
    const payload = {
      name: values.name,
      number: values.number,
      email: values.email || null,
      tags: values.tags ? values.tags.split(",").map((tag) => tag.trim()).filter(Boolean) : undefined
    };

    if (values.extraInfo) {
      try {
        payload.extraInfo = JSON.parse(values.extraInfo);
      } catch (error) {
        throw new Error("JSON no válido en campos personalizados.");
      }
    }

    return payload;
  };

  const handleCreateContact = async (values) => {
    try {
      const payload = buildContactPayload(values);
      const { data } = await axios.post(getContactsEndpoint(), payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveFormattedResult("Contacto creado", { contact: data });
      toast.success("¡Contacto creado correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON Inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleUpdateContact = async (values) => {
    try {
      const payload = buildContactPayload(values);
      const { data } = await axios.put(`${getContactsEndpoint()}/${values.contactId}`, payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveFormattedResult("Contacto actualizado", { contact: data });
      toast.success("¡Contacto actualizado correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON Inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleDeleteContact = async (values) => {
    try {
      await axios.delete(`${getContactsEndpoint()}/${values.contactId}`, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Contacto eliminado", { id: values.contactId, deleted: true });
      toast.success("¡Contacto eliminado!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListAndShowForm = () => (
    <Formik
      initialValues={{ token: "", contactId: "" }}
      onSubmit={(values) => handleListContacts(values.token)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="ID de contacto (opcional para búsqueda)"
                name="contactId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar todos"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.contactId) {
                    toast.error("Introduzca el ID del contacto para buscar un registro.");
                    return;
                  }
                  handleShowContact(values.token, values.contactId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        name: "",
        number: "",
        email: "",
        tags: "",
        extraInfo: ""
      }}
      onSubmit={async (values, actions) => {
        await handleCreateContact(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Número (con código de país)"
                name="number"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="E-mail"
                name="email"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Etiquetas (separadas por comas)"
                name="tags"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="VIP, Cliente potencial"
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label='Campos personalizados (JSON)'
                name="extraInfo"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
                placeholder='[{"name":"cpf","value":"123"}]'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear contacto"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        contactId: "",
        name: "",
        number: "",
        email: "",
        tags: "",
        extraInfo: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateContact(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Contacto ID"
                name="contactId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Número"
                name="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="E-mail"
                name="email"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Etiquetas"
                name="tags"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label='Campos personalizados (JSON)'
                name="extraInfo"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
                placeholder='[{"name":"cpf","value":"123"}]'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar contacto"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderDeleteForm = () => (
    <Formik
      initialValues={{
        token: "",
        contactId: ""
      }}
      onSubmit={async (values, actions) => {
        await handleDeleteContact(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Contacto ID"
                name="contactId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Eliminar contacto"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <div>
          <Typography variant="h5" gutterBottom>
            API de contactos
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Liste, cree, actualice y elimine contactos usando tokens externos de la empresa.
          </Typography>
        </div>
        <Button
          startIcon={<ReplyIcon />}
          variant="outlined"
          onClick={() => history.push("/messages-api")}
        >
          Volver a la documentación
        </Button>
      </Box>
      <Divider />

      <ApiPostmanDownload
        collectionName="WhatsApp - API de Contactos"
        requests={postmanRequests}
        filename="whatsapp-api-contactos.json"
        helperText="Introduce el token y haz clic en Descargar para importarlo a Postman."
      />
      <Box mb={4} className={classes.elementMargin}>
        <Typography variant="h6">Resumen</Typography>
        <Typography color="textSecondary">
          Gestiona contactos externos con nombre, número, etiquetas y campos adicionales usando los tokens de esta cuenta.
        </Typography>
        <Box mt={2} component="div" color="textSecondary">
          <ul>
            <li><b>Listar contactos:</b> GET {getContactsEndpoint()}</li>
            <li><b>Buscar contacto:</b> GET {getContactsEndpoint()}/:id</li>
            <li><b>Crear contacto:</b> POST {getContactsEndpoint()}</li>
            <li><b>Actualizar contacto:</b> PUT {getContactsEndpoint()}/:id</li>
            <li><b>Eliminar contacto:</b> DELETE {getContactsEndpoint()}/:id</li>
          </ul>
          Enviar siempre header <code>Authorization: Bearer {"{token}"}</code> con un token activo generado en la página API.
        </Box>
      </Box>
      <Box className={classes.elementMargin}>
        <Typography variant="h6" gutterBottom>
          Lista de contactos
        </Typography>
        {renderListAndShowForm()}
      </Box>
      <Box className={classes.elementMargin}>
        <Typography variant="h6" gutterBottom>
          Crear contacto
        </Typography>
        {renderCreateForm()}
      </Box>
      <Box className={classes.elementMargin}>
        <Typography variant="h6" gutterBottom>
          Actualizar contacto
        </Typography>
        {renderUpdateForm()}
      </Box>
      <Box className={classes.elementMargin}>
        <Typography variant="h6" gutterBottom>
          Eliminar contacto
        </Typography>
        {renderDeleteForm()}
      </Box>
      {testResult && (
        <Box className={classes.elementMargin}>
          <Typography variant="h6" gutterBottom>
            Resultado
          </Typography>
          <Paper className={classes.resultBox}>
            <Typography variant="body1" gutterBottom>
              {testResult.title}
            </Typography>
            <Typography variant="body2" gutterBottom>
              {testResult.payload}
            </Typography>
            <Typography variant="body2" gutterBottom>
              {testResult.timestamp}
            </Typography>
          </Paper>
        </Box>
      )}
    </Paper>
  );
};

export default ApiContatosPage;