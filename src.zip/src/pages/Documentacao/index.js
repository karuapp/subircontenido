import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";

import { i18n } from "../../translate/i18n";
import { Box, Button, CircularProgress, Grid, IconButton, Paper, TextField, Typography } from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import toastError from "../../errors/toastError";
import { toast } from "react-toastify";
import SendIcon from '@mui/icons-material/Send';
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import VisibilityIcon from "@mui/icons-material/Visibility";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";

import axios from "axios";
import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import {
  listCompanyApiKeys,
  createCompanyApiKey,
  deleteCompanyApiKey
} from "../../services/companyApiKeys";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  mainHeader: {
    marginTop: theme.spacing(1),
  },
  elementMargin: {
    padding: theme.spacing(2),
  },
  formContainer: {
    maxWidth: 500,
  },
  textRight: {
    textAlign: "right"
  },
  navCardsWrapper: {
    marginTop: theme.spacing(3)
  },
  navCard: {
    padding: theme.spacing(2),
    borderRadius: 12,
    border: "1px solid #e3e7f0",
    height: "100%",
    cursor: "pointer",
    transition: "transform 0.15s ease, box-shadow 0.15s ease",
    "&:hover": {
      transform: "translateY(-3px)",
      boxShadow: "0 12px 24px rgba(15, 23, 42, 0.12)"
    }
  },
  navCardTitle: {
    fontWeight: 600,
    marginBottom: theme.spacing(0.5)
  },
  navCardDescription: {
    color: theme.palette.text.secondary
  }
}));

const DocumentacaoPage = () => {
  const classes = useStyles();
  const history = useHistory();

  const [formMessageTextData,] = useState({ token: '', number: '', body: '', userId: '', queueId: '' })
  const [formMessageMediaData,] = useState({ token: '', number: '', medias: '', body:'', userId: '', queueId: '' })
  const [file, setFile] = useState({})
  const { user, socket } = useContext(AuthContext);
  const [apiKeys, setApiKeys] = useState([]);
  const [loadingKeys, setLoadingKeys] = useState(true);
  const [creatingToken, setCreatingToken] = useState(false);
  const [visibleTokens, setVisibleTokens] = useState({});

  const apiCards = [
    {
      title: "API de mensajería",
      description: "Envíe texto y contenido multimedia autenticados mediante tokens de empresa.",
      route: "/api-mensagens"
    },
    {
      title: "API de cliente",
      description: "Cree, actualice y sincronice clientes externos con webhooks.",
      route: "/messages-api/documentacao"
    },
    {
      title: "API de contacto",
      description: "Gestione contactos externos y sincronice datos de CRM.",
      route: "/api-contatos"
    },
    {
      title: "API de etiqueta",
      description: "Cree y organice etiquetas externas para segmentación y Kanban.",
      route: "/api-tags"
    },
    {
      title: "API de producto",
      description: "Gestione el catálogo de productos externo con indicadores y webhooks.",
      route: "/api-produtos"
    },
    {
      title: "API de servicio",
      description: "Sincronice los servicios ofrecidos y mantenga el CRM actualizado.",
      route: "/api-servicos"
    },
    {
      title: "API de usuario",
      description: "Gestione los usuarios de la empresa mediante una API externa.",
      route: "/api-usuarios"
    },
    {
      title: "API de cola",
      description: "Gestione las colas de servicio mediante una API externa.",
      route: "/api-filas"
    },
    {
      title: "API de negocio",
      description: "Gestione las transacciones (embudos) mediante una API externa.",
      route: "/api-negocios"
    },
    {
      title: "API de etiqueta Kanban",
      description: "Gestione las etiquetas Kanban (carriles del embudo) mediante una API externa.",
      route: "/api-tags-kanban"
    },
    {
      title: "API de Proyectos",
      description: "Gestiona proyectos mediante una API externa.",
      route: "/api-projetos"
    },
    {
      title: "API de Tareas",
      description: "Gestiona tareas de proyectos mediante una API externa.",
      route: "/api-tarefas"
    },
    {
      title: "API de Tickets",
      description: "Gestiona tickets de soporte mediante una API externa.",
      route: "/api-tickets"
    },
    {
      title: "API de Conexión de WhatsApp",
      description: "Gestiona conexiones de WhatsApp mediante una API externa.",
      route: "/api-conexoes"
    },
    {
      title: "API de Facturas",
      description: "Gestiona facturas mediante una API externa. Admite facturas regulares y de proyecto.",
      route: "/api-faturas"
    }
  ];

  const { getPlanCompany } = usePlans();

  useEffect(() => {
    async function fetchData() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página! Le estamos redirigiendo.");
        setTimeout(() => {
          history.push(`/`)
        }, 1000);
        return;
      }
      await loadApiKeys();
    }
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadApiKeys = async () => {
    try {
      setLoadingKeys(true);
      const data = await listCompanyApiKeys();
      setApiKeys(data);
    } catch (err) {
      toastError(err);
    } finally {
      setLoadingKeys(false);
    }
  };

  const handleCreateToken = async () => {
    const label = window.prompt("Proporcione un nombre para identificar este token.", "Integración");
    if (!label) {
      return;
    }

    const webhookUrl = window.prompt("Webhook URL (opcional)", "");
    const webhookSecret = window.prompt("Webhook secret (opcional)", "");

    try {
      setCreatingToken(true);
      await createCompanyApiKey({
        label,
        webhookUrl: webhookUrl || null,
        webhookSecret: webhookSecret || null
      });
      toast.success("¡Token generado correctamente!");
      await loadApiKeys();
    } catch (err) {
      toastError(err);
    } finally {
      setCreatingToken(false);
    }
  };

  const handleCopyToken = async (token) => {
    try {
      await navigator.clipboard.writeText(token);
      toast.success("¡Token copiado al portapapeles!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleDeleteToken = async (id) => {
    if (!window.confirm("¿Seguro que desea eliminar este token?")) return;

    try {
      await deleteCompanyApiKey(id);
      toast.success("¡Token eliminado correctamente!");
      await loadApiKeys();
    } catch (err) {
      toastError(err);
    }
  };

  const toggleTokenVisibility = (id) => {
    setVisibleTokens((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const getEndpoint = () => {
    return process.env.REACT_APP_BACKEND_URL + '/api/messages/send'
  }

  const handleSendTextMessage = async (values) => {
    const { number, body, userId, queueId } = values;
    const data = { number, body, userId, queueId, noRegister: true };
    try {
      await axios.request({
        url: getEndpoint(),
        method: 'POST',
        data,
        headers: {
          'Content-type': 'application/json',
          'Authorization': `Bearer ${values.token}` 
        }
      })
      toast.success('Mensaje enviado correctamente');
    } catch (err) {
      toastError(err);
    }
  }

  const handleSendMediaMessage = async (values) => {
    try {
      const firstFile = file[0];
      const data = new FormData();
      data.append('number', values.number);
      data.append('body', values.body ? values.body: firstFile.name);
      data.append('userId', values.userId);
      data.append('queueId', values.queueId);
      data.append('noRegister', 'true');
      data.append('medias', firstFile);
      await axios.request({
        url: getEndpoint(),
        method: 'POST',
        data,
        headers: {
          'Content-type': 'multipart/form-data',
          'Authorization': `Bearer ${values.token}`
        }
      })
      toast.success('Mensaje enviado correctamente');
    } catch (err) {
      toastError(err);
    }
  }

  const renderFormMessageText = () => {
    return (
      <Formik
        initialValues={formMessageTextData}
        enableReinitialize={true}
        onSubmit={(values, actions) => {
          setTimeout(async () => {
            await handleSendTextMessage(values);
            actions.setSubmitting(false);
            actions.resetForm()
          }, 400);
        }}
        className={classes.elementMargin}
      >
        {({ isSubmitting }) => (
          <Form className={classes.formContainer}>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.token")}
                  name="token"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                  required
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.number")}
                  name="number"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.body")}
                  name="body"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                  required
                />
              </Grid>
              <Grid item xs={12}  md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.userId")}
                  name="userId"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                />
              </Grid>
              <Grid item xs={12}  md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.queueId")}
                  name="queueId"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                />
              </Grid>
              <Grid item xs={12} className={classes.textRight}>
                <Button
                  type="submit"
                  startIcon={<SendIcon />}
                  style={{
                  color: "white",
                  backgroundColor: "#FFA500",
                  boxShadow: "none",
                  borderRadius: "5px",
                  }}
                  variant="contained"
                  className={classes.btnWrapper}
                >
                  {isSubmitting ? (
                    <CircularProgress
                      size={24}
                      className={classes.buttonProgress}
                    />
                  ) : 'Enviar'}
                </Button>
              </Grid>
            </Grid>
          </Form>
        )}
      </Formik>
    )
  }

  const renderFormMessageMedia = () => {
    return (
      <Formik
        initialValues={formMessageMediaData}
        enableReinitialize={true}
        onSubmit={(values, actions) => {
          setTimeout(async () => {
            await handleSendMediaMessage(values);
            actions.setSubmitting(false);
            actions.resetForm()
            document.getElementById('medias').files = null
            document.getElementById('medias').value = null
          }, 400);
        }}
        className={classes.elementMargin}
      >
        {({ isSubmitting }) => (
          <Form className={classes.formContainer}>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.mediaMessage.token")}
                  name="token"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                  required
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.mediaMessage.number")}
                  name="number"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.body")}
                  name="body"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                />
              </Grid>
              <Grid item xs={12}  md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.userId")}
                  name="userId"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                />
              </Grid>
              <Grid item xs={12}  md={6}>
                <Field
                  as={TextField}
                  label={i18n.t("messagesAPI.textMessage.queueId")}
                  name="queueId"
                  autoFocus
                  variant="outlined"
                  margin="dense"
                  fullWidth
                  className={classes.textField}
                />
              </Grid>
              <Grid item xs={12}>
                <input type="file" name="medias" id="medias" required onChange={(e) => setFile(e.target.files)} />
              </Grid>
              <Grid item xs={12} className={classes.textRight}>
                <Button
                  type="submit"
                  startIcon={<SendIcon />}
                  style={{
                  color: "white",
                  backgroundColor: "#437db5",
                  boxShadow: "none",
                  borderRadius: "5px",
                  }}
                  variant="contained"
                  className={classes.btnWrapper}
                >
                  {isSubmitting ? (
                    <CircularProgress
                      size={24}
                      className={classes.buttonProgress}
                    />
                  ) : 'Enviar'}
                </Button>
              </Grid>
            </Grid>
          </Form>
        )}
      </Formik>
    )
  }

  return (
    <Paper
      className={classes.mainPaper}
      style={{marginLeft: "5px"}}
      // className={classes.elementMargin}
      variant="outlined"
    >
      <Box display="flex" flexDirection="column" gap={16}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
          <div>
            <Typography variant="h5">{i18n.t("messagesAPI.API.title")}</Typography>
            <Typography variant="subtitle1" color="textSecondary">
              Genere tokens, configure webhooks y pruebe llamadas API externas.
            </Typography>
          </div>
          <Button
            color="primary"
            variant="contained"
            onClick={handleCreateToken}
            disabled={creatingToken}
          >
            {creatingToken ? "Generando..." : "Genere un nuevo token"}
          </Button>
        </Box>

        <Box className={classes.navCardsWrapper}>
          <Typography variant="subtitle1" gutterBottom>
            API disponibles
          </Typography>
          <Grid container spacing={2}>
            {apiCards.map((card) => (
              <Grid item xs={12} sm={6} md={4} key={card.title}>
                <Paper
                  elevation={0}
                  className={classes.navCard}
                  onClick={() => history.push(card.route)}
                >
                  <Typography className={classes.navCardTitle}>{card.title}</Typography>
                  <Typography variant="body2" className={classes.navCardDescription}>
                    {card.description}
                  </Typography>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Box>

        <Paper elevation={0} style={{ padding: 16, marginBottom: 24 }}>
          <Typography variant="h6" gutterBottom>
            Tokens activos
          </Typography>
          {loadingKeys ? (
            <Box display="flex" justifyContent="center" py={2}>
              <CircularProgress size={24} />
            </Box>
          ) : apiKeys.length === 0 ? (
            <Typography color="textSecondary">
              Aún no se han generado tokens. Haga clic en Generar nuevo token para comenzar.
            </Typography>
          ) : (
            <Grid container spacing={2}>
              {apiKeys.map((key) => (
                <Grid item xs={12} md={6} key={key.id}>
                  <Paper variant="outlined" style={{ padding: 16 }}>
                    <Typography variant="subtitle1" gutterBottom>
                      {key.label}
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      Último uso: {key.lastUsedAt ? new Date(key.lastUsedAt).toLocaleString() : "nunca"}
                    </Typography>
                    <Box
                      display="flex"
                      alignItems="center"
                      justifyContent="space-between"
                      mt={1}
                      mb={1}
                      style={{
                        padding: "12px 16px",
                        borderRadius: 8,
                        background: "#f4f6fb"
                      }}
                    >
                      <Typography variant="body2" style={{ fontFamily: "monospace" }}>
                        {visibleTokens[key.id] ? key.token : "••••••••••••••••••••••"}
                      </Typography>
                      <Box>
                        <IconButton onClick={() => toggleTokenVisibility(key.id)}>
                          {visibleTokens[key.id] ? <VisibilityOffIcon /> : <VisibilityIcon />}
                        </IconButton>
                        <IconButton onClick={() => handleCopyToken(key.token)}>
                          <ContentCopyIcon />
                        </IconButton>
                        <IconButton onClick={() => handleDeleteToken(key.id)}>
                          <DeleteOutlineIcon />
                        </IconButton>
                      </Box>
                    </Box>
                    {key.webhookUrl && (
                      <Typography variant="body2">
                        Webhook: <b>{key.webhookUrl}</b>
                      </Typography>
                    )}
                  </Paper>
                </Grid>
              ))}
            </Grid>
          )}
        </Paper>
      </Box>
    </Paper>
  );
};

export default DocumentacaoPage;