import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  elementMargin: {
    padding: theme.spacing(2)
  },
  formContainer: {
    maxWidth: 520
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiFilasPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("Esta empresa no tiene permiso para acceder a esta página.");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getQueuesEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/queues`;

  const postmanRequests = [
    {
      name: "Listar departamentos",
      method: "GET",
      url: getQueuesEndpoint(),
      description: "Devuelve las departamentos registradas en la empresa."
    },
    {
      name: "Buscar departamento por ID",
      method: "GET",
      url: `${getQueuesEndpoint()}/1`,
      description: "Reemplaza el ID al final de la URL para buscar una departamento específica."
    },
    {
      name: "Crear departamento",
      method: "POST",
      url: getQueuesEndpoint(),
      description: "Crea una nueva departamento.",
      body: {
        name: "Soporte técnico",
        color: "#5C59C2",
        greetingMessage: "¡Hola! Estás en la departamento de Soporte técnico.",
        outOfHoursMessage: "Estamos fuera del horario laboral."
      }
    },
    {
      name: "Actualizar departamento",
      method: "PUT",
      url: `${getQueuesEndpoint()}/1`,
      description: "Cambia el ID para actualizar la departamento deseada.",
      body: {
        name: "Soporte técnico (editado)",
        greetingMessage: "Nuevo mensaje de bienvenida"
      }
    },
    {
      name: "Eliminar departamento",
      method: "DELETE",
      url: `${getQueuesEndpoint()}/1`,
      description: "Elimina permanentemente la departamento especificada en la ruta."
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const cleanQueue = (queue) => ({
    id: queue.id,
    name: queue.name,
    color: queue.color,
    greetingMessage: queue.greetingMessage,
    outOfHoursMessage: queue.outOfHoursMessage,
    orderQueue: queue.orderQueue
  });

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListQueues = async (token) => {
    try {
      const { data } = await axios.get(getQueuesEndpoint(), {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult("Lista de departamentos", {
        ...data,
        queues: data.queues?.map(cleanQueue)
      });
      toast.success("¡departamentos cargadas!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowQueue = async (token, queueId) => {
    try {
      const { data } = await axios.get(`${getQueuesEndpoint()}/${queueId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`departamento ${queueId}`, cleanQueue(data));
      toast.success("¡departamento cargada!");
    } catch (err) {
      toastError(err);
    }
  };

  const buildQueuePayload = (values) => {
    const payload = {
      name: values.name,
      color: values.color,
      greetingMessage: values.greetingMessage || null,
      outOfHoursMessage: values.outOfHoursMessage || null,
      orderQueue: values.orderQueue ? Number(values.orderQueue) : 0
    };

    if (values.schedules) {
      try {
        payload.schedules = JSON.parse(values.schedules);
      } catch (error) {
        throw new Error("JSON no válido para las horas.");
      }
    }

    return payload;
  };

  const handleCreateQueue = async (values) => {
    try {
      const payload = buildQueuePayload(values);
      const { data } = await axios.post(getQueuesEndpoint(), payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("departamento creada", cleanQueue(data));
      toast.success("¡departamento creada correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON Inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleUpdateQueue = async (values) => {
    try {
      const payload = buildQueuePayload(values);
      const { data } = await axios.put(`${getQueuesEndpoint()}/${values.queueId}`, payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("departamento actualizada", cleanQueue(data));
      toast.success("¡departamento actualizada correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON Inválida")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleDeleteQueue = async (values) => {
    try {
      await axios.delete(`${getQueuesEndpoint()}/${values.queueId}`, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("departamento eliminada", { id: values.queueId, deleted: true });
      toast.success("¡departamento eliminada!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListAndShowForm = () => (
    <Formik
      initialValues={{ token: "", queueId: "" }}
      onSubmit={(values) => handleListQueues(values.token)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="ID de departamento (opcional para buscar uno)"
                name="queueId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar todos"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.queueId) {
                    toast.error("Ingrese el ID de departamento para buscar un registro.");
                    return;
                  }
                  handleShowQueue(values.token, values.queueId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        name: "",
        color: "#5C59C2",
        greetingMessage: "",
        outOfHoursMessage: "",
        orderQueue: "",
        schedules: ""
      }}
      onSubmit={async (values, actions) => {
        await handleCreateQueue(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Nombre de departamento"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Color (hex)"
                name="color"
                variant="outlined"
                margin="dense"
                fullWidth
                required
                placeholder="#5C59C2"
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Orden"
                name="orderQueue"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de saludo"
                name="greetingMessage"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de fuera de horario"
                name="outOfHoursMessage"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label='Horarios (JSON)'
                name="schedules"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
                placeholder='[{"weekday": "Segunda", "startTime": "08:00", "endTime": "18:00"}]'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear departamento"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        queueId: "",
        name: "",
        color: "",
        greetingMessage: "",
        outOfHoursMessage: "",
        orderQueue: "",
        schedules: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateQueue(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Queue ID"
                name="queueId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Color (hex)"
                name="color"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="#5C59C2"
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Orden"
                name="orderQueue"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de saludo"
                name="greetingMessage"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de fuera de horario"
                name="outOfHoursMessage"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label='Horarios (JSON)'
                name="schedules"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
                placeholder='[{"weekday": "Segunda", "startTime": "08:00", "endTime": "18:00"}]'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar departamento"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderDeleteForm = () => (
    <Formik
      initialValues={{ token: "", queueId: "" }}
      onSubmit={async (values, actions) => {
        await handleDeleteQueue(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="departamento ID"
                name="queueId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                color="secondary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Eliminar departamento"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de departamento</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Gestiona departamentos de servicio mediante una API externa.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Volver a tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Descripción general</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar departamentos:</b> GET {getQueuesEndpoint()}</li>
            <li><b>Buscar departamento:</b> GET {getQueuesEndpoint()}/:id</li>
            <li><b>Crear departamento:</b> POST {getQueuesEndpoint()}</li>
            <li><b>Actualizar departamento:</b> PUT {getQueuesEndpoint()}/:id</li>
            <li><b>Eliminar departamento:</b> DELETE {getQueuesEndpoint()}/:id</li>
          </ul>
          Enviar siempre header <code>Authorization: Bearer {"{token}"}</code> con un token activo generado en la página API.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="WhatsApp CRM - API de Departamento"
        requests={postmanRequests}
        filename="whatsapp-api-departamentos.json"
        helperText="Ingrese el token y haga clic en descargar para importarlo a Postman.."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Consultar Departamento</Typography>
        <Typography color="textSecondary">
          Informe sólo el token para listar todos o agregar un ID de departamento para buscar un registro específico.
        </Typography>
        {renderListAndShowForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. criar departamento</Typography>
        <Typography color="textSecondary">
          Campos Obrigatorios: <b>name</b> mi <b>color</b>.Mensajes y horarios son opcionales.
        </Typography>
        {renderCreateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Actualizar departamento</Typography>
        <Typography color="textSecondary">
          Informe o <b>Queue ID</b> e envie os campos que desea actualizar.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">4. Eliminar departamento</Typography>
        <Typography color="textSecondary">
          Esta operación elimina el registro definitivamente. Úselo con cuidado.
        </Typography>
        {renderDeleteForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">Resultado de la última prueba</Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiFilasPage;
