import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography,
  MenuItem
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  formContainer: {
    maxWidth: 700
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiTicketsPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("Esta empresa no tiene permiso para acceder a esta página.");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
  }, []);

  const getTicketsEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/tickets`;

  const postmanRequests = [
    {
      name: "Listar tickets",
      method: "GET",
      url: getTicketsEndpoint(),
      description: "Devuelve los tickets de la empresa. Utilice filtros como: ?status=open&queueId=1"
    },
    {
      name: "Buscar ticket por ID",
      method: "GET",
      url: `${getTicketsEndpoint()}/1`,
      description: "Devuelve los detalles de un ticket específico."
    },
    {
      name: "Listar mensajes de ticket",
      method: "GET",
      url: `${getTicketsEndpoint()}/1/messages`,
      description: "Devuelve los mensajes de un ticket."
    },
    {
      name: "Actualizar ticket",
      method: "PUT",
      url: `${getTicketsEndpoint()}/1`,
      description: "Actualiza el estado, el usuario, la cola o las etiquetas del ticket.",
      body: {
        status: "open",
        userId: 1,
        queueId: 1,
        tagIds: [1, 2]
      }
    },
    {
      name: "Cerrar ticket",
      method: "POST",
      url: `${getTicketsEndpoint()}/1/close`,
      description: "Cierra el ticket especificado."
    },
    {
      name: "Reabrir ticket",
      method: "POST",
      url: `${getTicketsEndpoint()}/1/reopen`,
      description: "Reabre un ticket cerrado."
    },
    {
      name: "Transferir ticket",
      method: "POST",
      url: `${getTicketsEndpoint()}/1/transfer`,
      description: "Transfiere el ticket a otro usuario o cola.",
      body: {
        userId: 2,
        queueId: 1
      }
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListTickets = async (values) => {
    try {
      const params = new URLSearchParams();
      if (values.status) params.append("status", values.status);
      if (values.queueId) params.append("queueId", values.queueId);
      if (values.userId) params.append("userId", values.userId);
      if (values.searchParam) params.append("searchParam", values.searchParam);
      const queryString = params.toString() ? `?${params.toString()}` : "";

      const { data } = await axios.get(`${getTicketsEndpoint()}${queryString}`, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Lista de entradas", data);
      toast.success("¡Entradas cargadas!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowTicket = async (token, ticketId) => {
    try {
      const { data } = await axios.get(`${getTicketsEndpoint()}/${ticketId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Ticket ${ticketId}`, data);
      toast.success("¡Entrada cargada!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleGetMessages = async (token, ticketId) => {
    try {
      const { data } = await axios.get(`${getTicketsEndpoint()}/${ticketId}/messages`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Mensajes de entradas ${ticketId}`, data);
      toast.success("¡Mensajes cargados!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleUpdateTicket = async (values) => {
    try {
      const payload = {};
      if (values.status) payload.status = values.status;
      if (values.userId) payload.userId = Number(values.userId);
      if (values.queueId) payload.queueId = Number(values.queueId);
      if (values.tagIds) {
        try {
          payload.tagIds = JSON.parse(values.tagIds);
        } catch (e) {
          toast.error("JSON inválido en tagIds");
          return;
        }
      }

      const { data } = await axios.put(`${getTicketsEndpoint()}/${values.ticketId}`, payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Ticket actualizado", data);
      toast.success("¡Ticket actualizado!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleCloseTicket = async (values) => {
    try {
      const { data } = await axios.post(`${getTicketsEndpoint()}/${values.ticketId}/close`, {}, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Ticket cerrado", data);
      toast.success("¡Ticket cerrado!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleReopenTicket = async (values) => {
    try {
      const { data } = await axios.post(`${getTicketsEndpoint()}/${values.ticketId}/reopen`, {}, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Ticket reabierto", data);
      toast.success("¡Ticket reabierto!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleTransferTicket = async (values) => {
    try {
      const payload = {};
      if (values.userId) payload.userId = Number(values.userId);
      if (values.queueId) payload.queueId = Number(values.queueId);

      const { data } = await axios.post(`${getTicketsEndpoint()}/${values.ticketId}/transfer`, payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Ticket transferido", data);
      toast.success("¡Ticket transferido!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListForm = () => (
    <Formik
      initialValues={{ token: "", ticketId: "", status: "", queueId: "", userId: "", searchParam: "" }}
      onSubmit={(values) => handleListTickets(values)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Ticket ID (opcional)"
                name="ticketId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                select
                label="Estado"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
              >
                <MenuItem value="">Todos</MenuItem>
                <MenuItem value="open">Abierto</MenuItem>
                <MenuItem value="pending">Pendiente</MenuItem>
                <MenuItem value="closed">Cerrado</MenuItem>
              </Field>
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Buscar contacto"
                name="searchParam"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="Nome ou número"
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Departamento ID"
                name="queueId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Agente ID"
                name="userId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={6} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.ticketId) {
                    toast.error("Informe o Ticket ID.");
                    return;
                  }
                  handleShowTicket(values.token, values.ticketId);
                }}
                style={{ marginRight: 8 }}
              >
                Buscar por ID
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.ticketId) {
                    toast.error("Por favor, proporcione el ID del ticket.");
                    return;
                  }
                  handleGetMessages(values.token, values.ticketId);
                }}
              >
                Ver mensajes
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{ token: "", ticketId: "", status: "", userId: "", queueId: "", tagIds: "" }}
      onSubmit={async (values, actions) => {
        await handleUpdateTicket(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Ticket ID"
                name="ticketId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Estado"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
              >
                <MenuItem value="">No cambiar</MenuItem>
                <MenuItem value="open">Abierto</MenuItem>
                <MenuItem value="pending">Pendiente</MenuItem>
                <MenuItem value="closed">Cerrado</MenuItem>
              </Field>
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Agente ID"
                name="userId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Departamento ID"
                name="queueId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label='Etiquetas (JSON array)'
                name="tagIds"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2]'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar ticket"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderActionsForm = () => (
    <Formik
      initialValues={{ token: "", ticketId: "", userId: "", queueId: "" }}
      onSubmit={() => {}}
    >
      {({ values }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Ticket ID"
                name="ticketId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Agente ID (transferir)"
                name="userId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Departamento ID (transferir)"
                name="queueId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                variant="contained"
                color="secondary"
                onClick={() => {
                  if (!values.ticketId) {
                    toast.error("Informe o Ticket ID.");
                    return;
                  }
                  handleCloseTicket(values);
                }}
                style={{ marginRight: 8 }}
              >
                Fechar
              </Button>
              <Button
                variant="contained"
                onClick={() => {
                  if (!values.ticketId) {
                    toast.error("Informe o Ticket ID.");
                    return;
                  }
                  handleReopenTicket(values);
                }}
                style={{ marginRight: 8 }}
              >
                Reabrir
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={() => {
                  if (!values.ticketId) {
                    toast.error("Informe o Ticket ID.");
                    return;
                  }
                  if (!values.userId && !values.queueId) {
                    toast.error("Introduce el ID de usuario o el ID de departamento para transferir.");
                    return;
                  }
                  handleTransferTicket(values);
                }}
              >
                Transferir
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de Tickets</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Gestiona tickets de soporte mediante una API externa.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Volver a tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Resumen</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar tickets:</b> GET {getTicketsEndpoint()}</li>
            <li><b>Buscar ticket:</b> GET {getTicketsEndpoint()}/:id</li>
            <li><b>Mensajes:</b> GET {getTicketsEndpoint()}/:id/messages</li>
            <li><b>Actualizar:</b> PUT {getTicketsEndpoint()}/:id</li>
            <li><b>Cerrar:</b> POST {getTicketsEndpoint()}/:id/close</li>
            <li><b>Reabrir:</b> POST {getTicketsEndpoint()}/:id/reopen</li>
            <li><b>Transferir:</b> POST {getTicketsEndpoint()}/:id/transfer</li>
          </ul>
          Enviar siempre header <code>Authorization: Bearer {"{token}"}</code>.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="whatsapp - API de Tickets"
        requests={postmanRequests}
        filename="whatsapp-api-tickets.json"
        helperText="Introduce el token y haz clic en descargar para importarlo a Postman."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Consultar tickets</Typography>
        <Typography color="textSecondary">
          Filtra los tickets o busca uno específico por ID. También puedes ver los mensajes.
        </Typography>
        {renderListForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. Actualizar ticket</Typography>
        <Typography color="textSecondary">
          Cambiar estado, asignar agente, departamento o etiquetas.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Acciones rápidas</Typography>
        <Typography color="textSecondary">
          Cerrar, reabrir o transferir tickets.
        </Typography>
        {renderActionsForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">Resultado de la última prueba</Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiTicketsPage;
