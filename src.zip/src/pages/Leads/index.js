import React, { useState, useEffect, useReducer } from "react";
import {
  Avatar,
  Box,
  Button,
  Chip,
  CircularProgress,
  IconButton,
  InputAdornment,
  makeStyles,
  MenuItem,
  TextField,
  Tooltip,
  Typography
} from "@material-ui/core";
import SearchIcon from "@material-ui/icons/Search";
import AddIcon from "@material-ui/icons/Add";
import EditIcon from "@material-ui/icons/Edit";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";
import PeopleAltIcon from "@material-ui/icons/PeopleAlt";

import api from "../../services/api";
import LeadModal from "../../components/LeadModal";
import ConfirmationModal from "../../components/ConfirmationModal";
import toastError from "../../errors/toastError";

const STATUS_OPTIONS = [
  { label: "Todo", value: "" },
  { label: "Nuevo", value: "new" },
  { label: "Contactado", value: "contacted" },
  { label: "Calificado", value: "qualified" },
  { label: "No calificado", value: "unqualified" },
  { label: "Convertido", value: "converted" },
  { label: "Perdido", value: "lost" }
];

const STATUS_LABEL = {
  new: "Nuevo",
  contacted: "Contactado",
  qualified: "Calificado",
  unqualified: "No calificado",
  converted: "Convertido",
  lost: "Perdido"
};

const STATUS_COLORS = {
  new: "#3b82f6",
  contacted: "#6366f1",
  qualified: "#059669",
  unqualified: "#f97316",
  converted: "#0f766e",
  lost: "#dc2626"
};

const reducer = (state, action) => {
  switch (action.type) {
    case "RESET":
      return [];
    case "LOAD_LEADS": {
      const incoming = action.payload;
      const clone = [...state];
      incoming.forEach((lead) => {
        const index = clone.findIndex((item) => item.id === lead.id);
        if (index > -1) {
          clone[index] = lead;
        } else {
          clone.push(lead);
        }
      });
      return clone;
    }
    case "DELETE_LEAD":
      return state.filter((lead) => lead.id !== action.payload);
    default:
      return state;
  }
};

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexDirection: "column",
    minHeight: "100vh",
    backgroundColor: theme.palette.background.default,
    padding: theme.spacing(3),
    gap: theme.spacing(3),
    overflowY: "auto",
    overflowX: "hidden",
    ...theme.scrollbarStyles,
    [theme.breakpoints.down("sm")]: {
      padding: theme.spacing(1),
      gap: theme.spacing(1)
    }
  },
  header: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: theme.spacing(2),
    [theme.breakpoints.down("sm")]: {
      flexDirection: "column",
      alignItems: "stretch"
    }
  },
  titleContainer: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1.5),
    [theme.breakpoints.down("sm")]: {
      width: "100%"
    }
  },
  titleIcon: {
    fontSize: 36,
    color: theme.palette.primary.main
  },
  title: {
    fontSize: 24,
    fontWeight: 600,
    color: theme.palette.text.primary
  },
  subtitle: {
    fontSize: 14,
    color: theme.palette.text.secondary
  },
  actions: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1),
    flexWrap: "wrap",
    [theme.breakpoints.down("sm")]: {
      width: "100%"
    }
  },
  searchField: {
    minWidth: 220,
    backgroundColor: theme.palette.background.paper,
    borderRadius: 8,
    "& .MuiOutlinedInput-root": {
      borderRadius: 8
    },
    [theme.breakpoints.down("sm")]: {
      flex: 1,
      minWidth: "unset"
    }
  },
  selectField: {
    minWidth: 200,
    [theme.breakpoints.down("sm")]: {
      flex: 1,
      minWidth: "unset"
    }
  },
  addButton: {
    backgroundColor: theme.palette.primary.main,
    color: "#fff",
    "&:hover": {
      backgroundColor: theme.palette.primary.dark
    }
  },
  content: {
    display: "flex",
    flexDirection: "column",
    backgroundColor: theme.palette.background.paper,
    borderRadius: 16,
    boxShadow: "0 10px 30px rgba(15,23,42,0.08)",
    overflow: "hidden"
  },
  listHeader: {
    display: "flex",
    alignItems: "center",
    padding: theme.spacing(2, 3),
    borderBottom: `1px solid ${theme.palette.divider}`
  },
  list: {
    display: "flex",
    flexDirection: "column"
  },
  listItem: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(2),
    padding: theme.spacing(2.5, 3),
    borderBottom: `1px solid ${theme.palette.divider}`,
    "&:last-child": {
      borderBottom: "none"
    },
    "&:hover": {
      backgroundColor: theme.palette.action.hover
    },
    [theme.breakpoints.down("sm")]: {
      flexDirection: "column",
      alignItems: "flex-start"
    }
  },
  itemAvatar: {
    width: 56,
    height: 56,
    fontSize: 20,
    fontWeight: 600,
    backgroundColor: theme.palette.primary.light,
    color: theme.palette.primary.contrastText
  },
  itemInfo: {
    flex: 1,
    minWidth: 0
  },
  itemNameRow: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1),
    flexWrap: "wrap"
  },
  itemName: {
    fontSize: 16,
    fontWeight: 600,
    color: theme.palette.text.primary
  },
  itemDetails: {
    fontSize: 13,
    color: theme.palette.text.secondary,
    display: "flex",
    flexWrap: "wrap",
    gap: theme.spacing(1)
  },
  itemMeta: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(2),
    marginTop: theme.spacing(1),
    flexWrap: "wrap",
    color: theme.palette.text.secondary,
    fontSize: 13
  },
  statusChip: {
    textTransform: "capitalize",
    fontWeight: 600,
    color: "#fff"
  },
  actionsColumn: {
    display: "flex",
    gap: theme.spacing(1)
  },
  emptyState: {
    padding: theme.spacing(6),
    textAlign: "center",
    color: theme.palette.text.secondary
  },
  loadingBox: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: theme.spacing(1),
    padding: theme.spacing(2),
    borderTop: `1px solid ${theme.palette.divider}`
  }
}));

const Leads = () => {
  const classes = useStyles();

  const [leads, dispatch] = useReducer(reducer, []);
  const [pageNumber, setPageNumber] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchParam, setSearchParam] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [leadModalOpen, setLeadModalOpen] = useState(false);
  const [selectedLeadId, setSelectedLeadId] = useState(null);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);
  const [deletingLead, setDeletingLead] = useState(null);
  const [refreshToken, setRefreshToken] = useState(0);

  useEffect(() => {
    dispatch({ type: "RESET" });
    setPageNumber(1);
    setRefreshToken((prev) => prev + 1);
  }, [searchParam, statusFilter]);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    const controller = new AbortController();

    const fetchLeads = async () => {
      console.info("[Leads] Fetching leads", {
        searchParam,
        statusFilter,
        pageNumber
      });
      try {
        const { data } = await api.get("/crm/leads", {
          params: {
            searchParam,
            status: statusFilter,
            pageNumber
          },
          signal: controller.signal
        });

        if (isMounted) {
          dispatch({ type: "LOAD_LEADS", payload: data.leads });
          setHasMore(data.hasMore);
          console.info("[Leads] Leads fetched", {
            received: data.leads?.length ?? 0,
            total: data.count,
            hasMore: data.hasMore
          });
        }
      } catch (err) {
        if (isMounted && err.name !== "CanceledError") {
          console.error("[Leads] Error fetching leads", err);
          toastError(err);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchLeads();

    return () => {
      isMounted = false;
      controller.abort();
    };
  }, [searchParam, statusFilter, pageNumber, refreshToken]);

  const handleScroll = (event) => {
    if (!hasMore || loading) return;
    const { scrollTop, scrollHeight, clientHeight } = event.currentTarget;
    if (scrollHeight - scrollTop - clientHeight < 160) {
      setPageNumber((prev) => prev + 1);
    }
  };

  const handleOpenModal = (leadId = null) => {
    setSelectedLeadId(leadId);
    setLeadModalOpen(true);
  };

  const handleCloseModal = () => {
    setSelectedLeadId(null);
    setLeadModalOpen(false);
  };

  const handleModalSuccess = () => {
    handleCloseModal();
    dispatch({ type: "RESET" });
    setPageNumber(1);
    setRefreshToken((prev) => prev + 1);
  };

  const handleDeleteLead = async () => {
    if (!deletingLead) return;

    try {
      await api.delete(`/crm/leads/${deletingLead.id}`);
      dispatch({ type: "DELETE_LEAD", payload: deletingLead.id });
    } catch (err) {
      toastError(err);
    } finally {
      setConfirmModalOpen(false);
      setDeletingLead(null);
      setRefreshToken((prev) => prev + 1);
    }
  };

  const getInitials = (name = "") => {
    if (!name.trim()) return "L";
    const pieces = name.trim().split(" ");
    return pieces.slice(0, 2).map((part) => part[0].toUpperCase()).join("");
  };

  const formatStatus = (status) => STATUS_LABEL[status] || "Novo";

  const statusColor = (status) => STATUS_COLORS[status] || STATUS_COLORS.new;

  return (
    <Box className={classes.root} onScroll={handleScroll}>
      <LeadModal
        open={leadModalOpen}
        onClose={handleCloseModal}
        leadId={selectedLeadId}
        onSuccess={handleModalSuccess}
      />

      <ConfirmationModal
        open={confirmModalOpen}
        onClose={() => setConfirmModalOpen(false)}
        title="Eliminar lead"
        onConfirm={handleDeleteLead}
      >
        ¿Seguro que desea eliminar este cliente potencial? Esta acción no se puede deshacer.
      </ConfirmationModal>

      <Box className={classes.header}>
        <Box className={classes.titleContainer}>
          <PeopleAltIcon className={classes.titleIcon} />
          <Box>
            <Typography className={classes.title}>Leads</Typography>
            <Typography className={classes.subtitle}>
              Administrar oportunidades y registros • {leads.length} lead(s)
            </Typography>
          </Box>
        </Box>

        <Box className={classes.actions}>
          <TextField
            size="small"
            variant="outlined"
            placeholder="Buscar por nombre, correo electrónico o número de teléfono"
            value={searchParam}
            onChange={(event) => setSearchParam(event.target.value)}
            className={classes.searchField}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon color="disabled" />
                </InputAdornment>
              )
            }}
          />
          <TextField
            select
            size="small"
            label="Status"
            variant="outlined"
            value={statusFilter}
            onChange={(event) => setStatusFilter(event.target.value)}
            className={classes.selectField}
          >
            {STATUS_OPTIONS.map((option) => (
              <MenuItem key={option.value} value={option.value}>
                {option.label}
              </MenuItem>
            ))}
          </TextField>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            className={classes.addButton}
            onClick={() => handleOpenModal()}
          >
            Nuevo Lead
          </Button>
        </Box>
      </Box>

      <Box className={classes.content}>
        {leads.length === 0 && !loading ? (
          <Box className={classes.emptyState}>
            <PeopleAltIcon style={{ fontSize: 48, marginBottom: 12 }} color="disabled" />
            <Typography variant="h6">No se encontraron clientes potenciales. Ajuste los filtros o </Typography>
            <Typography variant="body2">
              registre un nuevo cliente potencial para comenzar.
            </Typography>
          </Box>
        ) : (
          <Box className={classes.list}>
            {leads.map((lead) => (
              <Box key={lead.id} className={classes.listItem}>
                <Avatar className={classes.itemAvatar}>{getInitials(lead.name)}</Avatar>

                <Box className={classes.itemInfo}>
                  <Box className={classes.itemNameRow}>
                    <Typography className={classes.itemName}>
                      {lead.name || "Lead Sin nombre"}
                    </Typography>
                    <Chip
                      size="small"
                      label={formatStatus(lead.status)}
                      className={classes.statusChip}
                      style={{ backgroundColor: statusColor(lead.status) }}
                    />
                  </Box>
                  <Box className={classes.itemDetails}>
                    <span>ID: {lead.id}</span>
                    <span>•</span>
                    <span>{lead.email || "Sin correo electrónico"}</span>
                    <span>•</span>
                    <span>{lead.phone || "Sin número de teléfono"}</span>
                  </Box>
                  <Box className={classes.itemMeta}>
                    <span>Empresa: {lead.companyName || "N/A"}</span>
                    <span>Responsable: {lead.ownerUserId || "N/A"}</span>
                    <span>Temperatura: {lead.temperature || "N/A"}</span>
                    <span>Puntuación: {lead.score ?? 0}</span>
                  </Box>
                </Box>

                <Box className={classes.actionsColumn}>
                  <Tooltip title="Editar">
                    <IconButton size="small" onClick={() => handleOpenModal(lead.id)}>
                      <EditIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Eliminar">
                    <IconButton
                      size="small"
                      onClick={() => {
                        setDeletingLead(lead);
                        setConfirmModalOpen(true);
                      }}
                    >
                      <DeleteOutlineIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Box>
              </Box>
            ))}
          </Box>
        )}

        {loading && (
          <Box className={classes.loadingBox}>
            <CircularProgress size={20} />
            <Typography variant="body2">Cargando leads...</Typography>
          </Box>
        )}
        {!loading && hasMore && (
          <Box className={classes.loadingBox}>
            <Button size="small" onClick={() => setPageNumber((prev) => prev + 1)}>
              Cargar más
            </Button>
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default Leads;