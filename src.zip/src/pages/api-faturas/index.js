import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  formContainer: {
    maxWidth: 700
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiFaturasPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página!");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
  }, []);

  const getFaturasEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/faturas`;

  const postmanRequests = [
    {
      name: "Lista de facturas",
      method: "GET",
      url: getFaturasEndpoint(),
      description: "Muestra todas las facturas de la empresa."
    },
    {
      name: "Buscar factura por ID",
      method: "GET",
      url: `${getFaturasEndpoint()}/1`,
      description: "Muestra los detalles de una factura específica."
    },
    {
      name: "Facturas por proyecto",
      method: "GET",
      url: `${getFaturasEndpoint()}/project/1`,
      description: "Muestra las facturas de un proyecto específico."
    },
    {
      name: "Facturas por cliente",
      method: "GET",
      url: `${getFaturasEndpoint()}/client/1`,
      description: "Muestra las facturas de un cliente específico."
    },
    {
      name: "Crear factura",
      method: "POST",
      url: getFaturasEndpoint(),
      description: "Crea una nueva factura.",
      body: {
        clientId: 1,
        projectId: null,
        descricao: "Servicio de consultoría",
        valor: 1500.00,
        dataVencimento: "2025-02-15",
        tipoRecorrencia: "unica",
        observacoes: "Pago en efectivo"
      }
    },
    {
      name: "Actualizar factura",
      method: "PUT",
      url: `${getFaturasEndpoint()}/1`,
      description: "Actualiza una factura existente.",
      body: {
        descricao: "Servicio actualizado",
        valor: 2000.00,
        status: "aberta"
      }
    },
    {
      name: "Marcar como pagada",
      method: "POST",
      url: `${getFaturasEndpoint()}/1/pay`,
      description: "Marca la factura como pagada.",
      body: {
        dataPagamento: "2025-01-15",
        valorPago: 1500.00
      }
    },
    {
      name: "Cancelar factura",
      method: "POST",
      url: `${getFaturasEndpoint()}/1/cancel`,
      description: "Cancela la factura."
    },
    {
      name: "Eliminar factura",
      method: "DELETE",
      url: `${getFaturasEndpoint()}/1`,
      description: "Elimina una factura."
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListFaturas = async (values) => {
    try {
      let url = getFaturasEndpoint();
      const params = new URLSearchParams();
      if (values.status) params.append("status", values.status);
      if (values.tipoRecorrencia) params.append("tipoRecorrencia", values.tipoRecorrencia);
      if (values.clientId) params.append("clientId", values.clientId);
      if (values.projectId) params.append("projectId", values.projectId);
      if (params.toString()) url += `?${params.toString()}`;

      const { data } = await axios.get(url, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Lista de facturas", data);
      toast.success("¡Facturas subidas!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowFatura = async (token, faturaId) => {
    try {
      const { data } = await axios.get(`${getFaturasEndpoint()}/${faturaId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Factura ${faturaId}`, data);
      toast.success("¡Factura subida!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleCreateFatura = async (values) => {
    try {
      const payload = {
        clientId: Number(values.clientId),
        descricao: values.descricao,
        valor: Number(values.valor),
        dataVencimento: values.dataVencimento
      };
      if (values.projectId) payload.projectId = Number(values.projectId);
      if (values.tipoRecorrencia) payload.tipoRecorrencia = values.tipoRecorrencia;
      if (values.observacoes) payload.observacoes = values.observacoes;

      const { data } = await axios.post(getFaturasEndpoint(), payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Factura creada", data);
      toast.success("¡Factura creada!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleUpdateFatura = async (values) => {
    try {
      const payload = {};
      if (values.descricao) payload.descricao = values.descricao;
      if (values.valor) payload.valor = Number(values.valor);
      if (values.status) payload.status = values.status;
      if (values.dataVencimento) payload.dataVencimento = values.dataVencimento;
      if (values.projectId) payload.projectId = Number(values.projectId);
      if (values.observacoes) payload.observacoes = values.observacoes;

      const { data } = await axios.put(`${getFaturasEndpoint()}/${values.faturaId}`, payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Fatura atualizada", data);
      toast.success("Fatura atualizada!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleMarkAsPaid = async (values) => {
    try {
      const payload = {};
      if (values.dataPagamento) payload.dataPagamento = values.dataPagamento;
      if (values.valorPago) payload.valorPago = Number(values.valorPago);

      const { data } = await axios.post(`${getFaturasEndpoint()}/${values.faturaId}/pay`, payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Factura marcada como pagada", data);
      toast.success("¡Factura marcada como pagada!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleCancelFatura = async (values) => {
    try {
      const { data } = await axios.post(`${getFaturasEndpoint()}/${values.faturaId}/cancel`, {}, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Factura cancelada", data);
      toast.success("¡Factura cancelada!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleDeleteFatura = async (values) => {
    try {
      const { data } = await axios.delete(`${getFaturasEndpoint()}/${values.faturaId}`, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Factura eliminada", data);
      toast.success("¡Factura eliminada!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListForm = () => (
    <Formik
      initialValues={{ token: "", faturaId: "", status: "", tipoRecorrencia: "", clientId: "", projectId: "" }}
      onSubmit={(values) => handleListFaturas(values)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="ID de factura (opcional)"
                name="faturaId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Estado"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
                SelectProps={{ native: true }}
              >
                <option value="">Todos</option>
                <option value="aberta">Abierto</option>
                <option value="paga">Pagado</option>
                <option value="vencida">Vencido</option>
                <option value="cancelada">Cancelado</option>
              </Field>
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Recurrente"
                name="tipoRecorrencia"
                variant="outlined"
                margin="dense"
                fullWidth
                SelectProps={{ native: true }}
              >
                <option value="">Todos</option>
                <option value="unica">Pago único</option>
                <option value="mensal">Mensual</option>
                <option value="anual">Pago anual</option>
              </Field>
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Cliente ID"
                name="clientId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Proyecto ID"
                name="projectId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar todos"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.faturaId) {
                    toast.error("Informe o Fatura ID.");
                    return;
                  }
                  handleShowFatura(values.token, values.faturaId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        clientId: "",
        projectId: "",
        descricao: "",
        valor: "",
        dataVencimento: "",
        tipoRecorrencia: "unica",
        observacoes: ""
      }}
      onSubmit={async (values, actions) => {
        if (!values.clientId || !values.valor || !values.dataVencimento) {
          toast.error("Se requiere el cliente, el importe y la fecha de vencimiento.");
          actions.setSubmitting(false);
          return;
        }
        await handleCreateFatura(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Cliente ID"
                name="clientId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Proyecto ID (opcional)"
                name="projectId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Descripción"
                name="descricao"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Importe"
                name="valor"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Fecha de vencimiento"
                name="dataVencimento"
                type="date"
                variant="outlined"
                margin="dense"
                fullWidth
                required
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Recurrencia"
                name="tipoRecorrencia"
                variant="outlined"
                margin="dense"
                fullWidth
                SelectProps={{ native: true }}
              >
                <option value="unica">Pago único</option>
                <option value="mensal">Pago mensual</option>
                <option value="anual">Pago anual</option>
              </Field>
            </Grid>
            <Grid item xs={12} md={8}>
              <Field
                as={TextField}
                label="Notas"
                name="observacoes"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear factura"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        faturaId: "",
        descricao: "",
        valor: "",
        status: "",
        dataVencimento: "",
        projectId: "",
        observacoes: ""
      }}
      onSubmit={async (values, actions) => {
        if (!values.faturaId) {
          toast.error("Se requiere el ID de la factura.");
          actions.setSubmitting(false);
          return;
        }
        await handleUpdateFatura(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Factura ID"
                name="faturaId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Estado"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
                SelectProps={{ native: true }}
              >
                <option value="">No cambiar</option>
                <option value="aberta">Abierto</option>
                <option value="paga">Pagado</option>
                <option value="vencida">Vencido</option>
                <option value="cancelada">Cancelado</option>
              </Field>
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Descripción"
                name="descricao"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Importe"
                name="valor"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Fecha de vencimiento"
                name="dataVencimento"
                type="date"
                variant="outlined"
                margin="dense"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Proyecto ID"
                name="projectId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={8}>
              <Field
                as={TextField}
                label="Notas"
                name="observacoes"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar factura"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderActionsForm = () => (
    <Formik
      initialValues={{ token: "", faturaId: "", dataPagamento: "", valorPago: "" }}
      onSubmit={() => {}}
    >
      {({ values }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Factura ID"
                name="faturaId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Fecha de pago"
                name="dataPagamento"
                type="date"
                variant="outlined"
                margin="dense"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Importe pagado"
                name="valorPago"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                variant="contained"
                color="primary"
                onClick={() => {
                  if (!values.faturaId) {
                    toast.error("Introduzca el número de factura ID.");
                    return;
                  }
                  handleMarkAsPaid(values);
                }}
                style={{ marginRight: 8 }}
              >
                Marcar como paga
              </Button>
              <Button
                variant="contained"
                style={{ marginRight: 8, backgroundColor: "#ff9800", color: "#fff" }}
                onClick={() => {
                  if (!values.faturaId) {
                    toast.error("Introduzca el número de factura ID.");
                    return;
                  }
                  handleCancelFatura(values);
                }}
              >
                Cancelar
              </Button>
              <Button
                variant="outlined"
                color="secondary"
                onClick={() => {
                  if (!values.faturaId) {
                    toast.error("Introduzca el número de factura ID.");
                    return;
                  }
                  if (window.confirm("¿Está seguro de que desea eliminar esta factura?")) {
                    handleDeleteFatura(values);
                  }
                }}
              >
                Eliminar
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de facturas</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Gestiona tus facturas mediante una API externa. Admite facturas regulares y vinculadas a proyectos.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Voltar para tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Resumen</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar facturas:</b> GET {getFaturasEndpoint()}</li>
            <li><b>Buscar factura:</b> GET {getFaturasEndpoint()}/:id</li>
            <li><b>Facturas por proyecto:</b> GET {getFaturasEndpoint()}/project/:projectId</li>
            <li><b>Facturas por cliente:</b> GET {getFaturasEndpoint()}/client/:clientId</li>
            <li><b>Crear:</b> POST {getFaturasEndpoint()}</li>
            <li><b>Actualizar:</b> PUT {getFaturasEndpoint()}/:id</li>
            <li><b>Marcar como pagado:</b> POST {getFaturasEndpoint()}/:id/pay</li>
            <li><b>Cancelar:</b> POST {getFaturasEndpoint()}/:id/cancel</li>
            <li><b>Eliminar:</b> DELETE {getFaturasEndpoint()}/:id</li>
          </ul>
          Enviar siempre header <code>Authorization: Bearer {"{token}"}</code>.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="WhatsApp CRM - API de Faturas"
        requests={postmanRequests}
        filename="whatsapp-api-faturas.json"
        helperText="Introduce el token y haz clic en Descargar para importarlo a Postman."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Ver facturas</Typography>
        <Typography color="textSecondary">
          Enumere todas las facturas o busque una específica. Filtre por estado, recurrencia, cliente o proyecto.
        </Typography>
        {renderListForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. Crear factura</Typography>
        <Typography color="textSecondary">
          Crear una nueva factura. Vincular a un proyecto para facturas de proyectos.
        </Typography>
        {renderCreateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Actualizar factura</Typography>
        <Typography color="textSecondary">
          Cambiar la descripción, el importe, el estado y otra información de la factura.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">4. Acciones</Typography>
        <Typography color="textSecondary">
          Marcar como pagada, cancelar o eliminar factura.
        </Typography>
        {renderActionsForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">último resultado de la prueba</Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiFaturasPage;
