import React, { useState, useEffect, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Typography,
  Paper,
  Grid,
  Switch,
  FormControlLabel,
  Slider,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Button,
  Card,
  CardContent,
  Divider,
  CircularProgress,
  Alert,
  Chip,
  IconButton,
  Tooltip,
} from "@material-ui/core";
import {
  Settings as SettingsIcon,
  PhoneAndroid as PhoneIcon,
  TrendingUp as TrendingIcon,
  Assessment as AnalyticsIcon,
  Save as SaveIcon,
  Refresh as RefreshIcon,
  Info as InfoIcon,
  CheckCircle as CheckIcon,
  Error as ErrorIcon,
} from "@material-ui/icons";
import { toast } from "react-toastify";

import { AuthContext } from "../../context/Auth/AuthContext";
import toastError from "../../errors/toastError";
import { i18n } from "../../translate/i18n";
import {
  getContactSettings,
  updateContactSettings,
  getContactStats,
  testContactConfiguration,
  resetContactSettings,
} from "../../services/contactSettingsService";

const useStyles = makeStyles((theme) => ({
  container: {
    padding: theme.spacing(4),
    width: "100%",
    margin: 0,
    background: "#f8fafc",
    minHeight: "100vh",
  },
  pageHeader: {
    marginBottom: theme.spacing(3),
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },
  pageTitle: {
    fontSize: "28px",
    fontWeight: 700,
    color: "#1a1a2e",
    marginBottom: theme.spacing(0.5),
  },
  pageSubtitle: {
    fontSize: "14px",
    color: "#6b7280",
  },
  section: {
    marginBottom: theme.spacing(3),
  },
  sectionTitle: {
    fontSize: "20px",
    fontWeight: 600,
    color: "#374151",
    marginBottom: theme.spacing(2),
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1),
  },
  card: {
    padding: theme.spacing(3),
    background: "#ffffff",
    borderRadius: "12px",
    boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)",
    marginBottom: theme.spacing(2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 200,
  },
  sliderContainer: {
    margin: theme.spacing(2, 0),
  },
  sliderLabel: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: theme.spacing(1),
  },
  statsCard: {
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    color: "#ffffff",
    padding: theme.spacing(2),
    borderRadius: "8px",
    textAlign: "center",
  },
  statsNumber: {
    fontSize: "32px",
    fontWeight: "bold",
  },
  statsLabel: {
    fontSize: "14px",
    opacity: 0.9,
  },
  actionButtons: {
    display: "flex",
    gap: theme.spacing(2),
    marginTop: theme.spacing(3),
  },
  statusChip: {
    marginLeft: theme.spacing(1),
  },
  loadingContainer: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: theme.spacing(4),
  },
}));

const ContactSettings = () => {
  const classes = useStyles();
  const { user } = useContext(AuthContext);
  const [settings, setSettings] = useState({
    autoSaveContacts: "enabled",
    autoSaveContactsScore: 7,
    autoSaveContactsReason: "high_potential",
  });
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    loadSettings();
    loadStats();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const companyId = user.companyId;
      const response = await getContactSettings(companyId);
      if (response.settings) {
        setSettings(response.settings);
      }
    } catch (err) {
      toastError(err);
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      const companyId = user.companyId;
      const response = await getContactStats(companyId);
      setStats(response);
    } catch (err) {
      toastError(err);
    }
  };

  const handleChange = (field, value) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
    setHasChanges(true);
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const companyId = user.companyId;
      console.log("Enviando configuración:", settings);
      const response = await updateContactSettings(companyId, settings);
      console.log("Respuesta del backend:", response);
      toast.success("¡Configuración guardada correctamente!");
      
      // Actualizar estado con los datos devueltos del backend
      if (response.settings) {
        console.log("Actualizando estado con:", response.settings);
        setSettings(response.settings);
      }
      
      setHasChanges(false);
      loadStats();
    } catch (err) {
      console.error("Error al guardar la configuración:", err);
      toastError(err);
    } finally {
      setLoading(false);
    }
  };

  const handleTest = async () => {
    setTesting(true);
    try {
      const companyId = user.companyId;
      const response = await testContactConfiguration(companyId, {
        testMessage: "Hola, me gustaría saber más sobre sus productos y servicios. Estoy interesado en realizar una compra."
      });
      toast.success(response.message || "¡Prueba completada correctamente!");
    } catch (err) {
      toastError(err);
    } finally {
      setTesting(false);
    }
  };

  const handleReset = async () => {
    if (window.confirm("¿Seguro que desea restablecer la configuración a los valores predeterminados?")) {
      setLoading(true);
      try {
        const companyId = user.companyId;
        await resetContactSettings(companyId);
        toast.success("¡Configuración restablecida correctamente!");
        loadSettings();
        loadStats();
      } catch (err) {
        toastError(err);
      } finally {
        setLoading(false);
      }
    }
  };

  if (loading && !settings) {
    return (
      <div className={classes.loadingContainer}>
        <CircularProgress />
      </div>
    );
  }

  return (
    <div className={classes.container}>
      <div className={classes.pageHeader}>
        <div>
          <Typography className={classes.pageTitle}>
            <SettingsIcon /> Configuración de contactos
          </Typography>
          <Typography className={classes.pageSubtitle}>
            Administrar la deduplicación, la puntuación y el guardado automático de contactos
          </Typography>
        </div>
        {hasChanges && (
          <Chip
            label="Cambios no guardados"
            color="warning"
            size="small"
            className={classes.statusChip}
          />
        )}
      </div>

      {/* Estadísticas rápidas */}
      {stats && (
        <Grid container spacing={3} className={classes.section}>
          <Grid item xs={12} sm={6} md={3}>
            <Card className={classes.statsCard}>
              <Typography className={classes.statsNumber}>
                {stats.totalContacts || 0}
              </Typography>
              <Typography className={classes.statsLabel}>
                Total de contactos
              </Typography>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card className={classes.statsCard}>
              <Typography className={classes.statsNumber}>
                {stats.potentialContacts || 0}
              </Typography>
              <Typography className={classes.statsLabel}>
                Clientes potenciales
              </Typography>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card className={classes.statsCard}>
              <Typography className={classes.statsNumber}>
                {stats.savedToPhone || 0}
              </Typography>
              <Typography className={classes.statsLabel}>
                Guardado en el móvil
              </Typography>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card className={classes.statsCard}>
              <Typography className={classes.statsNumber}>
                {stats.averageScore ? stats.averageScore.toFixed(1) : "0.0"}
              </Typography>
              <Typography className={classes.statsLabel}>
                Puntuación media
              </Typography>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Configurações Principais */}
      <Paper className={classes.card}>
        <Typography className={classes.sectionTitle}>
          <PhoneIcon /> Guardado automático en el móvil
        </Typography>

        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <FormControlLabel
              control={
                <Switch
                  checked={settings.autoSaveContacts !== "disabled"}
                  onChange={(e) => 
                    handleChange("autoSaveContacts", e.target.checked ? "enabled" : "disabled")
                  }
                  color="primary"
                />
              }
              label="Activar el guardado automático"
            />
            <Typography variant="body2" color="textSecondary">
              Guarda automáticamente los contactos importantes en tu móvil
            </Typography>
          </Grid>

          <Grid item xs={12} md={6}>
            <FormControl className={classes.formControl} fullWidth>
              <InputLabel>Criterios de guardado</InputLabel>
              <Select
                value={settings.autoSaveContactsReason}
                onChange={(e) => handleChange("autoSaveContactsReason", e.target.value)}
                disabled={settings.autoSaveContacts === "disabled"}
              >
                <MenuItem value="high_potential">Solo para usuarios de alto potencial</MenuItem>
                <MenuItem value="message_analysis">Análisis de mensajes</MenuItem>
                <MenuItem value="business_hours">Horario comercial</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={12}>
            <div className={classes.sliderContainer}>
              <div className={classes.sliderLabel}>
                <Typography>Puntuación mínima para guardar</Typography>
                <Typography color="primary">
                  {settings.autoSaveContactsScore}
                </Typography>
              </div>
              <Slider
                value={settings.autoSaveContactsScore}
                onChange={(e, value) => handleChange("autoSaveContactsScore", value)}
                min={0}
                max={10}
                step={1}
                marks={[
                  { value: 0, label: "0" },
                  { value: 5, label: "5" },
                  { value: 7, label: "7" },
                  { value: 10, label: "10" },
                ]}
                disabled={settings.autoSaveContacts === "disabled"}
              />
              <Typography variant="caption" color="textSecondary">
                Los contactos con una puntuación igual o superior a este valor se guardarán automáticamente
              </Typography>
            </div>
          </Grid>
        </Grid>
      </Paper>

      {/* Información adicional */}
      <Paper className={classes.card}>
        <Typography className={classes.sectionTitle}>
          <InfoIcon /> Información del sistema
        </Typography>

        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <Typography variant="body2" color="textSecondary">
              <strong>Estado del sistema:</strong>{" "}
              <Chip
                label={settings.autoSaveContacts === "disabled" ? "Deshabilitado" : "Habilitado"}
                color={settings.autoSaveContacts === "disabled" ? "default" : "primary"}
                size="small"
              />
            </Typography>
          </Grid>
          <Grid item xs={12} md={6}>
            <Typography variant="body2" color="textSecondary">
              <strong>Criterios actuales:</strong> {settings.autoSaveContactsReason}
            </Typography>
          </Grid>
          <Grid item xs={12} md={6}>
            <Typography variant="body2" color="textSecondary">
              <strong>Puntuación mínima:</strong> {settings.autoSaveContactsScore}/10
            </Typography>
          </Grid>
          <Grid item xs={12} md={6}>
            <Typography variant="body2" color="textSecondary">
              <strong>Última actualización:</strong> {new Date().toLocaleString()}
            </Typography>
          </Grid>
        </Grid>
      </Paper>

      {/* Botones de acción */}
      <div className={classes.actionButtons}>
        <Button
          variant="contained"
          color="primary"
          startIcon={<SaveIcon />}
          onClick={handleSave}
          disabled={!hasChanges || loading}
        >
          {loading ? "Guardando..." : "Guardar configuración"}
        </Button>

        <Button
          variant="outlined"
          color="secondary"
          startIcon={<RefreshIcon />}
          onClick={handleTest}
          disabled={testing || settings.autoSaveContacts === "disabled"}
        >
          {testing ? "Pruebas..." : "Configuración de prueba"}
        </Button>

        <Button
          variant="outlined"
          color="default"
          startIcon={<RefreshIcon />}
          onClick={handleReset}
          disabled={loading}
        >
          Restablecer valores predeterminados
        </Button>
      </div>
    </div>
  );
};

export default ContactSettings;
