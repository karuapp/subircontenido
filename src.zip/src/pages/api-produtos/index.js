import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  elementMargin: {
    padding: theme.spacing(2)
  },
  formContainer: {
    maxWidth: 520
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiProdutosPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página!");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getProductsEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/products`;

  const postmanRequests = [
    {
      name: "Listar productos",
      method: "GET",
      url: getProductsEndpoint(),
      description: "Devuelve productos externos registrados."
    },
    {
      name: "Buscar producto por ID",
      method: "GET",
      url: `${getProductsEndpoint()}/1`,
      description: "Reemplaza el ID al final de la URL para buscar un producto específico."
    },
    {
      name: "Crear producto",
      method: "POST",
      url: getProductsEndpoint(),
      description: "Crea un nuevo producto externo.",
      body: {
        nome: "Corte de pelo",
        tipo: "servico",
        valor: 149.9,
        descricao: "Producto de ejemplo",
        status: "disponivel"
      }
    },
    {
      name: "Actualizar producto",
      method: "PUT",
      url: `${getProductsEndpoint()}/1`,
      description: "Cambia el ID para actualizar el producto deseado.",
      body: {
        nome: "Corte de pelo (nuevo)",
        status: "indisponivel"
      }
    },
    {
      name: "Eliminar producto",
      method: "DELETE",
      url: `${getProductsEndpoint()}/1`,
      description: "Elimina permanentemente el producto especificado en la ruta."
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const cleanProduct = (product) => ({
    id: product.id,
    nome: product.nome,
    tipo: product.tipo,
    valor: Number(product.valor || 0),
    status: product.status,
    descricao: product.descricao,
    imagemPrincipal: product.imagem_principal,
    galeria: product.galeria,
    dadosEspecificos: product.dados_especificos
  });

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListProducts = async (token) => {
    try {
      const { data } = await axios.get(getProductsEndpoint(), {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult("Lista de productos", {
        ...data,
        products: data.products?.map(cleanProduct)
      });
      toast.success("¡Productos cargados!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowProduct = async (token, productId) => {
    try {
      const { data } = await axios.get(`${getProductsEndpoint()}/${productId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Producto ${productId}`, cleanProduct(data));
      toast.success("¡Producto cargado!");
    } catch (err) {
      toastError(err);
    }
  };

  const buildProductPayload = (values) => {
    const payload = {
      nome: values.nome,
      tipo: values.tipo,
      valor: values.valor ? Number(values.valor) : undefined,
      descricao: values.descricao || null,
      status: values.status || undefined
    };

    if (values.dadosEspecificos) {
      try {
        payload.dados_especificos = JSON.parse(values.dadosEspecificos);
      } catch (error) {
        throw new Error("JSON Datos específicos no válidos.");
      }
    }

    return payload;
  };

  const handleCreateProduct = async (values) => {
    try {
      const payload = buildProductPayload(values);
      const { data } = await axios.post(getProductsEndpoint(), payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Producto creado.", cleanProduct(data));
      toast.success("¡Producto creado correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON Inválido.")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleUpdateProduct = async (values) => {
    try {
      const payload = buildProductPayload(values);
      const { data } = await axios.put(`${getProductsEndpoint()}/${values.productId}`, payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Producto actualizado", cleanProduct(data));
      toast.success("¡Producto actualizado correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleDeleteProduct = async (values) => {
    try {
      await axios.delete(`${getProductsEndpoint()}/${values.productId}`, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Producto eliminado", { id: values.productId, deleted: true });
      toast.success("¡Producto eliminado!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListAndShowForm = () => (
    <Formik
      initialValues={{ token: "", productId: "" }}
      onSubmit={(values) => handleListProducts(values.token)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="ID del producto (opcional para búsqueda)"
                name="productId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar todos"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.productId) {
                    toast.error("Ingrese el ID del producto para buscar un registro.");
                    return;
                  }
                  handleShowProduct(values.token, values.productId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        nome: "",
        tipo: "",
        descricao: "",
        valor: "",
        status: "disponivel",
        dadosEspecificos: ""
      }}
      onSubmit={async (values, actions) => {
        await handleCreateProduct(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre"
                name="nome"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Tipo"
                name="tipo"
                variant="outlined"
                margin="dense"
                fullWidth
                required
                placeholder="producto, servicio..."
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Valor"
                name="valor"
                variant="outlined"
                margin="dense"
                fullWidth
                required
                type="number"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Status"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="Disponible, No disponible..."
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Descripción"
                name="descricao"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label='Datos específicos (JSON)'
                name="dadosEspecificos"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
                placeholder='{"Color": "Rojo"}'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear producto"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        productId: "",
        nome: "",
        tipo: "",
        descricao: "",
        valor: "",
        status: "",
        dadosEspecificos: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateProduct(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Nombre ID"
                name="productId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Producto"
                name="nome"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Tipo"
                name="tipo"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Valor"
                name="valor"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Estado"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre mostrado"
                name="display"
                variant="outlined"
                margin="dense"
                fullWidth
                disabled
                helperText="Campo ilustrativo"
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Descripción"
                name="descricao"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label='Datos específicos (JSON)'
                name="dadosEspecificos"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
                placeholder='{"Color": "Rojo"}'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar producto"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderDeleteForm = () => (
    <Formik
      initialValues={{ token: "", productId: "" }}
      onSubmit={async (values, actions) => {
        await handleDeleteProduct(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Producto ID"
                name="productId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                color="secondary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Eliminar producto"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de Productos</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Generar, visualizar y sincronizar productos externos con los tokens de esta cuenta.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Volver a tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Resumen</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar productos:</b> GET {getProductsEndpoint()}</li>
            <li><b>Buscar producto:</b> GET {getProductsEndpoint()}/:id</li>
            <li><b>Crear producto:</b> POST {getProductsEndpoint()}</li>
            <li><b>Actualizar producto:</b> PUT {getProductsEndpoint()}/:id</li>
            <li><b>Eliminar producto:</b> DELETE {getProductsEndpoint()}/:id</li>
          </ul>
          Enviar siempre header <code>Authorization: Bearer {"{token}"}</code> con un token activo generado en la página API.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="whatsapp - API de Produtos"
        requests={postmanRequests}
        filename="whatsapp-api-produCtos.json"
        helperText="Ingrese el token y haga clic en descargar para importarlo a Postman."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Ver productos</Typography>
        <Typography color="textSecondary">
          Introduzca solo el token para listar todos los productos o añada un ID de producto para buscar un registro específico.
        </Typography>
        {renderListAndShowForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. Crear producto</Typography>
        <Typography color="textSecondary">
          Campos mínimos: <b>nome</b>, <b>tipo</b> y <b>valor</b>. La descripción, el estado y los detalles específicos son opcionales.
        </Typography>
        {renderCreateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Actualizar producto</Typography>
        <Typography color="textSecondary">
          Informar al <b>Product ID</b> Devuelto por el proceso de creación/listado, por favor envíe los campos que desea actualizar.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">4. Excluir produto</Typography>
        <Typography color="textSecondary">
          Esta operação remove o registro definitivamente. Utilize com cuidado.
        </Typography>
        {renderDeleteForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">último resultado de la prueba</Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiProdutosPage;
