import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  elementMargin: {
    padding: theme.spacing(2)
  },
  formContainer: {
    maxWidth: 520
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiClientesPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página!");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getClientsEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/clients`;

  const postmanRequests = [
    {
      name: "Listar clientes",
      method: "GET",
      url: getClientsEndpoint(),
      description: "Devuelve los clientes externos registrados."
    },
    {
      name: "Buscar cliente por ID",
      method: "GET",
      url: `${getClientsEndpoint()}/1`,
      description: "Reemplaza el ID al final de la URL para buscar un cliente específico."
    },
    {
      name: "Crear cliente",
      method: "POST",
      url: getClientsEndpoint(),
      description: "Crea un nuevo cliente externo.",
      body: {
        name: "Cliente María",
        email: "cliente@example.com",
        document: "123.456.789-00",
        phoneNumber: "001234567890"
      }
    },
    {
      name: "Actualizar cliente",
      method: "PUT",
      url: `${getClientsEndpoint()}/1`,
      description: "Cambia el ID para actualizar el cliente deseado.",
      body: {
        name: "Cliente María (editado)",
        email: "nuevo-email@example.com"
      }
    },
    {
      name: "Eliminar cliente",
      method: "DELETE",
      url: `${getClientsEndpoint()}/1`,
      description: "Elimina permanentemente el cliente especificado en la ruta."
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const cleanClient = (client) => ({
    id: client.id,
    name: client.name,
    email: client.email,
    document: client.document,
    phoneNumber: client.phoneNumber,
    status: client.status,
    ownerUserId: client.ownerUserId
  });

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListClients = async (token) => {
    try {
      const { data } = await axios.get(getClientsEndpoint(), {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult("Lista de clientes", {
        ...data,
        clients: data.clients?.map(cleanClient)
      });
      toast.success("¡Clientes cargados!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowClient = async (token, clientId) => {
    try {
      const { data } = await axios.get(`${getClientsEndpoint()}/${clientId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Cliente ${clientId}`, cleanClient(data));
      toast.success("¡Cliente cargado!");
    } catch (err) {
      toastError(err);
    }
  };

  const buildClientPayload = (values) => {
    const payload = {
      name: values.name,
      email: values.email || null,
      document: values.document || null,
      phoneNumber: values.phoneNumber || null
    };

    if (values.customFields) {
      try {
        payload.customFields = JSON.parse(values.customFields);
      } catch (error) {
        throw new Error("JSON no válido en campos personalizados.");
      }
    }

    return payload;
  };

  const handleCreateClient = async (values) => {
    try {
      const payload = buildClientPayload(values);
      const { data } = await axios.post(getClientsEndpoint(), payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Cliente creado.", cleanClient(data));
      toast.success("¡Cliente creado correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON no válido.")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleUpdateClient = async (values) => {
    try {
      const payload = buildClientPayload(values);
      const { data } = await axios.put(`${getClientsEndpoint()}/${values.clientId}`, payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Cliente actualizado.", cleanClient(data));
      toast.success("¡Cliente actualizado correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON Inválido.")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleDeleteClient = async (values) => {
    try {
      await axios.delete(`${getClientsEndpoint()}/${values.clientId}`, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Cliente eliminado", { id: values.clientId, deleted: true });
      toast.success("¡Cliente eliminado!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListAndShowForm = () => (
    <Formik
      initialValues={{ token: "", clientId: "" }}
      onSubmit={(values) => handleListClients(values.token)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="ID de cliente (opcional para buscar uno)"
                name="clientId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar todos"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.clientId) {
                    toast.error("Introduzca el ID del cliente para buscar un registro.");
                    return;
                  }
                  handleShowClient(values.token, values.clientId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        name: "",
        email: "",
        document: "",
        phoneNumber: "",
        customFields: ""
      }}
      onSubmit={async (values, actions) => {
        await handleCreateClient(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="E-mail"
                name="email"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Documento"
                name="document"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Número de teléfono"
                name="phoneNumber"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label='Campos personalizados (JSON)'
                name="customFields"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
                placeholder='{"campo": "valor"}'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear cliente"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        clientId: "",
        name: "",
        email: "",
        document: "",
        phoneNumber: "",
        customFields: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateClient(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Cliente ID"
                name="clientId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="E-mail"
                name="email"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Documento"
                name="document"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Número de teléfono"
                name="phoneNumber"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label='Campos personalizados (JSON)'
                name="customFields"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={3}
                placeholder='{"campo": "valor"}'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar cliente"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderDeleteForm = () => (
    <Formik
      initialValues={{ token: "", clientId: "" }}
      onSubmit={async (values, actions) => {
        await handleDeleteClient(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Cliente ID"
                name="clientId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                color="secondary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Eliminar cliente"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de Clientes</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Generar, consultar y sincronizar clientes externos utilizando los tokens de esta cuenta.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Volver a tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Resumen</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar clientes:</b> GET {getClientsEndpoint()}</li>
            <li><b>Buscar cliente:</b> GET {getClientsEndpoint()}/:id</li>
            <li><b>Criar cliente:</b> POST {getClientsEndpoint()}</li>
            <li><b>Atualizar cliente:</b> PUT {getClientsEndpoint()}/:id</li>
            <li><b>Eliminar cliente:</b> DELETE {getClientsEndpoint()}/:id</li>
          </ul>
          Envía siempre el header <code>Authorization: Bearer {"{token}"}</code> con un token activo generado en la página API.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="WhatsApp CRM - API de Clientes"
        requests={postmanRequests}
        filename="whatsapp-api-clientes.json"
        helperText="Introduce el token y haz clic en Descargar para importarlo a Postman."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Ver clientes</Typography>
        <Typography color="textSecondary">
          Introduce solo el token para listar todos los datos o añade un ID de cliente para buscar un registro específico.
        </Typography>
        {renderListAndShowForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. Crear cliente</Typography>
        <Typography color="textSecondary">
          Campos mínimos: <b>Nombre</b>. E-mail, El documento y el número de teléfono son opcionales.
          Puedes enviar campos personalizados en formato JSON.
        </Typography>
        {renderCreateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Actualizar cliente</Typography>
        <Typography color="textSecondary">
          Reporte de <b>Client ID</b> Se devuelve al crear/publicar y envía los campos que desea actualizar.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">4. Eliminar cliente</Typography>
        <Typography color="textSecondary">
          Esta operación elimina el registro permanentemente. Úselo con precaución.
        </Typography>
        {renderDeleteForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">último resultado de la prueba</Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiClientesPage;