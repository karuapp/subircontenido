import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography,
  MenuItem
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  formContainer: {
    maxWidth: 600
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiUsuariosPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página!");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
  }, []);

  const getUsersEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/users`;

  const postmanRequests = [
    {
      name: "Listar agentes",
      method: "GET",
      url: getUsersEndpoint(),
      description: "Devuelve los usuarios registrados en la empresa."
    },
    {
      name: "Buscar agente por ID",
      method: "GET",
      url: `${getUsersEndpoint()}/1`,
      description: "Reemplaza el ID al final de la URL para buscar un agente específico."
    },
    {
      name: "Crear agente",
      method: "POST",
      url: getUsersEndpoint(),
      description: "Crea un nuevo agente.",
      body: {
        name: "Juan Lopez",
        email: "joao@empresa.com",
        password: "password123",
        profile: "user",
        userType: "professional",
        startWork: "08:00",
        endWork: "18:00",
        workDays: "1,2,3,4,5",
        lunchStart: "12:00",
        lunchEnd: "13:00",
        queueIds: [1, 2]
      }
    },
    {
      name: "Actualizar agente",
      method: "PUT",
      url: `${getUsersEndpoint()}/1`,
      description: "Cambia el ID para actualizar el agente deseado.",
      body: {
        name: "Juan Lopez (editado)",
        profile: "admin",
        workDays: "1,2,3,4,5,6"
      }
    },
    {
      name: "Eliminar agente",
      method: "DELETE",
      url: `${getUsersEndpoint()}/1`,
      description: "Elimina permanentemente al agente especificado."
    },
    {
      name: "Enumerar servicios de agente",
      method: "GET",
      url: `${getUsersEndpoint()}/1/services`,
      description: "Devuelve los servicios vinculados al agente."
    },
    {
      name: "Vincular servicios al agente",
      method: "POST",
      url: `${getUsersEndpoint()}/1/services`,
      description: "Añade servicios al agente.",
      body: { serviceIds: [1, 2, 3] }
    },
    {
      name: "Definir servicios de agente",
      method: "PUT",
      url: `${getUsersEndpoint()}/1/services`,
      description: "Reemplaza todos los servicios del agente.",
      body: { serviceIds: [1, 2] }
    },
    {
      name: "Eliminar servicios de agente",
      method: "DELETE",
      url: `${getUsersEndpoint()}/1/services`,
      description: "Elimina servicios específicos del agente.",
      body: { serviceIds: [3] }
    },
    {
      name: "Obtener la agenda del agente",
      method: "GET",
      url: `${getUsersEndpoint()}/1/schedule`,
      description: "Devuelve la agenda del agente."
    },
    {
      name: "Crear la agenda del agente",
      method: "POST",
      url: `${getUsersEndpoint()}/1/schedule`,
      description: "Crea una agenda para el agente.",
      body: { name: "Agenda principal", description: "Agenda de citas", active: true }
    },
    {
      name: "Enumerar citas",
      method: "GET",
      url: `${getUsersEndpoint()}/1/appointments`,
      description: "Devuelve las citas del agente."
    },
    {
      name: "Crear cita",
      method: "POST",
      url: `${getUsersEndpoint()}/1/appointments`,
      description: "Crea una nueva cita.",
      body: {
        title: "Consulta",
        startDatetime: "2025-01-15T10:00:00",
        durationMinutes: 60,
        serviceId: 1,
        clientId: 1
      }
    },
    {
      name: "Actualizar estado de la cita",
      method: "PATCH",
      url: `${getUsersEndpoint()}/1/appointments/1/status`,
      description: "Actualiza el estado de la cita.",
      body: { status: "confirmed" }
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListUsers = async (token, profile) => {
    try {
      const params = profile ? `?profile=${profile}` : "";
      const { data } = await axios.get(`${getUsersEndpoint()}${params}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult("Lista de Agentes", data);
      toast.success("Agentes cargados!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowUser = async (token, userId) => {
    try {
      const { data } = await axios.get(`${getUsersEndpoint()}/${userId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Agente ${userId}`, data);
      toast.success("Agente cargado!");
    } catch (err) {
      toastError(err);
    }
  };

  const buildUserPayload = (values) => {
    const payload = {
      name: values.name,
      email: values.email,
      password: values.password || undefined,
      profile: values.profile || "user",
      startWork: values.startWork || "00:00",
      endWork: values.endWork || "23:59",
      userType: values.userType || "attendant",
      workDays: values.workDays || "1,2,3,4,5",
      color: values.color || "",
      allTicket: values.allTicket || "disable",
      allowGroup: values.allowGroup === "true" || values.allowGroup === true,
      farewellMessage: values.farewellMessage || ""
    };

    if (values.queueIds) {
      try {
        payload.queueIds = JSON.parse(values.queueIds);
      } catch (error) {
        throw new Error("JSON inválido en queueIds.");
      }
    }

    return payload;
  };

  const handleCreateUser = async (values) => {
    try {
      const payload = buildUserPayload(values);
      const { data } = await axios.post(getUsersEndpoint(), payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Agente creado", data);
      toast.success("Agente creado correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleUpdateUser = async (values) => {
    try {
      const payload = buildUserPayload(values);
      if (!payload.password) delete payload.password;
      const { data } = await axios.put(`${getUsersEndpoint()}/${values.userId}`, payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Agente actualizado", data);
      toast.success("Agente actualizado correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleDeleteUser = async (values) => {
    try {
      await axios.delete(`${getUsersEndpoint()}/${values.userId}`, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Agente eliminado", { id: values.userId, deleted: true });
      toast.success("Agente eliminado!");
    } catch (err) {
      toastError(err);
    }
  };

  // ==================== SERVIÇOS ====================

  const handleListServices = async (token, userId) => {
    try {
      const { data } = await axios.get(`${getUsersEndpoint()}/${userId}/services`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Servicios de Agente ${userId}`, data);
      toast.success("¡Servicios cargados!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleSetServices = async (values) => {
    try {
      let serviceIds;
      try {
        serviceIds = JSON.parse(values.serviceIds);
      } catch (e) {
        toast.error("JSON inválido en serviceIds");
        return;
      }

      const { data } = await axios.put(`${getUsersEndpoint()}/${values.userId}/services`, { serviceIds }, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Servicios actualizados", data);
      toast.success("¡Servicios actualizados!");
    } catch (err) {
      toastError(err);
    }
  };

  // ==================== AGENDA ====================

  const handleGetSchedule = async (token, userId) => {
    try {
      const { data } = await axios.get(`${getUsersEndpoint()}/${userId}/schedule`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Calendario del agente ${userId}`, data);
      toast.success("¡Calendario cargado!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleCreateSchedule = async (values) => {
    try {
      const payload = {
        name: values.scheduleName || `Agenda do usuário ${values.userId}`,
        description: values.scheduleDescription || "",
        active: true
      };

      const { data } = await axios.post(`${getUsersEndpoint()}/${values.userId}/schedule`, payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Calendario creado", data);
      toast.success("¡Calendario creado!");
    } catch (err) {
      toastError(err);
    }
  };

  // ==================== COMPROMISSOS ====================

  const handleListAppointments = async (token, userId) => {
    try {
      const { data } = await axios.get(`${getUsersEndpoint()}/${userId}/appointments`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Citas del agente ${userId}`, data);
      toast.success("¡Citas cargadas!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleCreateAppointment = async (values) => {
    try {
      const payload = {
        title: values.appointmentTitle || "Compromiso",
        startDatetime: values.startDatetime,
        durationMinutes: Number(values.durationMinutes) || 60
      };
      if (values.serviceId) payload.serviceId = Number(values.serviceId);
      if (values.clientId) payload.clientId = Number(values.clientId);
      if (values.appointmentDescription) payload.description = values.appointmentDescription;

      const { data } = await axios.post(`${getUsersEndpoint()}/${values.userId}/appointments`, payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Compromiso creado", data);
      toast.success("¡Compromiso creado!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleUpdateAppointmentStatus = async (values) => {
    try {
      const { data } = await axios.patch(
        `${getUsersEndpoint()}/${values.userId}/appointments/${values.appointmentId}/status`,
        { status: values.status },
        { headers: { Authorization: `Bearer ${values.token}` } }
      );
      saveResult("Estado actualizado", data);
      toast.success("¡Estado actualizado!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListAndShowForm = () => (
    <Formik
      initialValues={{ token: "", userId: "", profile: "" }}
      onSubmit={(values) => handleListUsers(values.token, values.profile)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Agente ID (opcional)"
                name="userId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Perfil (filtro)"
                name="profile"
                variant="outlined"
                margin="dense"
                fullWidth
              >
                <MenuItem value="">Todos</MenuItem>
                <MenuItem value="admin">Admin</MenuItem>
                <MenuItem value="user">Agente</MenuItem>
                <MenuItem value="super">Super</MenuItem>
              </Field>
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar todo"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.userId) {
                    toast.error("Ingrese el ID de agente para buscar.");
                    return;
                  }
                  handleShowUser(values.token, values.userId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        name: "",
        email: "",
        password: "",
        profile: "user",
        startWork: "08:00",
        endWork: "18:00",
        queueIds: ""
      }}
      onSubmit={async (values, actions) => {
        await handleCreateUser(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="E-mail"
                name="email"
                type="email"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Contraseña"
                name="password"
                type="password"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Perfil"
                name="profile"
                variant="outlined"
                margin="dense"
                fullWidth
              >
                <MenuItem value="user">Agente</MenuItem>
                <MenuItem value="admin">Admin</MenuItem>
              </Field>
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Hora de inicio de operaciones"
                name="startWork"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="08:00"
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Hora de fin de operaciones"
                name="endWork"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="18:00"
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label='Departamentos (JSON array de IDs)'
                name="queueIds"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2, 3]'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear agente"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        userId: "",
        name: "",
        email: "",
        password: "",
        profile: "",
        startWork: "",
        endWork: "",
        queueIds: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateUser(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Agente ID"
                name="userId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="E-mail"
                name="email"
                type="email"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Nueva contraseña (opcional)"
                name="password"
                type="password"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Perfil"
                name="profile"
                variant="outlined"
                margin="dense"
                fullWidth
              >
                <MenuItem value="">No cambiar</MenuItem>
                <MenuItem value="user">Agente</MenuItem>
                <MenuItem value="admin">Admin</MenuItem>
              </Field>
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Hora de inicio"
                name="startWork"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="08:00"
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Hora de fin"
                name="endWork"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="18:00"
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label='Departamentos (JSON array de IDs)'
                name="queueIds"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2, 3]'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar agente"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderDeleteForm = () => (
    <Formik
      initialValues={{ token: "", userId: "" }}
      onSubmit={async (values, actions) => {
        await handleDeleteUser(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Agente ID"
                name="userId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                color="secondary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Eliminar Agente"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderServicesForm = () => (
    <Formik
      initialValues={{ token: "", userId: "", serviceIds: "" }}
      onSubmit={() => {}}
    >
      {({ values }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Agente ID"
                name="userId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label='ID de servicio (JSON)'
                name="serviceIds"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2, 3]'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.userId) {
                    toast.error("Ingrese el ID de agente.");
                    return;
                  }
                  handleListServices(values.token, values.userId);
                }}
                style={{ marginRight: 8 }}
              >
                Enumerar servicios
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={() => {
                  if (!values.userId || !values.serviceIds) {
                    toast.error("Ingrese el ID de agente y los ID de servicio.");
                    return;
                  }
                  handleSetServices(values);
                }}
              >
                Definir servicios
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderScheduleForm = () => (
    <Formik
      initialValues={{ token: "", userId: "", scheduleName: "", scheduleDescription: "" }}
      onSubmit={() => {}}
    >
      {({ values }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Agente ID"
                name="userId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre de la agenda"
                name="scheduleName"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Descripción"
                name="scheduleDescription"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.userId) {
                    toast.error("Introduce el ID de agente.");
                    return;
                  }
                  handleGetSchedule(values.token, values.userId);
                }}
                style={{ marginRight: 8 }}
              >
                Ver agenda
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={() => {
                  if (!values.userId) {
                    toast.error("Informe o User ID.");
                    return;
                  }
                  handleCreateSchedule(values);
                }}
              >
                Crear agenda
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderAppointmentsForm = () => (
    <Formik
      initialValues={{
        token: "",
        userId: "",
        appointmentId: "",
        appointmentTitle: "",
        startDatetime: "",
        durationMinutes: "60",
        serviceId: "",
        clientId: "",
        status: ""
      }}
      onSubmit={() => {}}
    >
      {({ values }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Agente ID"
                name="userId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Título"
                name="appointmentTitle"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Fecha/Hora"
                name="startDatetime"
                type="datetime-local"
                variant="outlined"
                margin="dense"
                fullWidth
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Duración (min)"
                name="durationMinutes"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Servicio ID"
                name="serviceId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Cliente ID"
                name="clientId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <Field
                as={TextField}
                label="Cita ID"
                name="appointmentId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Estado (para actualizar)"
                name="status"
                variant="outlined"
                margin="dense"
                fullWidth
                SelectProps={{ native: true }}
              >
                <option value="">Seleccione</option>
                <option value="scheduled">Agendado</option>
                <option value="confirmed">Confirmado</option>
                <option value="completed">Completado</option>
                <option value="cancelled">Cancelado</option>
                <option value="no_show">Sin asistencia</option>
              </Field>
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.userId) {
                    toast.error("Informe o User ID.");
                    return;
                  }
                  handleListAppointments(values.token, values.userId);
                }}
                style={{ marginRight: 8 }}
              >
                Listar citas
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={() => {
                  if (!values.userId || !values.startDatetime) {
                    toast.error("Ingrese el ID de agente y la fecha/hora.");
                    return;
                  }
                  handleCreateAppointment(values);
                }}
                style={{ marginRight: 8 }}
              >
                Crear cita
              </Button>
              <Button
                variant="contained"
                style={{ backgroundColor: "#ff9800", color: "#fff" }}
                onClick={() => {
                  if (!values.userId || !values.appointmentId || !values.status) {
                    toast.error("Ingrese el ID de agente, el ID de la cita y el estado.");
                    return;
                  }
                  handleUpdateAppointmentStatus(values);
                }}
              >
                Actualizar estado
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de agente</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Gestionar agente de la empresa mediante API externa.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Volver a tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Información general</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar agente:</b> GET {getUsersEndpoint()}</li>
            <li><b>Buscar agente:</b> GET {getUsersEndpoint()}/:id</li>
            <li><b>Crear agente:</b> POST {getUsersEndpoint()}</li>
            <li><b>Actualizar agente:</b> PUT {getUsersEndpoint()}/:id</li>
            <li><b>Eliminar agente:</b> DELETE {getUsersEndpoint()}/:id</li>
          </ul>
          <b>Servicios del agente:</b>
          <ul>
            <li>GET {getUsersEndpoint()}/:id/services - Listar servicios</li>
            <li>POST {getUsersEndpoint()}/:id/services - Añadir servicios</li>
            <li>PUT {getUsersEndpoint()}/:id/services - Definir servicios</li>
            <li>DELETE {getUsersEndpoint()}/:id/services - Eliminar servicios</li>
          </ul>
          <b>Agenda e compromissos:</b>
          <ul>
            <li>GET {getUsersEndpoint()}/:id/schedule - Obtener agenda</li>
            <li>POST {getUsersEndpoint()}/:id/schedule - Crear agenda</li>
            <li>GET {getUsersEndpoint()}/:id/appointments - Listar citas</li>
            <li>POST {getUsersEndpoint()}/:id/appointments - Crear cita</li>
            <li>PATCH {getUsersEndpoint()}/:id/appointments/:appointmentId/status - Actualizar estado</li>
          </ul>
          Envíe siempre el header <code>Authorization: Bearer {"token"}</code> con un token activo.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="whatsapp - API de Usuários"
        requests={postmanRequests}
        filename="whatsapp-api-agentes.json"
        helperText="Ingrese el token y haga clic en descargar para importarlo a Postman."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Consultar a los agentes</Typography>
        <Typography color="textSecondary">
          Introduce el token para listar todos los usuarios o añade un ID de agente para buscar uno específico.
        </Typography>
        {renderListAndShowForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. Crear agente</Typography>
        <Typography color="textSecondary">
          Campos obligatorios: <b>name</b>, <b>email</b> y <b>password</b>.
        </Typography>
        {renderCreateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Actualizar agente</Typography>
        <Typography color="textSecondary">
          Introduce el <b>Agente ID</b> y complete los campos que desea actualizar.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">4. Eliminar agente</Typography>
        <Typography color="textSecondary">
          Elimina al agente permanentemente.
        </Typography>
        {renderDeleteForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">5. Servicios del agente</Typography>
        <Typography color="textSecondary">
          Vincular servicios al agente (para profesionales que prestan servicios).
        </Typography>
        {renderServicesForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">6. Calendario del agente</Typography>
        <Typography color="textSecondary">
          Administra el calendario y las citas del agente.
        </Typography>
        {renderScheduleForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">7. Citas</Typography>
        <Typography color="textSecondary">
          Crea y administra citas en el calendario del agente.
        </Typography>
        {renderAppointmentsForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">Resultado de la última prueba</Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiUsuariosPage;
