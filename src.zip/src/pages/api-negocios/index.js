import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  elementMargin: {
    padding: theme.spacing(2)
  },
  formContainer: {
    maxWidth: 520
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiNegociosPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página!");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getNegociosEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/negocios`;

  const postmanRequests = [
    {
      name: "Listar negocios",
      method: "GET",
      url: getNegociosEndpoint(),
      description: "Devuelve los negocios registrados en la empresa."
    },
    {
      name: "Buscar negocio por ID",
      method: "GET",
      url: `${getNegociosEndpoint()}/1`,
      description: "Reemplaza el ID al final de la URL para buscar un negocio específico."
    },
    {
      name: "Crear negocio",
      method: "POST",
      url: getNegociosEndpoint(),
      description: "Crea un nuevo negocio.",
      body: {
        name: "Ventas en línea",
        description: "Embudo de ventas para comercio electrónico",
        kanbanBoards: [1, 2, 3],
        users: [1, 2]
      }
    },
    {
      name: "Actualizar negocio",
      method: "PUT",
      url: `${getNegociosEndpoint()}/1`,
      description: "Cambie el ID para actualizar la negocio deseada.",
      body: {
        name: "Ventas en línea (editado)",
        description: "Nueva descripción"
      }
    },
    {
      name: "Eliminar negocio",
      method: "DELETE",
      url: `${getNegociosEndpoint()}/1`,
      description: "Elimina permanentemente la negocio especificada en la ruta."
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const cleanNegocio = (negocio) => ({
    id: negocio.id,
    name: negocio.name,
    description: negocio.description,
    kanbanBoards: negocio.kanbanBoards,
    users: negocio.users
  });

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListNegocios = async (token) => {
    try {
      const { data } = await axios.get(getNegociosEndpoint(), {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult("Lista de negocio", {
        ...data,
        negocios: data.negocios?.map(cleanNegocio)
      });
      toast.success("negocio cargadas!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowNegocio = async (token, negocioId) => {
    try {
      const { data } = await axios.get(`${getNegociosEndpoint()}/${negocioId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`negocio ${negocioId}`, cleanNegocio(data));
      toast.success("negocio cargada!");
    } catch (err) {
      toastError(err);
    }
  };

  const buildNegocioPayload = (values) => {
    const payload = {
      name: values.name,
      description: values.description || null
    };

    if (values.kanbanBoards) {
      try {
        payload.kanbanBoards = JSON.parse(values.kanbanBoards);
      } catch (error) {
        throw new Error("JSON no válido en kanbanBoards.");
      }
    }

    if (values.users) {
      try {
        payload.users = JSON.parse(values.users);
      } catch (error) {
        throw new Error("JSON no válido en users.");
      }
    }

    return payload;
  };

  const handleCreateNegocio = async (values) => {
    try {
      const payload = buildNegocioPayload(values);
      const { data } = await axios.post(getNegociosEndpoint(), payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("negocio creada", cleanNegocio(data));
      toast.success("negocio creada correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON Inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleUpdateNegocio = async (values) => {
    try {
      const payload = buildNegocioPayload(values);
      const { data } = await axios.put(`${getNegociosEndpoint()}/${values.negocioId}`, payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Negocio actualizado", cleanNegocio(data));
      toast.success("¡Negocio actualizado correctamente!");
    } catch (err) {
      if (err.message?.includes("JSON inválido")) {
        toast.error(err.message);
        return;
      }
      toastError(err);
    }
  };

  const handleDeleteNegocio = async (values) => {
    try {
      await axios.delete(`${getNegociosEndpoint()}/${values.negocioId}`, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Negocio eliminado", { id: values.negocioId, deleted: true });
      toast.success("¡Negocio eliminado!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListAndShowForm = () => (
    <Formik
      initialValues={{ token: "", negocioId: "" }}
      onSubmit={(values) => handleListNegocios(values.token)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="ID del negocio (opcional para buscar uno)"
                name="negocioId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar todos"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.negocioId) {
                    toast.error("Ingrese el ID del negocio para buscar un registro.");
                    return;
                  }
                  handleShowNegocio(values.token, values.negocioId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        name: "",
        description: "",
        kanbanBoards: "",
        users: ""
      }}
      onSubmit={async (values, actions) => {
        await handleCreateNegocio(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Nombre del negocio"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Descripción"
                name="description"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label='Etiquetas Kanban (JSON array de IDs)'
                name="kanbanBoards"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2, 3]'
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label='Usuarios (JSON array de IDs)'
                name="users"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2]'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear negocio"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        negocioId: "",
        name: "",
        description: "",
        kanbanBoards: "",
        users: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateNegocio(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Negocio ID"
                name="negocioId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Descripción"
                name="description"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label='Etiquetas Kanban (JSON array de IDs)'
                name="kanbanBoards"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2, 3]'
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label='Usuarios (JSON array de IDs)'
                name="users"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2]'
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar negocio"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderDeleteForm = () => (
    <Formik
      initialValues={{ token: "", negocioId: "" }}
      onSubmit={async (values, actions) => {
        await handleDeleteNegocio(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Negocio ID"
                name="negocioId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                color="secondary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Eliminar transacción"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de Negocios</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Gestiona negocios (embudos) mediante una API externa.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Volver a tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Resumen</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar negocios:</b> GET {getNegociosEndpoint()}</li>
            <li><b>Buscar una negocios:</b> GET {getNegociosEndpoint()}/:id</li>
            <li><b>Crear una negocios:</b> POST {getNegociosEndpoint()}</li>
            <li><b>Actualizar una negocios:</b> PUT {getNegociosEndpoint()}/:id</li>
            <li><b>Eliminar una negocios:</b> DELETE {getNegociosEndpoint()}/:id</li>
          </ul>
          Enviar siempre header <code>Authorization: Bearer {"{token}"}</code> con un token activo generado en la página API.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="whatsapp - API de Negocios"
        requests={postmanRequests}
        filename="whatsapp-api-negocios.json"
        helperText="Introduce el token y haz clic en Descargar para importarlo a Postman."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Ver negocios</Typography>
        <Typography color="textSecondary">
          Introduce solo el token para ver todas los negocios o añade un ID de oferta para buscar un registro específico.
        </Typography>
        {renderListAndShowForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. Crear un negocio</Typography>
        <Typography color="textSecondary">
          Campo obligatorio: <b>name</b>. Descripción, kanbanBoards y los usuarios son opcionales..
        </Typography>
        {renderCreateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Actualizar negocio</Typography>
        <Typography color="textSecondary">
          Informar al <b>Negocio ID</b> y envíe los campos que desea actualizar.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">4. Eliminar negocio</Typography>
        <Typography color="textSecondary">
          Esta operación elimina el negocio permanentemente. Úselo con precaución.
        </Typography>
        {renderDeleteForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">último resultado de la prueba</Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiNegociosPage;
