import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  formContainer: {
    maxWidth: 600
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiConexoesPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("¡Esta empresa no tiene permiso para acceder a esta página!");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
  }, []);

  const getWhatsappsEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/whatsapps`;

  const postmanRequests = [
    {
      name: "Listar conexiones",
      method: "GET",
      url: getWhatsappsEndpoint(),
      description: "Devuelve todas las conexiones de WhatsApp de la empresa."
    },
    {
      name: "Buscar conexión por ID",
      method: "GET",
      url: `${getWhatsappsEndpoint()}/1`,
      description: "Devuelve los detalles de una conexión específica."
    },
    {
      name: "Estado de la conexión",
      method: "GET",
      url: `${getWhatsappsEndpoint()}/1/status`,
      description: "Devuelve el estado actual de la conexión."
    },
    {
      name: "Obter QR Code",
      method: "GET",
      url: `${getWhatsappsEndpoint()}/1/qrcode`,
      description: "Devuelve el código QR para escanear con WhatsApp."
    },
    {
      name: "Crear conexión",
      method: "POST",
      url: getWhatsappsEndpoint(),
      description: "Crea una nueva conexión de WhatsApp.",
      body: {
        name: "Nueva WhatsApp",
        greetingMessage: "¡Hola! Bienvenido.",
        farewellMessage: "¡Gracias por contactarnos!",
        isDefault: false,
        queueIds: [1, 2]
      }
    },
    {
      name: "Actualizar conexión",
      method: "PUT",
      url: `${getWhatsappsEndpoint()}/1`,
      description: "Actualiza la configuración de la conexión.",
      body: {
        name: "WhatsApp Principal",
        greetingMessage: "¡Hola! Bienvenido.",
        farewellMessage: "¡Gracias por contactarnos!",
        isDefault: true,
        queueIds: [1, 2]
      }
    },
    {
      name: "Eliminar conexión",
      method: "DELETE",
      url: `${getWhatsappsEndpoint()}/1`,
      description: "Elimina una conexión de WhatsApp."
    },
    {
      name: "Reiniciar conexión",
      method: "POST",
      url: `${getWhatsappsEndpoint()}/1/restart`,
      description: "Reinicia la conexión para generar un nuevo código QR."
    },
    {
      name: "Desconectar",
      method: "POST",
      url: `${getWhatsappsEndpoint()}/1/disconnect`,
      description: "Desconecta la sesión de WhatsApp."
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListWhatsapps = async (token) => {
    try {
      const { data } = await axios.get(getWhatsappsEndpoint(), {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult("Lista de conexiones", data);
      toast.success("¡Conexiones cargadas!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowWhatsapp = async (token, whatsappId) => {
    try {
      const { data } = await axios.get(`${getWhatsappsEndpoint()}/${whatsappId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Conexión ${whatsappId}`, data);
      toast.success("¡Conexión cargada!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleGetStatus = async (token, whatsappId) => {
    try {
      const { data } = await axios.get(`${getWhatsappsEndpoint()}/${whatsappId}/status`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Estado de la conexión ${whatsappId}`, data);
      toast.success("¡Estado cargado!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleUpdateWhatsapp = async (values) => {
    try {
      const payload = {};
      if (values.name) payload.name = values.name;
      if (values.greetingMessage) payload.greetingMessage = values.greetingMessage;
      if (values.farewellMessage) payload.farewellMessage = values.farewellMessage;
      if (values.outOfHoursMessage) payload.outOfHoursMessage = values.outOfHoursMessage;
      if (values.isDefault !== "") payload.isDefault = values.isDefault === "true";
      if (values.allowGroup !== "") payload.allowGroup = values.allowGroup === "true";
      if (values.queueIds) {
        try {
          payload.queueIds = JSON.parse(values.queueIds);
        } catch (e) {
          toast.error("JSON no válido en queueIds");
          return;
        }
      }

      const { data } = await axios.put(`${getWhatsappsEndpoint()}/${values.whatsappId}`, payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Conexión actualizada", data);
      toast.success("¡Conexión actualizada!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleRestartWhatsapp = async (values) => {
    try {
      const { data } = await axios.post(`${getWhatsappsEndpoint()}/${values.whatsappId}/restart`, {}, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Conexión reiniciándose", data);
      toast.success("¡Conexión reiniciándose!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleDisconnectWhatsapp = async (values) => {
    try {
      const { data } = await axios.post(`${getWhatsappsEndpoint()}/${values.whatsappId}/disconnect`, {}, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Conexión desconectada", data);
      toast.success("¡Conexión desconectada!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleCreateWhatsapp = async (values) => {
    try {
      const payload = {
        name: values.name
      };
      if (values.greetingMessage) payload.greetingMessage = values.greetingMessage;
      if (values.farewellMessage) payload.farewellMessage = values.farewellMessage;
      if (values.outOfHoursMessage) payload.outOfHoursMessage = values.outOfHoursMessage;
      if (values.isDefault !== "") payload.isDefault = values.isDefault === "true";
      if (values.allowGroup !== "") payload.allowGroup = values.allowGroup === "true";
      if (values.queueIds) {
        try {
          payload.queueIds = JSON.parse(values.queueIds);
        } catch (e) {
          toast.error("JSON no válido en queueIds");
          return;
        }
      }

      const { data } = await axios.post(getWhatsappsEndpoint(), payload, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Conexión creada", data);
      toast.success("¡Conexión creada! Espere el código QR.");
    } catch (err) {
      toastError(err);
    }
  };

  const handleGetQrCode = async (token, whatsappId) => {
    try {
      const { data } = await axios.get(`${getWhatsappsEndpoint()}/${whatsappId}/qrcode`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Código QR de conexión ${whatsappId}`, data);
      if (data.qrcode) {
        toast.success("¡Código QR disponible!");
      } else {
        toast.info(data.message || "Código QR aún no disponible.");
      }
    } catch (err) {
      toastError(err);
    }
  };

  const handleDeleteWhatsapp = async (values) => {
    try {
      const { data } = await axios.delete(`${getWhatsappsEndpoint()}/${values.whatsappId}`, {
        headers: { Authorization: `Bearer ${values.token}` }
      });
      saveResult("Conexión eliminada", data);
      toast.success("¡Conexión eliminada!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListForm = () => (
    <Formik
      initialValues={{ token: "", whatsappId: "" }}
      onSubmit={(values) => handleListWhatsapps(values.token)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Whatsapp ID (opcional)"
                name="whatsappId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Ver todos"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.whatsappId) {
                    toast.error("Informe o Whatsapp ID.");
                    return;
                  }
                  handleShowWhatsapp(values.token, values.whatsappId);
                }}
                style={{ marginRight: 8 }}
              >
                Buscar por ID
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.whatsappId) {
                    toast.error("Informe o Whatsapp ID.");
                    return;
                  }
                  handleGetStatus(values.token, values.whatsappId);
                }}
                style={{ marginRight: 8 }}
              >
                Ver estado
              </Button>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => {
                  if (!values.whatsappId) {
                    toast.error("Ingresar ID de WhatsApp.");
                    return;
                  }
                  handleGetQrCode(values.token, values.whatsappId);
                }}
              >
                Ver código QR
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        name: "",
        greetingMessage: "",
        farewellMessage: "",
        outOfHoursMessage: "",
        isDefault: "",
        allowGroup: "",
        queueIds: ""
      }}
      onSubmit={async (values, actions) => {
        if (!values.name) {
          toast.error("El nombre es obligatorio.");
          actions.setSubmitting(false);
          return;
        }
        await handleCreateWhatsapp(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Nombre de la conexión"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de bienvenida"
                name="greetingMessage"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de despedida"
                name="farewellMessage"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label='Departamento (JSON array)'
                name="queueIds"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2]'
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Conexión predeterminada"
                name="isDefault"
                variant="outlined"
                margin="dense"
                fullWidth
                SelectProps={{ native: true }}
              >
                <option value="">No</option>
                <option value="true">Sí</option>
                <option value="false">No</option>
              </Field>
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Permitir grupos"
                name="allowGroup"
                variant="outlined"
                margin="dense"
                fullWidth
                SelectProps={{ native: true }}
              >
                <option value="">No</option>
                <option value="true">Sí</option>
                <option value="false">No</option>
              </Field>
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear conexión"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        whatsappId: "",
        name: "",
        greetingMessage: "",
        farewellMessage: "",
        outOfHoursMessage: "",
        isDefault: "",
        allowGroup: "",
        queueIds: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateWhatsapp(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Whatsapp ID"
                name="whatsappId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de bienvenida"
                name="greetingMessage"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de despedida"
                name="farewellMessage"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje fuera de horario"
                name="outOfHoursMessage"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label='Departamento (JSON array)'
                name="queueIds"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder='[1, 2]'
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Conexión predeterminada"
                name="isDefault"
                variant="outlined"
                margin="dense"
                fullWidth
                SelectProps={{ native: true }}
              >
                <option value="">No cambiar</option>
                <option value="true">Sí</option>
                <option value="false">No</option>
              </Field>
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                select
                label="Permitir grupos"
                name="allowGroup"
                variant="outlined"
                margin="dense"
                fullWidth
                SelectProps={{ native: true }}
              >
                <option value="">No cambiar</option>
                <option value="true">Sí</option>
                <option value="false">No</option>
              </Field>
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar conexión"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderActionsForm = () => (
    <Formik
      initialValues={{ token: "", whatsappId: "" }}
      onSubmit={() => {}}
    >
      {({ values }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Whatsapp ID"
                name="whatsappId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                variant="contained"
                color="primary"
                onClick={() => {
                  if (!values.whatsappId) {
                    toast.error("Ingresar Whatsapp ID.");
                    return;
                  }
                  handleRestartWhatsapp(values);
                }}
                style={{ marginRight: 8 }}
              >
                Reiniciar Conexão
              </Button>
              <Button
                variant="contained"
                color="secondary"
                onClick={() => {
                  if (!values.whatsappId) {
                    toast.error("Ingresar Whatsapp ID.");
                    return;
                  }
                  handleDisconnectWhatsapp(values);
                }}
                style={{ marginRight: 8 }}
              >
                Desconectar
              </Button>
              <Button
                variant="outlined"
                color="secondary"
                onClick={() => {
                  if (!values.whatsappId) {
                    toast.error("Ingresar Whatsapp ID.");
                    return;
                  }
                  if (window.confirm("¿Seguro que desea eliminar esta conexión?")) {
                    handleDeleteWhatsapp(values);
                  }
                }}
              >
                Eliminar
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de conexiones de WhatsApp</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Gestiona las conexiones de WhatsApp mediante una API externa.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Voltar para tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Resumen</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar conexiones:</b> GET {getWhatsappsEndpoint()}</li>
            <li><b>Buscar conexión:</b> GET {getWhatsappsEndpoint()}/:id</li>
            <li><b>Estado:</b> GET {getWhatsappsEndpoint()}/:id/status</li>
            <li><b>QR Code:</b> GET {getWhatsappsEndpoint()}/:id/qrcode</li>
            <li><b>Crear:</b> POST {getWhatsappsEndpoint()}</li>
            <li><b>Actualizar:</b> PUT {getWhatsappsEndpoint()}/:id</li>
            <li><b>Eliminar:</b> DELETE {getWhatsappsEndpoint()}/:id</li>
            <li><b>Reiniciar:</b> POST {getWhatsappsEndpoint()}/:id/restart</li>
            <li><b>Desconectar:</b> POST {getWhatsappsEndpoint()}/:id/disconnect</li>
          </ul>
          Enviar siempre el encabezado <code>Authorization: Bearer {"{token}"}</code>.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="WhatsApp - API de conexiones de WhatsApp"
        requests={postmanRequests}
        filename="whatsapp-api-conexiones.json"
        helperText="Ingrese el token y haga clic en Descargar para importarlo a Postman."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Ver conexiones</Typography>
        <Typography color="textSecondary">
          Vea todas las conexiones o busque una específica por ID. Use "Ver código QR" para obtener el código escaneado.
        </Typography>
        {renderListForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. Crear una conexión</Typography>
        <Typography color="textSecondary">
          Crea una nueva conexión de WhatsApp. Después de crearla, usa "Ver código QR" para escanearla.
        </Typography>
        {renderCreateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Actualizar conexión</Typography>
        <Typography color="textSecondary">
          Cambia el nombre, los mensajes y la configuración de la conexión.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">4. Acciones</Typography>
        <Typography color="textSecondary">
          Reinicia, desconecta o elimina la conexión de WhatsApp.
        </Typography>
        {renderActionsForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">último resultado de la prueba</Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiConexoesPage;
