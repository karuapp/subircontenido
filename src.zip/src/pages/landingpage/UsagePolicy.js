import React, { useContext } from "react";
import LegalPageLayout from "./LegalPageLayout";
import ColorModeContext from "../../layout/themeContext";

const UsagePolicy = () => {
  const { colorMode } = useContext(ColorModeContext) || {};

  const appName = colorMode?.appName || "Mi Aplicación";

  return (
    <LegalPageLayout
      title={`Política de Uso Aceptable de ${appName}`}
      intro={`Esta Política de Uso establece las normas obligatorias para garantizar un entorno seguro, legal y profesional dentro de ${appName}.`}
    >
      <p>
        Esta Política de Uso Aceptable (“AUP”) regula el comportamiento de los
        usuarios que utilizan {appName}, una plataforma SaaS de CRM omnicanal
        con integración a WhatsApp, redes sociales e inteligencia artificial.
        El incumplimiento podrá derivar en suspensión o cancelación inmediata
        del servicio.
      </p>

      <h2>1. Uso legal y responsable</h2>
      <p>
        El usuario se compromete a utilizar {appName} conforme a la legislación
        aplicable y a las políticas de los proveedores externos integrados
        (WhatsApp, Meta, APIs, etc.).
      </p>

      <ul>
        <li>No realizar actividades ilícitas o fraudulentas.</li>
        <li>No enviar comunicaciones masivas sin consentimiento previo.</li>
        <li>No utilizar bases de datos adquiridas sin autorización legal.</li>
        <li>No suplantar identidad ni engañar a terceros.</li>
      </ul>

      <h2>2. Prohibición de SPAM y abuso</h2>
      <p>
        Está estrictamente prohibido utilizar la plataforma para:
      </p>

      <ul>
        <li>Envío de SPAM o mensajes no solicitados.</li>
        <li>Phishing o intentos de obtención fraudulenta de datos.</li>
        <li>Campañas que violen políticas de WhatsApp o redes sociales.</li>
        <li>Automatizaciones diseñadas para evadir controles de terceros.</li>
      </ul>

      <h2>3. Uso de Inteligencia Artificial</h2>
      <p>
        Las funcionalidades de IA deben utilizarse de manera ética y
        responsable. Está prohibido generar:
      </p>

      <ul>
        <li>Contenido ilegal o engañoso.</li>
        <li>Mensajes discriminatorios o de odio.</li>
        <li>Contenido que infrinja derechos de terceros.</li>
      </ul>

      <p>
        {appName} se reserva el derecho de limitar o desactivar funciones de IA
        en caso de uso indebido.
      </p>

      <h2>4. Protección de datos y privacidad</h2>
      <p>
        El usuario es responsable de contar con base legal para recopilar y
        procesar datos de sus clientes. Deberá:
      </p>

      <ul>
        <li>Obtener consentimiento cuando sea requerido por ley.</li>
        <li>Permitir la eliminación de datos si el titular lo solicita.</li>
        <li>Implementar políticas internas de retención adecuadas.</li>
      </ul>

      <h2>5. Límites técnicos</h2>
      <p>
        El usuario deberá respetar los límites técnicos y operativos del plan
        contratado. Queda prohibido:
      </p>

      <ul>
        <li>Intentar vulnerar la seguridad de la plataforma.</li>
        <li>Realizar pruebas de penetración sin autorización escrita.</li>
        <li>Explotar errores o vulnerabilidades.</li>
      </ul>

      <h2>6. Integraciones externas</h2>
      <p>
        Las integraciones con servicios de terceros deben cumplir las
        condiciones establecidas por dichos proveedores. {appName} no es
        responsable por bloqueos o sanciones aplicadas por terceros debido al
        mal uso por parte del cliente.
      </p>

      <h2>7. Supervisión y cumplimiento</h2>
      <p>
        {appName} podrá investigar actividades sospechosas y solicitar
        información adicional al usuario. Nos reservamos el derecho de
        suspender o cancelar cuentas que incumplan esta política.
      </p>

      <h2>8. Consecuencias del incumplimiento</h2>
      <p>
        Las violaciones podrán resultar en:
      </p>

      <ul>
        <li>Advertencia formal.</li>
        <li>Limitación temporal de funcionalidades.</li>
        <li>Suspensión inmediata de la cuenta.</li>
        <li>Cancelación definitiva sin derecho a reembolso.</li>
      </ul>

      <h2>9. Modificaciones</h2>
      <p>
        {appName} podrá modificar esta Política de Uso en cualquier momento.
        La continuidad en el uso del servicio implicará aceptación de los
        cambios.
      </p>
    </LegalPageLayout>
  );
};

export default UsagePolicy;