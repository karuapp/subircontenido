import React, { useMemo, useContext  } from "react";
import { useHistory, useParams } from "react-router-dom";

import LandingFooter from "./Footer";
import ColorModeContext from "../../layout/themeContext"; // ruta según tu proyecto
import backgroundImage from "../../assets/fundolp.png";

const contentMap = {
  "super-ia": {
    heroTitle: "Super IA que entiende y responde como un humano",
    heroHighlight: "Inteligencia contextual avanzada",
    heroDescription:
      "Nuestra IA analiza intención, contexto y datos históricos para ofrecer respuestas naturales, precisas y alineadas con tu negocio.",
    badges: ["IA contextual", "Aprendizaje continuo", "Respuestas naturales"],
    sections: [
      {
        title: "Comprensión real del cliente",
        description:
          "Detecta intención, tono y urgencia para ofrecer respuestas inteligentes y oportunas.",
        bullets: [
          "Análisis semántico avanzado",
          "Detección automática de intención",
          "Mejora continua con entrenamiento"
        ]
      },
      {
        title: "Automatización con criterio",
        description:
          "No solo responde: decide cuándo escalar a un agente humano.",
        bullets: [
          "Escalamiento inteligente",
          "Priorización automática",
          "Integración con CRM"
        ]
      }
    ],
    ctaLabel: "Quiero activar la Super IA"
  },

  "kanban": {
    heroTitle: "Panel Kanban para gestionar leads y conversaciones",
    heroHighlight: "Organización visual",
    heroDescription:
      "Visualiza cada conversación en columnas personalizadas y mueve tus oportunidades según su estado.",
    badges: ["Drag & drop", "Columnas personalizadas", "Gestión de leads"],
    sections: [
      {
        title: "Control total del embudo",
        description:
          "Administra clientes potenciales desde el primer contacto hasta el cierre.",
        bullets: [
          "Estados personalizados",
          "Vista por agente",
          "Filtros avanzados"
        ]
      },
      {
        title: "Productividad en equipo",
        description:
          "Mejora la colaboración con asignaciones y seguimiento visual.",
        bullets: [
          "Asignación rápida",
          "Historial por tarjeta",
          "Indicadores de desempeño"
        ]
      }
    ],
    ctaLabel: "Organizar mi equipo"
  },

  "multi-atendimento": {
    heroTitle: "Atención múltiple en un mismo número",
    heroHighlight: "Trabajo en equipo",
    heroDescription:
      "Permite que varios agentes atiendan simultáneamente desde una misma línea de WhatsApp.",
    badges: ["Usuarios ilimitados", "Asignación automática", "Control de acceso"],
    sections: [
      {
        title: "Colaboración sin conflictos",
        description:
          "Evita respuestas duplicadas y mejora la coordinación.",
        bullets: [
          "Bloqueo inteligente de conversación",
          "Notas internas",
          "Transferencias rápidas"
        ]
      }
    ],
    ctaLabel: "Activar atención múltiple"
  },

  "chatbot-inteligente": {
    heroTitle: "Chatbot inteligente que habla el idioma de tu cliente",
    heroHighlight: "Automatización humanizada",
    heroDescription:
      "Flujos guiados por IA que entienden el contexto y personalizan respuestas automáticamente.",
    badges: ["IA propia", "Respuestas naturales", "Ruteo inteligente"],
    sections: [
      {
        title: "Atiende 24/7",
        description:
          "Configura personalidad, tono y reglas de negocio.",
        bullets: [
          "Flujos condicionales",
          "Fallback humano",
          "Variables dinámicas"
        ]
      },
      {
        title: "Constructor visual",
        description:
          "Crea flujos arrastrando bloques sin necesidad de código.",
        bullets: [
          "Bloques preconfigurados",
          "Pruebas integradas",
          "Logs detallados"
        ]
      }
    ],
    ctaLabel: "Quiero mi chatbot"
  },

  "reportes": {
    heroTitle: "Reportes y métricas en tiempo real",
    heroHighlight: "Decisiones basadas en datos",
    heroDescription:
      "Paneles visuales con indicadores clave para medir rendimiento y productividad.",
    badges: ["Dashboards", "KPIs", "Exportación"],
    sections: [
      {
        title: "Métricas detalladas",
        description:
          "Analiza tiempos de respuesta, volumen y desempeño.",
        bullets: [
          "Tiempo promedio",
          "Tasa de resolución",
          "Rendimiento por agente"
        ]
      }
    ],
    ctaLabel: "Ver reportes"
  },

  "fluxos-omnichannel": {
    heroTitle: "Flujos Omnichannel conectando todos tus canales",
    heroHighlight: "Experiencia unificada",
    heroDescription:
      "Orquesta conversaciones en WhatsApp, Instagram y más con historial centralizado.",
    badges: ["Ruteo inteligente", "Canales múltiples", "SLA en tiempo real"],
    sections: [
      {
        title: "Distribución automática",
        description:
          "Reglas por idioma, horario o prioridad.",
        bullets: [
          "Round robin",
          "Por habilidades",
          "Alertas automáticas"
        ]
      }
    ],
    ctaLabel: "Optimizar mis canales"
  },

  "multiplos-numeros": {
    heroTitle: "Gestiona múltiples números desde un solo panel",
    heroHighlight: "Centralización total",
    heroDescription:
      "Administra varias cuentas de WhatsApp sin cambiar de plataforma.",
    badges: ["Multi sesión", "Gestión centralizada", "Escalable"],
    sections: [
      {
        title: "Escala sin límites",
        description:
          "Ideal para agencias y empresas con alto volumen.",
        bullets: [
          "Separación por equipo",
          "Control por número",
          "Monitoreo independiente"
        ]
      }
    ],
    ctaLabel: "Agregar números"
  },

  "setorizacion": {
    heroTitle: "Organiza por departamentos",
    heroHighlight: "Estructura clara",
    heroDescription:
      "Divide tu operación en áreas como ventas, soporte o cobranzas.",
    badges: ["Departamentos", "Permisos", "Orden"],
    sections: [
      {
        title: "Gestión por sector",
        description:
          "Asigna contactos automáticamente al área correspondiente.",
        bullets: [
          "Reglas automáticas",
          "Visibilidad por sector",
          "Control de acceso"
        ]
      }
    ],
    ctaLabel: "Organizar departamentos"
  },

  "campanhas-com-ia": {
    heroTitle: "Campañas masivas con inteligencia artificial",
    heroHighlight: "Conversiones optimizadas",
    heroDescription:
      "Segmenta, personaliza y envía campañas inteligentes con métricas en tiempo real.",
    badges: ["Copy con IA", "Segmentación dinámica", "Dashboard en vivo"],
    sections: [
      {
        title: "Mensajes optimizados",
        description:
          "Genera variantes automáticamente.",
        bullets: [
          "Plantillas inteligentes",
          "Personalización automática",
          "Pruebas A/B"
        ]
      }
    ],
    ctaLabel: "Quiero vender con IA"
  },

  "tags-etiquetas": {
    heroTitle: "Organiza con etiquetas inteligentes",
    heroHighlight: "Segmentación avanzada",
    heroDescription:
      "Clasifica contactos para campañas y seguimiento personalizado.",
    badges: ["Etiquetas personalizadas", "Filtros", "Segmentación"],
    sections: [
      {
        title: "Control total",
        description:
          "Filtra y segmenta fácilmente.",
        bullets: [
          "Automáticas o manuales",
          "Búsqueda rápida",
          "Integración con campañas"
        ]
      }
    ],
    ctaLabel: "Organizar contactos"
  },

  "agendamientos": {
    heroTitle: "Programación automática de mensajes",
    heroHighlight: "Automatización total",
    heroDescription:
      "Envía recordatorios y seguimientos en la fecha exacta.",
    badges: ["Mensajes programados", "Recordatorios", "Seguimiento"],
    sections: [
      {
        title: "Ahorra tiempo",
        description:
          "Configura envíos únicos o recurrentes.",
        bullets: [
          "Programación flexible",
          "Confirmaciones automáticas",
          "Notificaciones internas"
        ]
      }
    ],
    ctaLabel: "Programar mensajes"
  },

  "api-e-webhooks": {
    heroTitle: "API & Webhooks para integrar tu sistema",
    heroHighlight: "Plataforma abierta",
    heroDescription:
      "Conecta tu CRM, ERP o cualquier sistema externo fácilmente.",
    badges: ["REST JSON", "Webhooks", "Documentación"],
    sections: [
      {
        title: "API completa",
        description:
          "Envía mensajes, crea tickets y sincroniza datos.",
        bullets: [
          "Autenticación segura",
          "Versionado",
          "Alta disponibilidad"
        ]
      }
    ],
    ctaLabel: "Explorar API"
  }
};

const FeatureDetailPage = () => {
  const history = useHistory();
  const { slug } = useParams();
  const { colorMode } = useContext(ColorModeContext) || {};

  // ✅ Usamos valores por defecto mientras colorMode carga
  const appName = colorMode?.appName || "Mi Aplicación";
    const logoImage =
    colorMode?.appLogoLight || "../../assets/logo.png";

  const pageData = contentMap[slug];

  const breadcrumbLabel = useMemo(() => {
    if (!pageData) return "Solución";
    const match = Object.entries(contentMap).find(([key]) => key === slug);
    if (!match) return "Solución";
    const textMap = {
      "super-ia": "Super IA",
      "kanban": "Kanban",
      "multi-atendimento": "Multi Atención",
      "chatbot-inteligente": "Chatbot Inteligente",
      "reportes": "Reportes",
      "fluxos-omnichannel": "Flujos Omnichannel",
      "multiplos-numeros": "Múltiples Números",
      "setorizacion": "Sectorización",
      "campanhas-com-ia": "Campañas con IA",
      "tags-etiquetas": "Tags y Etiquetas",
      "agendamientos": "Agendamientos",
      "api-e-webhooks": "API & Webhooks"
    };
    return textMap[slug] || "Solución";
  }, [slug, pageData]);

  if (!pageData) {
    return (
      <div className="feature-detail feature-detail--notfound">
        <style>{`
          .feature-detail--notfound {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 16px;
            font-family: "Segoe UI", sans-serif;
          }
          .feature-detail--notfound button {
            padding: 10px 24px;
            border-radius: 999px;
            border: none;
            background: #5f47ff;
            color: #fff;
            font-weight: 600;
            cursor: pointer;
          }
        `}</style>
        <h2>Contenido no encontrado</h2>
        <p>Seleccione una de las soluciones en la página de inicio.</p>
        <button type="button" onClick={() => history.push("/")}>Volver arriba</button>
      </div>
    );
  }

  return (
    <div className="feature-detail">
      <style>{`
        .feature-detail {
          min-height: 100vh;
          background: linear-gradient(180deg, #f9f9ff 0%, #eef0ff 35%, #ffffff 100%);
          color: #0f172a;
        }

        .feature-detail__hero {
          padding: 32px 24px 80px;
          background-image: url(${backgroundImage});
          background-size: cover;
          background-position: center;
          position: relative;
          overflow: hidden;
        }

        .feature-detail__hero::after {
          content: '';
          position: absolute;
          inset: 0;
          background: rgba(12, 7, 42, 0.78);
        }

        .feature-detail__hero-content {
          position: relative;
          z-index: 1;
          max-width: 1100px;
          margin: 0 auto;
          color: #fff;
        }

        .feature-detail__header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          margin-bottom: 40px;
        }

        .feature-detail__header img {
          height: 40px;
        }

        .feature-detail__header button {
          background: transparent;
          border: 1px solid rgba(255,255,255,0.4);
          padding: 10px 20px;
          border-radius: 999px;
          color: #fff;
          cursor: pointer;
        }

        .feature-detail__breadcrumb {
          font-size: 14px;
          color: rgba(255,255,255,0.75);
          margin-bottom: 16px;
        }

        .feature-detail__breadcrumb span {
          color: #a5b4fc;
        }

        .feature-detail__title {
          font-size: 40px;
          font-weight: 700;
          line-height: 1.2;
          margin-bottom: 16px;
        }

        .feature-detail__highlight {
          font-size: 20px;
          font-weight: 600;
          color: #c8d3ff;
          margin-bottom: 16px;
        }

        .feature-detail__description {
          font-size: 18px;
          color: rgba(255,255,255,0.85);
          max-width: 720px;
        }

        .feature-detail__badges {
          display: flex;
          gap: 12px;
          margin-top: 32px;
          flex-wrap: wrap;
        }

        .feature-detail__badge {
          padding: 8px 18px;
          border-radius: 999px;
          background: rgba(255,255,255,0.12);
          border: 1px solid rgba(255,255,255,0.2);
          font-size: 14px;
        }

        .feature-detail__sections {
          max-width: 1100px;
          margin: -80px auto 0;
          padding: 0 24px 80px;
          position: relative;
          z-index: 2;
        }

        .feature-detail__card {
          background: #fff;
          border-radius: 24px;
          padding: 32px;
          box-shadow: 0 30px 80px rgba(15,23,42,0.12);
          margin-bottom: 24px;
          border: 1px solid rgba(99,102,241,0.1);
        }

        .feature-detail__card h3 {
          font-size: 24px;
          margin-bottom: 12px;
          color: #5f47ff;
        }

        .feature-detail__card p {
          color: #475467;
          margin-bottom: 16px;
        }

        .feature-detail__card ul {
          padding-left: 18px;
          color: #1d2939;
          line-height: 1.6;
        }

        .feature-detail__cta {
          margin-top: 32px;
          text-align: center;
        }

        .feature-detail__cta button {
          padding: 14px 36px;
          border-radius: 999px;
          border: none;
          background: linear-gradient(135deg, #7c3aed, #5f47ff);
          color: #fff;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          box-shadow: 0 20px 40px rgba(94, 47, 255, 0.35);
        }

        @media (max-width: 768px) {
          .feature-detail__title {
            font-size: 32px;
          }
          .feature-detail__sections {
            margin-top: -40px;
          }
          .feature-detail__card {
            padding: 24px;
          }
        }
      `}</style>

      <section className="feature-detail__hero">
        <div className="feature-detail__hero-content">
          <div className="feature-detail__header">
            <button type="button" onClick={() => history.push("/")}>Volver</button>
            <img src={logoImage} alt={appName} />
          </div>
          <div className="feature-detail__breadcrumb">
            Inicio <span>›</span> Soluciones <span>›</span> {breadcrumbLabel}
          </div>
          <div className="feature-detail__highlight">{pageData.heroHighlight}</div>
          <h1 className="feature-detail__title">{pageData.heroTitle}</h1>
          <p className="feature-detail__description">{pageData.heroDescription}</p>
          <div className="feature-detail__badges">
            {pageData.badges.map((badge) => (
              <span key={badge} className="feature-detail__badge">{badge}</span>
            ))}
          </div>
        </div>
      </section>

      <section className="feature-detail__sections">
        {pageData.sections.map((section) => (
          <article key={section.title} className="feature-detail__card">
            <h3>{section.title}</h3>
            <p>{section.description}</p>
            <ul>
              {section.bullets.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>
        ))}

        <div className="feature-detail__cta">
          <button type="button" onClick={() => history.push("/cadastro")}>{pageData.ctaLabel}</button>
        </div>
      </section>

      <LandingFooter appName={appName} />
    </div>
  );
};

export default FeatureDetailPage;
