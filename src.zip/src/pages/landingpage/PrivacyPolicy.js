import React, { useContext } from "react";
import LegalPageLayout from "./LegalPageLayout";
import ColorModeContext from "../../layout/themeContext";

const PrivacyPolicy = () => {
  const { colorMode } = useContext(ColorModeContext) || {};

  // Nombre dinámico del SaaS
  const appName = colorMode?.appName || "Mi Aplicación";

  return (
    <LegalPageLayout
      title={`Política de Privacidad de ${appName}`}
      intro={`En ${appName} protegemos la información de nuestros usuarios y sus clientes con estándares avanzados de seguridad y cumplimiento normativo.`}
    >
      <p>
        La presente Política de Privacidad describe cómo {appName} recopila,
        utiliza, procesa y protege la información de los usuarios que utilizan
        nuestra plataforma SaaS de CRM omnicanal con integración a WhatsApp,
        redes sociales e inteligencia artificial.
      </p>

      <h2>1. Alcance del Servicio</h2>
      <p>
        {appName} es una plataforma tecnológica SaaS que permite a empresas
        gestionar conversaciones, contactos, automatizaciones y análisis a
        través de WhatsApp, redes sociales y otros canales digitales.
        {appName} actúa como proveedor de infraestructura tecnológica y no es
        responsable del contenido generado o gestionado por los usuarios dentro
        de la plataforma.
      </p>

      <h2>2. Datos que recopilamos</h2>
      <ul>
        <li>Datos de registro del cliente (nombre, correo, facturación).</li>
        <li>Información técnica (IP, logs, dispositivo, navegador).</li>
        <li>Mensajes, conversaciones y archivos gestionados en la plataforma.</li>
        <li>Contactos cargados o sincronizados por el usuario.</li>
        <li>Datos procesados por motores de inteligencia artificial.</li>
      </ul>

      <h2>3. Rol sobre los datos</h2>
      <p>
        El usuario que contrata {appName} es el responsable del tratamiento de
        los datos de sus clientes. {appName} actúa como encargado del
        tratamiento, procesando datos únicamente bajo instrucciones del usuario.
      </p>

      <h2>4. Uso de Inteligencia Artificial</h2>
      <p>
        Nuestra plataforma puede utilizar modelos de inteligencia artificial
        para automatización de respuestas, clasificación de conversaciones,
        análisis de sentimiento y generación de contenido. Estos procesos se
        realizan bajo estrictos controles de seguridad y no implican venta ni
        cesión de datos.
      </p>

      <h2>5. Seguridad de la Información</h2>
      <p>
        {appName} implementa medidas técnicas y organizativas avanzadas,
        incluyendo:
      </p>
      <ul>
        <li>Cifrado en tránsito (HTTPS/TLS).</li>
        <li>Almacenamiento seguro con cifrado en reposo cuando aplica.</li>
        <li>Backups automáticos y redundantes.</li>
        <li>Control de acceso basado en roles (RBAC).</li>
        <li>Monitoreo continuo y registro de actividad.</li>
      </ul>

      <h2>6. Confidencialidad de chats y contactos</h2>
      <p>
        {appName} no accede, analiza ni comercializa conversaciones o bases de
        datos de contactos con fines distintos a la prestación del servicio.
        Toda la información gestionada dentro de la plataforma pertenece
        exclusivamente al cliente.
      </p>

      <h2>7. Compartición con terceros</h2>
      <p>
        Solo compartimos información con proveedores esenciales de
        infraestructura (hosting, email, pasarelas de pago) bajo acuerdos de
        confidencialidad y estándares equivalentes de seguridad.
      </p>

      <h2>8. Retención y eliminación</h2>
      <p>
        Los datos se conservan mientras la cuenta esté activa. Tras la
        cancelación del servicio, podrán eliminarse definitivamente conforme a
        nuestros procedimientos internos y plazos legales.
      </p>

      <h2>9. Cumplimiento legal</h2>
      <p>
        {appName} cumple con principios alineados a normativas como GDPR,
        LGPD y otras leyes aplicables de protección de datos. En caso de
        requerimiento legal válido, podremos divulgar información conforme a
        la ley.
      </p>

      <h2>10. Limitación de responsabilidad</h2>
      <p>
        {appName} no será responsable por el uso indebido de la plataforma por
        parte de los usuarios ni por el contenido de los mensajes enviados a
        través de canales externos como WhatsApp o redes sociales.
      </p>

      <h2>11. Derechos del usuario</h2>
      <p>
        Los usuarios pueden solicitar acceso, corrección o eliminación de sus
        datos escribiendo al canal oficial de soporte indicado en el sitio.
      </p>

      <h2>12. Modificaciones</h2>
      <p>
        {appName} podrá actualizar esta política en cualquier momento.
        Las modificaciones serán publicadas en esta misma sección.
      </p>
    </LegalPageLayout>
  );
};

export default PrivacyPolicy;