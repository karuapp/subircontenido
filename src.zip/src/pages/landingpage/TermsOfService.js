import React, { useContext } from "react";
import LegalPageLayout from "./LegalPageLayout";
import ColorModeContext from "../../layout/themeContext";

const TermsOfService = () => {
  const { colorMode } = useContext(ColorModeContext) || {};

  const appName = colorMode?.appName || "Mi Aplicación";

  return (
    <LegalPageLayout
      title={`Términos de Servicio de ${appName}`}
      intro={`Estas condiciones regulan el uso de ${appName} como plataforma SaaS de CRM omnicanal con integración a WhatsApp, redes sociales e inteligencia artificial.`}
    >
      <p>
        Al acceder o utilizar {appName}, usted acepta quedar legalmente
        vinculado por estos Términos de Servicio. Si no está de acuerdo,
        deberá abstenerse de utilizar la plataforma.
      </p>

      <h2>1. Naturaleza del Servicio</h2>
      <p>
        {appName} es una plataforma tecnológica SaaS que permite la gestión
        de comunicaciones, automatizaciones, contactos y análisis mediante
        integraciones con WhatsApp, redes sociales y otros canales digitales.
        {appName} actúa exclusivamente como proveedor de infraestructura
        tecnológica y no como operador de telecomunicaciones.
      </p>

      <h2>2. Registro y Cuenta</h2>
      <p>
        El cliente es responsable de la veracidad de la información
        proporcionada durante el registro y del resguardo de sus credenciales.
        Toda actividad realizada desde su cuenta será considerada como
        autorizada por el titular.
      </p>

      <h2>3. Planes, pagos y facturación</h2>
      <p>
        El acceso a determinadas funcionalidades está sujeto al plan
        contratado. Los pagos son recurrentes según el ciclo seleccionado.
        La falta de pago podrá derivar en suspensión automática del servicio.
      </p>

      <h2>4. Uso aceptable</h2>
      <p>
        El cliente se compromete a utilizar {appName} conforme a la ley y
        a las políticas de los proveedores integrados (WhatsApp, Meta, APIs).
        Está prohibido:
      </p>
      <ul>
        <li>Enviar SPAM o comunicaciones masivas no autorizadas.</li>
        <li>Realizar actividades fraudulentas o ilícitas.</li>
        <li>Violar derechos de terceros.</li>
        <li>Usar la plataforma para distribuir malware o contenido ilegal.</li>
      </ul>

      <h2>5. Responsabilidad sobre el contenido</h2>
      <p>
        El cliente es el único responsable del contenido de los mensajes,
        bases de datos de contactos y campañas gestionadas dentro de la
        plataforma. {appName} no supervisa ni controla activamente dicho
        contenido.
      </p>

      <h2>6. Integraciones con terceros</h2>
      <p>
        {appName} depende de servicios externos como WhatsApp, Meta,
        proveedores de hosting y APIs. No garantizamos la disponibilidad
        continua de dichos servicios externos ni somos responsables por
        interrupciones atribuibles a terceros.
      </p>

      <h2>7. Inteligencia Artificial</h2>
      <p>
        Algunas funcionalidades utilizan modelos de inteligencia artificial
        para automatización, clasificación y generación de respuestas.
        El cliente entiende que los resultados generados por IA pueden
        contener imprecisiones y deberán ser supervisados.
      </p>

      <h2>8. Disponibilidad y SLA</h2>
      <p>
        {appName} implementa infraestructura redundante y monitoreo continuo.
        No obstante, no garantizamos disponibilidad ininterrumpida.
        El nivel de servicio (SLA) dependerá del plan contratado.
      </p>

      <h2>9. Propiedad intelectual</h2>
      <p>
        La plataforma, su código, diseño y funcionalidades son propiedad
        exclusiva de {appName}. El cliente recibe únicamente una licencia
        limitada, no exclusiva y revocable de uso.
      </p>

      <h2>10. Limitación de responsabilidad</h2>
      <p>
        En la máxima medida permitida por la ley, {appName} no será
        responsable por daños indirectos, lucro cesante, pérdida de datos
        o interrupciones derivadas del uso del servicio o de integraciones
        con terceros.
      </p>

      <h2>11. Suspensión y cancelación</h2>
      <p>
        Nos reservamos el derecho de suspender o cancelar cuentas por
        incumplimiento de estos términos, uso abusivo o requerimiento legal.
      </p>

      <h2>12. Modificaciones</h2>
      <p>
        {appName} podrá actualizar estos términos en cualquier momento.
        Las modificaciones serán efectivas desde su publicación.
      </p>

      <h2>13. Legislación aplicable</h2>
      <p>
        Estos términos se regirán por la legislación aplicable en la
        jurisdicción correspondiente al domicilio legal del proveedor.
      </p>
    </LegalPageLayout>
  );
};

export default TermsOfService;