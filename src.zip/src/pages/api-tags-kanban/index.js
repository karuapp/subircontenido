import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Button,
  CircularProgress,
  Divider,
  Grid,
  Paper,
  TextField,
  Typography
} from "@material-ui/core";
import { Field, Form, Formik } from "formik";
import axios from "axios";
import { toast } from "react-toastify";

import toastError from "../../errors/toastError";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";

import usePlans from "../../hooks/usePlans";
import { AuthContext } from "../../context/Auth/AuthContext";
import ApiPostmanDownload from "../../components/ApiPostmanDownload";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(2),
    paddingBottom: 100
  },
  elementMargin: {
    padding: theme.spacing(2)
  },
  formContainer: {
    maxWidth: 520
  },
  textRight: {
    textAlign: "right"
  },
  resultBox: {
    background: "#0f172a",
    color: "#e2e8f0",
    fontFamily: "JetBrains Mono, monospace",
    fontSize: 13,
    padding: theme.spacing(2),
    borderRadius: 8,
    overflowX: "auto"
  }
}));

const ApiTagsKanbanPage = () => {
  const classes = useStyles();
  const history = useHistory();
  const { user } = useContext(AuthContext);
  const { getPlanCompany } = usePlans();

  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    async function checkPermission() {
      const companyId = user.companyId;
      const planConfigs = await getPlanCompany(undefined, companyId);
      if (!planConfigs.plan.useExternalApi) {
        toast.error("Esta empresa no tiene permiso para acceder a esta página.");
        setTimeout(() => {
          history.push(`/`);
        }, 1000);
      }
    }
    checkPermission();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getTagsKanbanEndpoint = () => `${process.env.REACT_APP_BACKEND_URL}/api/external/tags-kanban`;

  const postmanRequests = [
    {
      name: "Enumerar etiquetas Kanban",
      method: "GET",
      url: getTagsKanbanEndpoint(),
      description: "Devuelve las etiquetas Kanban registradas en la empresa."
    },
    {
      name: "Buscar etiqueta Kanban por ID",
      method: "GET",
      url: `${getTagsKanbanEndpoint()}/1`,
      description: "Reemplaza el ID al final de la URL para buscar una etiqueta específica."
    },
    {
      name: "Crear etiqueta Kanban",
      method: "POST",
      url: getTagsKanbanEndpoint(),
      description: "Crea una nueva etiqueta Kanban.",
      body: {
        name: "En negociación",
        color: "#f59e0b",
        timeLane: 0,
        greetingMessageLane: "¡Hola! Estás en la fase de negociación."
      }
    },
    {
      name: "Actualizar etiqueta Kanban",
      method: "PUT",
      url: `${getTagsKanbanEndpoint()}/1`,
      description: "Cambia el ID para actualizar la etiqueta deseada.",
      body: {
        name: "En negociación (editado)",
        color: "#eab308"
      }
    },
    {
      name: "Eliminar etiqueta Kanban",
      method: "DELETE",
      url: `${getTagsKanbanEndpoint()}/1`,
      description: "Elimina permanentemente la etiqueta especificada en la ruta."
    }
  ];

  const formatJSON = (data) => JSON.stringify(data, null, 2);

  const cleanTag = (tag) => ({
    id: tag.id,
    name: tag.name,
    color: tag.color,
    kanban: tag.kanban,
    timeLane: tag.timeLane,
    nextLaneId: tag.nextLaneId,
    greetingMessageLane: tag.greetingMessageLane,
    rollbackLaneId: tag.rollbackLaneId
  });

  const saveResult = (title, payload) => {
    setTestResult({
      title,
      payload: typeof payload === "string" ? payload : formatJSON(payload),
      timestamp: new Date().toLocaleString()
    });
  };

  const handleListTags = async (token) => {
    try {
      const { data } = await axios.get(getTagsKanbanEndpoint(), {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult("Lista de etiquetas Kanban", {
        ...data,
        tags: data.tags?.map(cleanTag)
      });
      toast.success("¡Etiquetas Kanban cargadas!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleShowTag = async (token, tagId) => {
    try {
      const { data } = await axios.get(`${getTagsKanbanEndpoint()}/${tagId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      saveResult(`Etiqueta Kanban ${tagId}`, cleanTag(data));
      toast.success("¡Etiqueta Kanban cargada!");
    } catch (err) {
      toastError(err);
    }
  };

  const buildTagPayload = (values) => {
    return {
      name: values.name,
      color: values.color,
      timeLane: values.timeLane ? Number(values.timeLane) : 0,
      nextLaneId: values.nextLaneId ? Number(values.nextLaneId) : null,
      greetingMessageLane: values.greetingMessageLane || null,
      rollbackLaneId: values.rollbackLaneId ? Number(values.rollbackLaneId) : null
    };
  };

  const handleCreateTag = async (values) => {
    try {
      const payload = buildTagPayload(values);
      const { data } = await axios.post(getTagsKanbanEndpoint(), payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Etiqueta Kanban creada", cleanTag(data));
      toast.success("¡Etiqueta Kanban creada correctamente!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleUpdateTag = async (values) => {
    try {
      const payload = buildTagPayload(values);
      const { data } = await axios.put(`${getTagsKanbanEndpoint()}/${values.tagId}`, payload, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Etiqueta Kanban actualizada", cleanTag(data));
      toast.success("¡Etiqueta Kanban actualizada correctamente!");
    } catch (err) {
      toastError(err);
    }
  };

  const handleDeleteTag = async (values) => {
    try {
      await axios.delete(`${getTagsKanbanEndpoint()}/${values.tagId}`, {
        headers: {
          Authorization: `Bearer ${values.token}`
        }
      });
      saveResult("Etiqueta Kanban eliminada", { id: values.tagId, deleted: true });
      toast.success("¡Etiqueta Kanban eliminada!");
    } catch (err) {
      toastError(err);
    }
  };

  const renderListAndShowForm = () => (
    <Formik
      initialValues={{ token: "", tagId: "" }}
      onSubmit={(values) => handleListTags(values.token)}
    >
      {({ values, isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="ID de etiqueta (opcional para búsqueda)"
                name="tagId"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SendIcon />}
                disabled={isSubmitting}
                style={{ marginRight: 8 }}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Listar todo"}
              </Button>
              <Button
                variant="outlined"
                onClick={() => {
                  if (!values.tagId) {
                    toast.error("Ingrese el ID de etiqueta para buscar un registro.");
                    return;
                  }
                  handleShowTag(values.token, values.tagId);
                }}
              >
                Buscar por ID
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderCreateForm = () => (
    <Formik
      initialValues={{
        token: "",
        name: "",
        color: "#5C59C2",
        timeLane: "",
        nextLaneId: "",
        greetingMessageLane: "",
        rollbackLaneId: ""
      }}
      onSubmit={async (values, actions) => {
        await handleCreateTag(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Nombre de la etiqueta"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Color (hex)"
                name="color"
                variant="outlined"
                margin="dense"
                fullWidth
                required
                placeholder="#5C59C2"
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Tiempo en la columna (min)"
                name="timeLane"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Siguiente columna ID"
                name="nextLaneId"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Rollback columna ID"
                name="rollbackLaneId"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de saludo de la columna"
                name="greetingMessageLane"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Crear etiqueta Kanban"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderUpdateForm = () => (
    <Formik
      initialValues={{
        token: "",
        tagId: "",
        name: "",
        color: "",
        timeLane: "",
        nextLaneId: "",
        greetingMessageLane: "",
        rollbackLaneId: ""
      }}
      onSubmit={async (values, actions) => {
        await handleUpdateTag(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Etiqueta ID"
                name="tagId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Nombre"
                name="name"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Color (hex)"
                name="color"
                variant="outlined"
                margin="dense"
                fullWidth
                placeholder="#5C59C2"
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Tiempo en la columna (min)"
                name="timeLane"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Field
                as={TextField}
                label="Siguiente columna ID"
                name="nextLaneId"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Rollback columna ID"
                name="rollbackLaneId"
                type="number"
                variant="outlined"
                margin="dense"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Field
                as={TextField}
                label="Mensaje de saludo de la columna"
                name="greetingMessageLane"
                variant="outlined"
                margin="dense"
                fullWidth
                multiline
                minRows={2}
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                startIcon={<SendIcon />}
                variant="contained"
                color="primary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Actualizar etiqueta Kanban"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  const renderDeleteForm = () => (
    <Formik
      initialValues={{ token: "", tagId: "" }}
      onSubmit={async (values, actions) => {
        await handleDeleteTag(values);
        actions.setSubmitting(false);
      }}
    >
      {({ isSubmitting }) => (
        <Form className={classes.formContainer}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Token"
                name="token"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <Field
                as={TextField}
                label="Etiqueta ID"
                name="tagId"
                variant="outlined"
                margin="dense"
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} className={classes.textRight}>
              <Button
                type="submit"
                variant="contained"
                color="secondary"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress size={20} /> : "Eliminar etiqueta Kanban"}
              </Button>
            </Grid>
          </Grid>
        </Form>
      )}
    </Formik>
  );

  return (
    <Paper className={classes.mainPaper} variant="outlined">
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <div>
          <Typography variant="h5">API de Etiquetas Kanban</Typography>
          <Typography variant="subtitle1" color="textSecondary">
            Administrar etiquetas Kanban (columna de embudo) mediante una API externa.
          </Typography>
        </div>
        <Button startIcon={<ReplyIcon />} variant="outlined" onClick={() => history.push("/messages-api")}>
          Voltar para tokens
        </Button>
      </Box>

      <Box mb={4}>
        <Typography variant="h6">Resumen</Typography>
        <Typography component="div" color="textSecondary">
          <ul>
            <li><b>Listar etiquetas Kanban:</b> GET {getTagsKanbanEndpoint()}</li>
            <li><b>Buscar etiqueta Kanban:</b> GET {getTagsKanbanEndpoint()}/:id</li>
            <li><b>Crear etiqueta Kanban:</b> POST {getTagsKanbanEndpoint()}</li>
            <li><b>Actualizar etiqueta Kanban:</b> PUT {getTagsKanbanEndpoint()}/:id</li>
            <li><b>Eliminar etiqueta Kanban:</b> DELETE {getTagsKanbanEndpoint()}/:id</li>
          </ul>
          Enviar siempre  header <code>Authorization: Bearer {"{token}"}</code> con un token activo generado en la página API.
        </Typography>
      </Box>

      <Divider />

      <ApiPostmanDownload
        collectionName="Whaticket - API de Etiquetas Kanban"
        requests={postmanRequests}
        filename="whaticket-api-tags-kanban.json"
        helperText="Ingrese el token y haga clic en Descargar para importar a Postman."
      />

      <Box mt={4}>
        <Typography variant="h6" color="primary">1. Ver etiquetas Kanban</Typography>
        <Typography color="textSecondary">
          Ingrese solo el token para listar todas las etiquetas o agregue un ID de etiqueta para buscar un registro específico.
        </Typography>
        {renderListAndShowForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">2. Crear etiqueta Kanban</Typography>
        <Typography color="textSecondary">
          Campos obligatorios: <b>name</b> Y <b>color</b>. Los campos restantes son opcionales.
        </Typography>
        {renderCreateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">3. Actualizar etiqueta Kanban</Typography>
        <Typography color="textSecondary">
          Ingrese el <b>Tag ID</b> Envíe los campos que desee actualizar.
        </Typography>
        {renderUpdateForm()}
      </Box>

      <Divider style={{ margin: "32px 0" }} />

      <Box>
        <Typography variant="h6" color="primary">4. Eliminar etiqueta Kanban</Typography>
        <Typography color="textSecondary">
          Esta operación elimina el registro permanentemente. Úselo con precaución.
        </Typography>
        {renderDeleteForm()}
      </Box>

      {testResult && (
        <Box mt={4}>
          <Typography variant="h6">Resultado de la última prueba.</Typography>
          <Typography variant="body2" color="textSecondary">
            {testResult.title} — {testResult.timestamp}
          </Typography>
          <Box component="pre" mt={2} className={classes.resultBox}>
            {testResult.payload}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default ApiTagsKanbanPage;
