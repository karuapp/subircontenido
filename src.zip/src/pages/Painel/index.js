import React, { useContext, useState, useEffect, useMemo, useCallback } from "react";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import { useTheme } from "@material-ui/core/styles";
import { IconButton, Dialog, DialogTitle, DialogContent, DialogActions, Box, LinearProgress, Chip } from "@mui/material";
import { Groups, SaveAlt, TrendingUp, TrendingDown, Dashboard as DashboardIcon, Loop as LoopIcon, Event as EventIcon } from "@mui/icons-material";
import CallIcon from "@material-ui/icons/Call";
import RecordVoiceOverIcon from "@material-ui/icons/RecordVoiceOver";
import GroupAddIcon from "@material-ui/icons/GroupAdd";
import HourglassEmptyIcon from "@material-ui/icons/HourglassEmpty";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";
import FilterListIcon from "@material-ui/icons/FilterList";
import ClearIcon from "@material-ui/icons/Clear";
import CheckIcon from "@material-ui/icons/Check";
import AnnouncementIcon from "@material-ui/icons/Announcement";
import ArrowBackIosIcon from "@material-ui/icons/ArrowBackIos";
import ArrowForwardIosIcon from "@material-ui/icons/ArrowForwardIos";
import MessageIcon from '@material-ui/icons/Message';
import AccessAlarmIcon from '@material-ui/icons/AccessAlarm';
import TimerIcon from '@material-ui/icons/Timer';
import SendIcon from '@material-ui/icons/Send';
import PersonAddIcon from '@material-ui/icons/PersonAdd';
import AccessTimeIcon from '@material-ui/icons/AccessTime';
import TrendingUpIcon from '@material-ui/icons/TrendingUp';
import TrendingDownIcon from '@material-ui/icons/TrendingDown';
import * as XLSX from 'xlsx';
import { grey, blue } from "@material-ui/core/colors";
import { toast } from "react-toastify";
import TabPanel from "../../components/TabPanel";
import TableAttendantsStatus from "../../components/Dashboard/TableAttendantsStatus";
import { isArray } from "lodash";
import { AuthContext } from "../../context/Auth/AuthContext";
import Chart from "react-apexcharts";
import { listTutorialVideos, getVideoThumbnailFallback } from "../../services/tutorialVideoService";
import Grid from '@mui/material/Grid';
import useDashboard from "../../hooks/useDashboard";
import VideoModal from "../../components/VideoModal";
import CrmModal from "../../components/CrmModal";
import useContacts from "../../hooks/useContacts";
import useMessages from "../../hooks/useMessages";
import ChatsUser from "./ChartsUser";
import { listSliderBanners } from "../../services/sliderHomeService";
import ChartDonut from "./ChartDonut";
import Filters from "./Filters";
import { isEmpty } from "lodash";
import moment from "moment";
import { ChartsDate } from "./ChartsDate";
import { Avatar, Button, Card, CardContent, Container, Stack, Tab, Tabs } from "@mui/material";
import { i18n } from "../../translate/i18n";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import ForbiddenPage from "../../components/ForbiddenPage";
import { ArrowDownward, ArrowUpward } from "@material-ui/icons";
import { getBackendUrl } from "../../config";
import api from "../../services/api";
import { useHistory } from "react-router-dom";
import usePlans from "../../hooks/usePlans";

const useStyles = makeStyles((theme) => ({
  // Container principal
  container: {
    padding: theme.spacing(4),
    width: "100%",
    margin: 0,
    background: "#f8fafc",
    minHeight: "100vh",
  },
  
  // Header da página
  pageHeader: {
    marginBottom: theme.spacing(4),
  },
  pageTitle: {
    fontSize: "28px",
    fontWeight: 700,
    color: "#1a1a2e",
    marginBottom: theme.spacing(0.5),
  },
  pageSubtitle: {
    fontSize: "16px",
    color: "#6b7280",
  },
  breadcrumb: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1),
    color: "#9ca3af",
    fontSize: "14px",
    "& span": {
      color: "#3b82f6",
    },
  },
  
  // Slider de Banners
  bannerSlider: {
    width: "100%",
    height: "320px",
    borderRadius: 16,
    overflow: "hidden",
    position: "relative",
    marginBottom: theme.spacing(4),
    boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)",
  },
  bannerImage: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
  },
  bannerArrow: {
    position: "absolute",
    top: "50%",
    transform: "translateY(-50%)",
    background: "rgba(255, 255, 255, 0.9)",
    borderRadius: "50%",
    width: 44,
    height: 44,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    zIndex: 3,
    transition: "all 0.3s ease",
    boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
    "&:hover": {
      background: "#ffffff",
      transform: "translateY(-50%) scale(1.1)",
    },
  },
  bannerArrowLeft: {
    left: theme.spacing(2),
  },
  bannerArrowRight: {
    right: theme.spacing(2),
  },
  bannerDots: {
    position: "absolute",
    bottom: theme.spacing(2),
    left: "50%",
    transform: "translateX(-50%)",
    display: "flex",
    gap: theme.spacing(1),
    zIndex: 3,
  },
  bannerDot: {
    width: 10,
    height: 10,
    borderRadius: "50%",
    backgroundColor: "rgba(255,255,255,0.5)",
    cursor: "pointer",
    transition: "all 0.3s ease",
    "&.active": {
      backgroundColor: "#fff",
      transform: "scale(1.2)",
    },
  },
  
  // Cards de Indicadores
  indicatorCard: {
    background: "#ffffff",
    borderRadius: 16,
    padding: theme.spacing(3),
    boxShadow: "0 2px 12px rgba(0, 0, 0, 0.04)",
    border: "1px solid #f1f5f9",
    transition: "all 0.3s ease",
    height: "100%",
    "&:hover": {
      transform: "translateY(-2px)",
      boxShadow: "0 8px 25px rgba(0, 0, 0, 0.08)",
    },
  },
  indicatorLabel: {
    fontSize: "14px",
    fontWeight: 500,
    color: "#6b7280",
    marginBottom: theme.spacing(1),
  },
  indicatorValue: {
    fontSize: "32px",
    fontWeight: 700,
    color: "#1a1a2e",
    marginBottom: theme.spacing(1),
  },
  indicatorTrend: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(0.5),
    fontSize: "13px",
  },
  trendUp: {
    color: "#10b981",
    display: "flex",
    alignItems: "center",
    gap: "4px",
  },
  trendDown: {
    color: "#ef4444",
    display: "flex",
    alignItems: "center",
    gap: "4px",
  },
  trendNeutral: {
    color: "#6b7280",
  },
  
  // Gráficos
  chartCard: {
    background: "#ffffff",
    borderRadius: 16,
    padding: theme.spacing(3),
    boxShadow: "0 2px 12px rgba(0, 0, 0, 0.04)",
    border: "1px solid #f1f5f9",
    height: "100%",
  },
  chartHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: theme.spacing(3),
  },
  chartTitle: {
    fontSize: "18px",
    fontWeight: 600,
    color: "#1a1a2e",
  },
  chartSubtitle: {
    fontSize: "28px",
    fontWeight: 700,
    color: "#1a1a2e",
    marginTop: theme.spacing(0.5),
  },
  chartBadge: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(0.5),
    padding: "4px 12px",
    borderRadius: 20,
    fontSize: "13px",
    fontWeight: 500,
  },
  badgeUp: {
    background: "rgba(16, 185, 129, 0.1)",
    color: "#10b981",
  },
  badgeDown: {
    background: "rgba(239, 68, 68, 0.1)",
    color: "#ef4444",
  },
  
  // Tags Card
  tagsCard: {
    background: "#ffffff",
    borderRadius: 16,
    padding: theme.spacing(3),
    boxShadow: "0 2px 12px rgba(0, 0, 0, 0.04)",
    border: "1px solid #f1f5f9",
    height: "100%",
  },
  tagsTitle: {
    fontSize: "18px",
    fontWeight: 600,
    color: "#1a1a2e",
    marginBottom: theme.spacing(2),
  },
  tagsProgressBar: {
    display: "flex",
    height: 8,
    borderRadius: 4,
    overflow: "hidden",
    marginBottom: theme.spacing(3),
  },
  tagItem: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: theme.spacing(1.5, 0),
    borderBottom: "1px solid #f1f5f9",
    "&:last-child": {
      borderBottom: "none",
    },
  },
  tagDot: {
    width: 10,
    height: 10,
    borderRadius: "50%",
    marginRight: theme.spacing(1.5),
  },
  tagName: {
    fontSize: "14px",
    color: "#374151",
    flex: 1,
  },
  tagValue: {
    fontSize: "14px",
    fontWeight: 600,
    color: "#1a1a2e",
    marginRight: theme.spacing(2),
  },
  tagPercent: {
    fontSize: "14px",
    fontWeight: 600,
    color: "#1a1a2e",
  },
  
  // Tutoriais
  tutorialsSection: {
    marginTop: theme.spacing(4),
    background: "#ffffff",
    borderRadius: 16,
    padding: theme.spacing(3),
    boxShadow: "0 2px 12px rgba(0, 0, 0, 0.04)",
    border: "1px solid #f1f5f9",
  },
  tutorialsTitle: {
    fontSize: "20px",
    fontWeight: 600,
    color: "#1a1a2e",
    marginBottom: theme.spacing(3),
  },
  tutorialCard: {
    borderRadius: 12,
    overflow: "hidden",
    cursor: "pointer",
    transition: "all 0.3s ease",
    "&:hover": {
      transform: "scale(1.02)",
      boxShadow: "0 8px 25px rgba(0,0,0,0.15)",
    },
  },
  tutorialThumbnail: {
    width: "100%",
    height: 160,
    objectFit: "cover",
  },
  tutorialInfo: {
    padding: theme.spacing(2),
    background: "#f8fafc",
  },
  tutorialName: {
    fontSize: "14px",
    fontWeight: 600,
    color: "#1a1a2e",
  },
}));

const Dashboard = () => {
  const classes = useStyles();
  const theme = useTheme();
  const { user } = useContext(AuthContext);
  const history = useHistory();
  const { getPlanCompany } = usePlans();
  
  // Estados
  const [sliderBanners, setSliderBanners] = useState([]);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [tutorialVideos, setTutorialVideos] = useState([]);
  const [videoModalOpen, setVideoModalOpen] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [counters, setCounters] = useState({});
  const [attendants, setAttendants] = useState([]);
  const [tags, setTags] = useState([]);
  const [previousTags, setPreviousTags] = useState([]);
  const [ticketsLast30Days, setTicketsLast30Days] = useState({ labels: [], tickets: [], leads: [], finished: [] });
  const [previousCounters, setPreviousCounters] = useState({});
  const [nextInvoice, setNextInvoice] = useState(null);
  const [companyPlan, setCompanyPlan] = useState(null);
  
  // Hook do Dashboard
  const { find, getReport } = useDashboard();
  
  // Carregar dados
  const backendBaseUrl = useMemo(() => getBackendUrl()?.replace(/\/$/, ""), []);

  const buildBannerImageUrl = useCallback((banner) => {
    if (!banner) return "";
    const rawPath = banner.imageUrl || banner.image;
    if (!rawPath) return "";

    if (/^https?:\/\//i.test(rawPath)) {
      return rawPath;
    }

    let normalized = rawPath.replace(/\\/g, "/");
    if (normalized.startsWith("/")) {
      normalized = normalized.slice(1);
    }
    if (!normalized.startsWith("public/")) {
      normalized = `public/${normalized.replace(/^public\//, "")}`;
    }

    if (backendBaseUrl) {
      return `${backendBaseUrl}/${normalized}`;
    }

    return `/${normalized}`;
  }, [backendBaseUrl]);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        // Cargar banners
        const { data: bannersResponse } = await listSliderBanners();
        const parsedBanners = Array.isArray(bannersResponse)
          ? bannersResponse
          : bannersResponse?.sliderBanners || [];
        if (parsedBanners.length > 0) {
          const activeBanners = parsedBanners.filter(
            b => b?.status === "active" || b?.status === "ativo" || b?.isActive || b?.active
          );
          setSliderBanners(activeBanners.length > 0 ? activeBanners : parsedBanners);
        }
        
        // Cargar tutoriales
        const tutorialsData = await listTutorialVideos();
        if (tutorialsData && tutorialsData.length > 0) {
          setTutorialVideos(tutorialsData.filter(t => t.status === 'active').slice(0, 6));
        }
        
        // Cargar métricas del panel - Mes actual
        const dashboardData = await find({
          date_from: moment().startOf('month').format('YYYY-MM-DD'),
          date_to: moment().endOf('month').format('YYYY-MM-DD'),
        });
        
        if (dashboardData) {
          setCounters(dashboardData.counters || {});
          setAttendants(dashboardData.attendants || []);
          
          // Etiquetas con recuento de contactos
          if (dashboardData.tagsContactsSummary) {
            setTags(dashboardData.tagsContactsSummary.slice(0, 5));
          }
        }
        
        // Cargar métricas del mes anterior para comparar
        const previousMonthData = await find({
          date_from: moment().subtract(1, 'month').startOf('month').format('YYYY-MM-DD'),
          date_to: moment().subtract(1, 'month').endOf('month').format('YYYY-MM-DD'),
        });
        
        if (previousMonthData && previousMonthData.counters) {
          setPreviousCounters(previousMonthData.counters);
          
          // Etiquetas del mes anterior para comparar
          if (previousMonthData.tagsContactsSummary) {
            setPreviousTags(previousMonthData.tagsContactsSummary);
          }
        }
        
        // Cargar datos de los últimos 30 días - por semana (4 periodos)
        const dayPromises = [];
        const labels = [];
        
        // Dividir en 6 periodos de 5 días para una mejor visualización
        for (let i = 5; i >= 0; i--) {
          const periodEnd = moment().subtract(i * 5, 'days').format('YYYY-MM-DD');
          const periodStart = moment().subtract((i * 5) + 4, 'days').format('YYYY-MM-DD');
          
          labels.push(moment().subtract(i * 5, 'days').format('DD/MM'));
          
          dayPromises.push(
            find({
              date_from: periodStart,
              date_to: periodEnd,
            }).catch(() => null)
          );
        }
        
        const dayResults = await Promise.all(dayPromises);
        setTicketsLast30Days({
          labels,
          tickets: dayResults.map(r => (r?.counters?.supportHappening || 0) + (r?.counters?.supportFinished || 0) + (r?.counters?.supportPending || 0)),
          leads: dayResults.map(r => r?.counters?.leads || 0),
          finished: dayResults.map(r => r?.counters?.supportFinished || 0),
        });
        
      } catch (error) {
        console.error('Error al cargar los datos del panel:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, []);

  useEffect(() => {
    const loadNextInvoice = async () => {
      if (user?.profile !== "admin" || user?.companyId === 1) return;
      try {
        const { data } = await api.get("/invoices/all", {
          params: { pageNumber: 1 }
        });
        let invoicesList = [];
        if (Array.isArray(data)) {
          invoicesList = data;
        } else if (Array.isArray(data?.records)) {
          invoicesList = data.records;
        }

        const pendingInvoices = invoicesList
          .filter(inv => inv && inv.status !== "paid")
          .sort((a, b) => {
            const dateA = moment(a.dueDate || a.createdAt).valueOf();
            const dateB = moment(b.dueDate || b.createdAt).valueOf();
            return dateA - dateB;
          });

        if (pendingInvoices.length > 0) {
          setNextInvoice(pendingInvoices[0]);
        } else {
          setNextInvoice(null);
        }
      } catch (err) {
        console.error("Error al cargar la siguiente factura:", err);
        setNextInvoice(null);
      }
    };

    loadNextInvoice();
  }, [user?.profile]);

  useEffect(() => {
    const loadCompanyPlan = async () => {
      if (user?.profile !== "admin" || user?.companyId === 1 || !user?.companyId) return;
      try {
        const planData = await getPlanCompany(undefined, user.companyId);
        if (planData) {
          const recurrence = planData?.plan?.recurrence || user?.company?.recurrence || "MENSAL";
          const recurrenceMonthsMap = {
            MENSAL: 1,
            TRIMESTRAL: 3,
            SEMESTRAL: 6,
            ANUAL: 12
          };
          const rawStart = planData?.createdAt || user?.company?.createdAt || null;
          const trialActive = planData?.plan?.trial;
          const trialDays = planData?.plan?.trialDays || 0;
          let contractStartMoment = rawStart ? moment(rawStart) : null;
          let trialEndMoment = null;

          if (trialActive && contractStartMoment) {
            trialEndMoment = moment(contractStartMoment).add(trialDays, "day");
            contractStartMoment = moment(trialEndMoment);
          }

          const monthsToAdd = recurrenceMonthsMap[recurrence] || 1;
          const contractEndMoment = contractStartMoment
            ? moment(contractStartMoment).add(monthsToAdd, "month")
            : null;

          setCompanyPlan({
            planName: planData?.plan?.name || "Plan no definido",
            startDate: contractStartMoment ? contractStartMoment.toISOString() : null,
            dueDate: contractEndMoment ? contractEndMoment.toISOString() : null,
            recurrence,
            trial: trialActive,
            trialDays,
            trialEndDate: trialEndMoment ? trialEndMoment.toISOString() : null
          });
        }
      } catch (err) {
        console.error("Error al cargar el plan de la empresa:", err);
        setCompanyPlan(null);
      }
    };

    loadCompanyPlan();
  }, [user?.profile, user?.companyId, user?.company?.dueDate, user?.company?.createdAt, user?.company?.recurrence, getPlanCompany]);
  
  // Banners con deslizamiento automático
  useEffect(() => {
    if (sliderBanners.length > 1) {
      const interval = setInterval(() => {
        setCurrentSlide(prev => (prev + 1) % sliderBanners.length);
      }, 5000);
      return () => clearInterval(interval);
    } else {
      setCurrentSlide(0);
    }
  }, [sliderBanners]);
  
  // Navegación deslizante
  const handlePrevSlide = () => {
    setCurrentSlide(prev => prev === 0 ? sliderBanners.length - 1 : prev - 1);
  };
  
  const handleNextSlide = () => {
    setCurrentSlide(prev => (prev + 1) % sliderBanners.length);
  };
  
  // Abrir videotutorial
  const handleOpenVideo = (video) => {
    setSelectedVideo(video);
    setVideoModalOpen(true);
  };
  
  // Colores de las etiquetas
  const tagColors = ['#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ef4444'];
  
  // Calcular el total de etiquetas
  const totalTagsCount = tags.reduce((acc, tag) => acc + (tag.contactsCount || 0), 0);
  const totalPreviousTagsCount = previousTags.reduce((acc, tag) => acc + (tag.contactsCount || 0), 0);
  
  // Función para obtener el recuento anterior de una etiqueta
  const getPreviousTagCount = (tagId) => {
    const prevTag = previousTags.find(t => t.id === tagId);
    return prevTag?.contactsCount || 0;
  };
  
  // Calcular la variación de la etiqueta
  const getTagTrend = (currentCount, previousCount) => {
    if (previousCount === 0) return { value: currentCount > 0 ? 100 : 0, isUp: currentCount > 0 };
    const diff = ((currentCount - previousCount) / previousCount) * 100;
    return { value: Math.abs(diff).toFixed(0), isUp: diff >= 0 };
  };
  
  const hasSlides = sliderBanners.length > 0;
  
  // Función para calcular la variación porcentual
  const calcTrend = (current, previous) => {
    if (!previous || previous === 0) return { value: 0, isUp: true };
    const diff = ((current - previous) / previous) * 100;
    return { value: Math.abs(diff).toFixed(2), isUp: diff >= 0 };
  };
  
  // Calcular tendencias reales
  const leadsTrend = calcTrend(counters.leads || 0, previousCounters.leads || 0);
  const waitTimeTrend = calcTrend(counters.avgWaitTime || 0, previousCounters.avgWaitTime || 0);
  const openTrend = calcTrend(counters.supportHappening || 0, previousCounters.supportHappening || 0);
  const finishedTrend = calcTrend(counters.supportFinished || 0, previousCounters.supportFinished || 0);
  
  // Formatear el tiempo de espera promedio
  const formatWaitTime = (minutes) => {
    if (!minutes || minutes === 0) return '0 min';
    const mins = Math.round(parseFloat(minutes));
    if (mins < 60) return `${mins} min`;
    const hours = Math.floor(mins / 60);
    const remainMins = mins % 60;
    return `${hours}h ${remainMins}min`;
  };
  
  // Total de tickets en los últimos 30 días
  const totalTickets30Days = ticketsLast30Days.tickets.reduce((a, b) => a + b, 0);
  const totalLeads30Days = ticketsLast30Days.leads.reduce((a, b) => a + b, 0);
  const totalFinished30Days = ticketsLast30Days.finished.reduce((a, b) => a + b, 0);
  
  // Total de tickets del período para comparación
  const totalTicketsCurrentMonth = counters.supportFinished || 0;
  const totalTicketsPreviousMonth = previousCounters.supportFinished || 0;
  const ticketsTrend = calcTrend(totalTicketsCurrentMonth, totalTicketsPreviousMonth);

  if (loading) {
    return (
      <div className={classes.container} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ 
            width: 50, 
            height: 50, 
            border: '4px solid #f3f4f6', 
            borderTop: '4px solid #3b82f6', 
            borderRadius: '50%', 
            animation: 'spin 1s linear infinite',
            margin: '0 auto 16px'
          }} />
          <Typography style={{ color: '#6b7280' }}>Carregando dashboard...</Typography>
          <style>{`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}</style>
        </div>
      </div>
    );
  }

  return (
    <div className={classes.container}>
      {/* Header de Página */}
      <div className={classes.pageHeader}>
        <Grid container justifyContent="space-between" alignItems="flex-start">
          <Grid item>
            <Typography className={classes.pageTitle}>Panel de control</Typography>
            <Typography className={classes.pageSubtitle}>
              Bienvenido, {user?.name || 'Usuário'}
            </Typography>
          </Grid>
          <Grid item>
            <div className={classes.breadcrumb}>
              Inicio <span>›</span> <span>Panel de control</span>
            </div>
          </Grid>
        </Grid>
      </div>
      
      {/* Tarjetas de información del plan: solo para administradores de la empresa != 1 */}
      {user?.profile === "admin" && user?.companyId !== 1 && companyPlan && (
        <Grid container spacing={2} style={{ marginBottom: 24 }}>
          {/* Nombre del plan de la tarjeta */}
          <Grid item xs={12} sm={6} md={3}>
            <Box
              onClick={() => history.push("/financeiro")}
              style={{
                background: "#fff",
                borderRadius: 12,
                padding: "16px 20px",
                boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
                cursor: "pointer",
                border: "1px solid #e5e7eb",
                height: "100%",
                display: "flex",
                flexDirection: "column",
                gap: 8,
              }}
            >
              <Box display="flex" alignItems="center" gap={1}>
                <DashboardIcon style={{ fontSize: 20, color: "#3b82f6" }} />
                <Typography style={{ fontSize: 12, color: "#6b7280", fontWeight: 500 }}>
                  Plan actual
                </Typography>
              </Box>
              <Typography style={{ fontSize: 18, fontWeight: 700, color: "#1a1a2e" }}>
                {companyPlan.planName || "Sin plan"}
              </Typography>
              {companyPlan.trial && companyPlan.trialEndDate && moment(companyPlan.trialEndDate).isAfter(moment()) && (
                <Chip
                  label="Periodo de prueba"
                  size="small"
                  style={{ 
                    alignSelf: "flex-start", 
                    fontWeight: 600, 
                    fontSize: 10,
                    background: "#fef3c7",
                    color: "#d97706"
                  }}
                />
              )}
            </Box>
          </Grid>
          
          {/* Fecha de inicio del contrato de la tarjeta */}
          <Grid item xs={12} sm={6} md={3}>
            <Box
              style={{
                background: "#fff",
                borderRadius: 12,
                padding: "16px 20px",
                boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
                border: "1px solid #e5e7eb",
                height: "100%",
                display: "flex",
                flexDirection: "column",
                gap: 8,
              }}
            >
              <Box display="flex" alignItems="center" gap={1}>
                <EventIcon style={{ fontSize: 20, color: "#10b981" }} />
                <Typography style={{ fontSize: 12, color: "#6b7280", fontWeight: 500 }}>
                  Fecha de inicio del contrato
                </Typography>
              </Box>
              <Typography style={{ fontSize: 18, fontWeight: 700, color: "#1a1a2e" }}>
                {companyPlan.startDate
                  ? moment(companyPlan.startDate).format("DD/MM/YYYY")
                  : "--/--/----"}
              </Typography>
              {companyPlan.startDate && (
                <Typography style={{ fontSize: 11, color: "#6b7280" }}>
                  {moment(companyPlan.startDate).fromNow()}
                </Typography>
              )}
            </Box>
          </Grid>
          
          {/* Card Vencimento */}
          <Grid item xs={12} sm={6} md={3}>
            <Box
              style={{
                background: "#fff",
                borderRadius: 12,
                padding: "16px 20px",
                boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
                border: "1px solid #e5e7eb",
                height: "100%",
                display: "flex",
                flexDirection: "column",
                gap: 8,
              }}
            >
              <Box display="flex" alignItems="center" gap={1}>
                <EventIcon style={{ fontSize: 20, color: "#ef4444" }} />
                <Typography style={{ fontSize: 12, color: "#6b7280", fontWeight: 500 }}>
                  Fecha de vencimiento
                </Typography>
              </Box>
              <Typography style={{ fontSize: 18, fontWeight: 700, color: "#1a1a2e" }}>
                {companyPlan.dueDate
                  ? moment(companyPlan.dueDate).format("DD/MM/YYYY")
                  : "--/--/----"}
              </Typography>
              {companyPlan.dueDate && (
                <Typography style={{ fontSize: 11, color: moment(companyPlan.dueDate).isBefore(moment()) ? "#ef4444" : "#6b7280" }}>
                  {moment(companyPlan.dueDate).fromNow()}
                </Typography>
              )}
            </Box>
          </Grid>
          
          {/* Tarjeta recurrente/de prueba */}
          <Grid item xs={12} sm={6} md={3}>
            <Box
              style={{
                background: "#fff",
                borderRadius: 12,
                padding: "16px 20px",
                boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
                border: "1px solid #e5e7eb",
                height: "100%",
                display: "flex",
                flexDirection: "column",
                gap: 8,
              }}
            >
              <Box display="flex" alignItems="center" gap={1}>
                <LoopIcon style={{ fontSize: 20, color: "#8b5cf6" }} />
                <Typography style={{ fontSize: 12, color: "#6b7280", fontWeight: 500 }}>
                  Recurrencia
                </Typography>
              </Box>
              <Typography style={{ fontSize: 18, fontWeight: 700, color: "#1a1a2e" }}>
                {companyPlan.recurrence === "MENSUAL"
                  ? "Mensal"
                  : companyPlan.recurrence === "TRIMESTRAL"
                  ? "Trimestral"
                  : companyPlan.recurrence === "SEMESTRAL"
                  ? "Semestral"
                  : companyPlan.recurrence === "ANUAL"
                  ? "Anual"
                  : companyPlan.recurrence || "No definido"}
              </Typography>
              {companyPlan.trial && companyPlan.trialEndDate && (
                <Typography style={{ fontSize: 11, color: "#dc2626", fontWeight: 600 }}>
                  Realizar la prueba hasta {moment(companyPlan.trialEndDate).format("DD/MM/YYYY")}
                </Typography>
              )}
            </Box>
          </Grid>
        </Grid>
      )}
      
      {/* Slider de Banners */}
      {hasSlides && (
        <div className={classes.bannerSlider}>
          <img
            key={`banner-${currentSlide}-${sliderBanners[currentSlide]?.id || currentSlide}`}
            src={buildBannerImageUrl(sliderBanners[currentSlide])}
            alt={`Banner ${currentSlide + 1}`}
            className={classes.bannerImage}
            onError={(e) => {
              e.target.style.visibility = "hidden";
            }}
          />
          
          {sliderBanners.length > 1 && (
            <>
              <div 
                className={`${classes.bannerArrow} ${classes.bannerArrowLeft}`}
                onClick={handlePrevSlide}
              >
                <ArrowBackIosIcon style={{ fontSize: 18, marginLeft: 4 }} />
              </div>
              <div 
                className={`${classes.bannerArrow} ${classes.bannerArrowRight}`}
                onClick={handleNextSlide}
              >
                <ArrowForwardIosIcon style={{ fontSize: 18 }} />
              </div>
              
              <div className={classes.bannerDots}>
                {sliderBanners.map((_, index) => (
                  <div
                    key={index}
                    className={`${classes.bannerDot} ${index === currentSlide ? 'active' : ''}`}
                    onClick={() => setCurrentSlide(index)}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      )}
      
      {/* Sección de Tutoriales */}
      {tutorialVideos.length > 0 && (
        <div className={classes.tutorialsSection}>
          <Typography className={classes.tutorialsTitle}>Tutoriales</Typography>
          <Grid container spacing={2}>
            {tutorialVideos.map((video) => (
              <Grid item xs={12} sm={6} md={4} lg={2} key={video.id}>
                <div 
                  className={classes.tutorialCard}
                  onClick={() => handleOpenVideo(video)}
                >
                  <img
                    src={video.thumbnailUrl || getVideoThumbnailFallback(video.videoUrl)}
                    alt={video.title}
                    className={classes.tutorialThumbnail}
                  />
                  <div className={classes.tutorialInfo}>
                    <Typography className={classes.tutorialName}>{video.title}</Typography>
                  </div>
                </div>
              </Grid>
            ))}
          </Grid>
        </div>
      )}
      
      {/* Modal de Vídeo */}
      <VideoModal
        open={videoModalOpen}
        onClose={() => setVideoModalOpen(false)}
        videoUrl={selectedVideo?.videoUrl}
        title={selectedVideo?.title}
      />
    </div>
  );
};

export default Dashboard;