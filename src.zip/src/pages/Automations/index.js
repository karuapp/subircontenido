import React, { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "react-toastify";
import { makeStyles, useTheme } from "@material-ui/core/styles";

import {
  Box,
  Button,
  CircularProgress,
  FormControl,
  IconButton,
  MenuItem,
  Paper,
  Select,
  Switch,
  Tooltip,
  Typography
} from "@material-ui/core";

import {
  Add as AddIcon,
  Cake as CakeIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  EventAvailable as EventIcon,
  Receipt as ReceiptIcon,
  Refresh as RefreshIcon,
  WarningRounded as WarningIcon
} from "@material-ui/icons";

import ConfirmationModal from "../../components/ConfirmationModal";
import ScheduledDispatcherModal from "../../components/AutomationModal";
import {
  deleteScheduledDispatcher,
  eventTypeOptions,
  listScheduledDispatchers,
  toggleScheduledDispatcher
} from "../../services/scheduledDispatcherService";

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    flexDirection: "column",
    height: "100%",
    padding: theme.spacing(3),
    gap: theme.spacing(3),
    backgroundColor: theme.palette.background.default,
    ...theme.scrollbarStyles
  },
  pageHeader: {
    display: "flex",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: theme.spacing(2)
  },
  headerTitle: {
    fontWeight: 700,
    fontSize: 26
  },
  headerSubtitle: {
    color: theme.palette.text.secondary
  },
  headerActions: {
    display: "flex",
    gap: theme.spacing(1),
    alignItems: "center"
  },
  filters: {
    display: "flex",
    flexWrap: "wrap",
    gap: theme.spacing(1.5),
    alignItems: "center"
  },
  searchInput: {
    flex: 1,
    minWidth: 260,
    backgroundColor: theme.palette.background.paper,
    borderRadius: 16,
    padding: theme.spacing(0.5, 1.5),
    boxShadow: theme.shadows[1]
  },
  searchFieldInput: {
    width: "100%"
  },
  selectControl: {
    minWidth: 250
  },
  listWrapper: {
    flex: 1,
    overflowY: "auto",
    ...theme.scrollbarStyles
  },
  dispatcherCard: {
    display: "flex",
    gap: theme.spacing(2),
    padding: theme.spacing(2),
    borderRadius: 18,
    alignItems: "stretch",
    backgroundColor: theme.palette.background.paper,
    boxShadow: theme.shadows[1],
    marginBottom: theme.spacing(1.5)
  },
  iconBubble: {
    width: 56,
    height: 56,
    borderRadius: 16,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "#fff",
    flexShrink: 0
  },
  cardBody: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    gap: theme.spacing(1)
  },
  cardHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: theme.spacing(1),
    flexWrap: "wrap"
  },
  cardTitle: {
    fontWeight: 600,
    fontSize: 18
  },
  cardMeta: {
    display: "flex",
    flexWrap: "wrap",
    gap: theme.spacing(2),
    fontSize: 13,
    color: theme.palette.text.secondary
  },
  cardMessage: {
    backgroundColor: theme.palette.action.hover,
    borderRadius: 12,
    padding: theme.spacing(1.5),
    fontSize: 14,
    color: theme.palette.text.secondary
  },
  cardActions: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
    gap: theme.spacing(1),
    minWidth: 120
  },
  statusTextActive: {
    fontSize: 12,
    fontWeight: 600,
    color: theme.palette.success.main
  },
  statusTextInactive: {
    fontSize: 12,
    fontWeight: 600,
    color: theme.palette.error.main
  },
  actionsRow: {
    display: "flex",
    gap: theme.spacing(1)
  },
  emptyState: {
    minHeight: 280,
    borderRadius: 18,
    backgroundColor: theme.palette.background.paper,
    boxShadow: theme.shadows[1],
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    gap: theme.spacing(2),
    padding: theme.spacing(6)
  }
}));

const Automations = () => {
  const classes = useStyles();
  const theme = useTheme();

  const [dispatchers, setDispatchers] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [eventFilter, setEventFilter] = useState("all");

  const [modalOpen, setModalOpen] = useState(false);
  const [editingDispatcher, setEditingDispatcher] = useState(null);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);
  const [dispatcherPendingDeletion, setDispatcherPendingDeletion] = useState(null);

  const loadDispatchers = useCallback(async () => {
    try {
      setLoading(true);
      const data = await listScheduledDispatchers();
      setDispatchers(data);
    } catch (error) {
      toast.error("No se pueden cargar los envios programados");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDispatchers();
  }, [loadDispatchers]);

  useEffect(() => {
    const nextList = dispatchers.filter(dispatcher => {
      const matchesEvent =
        eventFilter === "all" || dispatcher.eventType === eventFilter;
      return matchesEvent;
    });
    setFiltered(nextList);
  }, [dispatchers, eventFilter]);

  const stats = useMemo(() => {
    const active = dispatchers.filter(item => item.active).length;
    const byEvent = eventTypeOptions.reduce((acc, curr) => {
      acc[curr.value] = dispatchers.filter(item => item.eventType === curr.value)
        .length;
      return acc;
    }, {});
    return { total: dispatchers.length, active, byEvent };
  }, [dispatchers]);

  const handleToggleDispatcher = async dispatcher => {
    try {
      await toggleScheduledDispatcher(dispatcher.id, !dispatcher.active);
      toast.success(
        dispatcher.active ? "Envios deshabilitado" : "Envios habilitado"
      );
      loadDispatchers();
    } catch (error) {
      toast.error("No se puede actualizar el estado");
    }
  };

  const handleDeleteDispatcher = async () => {
    if (!dispatcherPendingDeletion) return;
    try {
      await deleteScheduledDispatcher(dispatcherPendingDeletion.id);
      toast.success("Envios eliminado");
      setConfirmModalOpen(false);
      setDispatcherPendingDeletion(null);
      loadDispatchers();
    } catch (error) {
      toast.error("Error al eliminar el Envios");
    }
  };

  const handleOpenModal = dispatcher => {
    setEditingDispatcher(dispatcher || null);
    setModalOpen(true);
  };

  const handleCloseModal = shouldReload => {
    setModalOpen(false);
    setEditingDispatcher(null);
    if (shouldReload) {
      loadDispatchers();
    }
  };

  const eventVisuals = useMemo(
    () => ({
      birthday: {
        label: "Cumpleaños",
        icon: <CakeIcon />,
        background: theme.palette.success.main
      },
      invoice_reminder: {
        label: "Recordatorio de factura",
        icon: <ReceiptIcon />,
        background: theme.palette.info.main
      },
      invoice_overdue: {
        label: "Pago vencido",
        icon: <WarningIcon />,
        background: theme.palette.error.main
      }
    }),
    [theme]
  );

  const renderRulesDescription = dispatcher => {
    if (dispatcher.eventType === "invoice_reminder") {
      return `Enviar ${dispatcher.daysBeforeDue || 0} Día(s) antes de la fecha de vencimiento`;
    }
    if (dispatcher.eventType === "invoice_overdue") {
      return `Enviar ${dispatcher.daysAfterDue || 0} Día(s) después de la fecha de vencimiento`;
    }
    return "Se ejecuta en el cumpleaños del cliente";
  };

  return (
    <Box className={classes.root}>
      <ConfirmationModal
        title="Eliminar el envio programado"
        open={confirmModalOpen}
        onClose={() => setConfirmModalOpen(false)}
        onConfirm={handleDeleteDispatcher}
      >
        ¿Seguro que desea eliminar? "{dispatcherPendingDeletion?.title}"?
      </ConfirmationModal>

      <ScheduledDispatcherModal
        open={modalOpen}
        onClose={handleCloseModal}
        dispatcher={editingDispatcher}
      />

      <Box className={classes.pageHeader}>
        <Box>
          <Typography className={classes.headerTitle}>
            Envios automáticos
          </Typography>
          <Typography className={classes.headerSubtitle}>
            {stats.total}{" "}
            {stats.total === 1 ? "Regla configurada" : "Reglas configuradas"}
          </Typography>
        </Box>
        <Box className={classes.headerActions}>
          <FormControl
            variant="outlined"
            size="small"
            className={classes.selectControl}
          >
            <Select
              value={eventFilter}
              onChange={event => setEventFilter(event.target.value)}
            >
              <MenuItem value="all">Todos los eventos</MenuItem>
              {eventTypeOptions.map(option => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={loadDispatchers}
            disabled={loading}
          >
            Recargar
          </Button>
          <Button
            color="primary"
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => handleOpenModal()}
          >
            Nuevo Envio
          </Button>
        </Box>
      </Box>

      <Box className={classes.listWrapper}>
        {loading ? (
          <Box className={classes.emptyState}>
            <CircularProgress />

            <Typography variant="body1">
              Cargando envios programados...
            </Typography>
          </Box>
        ) : filtered.length === 0 ? (
          <Box className={classes.emptyState}>
            <EventIcon fontSize="large" color="primary" />
            <Typography variant="h6">No se encontraron envios</Typography>
            <Typography variant="body2" color="textSecondary">
              Comienza creando una nueva regla de Envio automático.
            </Typography>
            <Button
              color="primary"
              variant="contained"
              startIcon={<AddIcon />}
              onClick={() => handleOpenModal()}
            >
              Crear el primer envio
            </Button>
          </Box>
        ) : (
          filtered.map(dispatcher => {
            const visuals = eventVisuals[dispatcher.eventType] || {
              icon: <EventIcon />,
              background: theme.palette.primary.main,
              label: dispatcher.eventType
            };
            const eventMeta = eventTypeOptions.find(
              item => item.value === dispatcher.eventType
            );

            return (
              <Paper key={dispatcher.id} className={classes.dispatcherCard}>
                <Box
                  className={classes.iconBubble}
                  style={{ backgroundColor: visuals.background }}
                >
                  {visuals.icon}
                </Box>
                <Box className={classes.cardBody}>
                  <Box className={classes.cardHeader}>
                    <Typography className={classes.cardTitle}>
                      {dispatcher.title}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      {eventMeta?.label || visuals.label}
                    </Typography>
                  </Box>
                  <Typography variant="body2" color="textSecondary">
                    {renderRulesDescription(dispatcher)}
                  </Typography>
                  <Box className={classes.cardMeta}>
                    <span>Inicio: {dispatcher.startTime}</span>
                    <span>Intervalo: {dispatcher.sendIntervalSeconds}s</span>
                    <span>
                      Conexão: {dispatcher.whatsapp?.name || "Indefinido"}
                    </span>
                  </Box>
                  <Typography variant="caption" color="textSecondary">
                    Última actualizacióno{" "}
                    {new Date(dispatcher.updatedAt).toLocaleDateString()}
                  </Typography>
                </Box>
                <Box className={classes.cardActions}>
                  <Tooltip
                    title={dispatcher.active ? "Desactivar envio" : "Activar envio"}
                  >
                    <Switch
                      checked={dispatcher.active}
                      onChange={() => handleToggleDispatcher(dispatcher)}
                      color="primary"
                    />
                  </Tooltip>
                  <Typography
                    className={
                      dispatcher.active
                        ? classes.statusTextActive
                        : classes.statusTextInactive
                    }
                  >
                    {dispatcher.active ? "Activo" : "Inactivo"}
                  </Typography>
                  <Box className={classes.actionsRow}>
                    <Tooltip title="Editar">
                      <IconButton
                        onClick={() => handleOpenModal(dispatcher)}
                        size="small"
                      >
                        <EditIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Excluir">
                      <IconButton
                        onClick={() => {
                          setDispatcherPendingDeletion(dispatcher);
                          setConfirmModalOpen(true);
                        }}
                        size="small"
                      >
                        <DeleteIcon color="error" />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Box>
              </Paper>
            );
          })
        )}
      </Box>
    </Box>
  );
};

export default Automations;