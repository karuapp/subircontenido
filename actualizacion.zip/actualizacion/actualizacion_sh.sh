#!/bin/bash
set -e

# 🎨 Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
WHITE='\033[1;37m'
NC='\033[0m'

echo -e "${WHITE}🔄 Iniciando actualizador automático...${NC}"

# 1️⃣ Actualizar sistema
sudo apt -y update && sudo apt -y upgrade

# 2️⃣ Desempaquetar actualizacion.zip
if [ -f "./actualizacion.zip" ]; then
  echo -e "${WHITE}📦 Desempaquetando actualizacion.zip...${NC}"
  sudo rm -rf /actualizacion
  sudo unzip -o actualizacion.zip -d /
else
  echo -e "${RED}❌ No se encontró actualizacion.zip.${NC}"
  exit 1
fi

# 3️⃣ Preguntar instancia
read -p "👉 Ingresa el nombre de la instancia (ejemplo: whaticket): " instance_name

if [ -z "$instance_name" ]; then
  echo -e "${RED}❌ No ingresaste un nombre.${NC}"
  exit 1
fi

# Nueva ruta base fija
BASE_PATH="/home/deploy/$instance_name"

if [ ! -d "$BASE_PATH" ]; then
  echo -e "${RED}❌ La ruta $BASE_PATH no existe.${NC}"
  exit 1
fi

echo -e "${GREEN}✅ Instancia seleccionada: $instance_name${NC}"

############################################
# 4️⃣ ACTUALIZAR BACKEND
############################################

echo -e "${WHITE}⚙️ Actualizando backend...${NC}"

cd "$BASE_PATH/backend" || exit 1

# 🔥 Solo eliminar src y package.json
rm -rf src
rm -f package.json


# Copiar nueva versión
rsync -av /actualizacion/backend/src ./src
rsync -av /actualizacion/backend/package.json ./package.json

# Instalar dependencias y migraciones
npm install --force
npm run build




# Permisos con usuario fijo deploy
sudo chown -R deploy:deploy "$BASE_PATH/backend"
sudo chmod -R 775 "$BASE_PATH/backend/cache"
sudo chmod -R 775 "$BASE_PATH/backend/uploads"

############################################
# 5️⃣ ACTUALIZAR FRONTEND
############################################

echo -e "${WHITE}⚙️ Actualizando frontend...${NC}"

cd "$BASE_PATH/frontend" || exit 1

# 🔥 Solo eliminar src y package.json
rm -rf src
rm -f package.json

# Copiar nueva versión
rsync -av /actualizacion/frontend/src ./src
rsync -av /actualizacion/frontend/package.json ./package.json

# Reinstalar dependencias
npm install --force

npm run build

############################################
# 6️⃣ REINICIAR PM2
############################################

echo -e "${WHITE}🚀 Reiniciando servicios con PM2...${NC}"

sudo su - deploy -c "pm2 restart all"

echo -e "${GREEN}🎉 Actualización completada para $instance_name${NC}"