const DIGIT_REGEX = /\D/g;

const stripDigits = (value?: string | null): string => {
  if (!value) return "";
  return value.replace(DIGIT_REGEX, "");
};

// Detecta si es un LID (Linked ID de WhatsApp Business API)
export const isLidNumber = (digits: string): boolean => {
  if (!digits) return false;

  // LIDs suelen tener 15+ dígitos y no son números reales
  if (digits.length > 15) return true;

  return false;
};

export const normalizePhoneNumber = (value?: string | null): string => {
  const digits = stripDigits(value);

  if (!digits) return "";

  // Si es LID, ignorar
  if (isLidNumber(digits)) {
    console.log(`[normalizePhoneNumber] LID detectado, ignorando: ${digits}`);
    return "";
  }

  // 🔥 NO agregar prefijo
  // 🔥 NO validar país
  // 🔥 NO modificar número

  // Validación mínima básica
  if (digits.length < 8) {
    console.log(`[normalizePhoneNumber] Número inválido (muy corto): ${digits}`);
    return "";
  }

  return digits;
};

const extractDigitsFromJid = (jid?: string | null): string => {
  if (!jid) return "";
  return stripDigits(jid);
};

const getCandidateNumbers = (candidates: Array<string | null | undefined>): string[] =>
  candidates
    .map(extractDigitsFromJid)
    .filter(digits => !!digits);

export const resolveContactNumber = ({
  rawNumber,
  remoteJid,
  remoteJidAlt
}: {
  rawNumber?: string | null;
  remoteJid?: string | null;
  remoteJidAlt?: string | null;
}): string => {

  const rawCandidates = getCandidateNumbers([remoteJidAlt, remoteJid, rawNumber]);

  for (const digits of rawCandidates) {
    const normalized = normalizePhoneNumber(digits);
    if (normalized) {
      return normalized;
    }
  }

  return "";
};

export const buildRemoteJidFromNumber = (number: string, isGroup = false): string => {
  if (!number) return "";

  return isGroup
    ? `${number}@g.us`
    : `${number}@s.whatsapp.net`;
};

export const sanitizeRemoteJid = (
  remoteJid?: string | null,
  number?: string | null,
  isGroup = false
): string => {

  if (number) {
    const normalized = normalizePhoneNumber(number);
    if (normalized) {
      return buildRemoteJidFromNumber(normalized, isGroup);
    }
  }

  return "";
};
