import { Router, Request, Response } from 'express';
import {
  getAppointments,
  getAppointmentById,
  createAppointment,
  updateAppointment,
  getClinics,
  getClinicById,
  getPatients,
  getPatientById,
  createPatient,
  updatePatient
} from '../services/imaginasoftApi';

const router = Router();

// --- Rotas de Clinics ---
router.get('/clinics', async (req: Request, res: Response) => {
  try {
    const clinics = await getClinics();
    res.json(clinics);
  } catch (error: any) {
    console.error('Error al recuperar clínicas:', error);
    res.status(500).json({ error: 'Error al recuperar clínicas', details: error.message });
  }
});

router.get('/clinics/:id', async (req: Request, res: Response) => {
  try {
    const clinic = await getClinicById(req.params.id);
    res.json(clinic);
  } catch (error: any) {
    console.error('Error al recuperar detalles de la clínica:', error);
    res.status(500).json({ error: 'Error al recuperar detalles de la clínica', details: error.message });
  }
});

// --- Rotas de Patients ---
router.get('/patients', async (req: Request, res: Response) => {
  try {
    const patients = await getPatients(req.query);
    res.json(patients);
  } catch (error: any) {
    console.error('Error al recuperar pacientes:', error);
    res.status(500).json({ error: 'Error al recuperar pacientes', details: error.message });
  }
});

router.get('/patients/:id', async (req: Request, res: Response) => {
  try {
    const patient = await getPatientById(req.params.id);
    res.json(patient);
  } catch (error: any) {
    console.error('Error al recuperar detalles del paciente:', error);
    res.status(500).json({ error: 'Error al recuperar detalles del paciente', details: error.message });
  }
});

router.post('/patients', async (req: Request, res: Response) => {
  try {
    const newPatient = await createPatient(req.body);
    res.status(201).json(newPatient);
  } catch (error: any) {
    console.error('Error al crear paciente:', error);
    res.status(500).json({ error: 'Error al crear paciente', details: error.message });
  }
});

router.put('/patients/:id', async (req: Request, res: Response) => {
  try {
    const updatedPatient = await updatePatient(req.params.id, req.body);
    res.json(updatedPatient);
  } catch (error: any) {
    console.error('Error al actualizar paciente:', error);
    res.status(500).json({ error: 'Error al actualizar paciente', details: error.message });
  }
});

// --- Rutas de citas ---
router.get('/appointments', async (req: Request, res: Response) => {
  try {
    const appointments = await getAppointments(req.query);
    res.json(appointments);
  } catch (error: any) {
    console.error('Error al recuperar citas:', error);
    res.status(500).json({ error: 'Error al recuperar citas', details: error.message });
  }
});

router.get('/appointments/:id', async (req: Request, res: Response) => {
  try {
    const appointment = await getAppointmentById(req.params.id);
    res.json(appointment);
  } catch (error: any) {
    console.error('Error al recuperar los detalles de la cita:', error);
    res.status(500).json({ error: 'Error al recuperar los detalles de la cita', details: error.message });
  }
});

router.post('/appointments', async (req: Request, res: Response) => {
  try {
    const newAppointment = await createAppointment(req.body);
    res.status(201).json(newAppointment);
  } catch (error: any) {
    console.error('Error al crear la cita:', error);
    res.status(500).json({ error: 'Error al crear la cita', details: error.message });
  }
});

router.put('/appointments/:id', async (req: Request, res: Response) => {
  try {
    const updatedAppointment = await updateAppointment(req.params.id, req.body);
    res.json(updatedAppointment);
  } catch (error: any) {
    console.error('Error al actualizar la cita:', error);
    res.status(500).json({ error: 'Error al actualizar la cita', details: error.message });
  }
});

export default router;