import { Router } from "express";
import multer from "multer";

import isAuth from "../middleware/isAuth";
import mediaLibraryUploadConfig from "../config/mediaLibraryUpload";
import * as MediaFolderController from "../controllers/MediaLibrary/MediaFolderController";

const mediaLibraryRoutes = Router();
const upload = multer(mediaLibraryUploadConfig);

mediaLibraryRoutes.use(isAuth);

mediaLibraryRoutes.get("/media-folders", MediaFolderController.index);
mediaLibraryRoutes.post("/media-folders", MediaFolderController.store);
mediaLibraryRoutes.put("/media-folders/:folderId", MediaFolderController.update);
mediaLibraryRoutes.delete("/media-folders/:folderId", MediaFolderController.remove);

mediaLibraryRoutes.get(
  "/media-folders/:folderId/files",
  MediaFolderController.listFiles
);
mediaLibraryRoutes.post(
  "/media-folders/:folderId/files",
  upload.single("file"),
  MediaFolderController.uploadFile
);

mediaLibraryRoutes.put(
  "/media-files/:fileId",
  MediaFolderController.updateFile
);
mediaLibraryRoutes.delete(
  "/media-files/:fileId",
  MediaFolderController.deleteFile
);

export default mediaLibraryRoutes;
