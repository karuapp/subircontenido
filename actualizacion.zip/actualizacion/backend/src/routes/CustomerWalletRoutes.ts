import { Router } from "express";
import isAuth from "../middleware/isAuth";
import { index } from "../controllers/CustomerWalletController/IndexController";
import { store } from "../controllers/CustomerWalletController/StoreController";
import { addCustomer } from "../controllers/CustomerWalletController/AddCustomerController";
import { addUser } from "../controllers/CustomerWalletController/AddUserController";

const customerWalletRoutes = Router();

customerWalletRoutes.get("/wallets", isAuth, index);
customerWalletRoutes.post("/wallets", isAuth, store);
customerWalletRoutes.post("/wallets/:walletId/customers", isAuth, addCustomer);
customerWalletRoutes.post("/wallets/:walletId/users", isAuth, addUser);

export default customerWalletRoutes;
