--
-- PostgreSQL database dump
--

\restrict Sezt8VbHelHJrZDLKgeUwuEd5EnhaU9N4hrFWdMAzOFwrS2QncZSui8KcnNlMue

-- Dumped from database version 18.1 (Ubuntu 18.1-1.pgdg24.04+2)
-- Dumped by pg_dump version 18.1 (Ubuntu 18.1-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: enum_MobileWebhooks_platform; Type: TYPE; Schema: public; Owner: whaticket
--

CREATE TYPE public."enum_MobileWebhooks_platform" AS ENUM (
    'android',
    'ios'
);


ALTER TYPE public."enum_MobileWebhooks_platform" OWNER TO whaticket;

--
-- Name: update_tutorial_videos_updated_at(); Type: FUNCTION; Schema: public; Owner: whaticket
--

CREATE FUNCTION public.update_tutorial_videos_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_tutorial_videos_updated_at() OWNER TO whaticket;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: whaticket
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."updatedAt" = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO whaticket;

--
-- Name: update_user_device_updated_at(); Type: FUNCTION; Schema: public; Owner: whaticket
--

CREATE FUNCTION public.update_user_device_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."updatedAt" = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_user_device_updated_at() OWNER TO whaticket;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Announcements; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Announcements" (
    id integer NOT NULL,
    priority integer,
    title character varying(255) NOT NULL,
    text text NOT NULL,
    "mediaPath" text,
    "mediaName" text,
    "companyId" integer NOT NULL,
    status boolean,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Announcements" OWNER TO whaticket;

--
-- Name: Announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Announcements_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Announcements_id_seq" OWNER TO whaticket;

--
-- Name: Announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Announcements_id_seq" OWNED BY public."Announcements".id;


--
-- Name: ApiUsages; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."ApiUsages" (
    id integer NOT NULL,
    "companyId" integer DEFAULT 0,
    "dateUsed" text NOT NULL,
    "UsedOnDay" integer DEFAULT 0,
    "usedText" integer DEFAULT 0,
    "usedPDF" integer DEFAULT 0,
    "usedImage" integer DEFAULT 0,
    "usedVideo" integer DEFAULT 0,
    "usedOther" integer DEFAULT 0,
    "usedCheckNumber" integer DEFAULT 0,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ApiUsages" OWNER TO whaticket;

--
-- Name: ApiUsages_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."ApiUsages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ApiUsages_id_seq" OWNER TO whaticket;

--
-- Name: ApiUsages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."ApiUsages_id_seq" OWNED BY public."ApiUsages".id;


--
-- Name: AutomationActions; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."AutomationActions" (
    id integer NOT NULL,
    "automationId" integer NOT NULL,
    "actionType" character varying(50) NOT NULL,
    "actionConfig" jsonb DEFAULT '{}'::jsonb,
    "order" integer DEFAULT 1,
    "delayMinutes" integer DEFAULT 0,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."AutomationActions" OWNER TO whaticket;

--
-- Name: AutomationActions_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."AutomationActions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationActions_id_seq" OWNER TO whaticket;

--
-- Name: AutomationActions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."AutomationActions_id_seq" OWNED BY public."AutomationActions".id;


--
-- Name: AutomationExecutions; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."AutomationExecutions" (
    id integer NOT NULL,
    "automationId" integer NOT NULL,
    "automationActionId" integer NOT NULL,
    "contactId" integer,
    "ticketId" integer,
    "scheduledAt" timestamp with time zone NOT NULL,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    attempts integer DEFAULT 0,
    "lastAttemptAt" timestamp with time zone,
    "completedAt" timestamp with time zone,
    error text,
    metadata jsonb DEFAULT '{}'::jsonb,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."AutomationExecutions" OWNER TO whaticket;

--
-- Name: AutomationExecutions_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."AutomationExecutions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationExecutions_id_seq" OWNER TO whaticket;

--
-- Name: AutomationExecutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."AutomationExecutions_id_seq" OWNED BY public."AutomationExecutions".id;


--
-- Name: AutomationLogs; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."AutomationLogs" (
    id integer NOT NULL,
    "automationId" integer NOT NULL,
    "contactId" integer,
    "ticketId" integer,
    status character varying(20) DEFAULT 'pending'::character varying,
    "executedAt" timestamp with time zone,
    result jsonb DEFAULT '{}'::jsonb,
    error text,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."AutomationLogs" OWNER TO whaticket;

--
-- Name: AutomationLogs_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."AutomationLogs_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AutomationLogs_id_seq" OWNER TO whaticket;

--
-- Name: AutomationLogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."AutomationLogs_id_seq" OWNED BY public."AutomationLogs".id;


--
-- Name: Automations; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Automations" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    "triggerType" character varying(50) NOT NULL,
    "triggerConfig" jsonb DEFAULT '{}'::jsonb,
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."Automations" OWNER TO whaticket;

--
-- Name: Automations_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Automations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Automations_id_seq" OWNER TO whaticket;

--
-- Name: Automations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Automations_id_seq" OWNED BY public."Automations".id;


--
-- Name: Baileys; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Baileys" (
    id integer NOT NULL,
    "whatsappId" integer NOT NULL,
    contacts jsonb,
    chats jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Baileys" OWNER TO whaticket;

--
-- Name: Baileys_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Baileys_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Baileys_id_seq" OWNER TO whaticket;

--
-- Name: Baileys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Baileys_id_seq" OWNED BY public."Baileys".id;


--
-- Name: CampaignSettings; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."CampaignSettings" (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    value text,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."CampaignSettings" OWNER TO whaticket;

--
-- Name: CampaignSettings_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."CampaignSettings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CampaignSettings_id_seq" OWNER TO whaticket;

--
-- Name: CampaignSettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."CampaignSettings_id_seq" OWNED BY public."CampaignSettings".id;


--
-- Name: CampaignShipping; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."CampaignShipping" (
    id integer NOT NULL,
    "jobId" character varying(255),
    number character varying(255) NOT NULL,
    message text NOT NULL,
    "confirmationMessage" text,
    confirmation boolean,
    "contactId" integer,
    "campaignId" integer NOT NULL,
    "confirmationRequestedAt" timestamp with time zone,
    "confirmedAt" timestamp with time zone,
    "deliveredAt" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."CampaignShipping" OWNER TO whaticket;

--
-- Name: CampaignShipping_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."CampaignShipping_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CampaignShipping_id_seq" OWNER TO whaticket;

--
-- Name: CampaignShipping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."CampaignShipping_id_seq" OWNED BY public."CampaignShipping".id;


--
-- Name: Campaigns; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Campaigns" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message1 text DEFAULT ''::text,
    message2 text DEFAULT ''::text,
    message3 text DEFAULT ''::text,
    message4 text DEFAULT ''::text,
    message5 text DEFAULT ''::text,
    "confirmationMessage1" text DEFAULT ''::text,
    "confirmationMessage2" text DEFAULT ''::text,
    "confirmationMessage3" text DEFAULT ''::text,
    "confirmationMessage4" text DEFAULT ''::text,
    "confirmationMessage5" text DEFAULT ''::text,
    status character varying(255),
    confirmation boolean DEFAULT false,
    "mediaPath" text,
    "mediaName" text,
    "companyId" integer NOT NULL,
    "contactListId" integer,
    "whatsappId" integer,
    "scheduledAt" timestamp with time zone,
    "completedAt" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "userId" integer,
    "queueId" integer,
    "statusTicket" character varying(255) DEFAULT 'closed'::character varying,
    "openTicket" character varying(255) DEFAULT 'disabled'::character varying
);


ALTER TABLE public."Campaigns" OWNER TO whaticket;

--
-- Name: Campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Campaigns_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Campaigns_id_seq" OWNER TO whaticket;

--
-- Name: Campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Campaigns_id_seq" OWNED BY public."Campaigns".id;


--
-- Name: ChatMessages; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."ChatMessages" (
    id integer NOT NULL,
    "chatId" integer NOT NULL,
    "senderId" integer NOT NULL,
    message text DEFAULT ''::text,
    "mediaPath" text,
    "mediaName" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ChatMessages" OWNER TO whaticket;

--
-- Name: ChatMessages_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."ChatMessages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ChatMessages_id_seq" OWNER TO whaticket;

--
-- Name: ChatMessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."ChatMessages_id_seq" OWNED BY public."ChatMessages".id;


--
-- Name: ChatUsers; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."ChatUsers" (
    id integer NOT NULL,
    "chatId" integer NOT NULL,
    "userId" integer NOT NULL,
    unreads integer DEFAULT 0,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ChatUsers" OWNER TO whaticket;

--
-- Name: ChatUsers_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."ChatUsers_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ChatUsers_id_seq" OWNER TO whaticket;

--
-- Name: ChatUsers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."ChatUsers_id_seq" OWNED BY public."ChatUsers".id;


--
-- Name: Chatbots; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Chatbots" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "queueId" integer,
    "chatbotId" integer,
    "greetingMessage" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isAgent" boolean DEFAULT false,
    "optQueueId" integer,
    "optUserId" integer,
    "queueType" character varying(255) DEFAULT 'text'::character varying NOT NULL,
    "optIntegrationId" integer,
    "optFileId" integer,
    "closeTicket" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Chatbots" OWNER TO whaticket;

--
-- Name: Chatbots_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Chatbots_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Chatbots_id_seq" OWNER TO whaticket;

--
-- Name: Chatbots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Chatbots_id_seq" OWNED BY public."Chatbots".id;


--
-- Name: Chats; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Chats" (
    id integer NOT NULL,
    title text DEFAULT ''::text,
    uuid character varying(255) DEFAULT ''::character varying,
    "ownerId" integer NOT NULL,
    "lastMessage" text,
    "companyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Chats" OWNER TO whaticket;

--
-- Name: Chats_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Chats_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Chats_id_seq" OWNER TO whaticket;

--
-- Name: Chats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Chats_id_seq" OWNED BY public."Chats".id;


--
-- Name: Companies; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Companies" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(255),
    email character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "planId" integer,
    status boolean DEFAULT true,
    schedules jsonb DEFAULT '[]'::jsonb,
    "dueDate" timestamp with time zone,
    recurrence character varying(255) DEFAULT ''::character varying,
    document character varying(255) DEFAULT ''::character varying,
    "paymentMethod" character varying(255) DEFAULT ''::character varying,
    "lastLogin" timestamp with time zone,
    "folderSize" character varying(255),
    "numberFileFolder" character varying(255),
    "updatedAtFolder" character varying(255),
    type character varying(10) DEFAULT 'pf'::character varying NOT NULL,
    segment character varying(50) DEFAULT 'outros'::character varying NOT NULL,
    "loadingImage" character varying(255)
);


ALTER TABLE public."Companies" OWNER TO whaticket;

--
-- Name: CompaniesSettings; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."CompaniesSettings" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "hoursCloseTicketsAuto" character varying(255) NOT NULL,
    "chatBotType" character varying(255) NOT NULL,
    "acceptCallWhatsapp" character varying(255) NOT NULL,
    "userRandom" character varying(255) NOT NULL,
    "sendGreetingMessageOneQueues" character varying(255) NOT NULL,
    "sendSignMessage" character varying(255) NOT NULL,
    "sendFarewellWaitingTicket" character varying(255) NOT NULL,
    "userRating" character varying(255) NOT NULL,
    "sendGreetingAccepted" character varying(255) NOT NULL,
    "CheckMsgIsGroup" character varying(255) NOT NULL,
    "sendQueuePosition" character varying(255) NOT NULL,
    "scheduleType" character varying(255) NOT NULL,
    "acceptAudioMessageContact" character varying(255) NOT NULL,
    "enableLGPD" character varying(255) NOT NULL,
    "sendMsgTransfTicket" character varying(255) NOT NULL,
    "requiredTag" character varying(255) NOT NULL,
    "lgpdDeleteMessage" character varying(255) NOT NULL,
    "lgpdHideNumber" character varying(255) NOT NULL,
    "lgpdConsent" character varying(255) NOT NULL,
    "lgpdLink" character varying(255),
    "lgpdMessage" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "DirectTicketsToWallets" boolean DEFAULT false,
    "closeTicketOnTransfer" boolean DEFAULT false,
    "greetingAcceptedMessage" text DEFAULT ''::text,
    "AcceptCallWhatsappMessage" text DEFAULT ''::text,
    "sendQueuePositionMessage" text DEFAULT ''::text,
    "transferMessage" text DEFAULT ''::text,
    "showNotificationPending" boolean DEFAULT false NOT NULL,
    "notificameHub" character varying(255),
    "autoSaveContacts" character varying(20) DEFAULT 'disabled'::character varying,
    "autoSaveContactsScore" integer DEFAULT 7,
    "autoSaveContactsReason" character varying(50) DEFAULT 'high_potential'::character varying
);


ALTER TABLE public."CompaniesSettings" OWNER TO whaticket;

--
-- Name: CompaniesSettings_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."CompaniesSettings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CompaniesSettings_id_seq" OWNER TO whaticket;

--
-- Name: CompaniesSettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."CompaniesSettings_id_seq" OWNED BY public."CompaniesSettings".id;


--
-- Name: Companies_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Companies_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Companies_id_seq" OWNER TO whaticket;

--
-- Name: Companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Companies_id_seq" OWNED BY public."Companies".id;


--
-- Name: ContactCustomFields; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."ContactCustomFields" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    "contactId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ContactCustomFields" OWNER TO whaticket;

--
-- Name: ContactCustomFields_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."ContactCustomFields_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ContactCustomFields_id_seq" OWNER TO whaticket;

--
-- Name: ContactCustomFields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."ContactCustomFields_id_seq" OWNED BY public."ContactCustomFields".id;


--
-- Name: ContactGroups; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."ContactGroups" (
    id integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "contactId" integer,
    "companyId" integer,
    "userId" integer
);


ALTER TABLE public."ContactGroups" OWNER TO whaticket;

--
-- Name: ContactGroups_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."ContactGroups_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ContactGroups_id_seq" OWNER TO whaticket;

--
-- Name: ContactGroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."ContactGroups_id_seq" OWNED BY public."ContactGroups".id;


--
-- Name: ContactListItems; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."ContactListItems" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    number character varying(255) NOT NULL,
    email character varying(255),
    "contactListId" integer NOT NULL,
    "isWhatsappValid" boolean DEFAULT false,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isGroup" boolean DEFAULT false
);


ALTER TABLE public."ContactListItems" OWNER TO whaticket;

--
-- Name: ContactListItems_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."ContactListItems_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ContactListItems_id_seq" OWNER TO whaticket;

--
-- Name: ContactListItems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."ContactListItems_id_seq" OWNED BY public."ContactListItems".id;


--
-- Name: ContactLists; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."ContactLists" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ContactLists" OWNER TO whaticket;

--
-- Name: ContactLists_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."ContactLists_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ContactLists_id_seq" OWNER TO whaticket;

--
-- Name: ContactLists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."ContactLists_id_seq" OWNED BY public."ContactLists".id;


--
-- Name: ContactTags; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."ContactTags" (
    "contactId" integer NOT NULL,
    "tagId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ContactTags" OWNER TO whaticket;

--
-- Name: ContactWallets; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."ContactWallets" (
    id integer NOT NULL,
    "walletId" integer NOT NULL,
    "contactId" integer NOT NULL,
    "companyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ContactWallets" OWNER TO whaticket;

--
-- Name: ContactWallets_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."ContactWallets_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ContactWallets_id_seq" OWNER TO whaticket;

--
-- Name: ContactWallets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."ContactWallets_id_seq" OWNED BY public."ContactWallets".id;


--
-- Name: Contacts; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Contacts" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    number character varying(255) NOT NULL,
    "profilePicUrl" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    "isGroup" boolean DEFAULT false NOT NULL,
    "companyId" integer,
    "acceptAudioMessage" boolean DEFAULT true NOT NULL,
    channel text DEFAULT 'whatsapp'::text,
    active boolean DEFAULT true,
    "disableBot" boolean DEFAULT false NOT NULL,
    "remoteJid" character varying(255) DEFAULT NULL::character varying,
    "lgpdAcceptedAt" timestamp with time zone,
    "urlPicture" text,
    "pictureUpdated" boolean DEFAULT false NOT NULL,
    "whatsappId" integer,
    "isLid" boolean DEFAULT false NOT NULL,
    birthday timestamp without time zone,
    anniversary timestamp without time zone,
    info text,
    files jsonb,
    "cpfCnpj" character varying(32),
    address character varying(255),
    lid character varying(255),
    "savedToPhone" boolean DEFAULT false,
    "savedToPhoneAt" timestamp with time zone,
    "savedToPhoneReason" character varying(100),
    "potentialScore" integer DEFAULT 0,
    "isPotential" boolean DEFAULT false,
    "lidStability" character varying(20) DEFAULT 'unknown'::character varying
);


ALTER TABLE public."Contacts" OWNER TO whaticket;

--
-- Name: Contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Contacts_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Contacts_id_seq" OWNER TO whaticket;

--
-- Name: Contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Contacts_id_seq" OWNED BY public."Contacts".id;


--
-- Name: DialogChatBots; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."DialogChatBots" (
    id integer NOT NULL,
    awaiting integer DEFAULT 0 NOT NULL,
    "contactId" integer,
    "chatbotId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "queueId" integer
);


ALTER TABLE public."DialogChatBots" OWNER TO whaticket;

--
-- Name: DialogChatBots_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."DialogChatBots_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DialogChatBots_id_seq" OWNER TO whaticket;

--
-- Name: DialogChatBots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."DialogChatBots_id_seq" OWNED BY public."DialogChatBots".id;


--
-- Name: Faturas; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Faturas" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "contactId" integer NOT NULL,
    valor numeric(12,2) NOT NULL,
    descricao text,
    status character varying(20) DEFAULT 'pendente'::character varying NOT NULL,
    "dataCriacao" timestamp without time zone DEFAULT now(),
    "dataVencimento" timestamp without time zone NOT NULL,
    "dataPagamento" timestamp without time zone,
    recorrente boolean DEFAULT false NOT NULL,
    intervalo character varying(20),
    "proximaCobranca" timestamp without time zone,
    "limiteRecorrencias" integer,
    "recorrenciasRealizadas" integer DEFAULT 0,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now()
);


ALTER TABLE public."Faturas" OWNER TO whaticket;

--
-- Name: Faturas_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Faturas_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Faturas_id_seq" OWNER TO whaticket;

--
-- Name: Faturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Faturas_id_seq" OWNED BY public."Faturas".id;


--
-- Name: Ferramentas; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Ferramentas" (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    descricao text,
    url text NOT NULL,
    metodo character varying(10) NOT NULL,
    headers jsonb,
    body jsonb,
    query_params jsonb,
    placeholders jsonb,
    status character varying(20) DEFAULT 'ativo'::character varying,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now(),
    "companyId" integer
);


ALTER TABLE public."Ferramentas" OWNER TO whaticket;

--
-- Name: Ferramentas_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Ferramentas_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Ferramentas_id_seq" OWNER TO whaticket;

--
-- Name: Ferramentas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Ferramentas_id_seq" OWNED BY public."Ferramentas".id;


--
-- Name: Files; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Files" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    name character varying(255) NOT NULL,
    message text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Files" OWNER TO whaticket;

--
-- Name: FilesOptions; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."FilesOptions" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    "fileId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "mediaType" character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public."FilesOptions" OWNER TO whaticket;

--
-- Name: FilesOptions_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."FilesOptions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FilesOptions_id_seq" OWNER TO whaticket;

--
-- Name: FilesOptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."FilesOptions_id_seq" OWNED BY public."FilesOptions".id;


--
-- Name: Files_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Files_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Files_id_seq" OWNER TO whaticket;

--
-- Name: Files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Files_id_seq" OWNED BY public."Files".id;


--
-- Name: FlowAudios; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."FlowAudios" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    name character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."FlowAudios" OWNER TO whaticket;

--
-- Name: FlowAudios_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."FlowAudios_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FlowAudios_id_seq" OWNER TO whaticket;

--
-- Name: FlowAudios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."FlowAudios_id_seq" OWNED BY public."FlowAudios".id;


--
-- Name: FlowBuilders; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."FlowBuilders" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(255) NOT NULL,
    active boolean DEFAULT true,
    flow json,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    company_id integer DEFAULT 0 NOT NULL,
    variables json
);


ALTER TABLE public."FlowBuilders" OWNER TO whaticket;

--
-- Name: FlowBuilders_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."FlowBuilders_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FlowBuilders_id_seq" OWNER TO whaticket;

--
-- Name: FlowBuilders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."FlowBuilders_id_seq" OWNED BY public."FlowBuilders".id;


--
-- Name: FlowCampaigns; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."FlowCampaigns" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    name character varying(255) NOT NULL,
    "flowId" integer NOT NULL,
    phrase character varying(255) NOT NULL,
    status boolean DEFAULT true NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "whatsappId" integer,
    phrases text,
    "matchType" character varying(20)
);


ALTER TABLE public."FlowCampaigns" OWNER TO whaticket;

--
-- Name: FlowCampaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."FlowCampaigns_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FlowCampaigns_id_seq" OWNER TO whaticket;

--
-- Name: FlowCampaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."FlowCampaigns_id_seq" OWNED BY public."FlowCampaigns".id;


--
-- Name: FlowDefaults; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."FlowDefaults" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    "flowIdWelcome" integer,
    "flowIdNotPhrase" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."FlowDefaults" OWNER TO whaticket;

--
-- Name: FlowDefaults_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."FlowDefaults_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FlowDefaults_id_seq" OWNER TO whaticket;

--
-- Name: FlowDefaults_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."FlowDefaults_id_seq" OWNED BY public."FlowDefaults".id;


--
-- Name: FlowImgs; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."FlowImgs" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    name character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."FlowImgs" OWNER TO whaticket;

--
-- Name: FlowImgs_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."FlowImgs_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FlowImgs_id_seq" OWNER TO whaticket;

--
-- Name: FlowImgs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."FlowImgs_id_seq" OWNED BY public."FlowImgs".id;


--
-- Name: GoogleCalendarIntegrations; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."GoogleCalendarIntegrations" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "googleUserId" character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "accessToken" text NOT NULL,
    "refreshToken" text NOT NULL,
    "expiryDate" timestamp with time zone,
    "calendarId" character varying(255) DEFAULT 'primary'::character varying,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "userId" integer
);


ALTER TABLE public."GoogleCalendarIntegrations" OWNER TO whaticket;

--
-- Name: GoogleCalendarIntegrations_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."GoogleCalendarIntegrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GoogleCalendarIntegrations_id_seq" OWNER TO whaticket;

--
-- Name: GoogleCalendarIntegrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."GoogleCalendarIntegrations_id_seq" OWNED BY public."GoogleCalendarIntegrations".id;


--
-- Name: GoogleSheetsTokens; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."GoogleSheetsTokens" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "googleUserId" character varying,
    email character varying,
    "accessToken" text,
    "refreshToken" text,
    "expiryDate" timestamp without time zone,
    "rawTokens" jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."GoogleSheetsTokens" OWNER TO whaticket;

--
-- Name: GoogleSheetsTokens_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."GoogleSheetsTokens_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GoogleSheetsTokens_id_seq" OWNER TO whaticket;

--
-- Name: GoogleSheetsTokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."GoogleSheetsTokens_id_seq" OWNED BY public."GoogleSheetsTokens".id;


--
-- Name: Helps; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Helps" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    video character varying(255),
    link text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Helps" OWNER TO whaticket;

--
-- Name: Helps_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Helps_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Helps_id_seq" OWNER TO whaticket;

--
-- Name: Helps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Helps_id_seq" OWNED BY public."Helps".id;


--
-- Name: IaWorkflows; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."IaWorkflows" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "orchestratorPromptId" integer NOT NULL,
    "agentPromptId" integer NOT NULL,
    alias character varying(255) NOT NULL,
    "createdAt" timestamp(6) without time zone NOT NULL,
    "updatedAt" timestamp(6) without time zone NOT NULL
);


ALTER TABLE public."IaWorkflows" OWNER TO whaticket;

--
-- Name: IaWorkflows_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."IaWorkflows_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."IaWorkflows_id_seq" OWNER TO whaticket;

--
-- Name: IaWorkflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."IaWorkflows_id_seq" OWNED BY public."IaWorkflows".id;


--
-- Name: Integrations; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Integrations" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    name character varying(255) NOT NULL,
    "isActive" boolean DEFAULT false,
    token text,
    "foneContact" character varying(255),
    "userLogin" character varying(255),
    "passLogin" character varying(255),
    "finalCurrentMonth" integer,
    "initialCurrentMonth" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Integrations" OWNER TO whaticket;

--
-- Name: Integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Integrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Integrations_id_seq" OWNER TO whaticket;

--
-- Name: Integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Integrations_id_seq" OWNED BY public."Integrations".id;


--
-- Name: Invoices; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Invoices" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "dueDate" character varying(255),
    detail character varying(255),
    status character varying(255),
    value double precision,
    users integer DEFAULT 0,
    connections integer DEFAULT 0,
    queues integer DEFAULT 0,
    "useWhatsapp" boolean DEFAULT true,
    "useFacebook" boolean DEFAULT true,
    "useInstagram" boolean DEFAULT true,
    "useCampaigns" boolean DEFAULT true,
    "useSchedules" boolean DEFAULT true,
    "useInternalChat" boolean DEFAULT true,
    "useExternalApi" boolean DEFAULT true,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "linkInvoice" text DEFAULT ''::text
);


ALTER TABLE public."Invoices" OWNER TO whaticket;

--
-- Name: Invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Invoices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Invoices_id_seq" OWNER TO whaticket;

--
-- Name: Invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Invoices_id_seq" OWNED BY public."Invoices".id;


--
-- Name: LogTickets; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."LogTickets" (
    id integer NOT NULL,
    "userId" integer,
    "ticketId" integer NOT NULL,
    "queueId" integer,
    type character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."LogTickets" OWNER TO whaticket;

--
-- Name: LogTickets_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."LogTickets_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."LogTickets_id_seq" OWNER TO whaticket;

--
-- Name: LogTickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."LogTickets_id_seq" OWNED BY public."LogTickets".id;


--
-- Name: MediaFiles; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."MediaFiles" (
    id integer NOT NULL,
    folder_id integer NOT NULL,
    company_id integer NOT NULL,
    original_name character varying(255) NOT NULL,
    custom_name character varying(255),
    mime_type character varying(128) NOT NULL,
    size bigint NOT NULL,
    storage_path text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."MediaFiles" OWNER TO whaticket;

--
-- Name: MediaFiles_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."MediaFiles_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MediaFiles_id_seq" OWNER TO whaticket;

--
-- Name: MediaFiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."MediaFiles_id_seq" OWNED BY public."MediaFiles".id;


--
-- Name: MediaFolders; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."MediaFolders" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."MediaFolders" OWNER TO whaticket;

--
-- Name: MediaFolders_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."MediaFolders_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MediaFolders_id_seq" OWNER TO whaticket;

--
-- Name: MediaFolders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."MediaFolders_id_seq" OWNED BY public."MediaFolders".id;


--
-- Name: Messages; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Messages" (
    body text NOT NULL,
    ack integer DEFAULT 0 NOT NULL,
    read boolean DEFAULT false NOT NULL,
    "mediaType" character varying(255),
    "mediaUrl" character varying(255),
    "ticketId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "fromMe" boolean DEFAULT false NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "contactId" integer,
    "companyId" integer,
    "remoteJid" text,
    "dataJson" text,
    participant text,
    "queueId" integer,
    "ticketTrakingId" integer,
    "quotedMsgId" integer,
    wid character varying(255),
    id integer NOT NULL,
    "isPrivate" boolean DEFAULT false,
    "isEdited" boolean DEFAULT false,
    "isForwarded" boolean DEFAULT false,
    "fromAgent" boolean DEFAULT false NOT NULL,
    "userId" integer
);


ALTER TABLE public."Messages" OWNER TO whaticket;

--
-- Name: Messages_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Messages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Messages_id_seq" OWNER TO whaticket;

--
-- Name: Messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Messages_id_seq" OWNED BY public."Messages".id;


--
-- Name: MobileWebhooks; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."MobileWebhooks" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "companyId" integer NOT NULL,
    "webhookUrl" character varying(255) NOT NULL,
    "deviceToken" character varying(255) NOT NULL,
    platform public."enum_MobileWebhooks_platform" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "failureCount" integer DEFAULT 0 NOT NULL,
    "lastUsed" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."MobileWebhooks" OWNER TO whaticket;

--
-- Name: MobileWebhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."MobileWebhooks_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MobileWebhooks_id_seq" OWNER TO whaticket;

--
-- Name: MobileWebhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."MobileWebhooks_id_seq" OWNED BY public."MobileWebhooks".id;


--
-- Name: Negocios; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Negocios" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    "kanbanBoards" jsonb,
    users jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."Negocios" OWNER TO whaticket;

--
-- Name: Negocios_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Negocios_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Negocios_id_seq" OWNER TO whaticket;

--
-- Name: Negocios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Negocios_id_seq" OWNED BY public."Negocios".id;


--
-- Name: Partners; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Partners" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(255),
    email character varying(255),
    document character varying(255),
    commission numeric(10,2) NOT NULL,
    "typeCommission" character varying(255) NOT NULL,
    "walletId" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Partners" OWNER TO whaticket;

--
-- Name: Partners_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Partners_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Partners_id_seq" OWNER TO whaticket;

--
-- Name: Partners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Partners_id_seq" OWNED BY public."Partners".id;


--
-- Name: Plans; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Plans" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    users integer DEFAULT 0,
    connections integer DEFAULT 0,
    queues integer DEFAULT 0,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    amount character varying(255),
    "useFacebook" boolean DEFAULT true,
    "useInstagram" boolean DEFAULT true,
    "useWhatsapp" boolean DEFAULT true,
    "useCampaigns" boolean DEFAULT true,
    "useExternalApi" boolean DEFAULT true,
    "useInternalChat" boolean DEFAULT true,
    "useSchedules" boolean DEFAULT true,
    "useKanban" boolean DEFAULT true,
    "isPublic" boolean DEFAULT true NOT NULL,
    recurrence character varying(255),
    trial boolean DEFAULT false,
    "trialDays" integer DEFAULT 0,
    "useIntegrations" boolean DEFAULT true,
    "useOpenAi" boolean DEFAULT true
);


ALTER TABLE public."Plans" OWNER TO whaticket;

--
-- Name: Plans_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Plans_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Plans_id_seq" OWNER TO whaticket;

--
-- Name: Plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Plans_id_seq" OWNED BY public."Plans".id;


--
-- Name: Produtos; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Produtos" (
    id integer NOT NULL,
    "companyId" integer,
    tipo character varying(20) NOT NULL,
    nome character varying(255) NOT NULL,
    descricao text,
    valor numeric(12,2),
    status character varying(20) DEFAULT 'disponivel'::character varying,
    imagem_principal text,
    galeria jsonb,
    dados_especificos jsonb,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now()
);


ALTER TABLE public."Produtos" OWNER TO whaticket;

--
-- Name: Produtos_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Produtos_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Produtos_id_seq" OWNER TO whaticket;

--
-- Name: Produtos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Produtos_id_seq" OWNED BY public."Produtos".id;


--
-- Name: PromptToolSettings; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."PromptToolSettings" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "promptId" integer,
    "toolName" character varying(255) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."PromptToolSettings" OWNER TO whaticket;

--
-- Name: PromptToolSettings_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."PromptToolSettings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PromptToolSettings_id_seq" OWNER TO whaticket;

--
-- Name: PromptToolSettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."PromptToolSettings_id_seq" OWNED BY public."PromptToolSettings".id;


--
-- Name: Prompts; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Prompts" (
    id integer NOT NULL,
    name text NOT NULL,
    "apiKey" text NOT NULL,
    prompt text NOT NULL,
    "maxTokens" integer DEFAULT 100 NOT NULL,
    "maxMessages" integer DEFAULT 10 NOT NULL,
    temperature integer DEFAULT 1 NOT NULL,
    "promptTokens" integer DEFAULT 0 NOT NULL,
    "completionTokens" integer DEFAULT 0 NOT NULL,
    "totalTokens" integer DEFAULT 0 NOT NULL,
    voice text,
    "voiceKey" text,
    "voiceRegion" text,
    "queueId" integer NOT NULL,
    "companyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    model character varying(255),
    provider character varying(255) DEFAULT 'openai'::character varying,
    "knowledgeBase" jsonb DEFAULT '[]'::jsonb
);


ALTER TABLE public."Prompts" OWNER TO whaticket;

--
-- Name: Prompts_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Prompts_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Prompts_id_seq" OWNER TO whaticket;

--
-- Name: Prompts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Prompts_id_seq" OWNED BY public."Prompts".id;


--
-- Name: QueueIntegrations; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."QueueIntegrations" (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "projectName" character varying(255) NOT NULL,
    "jsonContent" text NOT NULL,
    language character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "urlN8N" character varying(255) DEFAULT true NOT NULL,
    "companyId" integer,
    "typebotExpires" integer DEFAULT 0 NOT NULL,
    "typebotKeywordFinish" character varying(255) DEFAULT ''::character varying NOT NULL,
    "typebotUnknownMessage" character varying(255) DEFAULT ''::character varying NOT NULL,
    "typebotSlug" character varying(255) DEFAULT ''::character varying NOT NULL,
    "typebotDelayMessage" integer DEFAULT 1000 NOT NULL,
    "typebotKeywordRestart" character varying(255) DEFAULT ''::character varying,
    "typebotRestartMessage" character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public."QueueIntegrations" OWNER TO whaticket;

--
-- Name: QueueIntegrations_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."QueueIntegrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."QueueIntegrations_id_seq" OWNER TO whaticket;

--
-- Name: QueueIntegrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."QueueIntegrations_id_seq" OWNED BY public."QueueIntegrations".id;


--
-- Name: QueueOptions; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."QueueOptions" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    message text,
    option text,
    "queueId" integer,
    "parentId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."QueueOptions" OWNER TO whaticket;

--
-- Name: QueueOptions_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."QueueOptions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."QueueOptions_id_seq" OWNER TO whaticket;

--
-- Name: QueueOptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."QueueOptions_id_seq" OWNED BY public."QueueOptions".id;


--
-- Name: Queues; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Queues" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    color character varying(255) NOT NULL,
    "greetingMessage" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "companyId" integer,
    schedules jsonb DEFAULT '[]'::jsonb,
    "outOfHoursMessage" text,
    "orderQueue" integer,
    "tempoRoteador" integer DEFAULT 0 NOT NULL,
    "ativarRoteador" boolean DEFAULT false NOT NULL,
    "integrationId" integer,
    "fileListId" integer,
    "closeTicket" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Queues" OWNER TO whaticket;

--
-- Name: Queues_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Queues_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Queues_id_seq" OWNER TO whaticket;

--
-- Name: Queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Queues_id_seq" OWNED BY public."Queues".id;


--
-- Name: QuickMessages; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."QuickMessages" (
    id integer NOT NULL,
    shortcode character varying(255) NOT NULL,
    message text,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "userId" integer,
    "mediaPath" character varying(255) DEFAULT NULL::character varying,
    "mediaName" character varying(255) DEFAULT NULL::character varying,
    geral boolean DEFAULT false NOT NULL,
    visao boolean DEFAULT true
);


ALTER TABLE public."QuickMessages" OWNER TO whaticket;

--
-- Name: QuickMessages_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."QuickMessages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."QuickMessages_id_seq" OWNER TO whaticket;

--
-- Name: QuickMessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."QuickMessages_id_seq" OWNED BY public."QuickMessages".id;


--
-- Name: ScheduledMessages; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."ScheduledMessages" (
    id integer NOT NULL,
    data_mensagem_programada timestamp with time zone,
    id_conexao character varying(255),
    intervalo character varying(255),
    valor_intervalo character varying(255),
    mensagem text,
    tipo_dias_envio character varying(255),
    mostrar_usuario_mensagem boolean DEFAULT false,
    criar_ticket boolean DEFAULT false,
    contatos jsonb,
    tags jsonb,
    "companyId" integer,
    nome character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "mediaPath" character varying(255),
    "mediaName" character varying(255),
    tipo_arquivo character varying(255),
    usuario_envio character varying(255),
    enviar_quantas_vezes character varying(255)
);


ALTER TABLE public."ScheduledMessages" OWNER TO whaticket;

--
-- Name: ScheduledMessagesEnvios; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."ScheduledMessagesEnvios" (
    id integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "mediaPath" character varying(255),
    "mediaName" character varying(255),
    mensagem text,
    "companyId" integer,
    data_envio timestamp with time zone,
    scheduledmessages integer,
    key character varying(255)
);


ALTER TABLE public."ScheduledMessagesEnvios" OWNER TO whaticket;

--
-- Name: ScheduledMessagesEnvios_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."ScheduledMessagesEnvios_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ScheduledMessagesEnvios_id_seq" OWNER TO whaticket;

--
-- Name: ScheduledMessagesEnvios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."ScheduledMessagesEnvios_id_seq" OWNED BY public."ScheduledMessagesEnvios".id;


--
-- Name: ScheduledMessages_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."ScheduledMessages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ScheduledMessages_id_seq" OWNER TO whaticket;

--
-- Name: ScheduledMessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."ScheduledMessages_id_seq" OWNED BY public."ScheduledMessages".id;


--
-- Name: Schedules; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Schedules" (
    id integer NOT NULL,
    body text NOT NULL,
    "sendAt" timestamp with time zone,
    "sentAt" timestamp with time zone,
    "contactId" integer,
    "ticketId" integer,
    "userId" integer,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    status character varying(255),
    "ticketUserId" integer,
    "whatsappId" integer,
    "statusTicket" character varying(255) DEFAULT 'closed'::character varying,
    "queueId" integer,
    "openTicket" character varying(255) DEFAULT 'disabled'::character varying,
    "mediaName" character varying(255) DEFAULT NULL::character varying,
    "mediaPath" character varying(255) DEFAULT NULL::character varying,
    intervalo integer DEFAULT 1,
    "valorIntervalo" integer DEFAULT 0,
    "enviarQuantasVezes" integer DEFAULT 1,
    "tipoDias" integer DEFAULT 4,
    "contadorEnvio" integer DEFAULT 0,
    assinar boolean DEFAULT false,
    "googleEventId" character varying(255)
);


ALTER TABLE public."Schedules" OWNER TO whaticket;

--
-- Name: Schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Schedules_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Schedules_id_seq" OWNER TO whaticket;

--
-- Name: Schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Schedules_id_seq" OWNED BY public."Schedules".id;


--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO whaticket;

--
-- Name: Settings; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Settings" (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "companyId" integer,
    id integer NOT NULL
);


ALTER TABLE public."Settings" OWNER TO whaticket;

--
-- Name: Settings_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Settings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Settings_id_seq" OWNER TO whaticket;

--
-- Name: Settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Settings_id_seq" OWNED BY public."Settings".id;


--
-- Name: SliderBanners; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."SliderBanners" (
    id integer NOT NULL,
    image text NOT NULL,
    url text,
    "companyId" integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now(),
    CONSTRAINT slider_company_only_one CHECK (("companyId" = 1))
);


ALTER TABLE public."SliderBanners" OWNER TO whaticket;

--
-- Name: SliderBanners_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."SliderBanners_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SliderBanners_id_seq" OWNER TO whaticket;

--
-- Name: SliderBanners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."SliderBanners_id_seq" OWNED BY public."SliderBanners".id;


--
-- Name: Subscriptions; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Subscriptions" (
    id integer NOT NULL,
    "isActive" boolean DEFAULT false,
    "expiresAt" timestamp with time zone NOT NULL,
    "userPriceCents" integer,
    "whatsPriceCents" integer,
    "lastInvoiceUrl" character varying(255),
    "lastPlanChange" timestamp with time zone,
    "companyId" integer NOT NULL,
    "providerSubscriptionId" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Subscriptions" OWNER TO whaticket;

--
-- Name: Subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Subscriptions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Subscriptions_id_seq" OWNER TO whaticket;

--
-- Name: Subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Subscriptions_id_seq" OWNED BY public."Subscriptions".id;


--
-- Name: Tags; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Tags" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    color character varying(255),
    "companyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    kanban integer,
    "timeLane" integer DEFAULT 0,
    "nextLaneId" integer,
    "greetingMessageLane" text,
    "rollbackLaneId" integer DEFAULT 0
);


ALTER TABLE public."Tags" OWNER TO whaticket;

--
-- Name: Tags_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Tags_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Tags_id_seq" OWNER TO whaticket;

--
-- Name: Tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Tags_id_seq" OWNED BY public."Tags".id;


--
-- Name: TicketNotes; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."TicketNotes" (
    id integer NOT NULL,
    note character varying(255) NOT NULL,
    "userId" integer,
    "contactId" integer NOT NULL,
    "ticketId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."TicketNotes" OWNER TO whaticket;

--
-- Name: TicketNotes_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."TicketNotes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TicketNotes_id_seq" OWNER TO whaticket;

--
-- Name: TicketNotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."TicketNotes_id_seq" OWNED BY public."TicketNotes".id;


--
-- Name: TicketTags; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."TicketTags" (
    "ticketId" integer NOT NULL,
    "tagId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."TicketTags" OWNER TO whaticket;

--
-- Name: TicketTraking; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."TicketTraking" (
    id integer NOT NULL,
    "ticketId" integer,
    "companyId" integer,
    "whatsappId" integer,
    "userId" integer,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    "queuedAt" timestamp with time zone,
    "startedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "ratingAt" timestamp with time zone,
    rated boolean DEFAULT false,
    "closedAt" timestamp with time zone,
    "chatbotAt" timestamp with time zone,
    "queueId" integer
);


ALTER TABLE public."TicketTraking" OWNER TO whaticket;

--
-- Name: TicketTraking_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."TicketTraking_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TicketTraking_id_seq" OWNER TO whaticket;

--
-- Name: TicketTraking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."TicketTraking_id_seq" OWNED BY public."TicketTraking".id;


--
-- Name: Tickets; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Tickets" (
    id integer NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    "lastMessage" text DEFAULT ''::text,
    "contactId" integer,
    "userId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "whatsappId" integer,
    "isGroup" boolean DEFAULT false NOT NULL,
    "unreadMessages" integer,
    "queueId" integer,
    "companyId" integer,
    uuid uuid,
    chatbot boolean DEFAULT false,
    "queueOptionId" integer,
    "isBot" boolean,
    channel text DEFAULT 'whatsapp'::text,
    "amountUsedBotQueues" integer,
    "fromMe" boolean DEFAULT false NOT NULL,
    "amountUsedBotQueuesNPS" integer DEFAULT 0 NOT NULL,
    "sendInactiveMessage" boolean DEFAULT false NOT NULL,
    "lgpdSendMessageAt" timestamp with time zone,
    "lgpdAcceptedAt" timestamp with time zone,
    imported timestamp with time zone,
    "flowWebhook" boolean DEFAULT false NOT NULL,
    "lastFlowId" character varying(255),
    "dataWebhook" json,
    "hashFlowId" character varying(255),
    "useIntegration" boolean DEFAULT false,
    "integrationId" integer,
    "isOutOfHour" boolean DEFAULT false,
    "flowStopped" character varying(255),
    "isActiveDemand" boolean DEFAULT false,
    "typebotSessionId" character varying(255) DEFAULT NULL::character varying,
    "typebotStatus" boolean DEFAULT false NOT NULL,
    "typebotSessionTime" timestamp with time zone,
    "productsSent" jsonb DEFAULT '[]'::jsonb NOT NULL,
    crm_lead_id bigint,
    crm_client_id bigint,
    "leadValue" numeric(10,2),
    lid character varying
);


ALTER TABLE public."Tickets" OWNER TO whaticket;

--
-- Name: Tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Tickets_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Tickets_id_seq" OWNER TO whaticket;

--
-- Name: Tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Tickets_id_seq" OWNED BY public."Tickets".id;


--
-- Name: UserDevices; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."UserDevices" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "deviceToken" text NOT NULL,
    platform character varying(10) NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT "UserDevices_platform_check" CHECK (((platform)::text = ANY (ARRAY[('ios'::character varying)::text, ('android'::character varying)::text])))
);


ALTER TABLE public."UserDevices" OWNER TO whaticket;

--
-- Name: UserDevices_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."UserDevices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserDevices_id_seq" OWNER TO whaticket;

--
-- Name: UserDevices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."UserDevices_id_seq" OWNED BY public."UserDevices".id;


--
-- Name: UserGoogleCalendarIntegrations; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."UserGoogleCalendarIntegrations" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    company_id integer NOT NULL,
    "googleUserId" character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "accessToken" text NOT NULL,
    "refreshToken" text NOT NULL,
    "expiryDate" timestamp without time zone,
    "calendarId" character varying(255) DEFAULT 'primary'::character varying NOT NULL,
    active boolean DEFAULT true,
    "syncToken" text,
    "lastSyncAt" timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserGoogleCalendarIntegrations" OWNER TO whaticket;

--
-- Name: TABLE "UserGoogleCalendarIntegrations"; Type: COMMENT; Schema: public; Owner: whaticket
--

COMMENT ON TABLE public."UserGoogleCalendarIntegrations" IS 'Tabela de integrações individuais do Google Calendar por usuário';


--
-- Name: UserGoogleCalendarIntegrations_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."UserGoogleCalendarIntegrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserGoogleCalendarIntegrations_id_seq" OWNER TO whaticket;

--
-- Name: UserGoogleCalendarIntegrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."UserGoogleCalendarIntegrations_id_seq" OWNED BY public."UserGoogleCalendarIntegrations".id;


--
-- Name: UserQueues; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."UserQueues" (
    "userId" integer NOT NULL,
    "queueId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."UserQueues" OWNER TO whaticket;

--
-- Name: UserRatings; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."UserRatings" (
    id integer NOT NULL,
    "ticketId" integer,
    "companyId" integer,
    "userId" integer,
    rate integer DEFAULT 0,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone
);


ALTER TABLE public."UserRatings" OWNER TO whaticket;

--
-- Name: UserRatings_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."UserRatings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserRatings_id_seq" OWNER TO whaticket;

--
-- Name: UserRatings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."UserRatings_id_seq" OWNED BY public."UserRatings".id;


--
-- Name: UserServices; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."UserServices" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "serviceId" integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."UserServices" OWNER TO whaticket;

--
-- Name: UserServices_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."UserServices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserServices_id_seq" OWNER TO whaticket;

--
-- Name: UserServices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."UserServices_id_seq" OWNED BY public."UserServices".id;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "passwordHash" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    profile character varying(255) DEFAULT 'admin'::character varying NOT NULL,
    "tokenVersion" integer DEFAULT 0 NOT NULL,
    "companyId" integer,
    super boolean DEFAULT false,
    online boolean DEFAULT false,
    "endWork" character varying(255) DEFAULT '23:59'::character varying,
    "startWork" character varying(255) DEFAULT '00:00'::character varying,
    color character varying(255),
    "farewellMessage" text,
    "whatsappId" integer,
    "allTicket" character varying(255) DEFAULT 'disable'::character varying NOT NULL,
    "allowGroup" boolean DEFAULT false NOT NULL,
    "defaultMenu" character varying(255) DEFAULT 'closed'::character varying NOT NULL,
    "defaultTheme" character varying(255) DEFAULT 'light'::character varying NOT NULL,
    "profileImage" character varying(255),
    "allHistoric" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "allUserChat" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "resetPassword" character varying(255),
    "userClosePendingTicket" character varying(255) DEFAULT 'enabled'::character varying NOT NULL,
    "showDashboard" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "defaultTicketsManagerWidth" integer DEFAULT 550 NOT NULL,
    "allowRealTime" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "allowConnections" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "userType" character varying(255) DEFAULT 'attendant'::character varying,
    "workDays" character varying(255) DEFAULT '1,2,3,4,5'::character varying,
    "lunchStart" character varying(255) DEFAULT NULL::character varying,
    "lunchEnd" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."Users" OWNER TO whaticket;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Users_id_seq" OWNER TO whaticket;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: Versions; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Versions" (
    id integer NOT NULL,
    "versionFrontend" text NOT NULL,
    "versionBackend" text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Versions" OWNER TO whaticket;

--
-- Name: Versions_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Versions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Versions_id_seq" OWNER TO whaticket;

--
-- Name: Versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Versions_id_seq" OWNED BY public."Versions".id;


--
-- Name: Webhooks; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Webhooks" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(255) NOT NULL,
    hash_id character varying(255) NOT NULL,
    config json,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    active boolean DEFAULT false,
    "requestMonth" integer DEFAULT 0,
    "requestAll" integer DEFAULT 0,
    company_id integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."Webhooks" OWNER TO whaticket;

--
-- Name: Webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Webhooks_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Webhooks_id_seq" OWNER TO whaticket;

--
-- Name: Webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Webhooks_id_seq" OWNED BY public."Webhooks".id;


--
-- Name: WhatsappQueues; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."WhatsappQueues" (
    "whatsappId" integer NOT NULL,
    "queueId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."WhatsappQueues" OWNER TO whaticket;

--
-- Name: Whatsapps; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public."Whatsapps" (
    id integer NOT NULL,
    session text,
    qrcode text,
    status character varying(255),
    battery character varying(255),
    plugged boolean,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    retries integer DEFAULT 0 NOT NULL,
    "greetingMessage" text,
    "companyId" integer,
    "complationMessage" text,
    "outOfHoursMessage" text,
    token text,
    "farewellMessage" text,
    provider text DEFAULT 'stable'::text,
    number text,
    channel text,
    "facebookUserToken" text,
    "tokenMeta" text,
    "facebookPageUserId" text,
    "facebookUserId" text,
    "maxUseBotQueues" integer,
    "expiresTicket" integer DEFAULT 0,
    "allowGroup" boolean DEFAULT false NOT NULL,
    "timeUseBotQueues" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "timeSendQueue" integer,
    "sendIdQueue" integer,
    "expiresInactiveMessage" text,
    "maxUseBotQueuesNPS" integer DEFAULT 0,
    "inactiveMessage" character varying(255) DEFAULT ''::character varying,
    "whenExpiresTicket" character varying(255) DEFAULT ''::character varying,
    "expiresTicketNPS" character varying(255) DEFAULT ''::character varying,
    "timeInactiveMessage" character varying(255) DEFAULT ''::character varying,
    "ratingMessage" text,
    "groupAsTicket" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "importOldMessages" text,
    "importRecentMessages" text,
    "statusImportMessages" character varying(255),
    "closedTicketsPostImported" boolean,
    "importOldMessagesGroups" boolean,
    "timeCreateNewTicket" integer,
    "greetingMediaAttachment" character varying(255) DEFAULT NULL::character varying,
    "promptId" integer,
    "integrationId" integer,
    schedules jsonb DEFAULT '[]'::jsonb,
    "collectiveVacationEnd" character varying(255) DEFAULT NULL::character varying,
    "collectiveVacationStart" character varying(255) DEFAULT NULL::character varying,
    "collectiveVacationMessage" text,
    "queueIdImportMessages" integer,
    "flowIdNotPhrase" integer,
    "flowIdWelcome" integer,
    wavoip text,
    "notificameHub" boolean DEFAULT false NOT NULL,
    "coexistencePhoneNumberId" text,
    "coexistenceWabaId" text,
    "coexistencePermanentToken" text,
    "coexistenceEnabled" boolean DEFAULT false NOT NULL,
    "businessAppConnected" boolean DEFAULT false NOT NULL,
    "messageRoutingMode" character varying(255) DEFAULT 'automatic'::character varying NOT NULL,
    "routingRules" jsonb,
    "lastCoexistenceSync" timestamp without time zone
);


ALTER TABLE public."Whatsapps" OWNER TO whaticket;

--
-- Name: Whatsapps_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public."Whatsapps_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Whatsapps_id_seq" OWNER TO whaticket;

--
-- Name: Whatsapps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public."Whatsapps_id_seq" OWNED BY public."Whatsapps".id;


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    start_datetime timestamp without time zone NOT NULL,
    duration_minutes integer DEFAULT 60,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    schedule_id integer NOT NULL,
    service_id integer,
    client_id integer,
    contact_id integer,
    company_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    google_event_id character varying(255)
);


ALTER TABLE public.appointments OWNER TO whaticket;

--
-- Name: COLUMN appointments.google_event_id; Type: COMMENT; Schema: public; Owner: whaticket
--

COMMENT ON COLUMN public.appointments.google_event_id IS 'ID do evento correspondente no Google Calendar';


--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_id_seq OWNER TO whaticket;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: company_api_keys; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.company_api_keys (
    id integer NOT NULL,
    company_id integer NOT NULL,
    label character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    webhook_url character varying(255),
    webhook_secret character varying(255),
    active boolean DEFAULT true NOT NULL,
    last_used_at timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.company_api_keys OWNER TO whaticket;

--
-- Name: company_api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.company_api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.company_api_keys_id_seq OWNER TO whaticket;

--
-- Name: company_api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.company_api_keys_id_seq OWNED BY public.company_api_keys.id;


--
-- Name: company_integration_field_maps; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.company_integration_field_maps (
    id integer NOT NULL,
    integration_id integer NOT NULL,
    external_field character varying(255) NOT NULL,
    crm_field character varying(255),
    transform_expression text,
    options jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.company_integration_field_maps OWNER TO whaticket;

--
-- Name: company_integration_field_maps_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.company_integration_field_maps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.company_integration_field_maps_id_seq OWNER TO whaticket;

--
-- Name: company_integration_field_maps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.company_integration_field_maps_id_seq OWNED BY public.company_integration_field_maps.id;


--
-- Name: company_integration_settings; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.company_integration_settings (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name character varying(255) NOT NULL,
    provider character varying(255),
    base_url character varying(255),
    api_key text,
    api_secret text,
    webhook_secret text,
    metadata jsonb,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.company_integration_settings OWNER TO whaticket;

--
-- Name: company_integration_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.company_integration_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.company_integration_settings_id_seq OWNER TO whaticket;

--
-- Name: company_integration_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.company_integration_settings_id_seq OWNED BY public.company_integration_settings.id;


--
-- Name: company_payment_settings; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.company_payment_settings (
    id integer NOT NULL,
    company_id integer NOT NULL,
    provider character varying(255) NOT NULL,
    token text NOT NULL,
    additional_data jsonb,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.company_payment_settings OWNER TO whaticket;

--
-- Name: company_payment_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.company_payment_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.company_payment_settings_id_seq OWNER TO whaticket;

--
-- Name: company_payment_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.company_payment_settings_id_seq OWNED BY public.company_payment_settings.id;


--
-- Name: crm_client_contacts; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.crm_client_contacts (
    id bigint NOT NULL,
    client_id bigint NOT NULL,
    contact_id bigint NOT NULL,
    role character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.crm_client_contacts OWNER TO whaticket;

--
-- Name: crm_client_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.crm_client_contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.crm_client_contacts_id_seq OWNER TO whaticket;

--
-- Name: crm_client_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.crm_client_contacts_id_seq OWNED BY public.crm_client_contacts.id;


--
-- Name: crm_clients; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.crm_clients (
    id bigint NOT NULL,
    company_id bigint NOT NULL,
    type character varying(20) DEFAULT 'pf'::character varying NOT NULL,
    name character varying(150) NOT NULL,
    company_name character varying(150),
    document character varying(30),
    birth_date date,
    email character varying(150),
    phone character varying(30),
    zip_code character varying(15),
    address character varying(150),
    number character varying(20),
    complement character varying(100),
    neighborhood character varying(100),
    city character varying(100),
    state character varying(2),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    client_since date,
    owner_user_id bigint,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    contact_id bigint,
    primary_ticket_id bigint,
    asaas_customer_id character varying(255),
    lid character varying
);


ALTER TABLE public.crm_clients OWNER TO whaticket;

--
-- Name: crm_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.crm_clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.crm_clients_id_seq OWNER TO whaticket;

--
-- Name: crm_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.crm_clients_id_seq OWNED BY public.crm_clients.id;


--
-- Name: crm_leads; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.crm_leads (
    id bigint NOT NULL,
    company_id bigint NOT NULL,
    name character varying(150) NOT NULL,
    email character varying(150),
    phone character varying(30),
    birth_date date,
    document character varying(30),
    company_name character varying(150),
    "position" character varying(100),
    source character varying(60),
    campaign character varying(100),
    medium character varying(50),
    status character varying(30) DEFAULT 'new'::character varying NOT NULL,
    score integer DEFAULT 0,
    temperature character varying(20),
    owner_user_id bigint,
    notes text,
    last_activity_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    contact_id bigint,
    primary_ticket_id bigint,
    converted_client_id bigint,
    converted_at timestamp with time zone,
    lead_status character varying(32) DEFAULT 'novo'::character varying,
    lid character varying(255)
);


ALTER TABLE public.crm_leads OWNER TO whaticket;

--
-- Name: crm_leads_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.crm_leads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.crm_leads_id_seq OWNER TO whaticket;

--
-- Name: crm_leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.crm_leads_id_seq OWNED BY public.crm_leads.id;


--
-- Name: financeiro_faturas; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.financeiro_faturas (
    id bigint NOT NULL,
    company_id bigint NOT NULL,
    client_id bigint NOT NULL,
    descricao character varying(255) NOT NULL,
    valor numeric(14,2) NOT NULL,
    status character varying(20) DEFAULT 'aberta'::character varying NOT NULL,
    data_vencimento date NOT NULL,
    data_pagamento timestamp with time zone,
    tipo_referencia character varying(20),
    referencia_id bigint,
    tipo_recorrencia character varying(20) DEFAULT 'unica'::character varying NOT NULL,
    quantidade_ciclos integer,
    ciclo_atual integer DEFAULT 1 NOT NULL,
    data_inicio date DEFAULT CURRENT_DATE NOT NULL,
    data_fim date,
    ativa boolean DEFAULT true NOT NULL,
    observacoes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    valor_pago numeric(14,2) DEFAULT 0 NOT NULL,
    payment_provider character varying(255),
    payment_link text,
    payment_external_id character varying(255),
    checkout_token character varying(64),
    project_id integer,
    CONSTRAINT chk_financeiro_faturas_referencia CHECK ((((tipo_referencia IS NULL) AND (referencia_id IS NULL)) OR ((tipo_referencia IS NOT NULL) AND (referencia_id IS NOT NULL)))),
    CONSTRAINT chk_recorrencia CHECK ((((tipo_recorrencia)::text = 'unica'::text) OR (((tipo_recorrencia)::text = ANY (ARRAY[('mensal'::character varying)::text, ('anual'::character varying)::text])) AND (data_inicio IS NOT NULL)))),
    CONSTRAINT chk_referencia_opcional CHECK ((((tipo_referencia IS NULL) AND (referencia_id IS NULL)) OR ((tipo_referencia IS NOT NULL) AND (referencia_id IS NOT NULL))))
);


ALTER TABLE public.financeiro_faturas OWNER TO whaticket;

--
-- Name: financeiro_faturas_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.financeiro_faturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.financeiro_faturas_id_seq OWNER TO whaticket;

--
-- Name: financeiro_faturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.financeiro_faturas_id_seq OWNED BY public.financeiro_faturas.id;


--
-- Name: financeiro_pagamentos; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.financeiro_pagamentos (
    id bigint NOT NULL,
    company_id bigint NOT NULL,
    fatura_id bigint NOT NULL,
    metodo_pagamento character varying(20) NOT NULL,
    valor numeric(14,2) NOT NULL,
    data_pagamento timestamp without time zone DEFAULT now() NOT NULL,
    observacoes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.financeiro_pagamentos OWNER TO whaticket;

--
-- Name: financeiro_pagamentos_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.financeiro_pagamentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.financeiro_pagamentos_id_seq OWNER TO whaticket;

--
-- Name: financeiro_pagamentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.financeiro_pagamentos_id_seq OWNED BY public.financeiro_pagamentos.id;


--
-- Name: media_files; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.media_files (
    id integer NOT NULL,
    folder_id integer NOT NULL,
    company_id integer NOT NULL,
    original_name character varying(255) NOT NULL,
    custom_name character varying(255),
    mime_type character varying(255) NOT NULL,
    size bigint NOT NULL,
    storage_path text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.media_files OWNER TO whaticket;

--
-- Name: media_files_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.media_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_files_id_seq OWNER TO whaticket;

--
-- Name: media_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.media_files_id_seq OWNED BY public.media_files.id;


--
-- Name: media_folders; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.media_folders (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    company_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.media_folders OWNER TO whaticket;

--
-- Name: media_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.media_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_folders_id_seq OWNER TO whaticket;

--
-- Name: media_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.media_folders_id_seq OWNED BY public.media_folders.id;


--
-- Name: profissionais; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.profissionais (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    nome character varying(255) NOT NULL,
    servicos jsonb DEFAULT '[]'::jsonb NOT NULL,
    agenda jsonb DEFAULT '{}'::jsonb NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    comissao numeric(10,2) DEFAULT 0 NOT NULL,
    "valorEmAberto" numeric(12,2) DEFAULT 0 NOT NULL,
    "valoresRecebidos" numeric(12,2) DEFAULT 0 NOT NULL,
    "valoresAReceber" numeric(12,2) DEFAULT 0 NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.profissionais OWNER TO whaticket;

--
-- Name: profissionais_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.profissionais_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.profissionais_id_seq OWNER TO whaticket;

--
-- Name: profissionais_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.profissionais_id_seq OWNED BY public.profissionais.id;


--
-- Name: project_products; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.project_products (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "projectId" integer NOT NULL,
    "productId" integer NOT NULL,
    quantity integer DEFAULT 1,
    "unitPrice" numeric(10,2),
    notes text,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_products OWNER TO whaticket;

--
-- Name: project_products_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.project_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.project_products_id_seq OWNER TO whaticket;

--
-- Name: project_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.project_products_id_seq OWNED BY public.project_products.id;


--
-- Name: project_services; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.project_services (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "projectId" integer NOT NULL,
    "serviceId" integer NOT NULL,
    quantity integer DEFAULT 1,
    "unitPrice" numeric(10,2),
    notes text,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_services OWNER TO whaticket;

--
-- Name: project_services_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.project_services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.project_services_id_seq OWNER TO whaticket;

--
-- Name: project_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.project_services_id_seq OWNED BY public.project_services.id;


--
-- Name: project_task_users; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.project_task_users (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "taskId" integer NOT NULL,
    "userId" integer NOT NULL,
    responsibility character varying(255),
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_task_users OWNER TO whaticket;

--
-- Name: project_task_users_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.project_task_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.project_task_users_id_seq OWNER TO whaticket;

--
-- Name: project_task_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.project_task_users_id_seq OWNED BY public.project_task_users.id;


--
-- Name: project_tasks; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.project_tasks (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "projectId" integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'pending'::character varying,
    "order" integer DEFAULT 0,
    "startDate" timestamp with time zone,
    "dueDate" timestamp with time zone,
    "completedAt" timestamp with time zone,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_tasks OWNER TO whaticket;

--
-- Name: project_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.project_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.project_tasks_id_seq OWNER TO whaticket;

--
-- Name: project_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.project_tasks_id_seq OWNED BY public.project_tasks.id;


--
-- Name: project_users; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.project_users (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "projectId" integer NOT NULL,
    "userId" integer NOT NULL,
    role character varying(100),
    "effortAllocation" integer,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_users OWNER TO whaticket;

--
-- Name: project_users_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.project_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.project_users_id_seq OWNER TO whaticket;

--
-- Name: project_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.project_users_id_seq OWNED BY public.project_users.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "clientId" integer,
    "invoiceId" integer,
    name character varying(255) NOT NULL,
    description text,
    "deliveryTime" timestamp with time zone,
    warranty text,
    terms text,
    status character varying(50) DEFAULT 'draft'::character varying,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.projects OWNER TO whaticket;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projects_id_seq OWNER TO whaticket;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: scheduled_dispatch_logs; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.scheduled_dispatch_logs (
    id integer NOT NULL,
    dispatcher_id integer NOT NULL,
    contact_id integer,
    ticket_id integer,
    company_id integer NOT NULL,
    status character varying(32) NOT NULL,
    error_message text,
    sent_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scheduled_dispatch_logs OWNER TO whaticket;

--
-- Name: scheduled_dispatch_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.scheduled_dispatch_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scheduled_dispatch_logs_id_seq OWNER TO whaticket;

--
-- Name: scheduled_dispatch_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.scheduled_dispatch_logs_id_seq OWNED BY public.scheduled_dispatch_logs.id;


--
-- Name: scheduled_dispatchers; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.scheduled_dispatchers (
    id integer NOT NULL,
    company_id integer NOT NULL,
    title character varying(255) NOT NULL,
    message_template text NOT NULL,
    event_type character varying(32) NOT NULL,
    whatsapp_id integer,
    start_time character(5) DEFAULT '08:00'::bpchar NOT NULL,
    send_interval_seconds integer DEFAULT 30 NOT NULL,
    days_before_due integer,
    days_after_due integer,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scheduled_dispatchers OWNER TO whaticket;

--
-- Name: scheduled_dispatchers_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.scheduled_dispatchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scheduled_dispatchers_id_seq OWNER TO whaticket;

--
-- Name: scheduled_dispatchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.scheduled_dispatchers_id_seq OWNED BY public.scheduled_dispatchers.id;


--
-- Name: servicos; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.servicos (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    nome character varying(255) NOT NULL,
    descricao text,
    "valorOriginal" numeric(10,2) DEFAULT 0 NOT NULL,
    "possuiDesconto" boolean DEFAULT false NOT NULL,
    "valorComDesconto" numeric(10,2),
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.servicos OWNER TO whaticket;

--
-- Name: servicos_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.servicos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.servicos_id_seq OWNER TO whaticket;

--
-- Name: servicos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.servicos_id_seq OWNED BY public.servicos.id;


--
-- Name: slider_home; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.slider_home (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    image text NOT NULL,
    "companyId" integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT slider_home_company_only_one CHECK (("companyId" = 1))
);


ALTER TABLE public.slider_home OWNER TO whaticket;

--
-- Name: slider_home_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.slider_home_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.slider_home_id_seq OWNER TO whaticket;

--
-- Name: slider_home_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.slider_home_id_seq OWNED BY public.slider_home.id;


--
-- Name: tutorial_videos; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.tutorial_videos (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    video_url character varying(500) NOT NULL,
    thumbnail_url character varying(500),
    company_id integer NOT NULL,
    user_id integer NOT NULL,
    is_active boolean DEFAULT true,
    views_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tutorial_videos_description_check CHECK ((char_length(description) <= 300))
);


ALTER TABLE public.tutorial_videos OWNER TO whaticket;

--
-- Name: tutorial_videos_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.tutorial_videos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tutorial_videos_id_seq OWNER TO whaticket;

--
-- Name: tutorial_videos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.tutorial_videos_id_seq OWNED BY public.tutorial_videos.id;


--
-- Name: user_schedules; Type: TABLE; Schema: public; Owner: whaticket
--

CREATE TABLE public.user_schedules (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    active boolean DEFAULT true,
    user_id integer NOT NULL,
    company_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    user_google_calendar_integration_id integer
);


ALTER TABLE public.user_schedules OWNER TO whaticket;

--
-- Name: COLUMN user_schedules.user_google_calendar_integration_id; Type: COMMENT; Schema: public; Owner: whaticket
--

COMMENT ON COLUMN public.user_schedules.user_google_calendar_integration_id IS 'ID da integração Google Calendar vinculada a esta agenda';


--
-- Name: user_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: whaticket
--

CREATE SEQUENCE public.user_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_schedules_id_seq OWNER TO whaticket;

--
-- Name: user_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: whaticket
--

ALTER SEQUENCE public.user_schedules_id_seq OWNED BY public.user_schedules.id;


--
-- Name: Announcements id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Announcements" ALTER COLUMN id SET DEFAULT nextval('public."Announcements_id_seq"'::regclass);


--
-- Name: ApiUsages id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ApiUsages" ALTER COLUMN id SET DEFAULT nextval('public."ApiUsages_id_seq"'::regclass);


--
-- Name: AutomationActions id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationActions" ALTER COLUMN id SET DEFAULT nextval('public."AutomationActions_id_seq"'::regclass);


--
-- Name: AutomationExecutions id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationExecutions" ALTER COLUMN id SET DEFAULT nextval('public."AutomationExecutions_id_seq"'::regclass);


--
-- Name: AutomationLogs id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationLogs" ALTER COLUMN id SET DEFAULT nextval('public."AutomationLogs_id_seq"'::regclass);


--
-- Name: Automations id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Automations" ALTER COLUMN id SET DEFAULT nextval('public."Automations_id_seq"'::regclass);


--
-- Name: Baileys id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Baileys" ALTER COLUMN id SET DEFAULT nextval('public."Baileys_id_seq"'::regclass);


--
-- Name: CampaignSettings id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."CampaignSettings" ALTER COLUMN id SET DEFAULT nextval('public."CampaignSettings_id_seq"'::regclass);


--
-- Name: CampaignShipping id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."CampaignShipping" ALTER COLUMN id SET DEFAULT nextval('public."CampaignShipping_id_seq"'::regclass);


--
-- Name: Campaigns id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Campaigns" ALTER COLUMN id SET DEFAULT nextval('public."Campaigns_id_seq"'::regclass);


--
-- Name: ChatMessages id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ChatMessages" ALTER COLUMN id SET DEFAULT nextval('public."ChatMessages_id_seq"'::regclass);


--
-- Name: ChatUsers id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ChatUsers" ALTER COLUMN id SET DEFAULT nextval('public."ChatUsers_id_seq"'::regclass);


--
-- Name: Chatbots id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chatbots" ALTER COLUMN id SET DEFAULT nextval('public."Chatbots_id_seq"'::regclass);


--
-- Name: Chats id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chats" ALTER COLUMN id SET DEFAULT nextval('public."Chats_id_seq"'::regclass);


--
-- Name: Companies id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Companies" ALTER COLUMN id SET DEFAULT nextval('public."Companies_id_seq"'::regclass);


--
-- Name: CompaniesSettings id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."CompaniesSettings" ALTER COLUMN id SET DEFAULT nextval('public."CompaniesSettings_id_seq"'::regclass);


--
-- Name: ContactCustomFields id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactCustomFields" ALTER COLUMN id SET DEFAULT nextval('public."ContactCustomFields_id_seq"'::regclass);


--
-- Name: ContactGroups id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactGroups" ALTER COLUMN id SET DEFAULT nextval('public."ContactGroups_id_seq"'::regclass);


--
-- Name: ContactListItems id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactListItems" ALTER COLUMN id SET DEFAULT nextval('public."ContactListItems_id_seq"'::regclass);


--
-- Name: ContactLists id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactLists" ALTER COLUMN id SET DEFAULT nextval('public."ContactLists_id_seq"'::regclass);


--
-- Name: ContactWallets id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactWallets" ALTER COLUMN id SET DEFAULT nextval('public."ContactWallets_id_seq"'::regclass);


--
-- Name: Contacts id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Contacts" ALTER COLUMN id SET DEFAULT nextval('public."Contacts_id_seq"'::regclass);


--
-- Name: DialogChatBots id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."DialogChatBots" ALTER COLUMN id SET DEFAULT nextval('public."DialogChatBots_id_seq"'::regclass);


--
-- Name: Faturas id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Faturas" ALTER COLUMN id SET DEFAULT nextval('public."Faturas_id_seq"'::regclass);


--
-- Name: Ferramentas id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Ferramentas" ALTER COLUMN id SET DEFAULT nextval('public."Ferramentas_id_seq"'::regclass);


--
-- Name: Files id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Files" ALTER COLUMN id SET DEFAULT nextval('public."Files_id_seq"'::regclass);


--
-- Name: FilesOptions id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FilesOptions" ALTER COLUMN id SET DEFAULT nextval('public."FilesOptions_id_seq"'::regclass);


--
-- Name: FlowAudios id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FlowAudios" ALTER COLUMN id SET DEFAULT nextval('public."FlowAudios_id_seq"'::regclass);


--
-- Name: FlowBuilders id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FlowBuilders" ALTER COLUMN id SET DEFAULT nextval('public."FlowBuilders_id_seq"'::regclass);


--
-- Name: FlowCampaigns id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FlowCampaigns" ALTER COLUMN id SET DEFAULT nextval('public."FlowCampaigns_id_seq"'::regclass);


--
-- Name: FlowDefaults id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FlowDefaults" ALTER COLUMN id SET DEFAULT nextval('public."FlowDefaults_id_seq"'::regclass);


--
-- Name: FlowImgs id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FlowImgs" ALTER COLUMN id SET DEFAULT nextval('public."FlowImgs_id_seq"'::regclass);


--
-- Name: GoogleCalendarIntegrations id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."GoogleCalendarIntegrations" ALTER COLUMN id SET DEFAULT nextval('public."GoogleCalendarIntegrations_id_seq"'::regclass);


--
-- Name: GoogleSheetsTokens id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."GoogleSheetsTokens" ALTER COLUMN id SET DEFAULT nextval('public."GoogleSheetsTokens_id_seq"'::regclass);


--
-- Name: Helps id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Helps" ALTER COLUMN id SET DEFAULT nextval('public."Helps_id_seq"'::regclass);


--
-- Name: IaWorkflows id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."IaWorkflows" ALTER COLUMN id SET DEFAULT nextval('public."IaWorkflows_id_seq"'::regclass);


--
-- Name: Integrations id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Integrations" ALTER COLUMN id SET DEFAULT nextval('public."Integrations_id_seq"'::regclass);


--
-- Name: Invoices id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Invoices" ALTER COLUMN id SET DEFAULT nextval('public."Invoices_id_seq"'::regclass);


--
-- Name: LogTickets id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."LogTickets" ALTER COLUMN id SET DEFAULT nextval('public."LogTickets_id_seq"'::regclass);


--
-- Name: MediaFiles id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."MediaFiles" ALTER COLUMN id SET DEFAULT nextval('public."MediaFiles_id_seq"'::regclass);


--
-- Name: MediaFolders id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."MediaFolders" ALTER COLUMN id SET DEFAULT nextval('public."MediaFolders_id_seq"'::regclass);


--
-- Name: Messages id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Messages" ALTER COLUMN id SET DEFAULT nextval('public."Messages_id_seq"'::regclass);


--
-- Name: MobileWebhooks id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."MobileWebhooks" ALTER COLUMN id SET DEFAULT nextval('public."MobileWebhooks_id_seq"'::regclass);


--
-- Name: Negocios id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Negocios" ALTER COLUMN id SET DEFAULT nextval('public."Negocios_id_seq"'::regclass);


--
-- Name: Partners id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Partners" ALTER COLUMN id SET DEFAULT nextval('public."Partners_id_seq"'::regclass);


--
-- Name: Plans id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Plans" ALTER COLUMN id SET DEFAULT nextval('public."Plans_id_seq"'::regclass);


--
-- Name: Produtos id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Produtos" ALTER COLUMN id SET DEFAULT nextval('public."Produtos_id_seq"'::regclass);


--
-- Name: PromptToolSettings id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."PromptToolSettings" ALTER COLUMN id SET DEFAULT nextval('public."PromptToolSettings_id_seq"'::regclass);


--
-- Name: Prompts id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Prompts" ALTER COLUMN id SET DEFAULT nextval('public."Prompts_id_seq"'::regclass);


--
-- Name: QueueIntegrations id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QueueIntegrations" ALTER COLUMN id SET DEFAULT nextval('public."QueueIntegrations_id_seq"'::regclass);


--
-- Name: QueueOptions id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QueueOptions" ALTER COLUMN id SET DEFAULT nextval('public."QueueOptions_id_seq"'::regclass);


--
-- Name: Queues id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Queues" ALTER COLUMN id SET DEFAULT nextval('public."Queues_id_seq"'::regclass);


--
-- Name: QuickMessages id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QuickMessages" ALTER COLUMN id SET DEFAULT nextval('public."QuickMessages_id_seq"'::regclass);


--
-- Name: ScheduledMessages id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ScheduledMessages" ALTER COLUMN id SET DEFAULT nextval('public."ScheduledMessages_id_seq"'::regclass);


--
-- Name: ScheduledMessagesEnvios id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ScheduledMessagesEnvios" ALTER COLUMN id SET DEFAULT nextval('public."ScheduledMessagesEnvios_id_seq"'::regclass);


--
-- Name: Schedules id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Schedules" ALTER COLUMN id SET DEFAULT nextval('public."Schedules_id_seq"'::regclass);


--
-- Name: Settings id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Settings" ALTER COLUMN id SET DEFAULT nextval('public."Settings_id_seq"'::regclass);


--
-- Name: SliderBanners id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."SliderBanners" ALTER COLUMN id SET DEFAULT nextval('public."SliderBanners_id_seq"'::regclass);


--
-- Name: Subscriptions id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Subscriptions" ALTER COLUMN id SET DEFAULT nextval('public."Subscriptions_id_seq"'::regclass);


--
-- Name: Tags id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tags" ALTER COLUMN id SET DEFAULT nextval('public."Tags_id_seq"'::regclass);


--
-- Name: TicketNotes id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketNotes" ALTER COLUMN id SET DEFAULT nextval('public."TicketNotes_id_seq"'::regclass);


--
-- Name: TicketTraking id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketTraking" ALTER COLUMN id SET DEFAULT nextval('public."TicketTraking_id_seq"'::regclass);


--
-- Name: Tickets id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets" ALTER COLUMN id SET DEFAULT nextval('public."Tickets_id_seq"'::regclass);


--
-- Name: UserDevices id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserDevices" ALTER COLUMN id SET DEFAULT nextval('public."UserDevices_id_seq"'::regclass);


--
-- Name: UserGoogleCalendarIntegrations id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserGoogleCalendarIntegrations" ALTER COLUMN id SET DEFAULT nextval('public."UserGoogleCalendarIntegrations_id_seq"'::regclass);


--
-- Name: UserRatings id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserRatings" ALTER COLUMN id SET DEFAULT nextval('public."UserRatings_id_seq"'::regclass);


--
-- Name: UserServices id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserServices" ALTER COLUMN id SET DEFAULT nextval('public."UserServices_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Name: Versions id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Versions" ALTER COLUMN id SET DEFAULT nextval('public."Versions_id_seq"'::regclass);


--
-- Name: Webhooks id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Webhooks" ALTER COLUMN id SET DEFAULT nextval('public."Webhooks_id_seq"'::regclass);


--
-- Name: Whatsapps id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Whatsapps" ALTER COLUMN id SET DEFAULT nextval('public."Whatsapps_id_seq"'::regclass);


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: company_api_keys id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_api_keys ALTER COLUMN id SET DEFAULT nextval('public.company_api_keys_id_seq'::regclass);


--
-- Name: company_integration_field_maps id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_integration_field_maps ALTER COLUMN id SET DEFAULT nextval('public.company_integration_field_maps_id_seq'::regclass);


--
-- Name: company_integration_settings id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_integration_settings ALTER COLUMN id SET DEFAULT nextval('public.company_integration_settings_id_seq'::regclass);


--
-- Name: company_payment_settings id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_payment_settings ALTER COLUMN id SET DEFAULT nextval('public.company_payment_settings_id_seq'::regclass);


--
-- Name: crm_client_contacts id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_client_contacts ALTER COLUMN id SET DEFAULT nextval('public.crm_client_contacts_id_seq'::regclass);


--
-- Name: crm_clients id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_clients ALTER COLUMN id SET DEFAULT nextval('public.crm_clients_id_seq'::regclass);


--
-- Name: crm_leads id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_leads ALTER COLUMN id SET DEFAULT nextval('public.crm_leads_id_seq'::regclass);


--
-- Name: financeiro_faturas id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.financeiro_faturas ALTER COLUMN id SET DEFAULT nextval('public.financeiro_faturas_id_seq'::regclass);


--
-- Name: financeiro_pagamentos id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.financeiro_pagamentos ALTER COLUMN id SET DEFAULT nextval('public.financeiro_pagamentos_id_seq'::regclass);


--
-- Name: media_files id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.media_files ALTER COLUMN id SET DEFAULT nextval('public.media_files_id_seq'::regclass);


--
-- Name: media_folders id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.media_folders ALTER COLUMN id SET DEFAULT nextval('public.media_folders_id_seq'::regclass);


--
-- Name: profissionais id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.profissionais ALTER COLUMN id SET DEFAULT nextval('public.profissionais_id_seq'::regclass);


--
-- Name: project_products id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_products ALTER COLUMN id SET DEFAULT nextval('public.project_products_id_seq'::regclass);


--
-- Name: project_services id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_services ALTER COLUMN id SET DEFAULT nextval('public.project_services_id_seq'::regclass);


--
-- Name: project_task_users id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_task_users ALTER COLUMN id SET DEFAULT nextval('public.project_task_users_id_seq'::regclass);


--
-- Name: project_tasks id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_tasks ALTER COLUMN id SET DEFAULT nextval('public.project_tasks_id_seq'::regclass);


--
-- Name: project_users id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_users ALTER COLUMN id SET DEFAULT nextval('public.project_users_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: scheduled_dispatch_logs id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.scheduled_dispatch_logs ALTER COLUMN id SET DEFAULT nextval('public.scheduled_dispatch_logs_id_seq'::regclass);


--
-- Name: scheduled_dispatchers id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.scheduled_dispatchers ALTER COLUMN id SET DEFAULT nextval('public.scheduled_dispatchers_id_seq'::regclass);


--
-- Name: servicos id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.servicos ALTER COLUMN id SET DEFAULT nextval('public.servicos_id_seq'::regclass);


--
-- Name: slider_home id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.slider_home ALTER COLUMN id SET DEFAULT nextval('public.slider_home_id_seq'::regclass);


--
-- Name: tutorial_videos id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.tutorial_videos ALTER COLUMN id SET DEFAULT nextval('public.tutorial_videos_id_seq'::regclass);


--
-- Name: user_schedules id; Type: DEFAULT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.user_schedules ALTER COLUMN id SET DEFAULT nextval('public.user_schedules_id_seq'::regclass);


--
-- Data for Name: Announcements; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Announcements" (id, priority, title, text, "mediaPath", "mediaName", "companyId", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ApiUsages; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."ApiUsages" (id, "companyId", "dateUsed", "UsedOnDay", "usedText", "usedPDF", "usedImage", "usedVideo", "usedOther", "usedCheckNumber", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AutomationActions; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."AutomationActions" (id, "automationId", "actionType", "actionConfig", "order", "delayMinutes", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AutomationExecutions; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."AutomationExecutions" (id, "automationId", "automationActionId", "contactId", "ticketId", "scheduledAt", status, attempts, "lastAttemptAt", "completedAt", error, metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AutomationLogs; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."AutomationLogs" (id, "automationId", "contactId", "ticketId", status, "executedAt", result, error, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Automations; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Automations" (id, "companyId", name, description, "triggerType", "triggerConfig", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Baileys; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Baileys" (id, "whatsappId", contacts, chats, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignSettings; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."CampaignSettings" (id, key, value, "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignShipping; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."CampaignShipping" (id, "jobId", number, message, "confirmationMessage", confirmation, "contactId", "campaignId", "confirmationRequestedAt", "confirmedAt", "deliveredAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Campaigns; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Campaigns" (id, name, message1, message2, message3, message4, message5, "confirmationMessage1", "confirmationMessage2", "confirmationMessage3", "confirmationMessage4", "confirmationMessage5", status, confirmation, "mediaPath", "mediaName", "companyId", "contactListId", "whatsappId", "scheduledAt", "completedAt", "createdAt", "updatedAt", "userId", "queueId", "statusTicket", "openTicket") FROM stdin;
\.


--
-- Data for Name: ChatMessages; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."ChatMessages" (id, "chatId", "senderId", message, "mediaPath", "mediaName", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ChatUsers; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."ChatUsers" (id, "chatId", "userId", unreads, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Chatbots; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Chatbots" (id, name, "queueId", "chatbotId", "greetingMessage", "createdAt", "updatedAt", "isAgent", "optQueueId", "optUserId", "queueType", "optIntegrationId", "optFileId", "closeTicket") FROM stdin;
\.


--
-- Data for Name: Chats; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Chats" (id, title, uuid, "ownerId", "lastMessage", "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Companies; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Companies" (id, name, phone, email, "createdAt", "updatedAt", "planId", status, schedules, "dueDate", recurrence, document, "paymentMethod", "lastLogin", "folderSize", "numberFileFolder", "updatedAtFolder", type, segment, "loadingImage") FROM stdin;
1	empresa	50499999999	admin@admin.com	2026-02-08 22:16:01.019-06	2026-02-20 18:31:56.422-06	1	t	[]	2099-12-31 00:00:00-06	MENSAL	52998224725		2026-02-20 18:31:56.422-06	\N	\N	\N	pf	outros	\N
\.


--
-- Data for Name: CompaniesSettings; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."CompaniesSettings" (id, "companyId", "hoursCloseTicketsAuto", "chatBotType", "acceptCallWhatsapp", "userRandom", "sendGreetingMessageOneQueues", "sendSignMessage", "sendFarewellWaitingTicket", "userRating", "sendGreetingAccepted", "CheckMsgIsGroup", "sendQueuePosition", "scheduleType", "acceptAudioMessageContact", "enableLGPD", "sendMsgTransfTicket", "requiredTag", "lgpdDeleteMessage", "lgpdHideNumber", "lgpdConsent", "lgpdLink", "lgpdMessage", "createdAt", "updatedAt", "DirectTicketsToWallets", "closeTicketOnTransfer", "greetingAcceptedMessage", "AcceptCallWhatsappMessage", "sendQueuePositionMessage", "transferMessage", "showNotificationPending", "notificameHub", "autoSaveContacts", "autoSaveContactsScore", "autoSaveContactsReason") FROM stdin;
105	1	9999999999	text	enabled	enabled	enabled	enabled	enabled	enabled	enabled	enabled	enabled	disabled	enabled	enabled	disabled	enabled	disabled	disabled	disabled			2026-02-08 22:16:01.065-06	2026-02-08 22:16:01.066-06	f	t					t	\N	disabled	7	high_potential
\.


--
-- Data for Name: ContactCustomFields; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."ContactCustomFields" (id, name, value, "contactId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ContactGroups; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."ContactGroups" (id, "createdAt", "updatedAt", "contactId", "companyId", "userId") FROM stdin;
\.


--
-- Data for Name: ContactListItems; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."ContactListItems" (id, name, number, email, "contactListId", "isWhatsappValid", "companyId", "createdAt", "updatedAt", "isGroup") FROM stdin;
\.


--
-- Data for Name: ContactLists; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."ContactLists" (id, name, "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ContactTags; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."ContactTags" ("contactId", "tagId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ContactWallets; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."ContactWallets" (id, "walletId", "contactId", "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Contacts; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Contacts" (id, name, number, "profilePicUrl", "createdAt", "updatedAt", email, "isGroup", "companyId", "acceptAudioMessage", channel, active, "disableBot", "remoteJid", "lgpdAcceptedAt", "urlPicture", "pictureUpdated", "whatsappId", "isLid", birthday, anniversary, info, files, "cpfCnpj", address, lid, "savedToPhone", "savedToPhoneAt", "savedToPhoneReason", "potentialScore", "isPotential", "lidStability") FROM stdin;
2615	Contato sem nome	5550489520312	https://app2.whatitan.com/nopicture.png	2026-02-10 21:59:34.059-06	2026-02-10 21:59:34.059-06		f	1	t	whatsapp	t	f	5550489520312@s.whatsapp.net	\N		f	138	f	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	0	f	unknown
2620	✨️𝐼𝑎𝑛 𝑑𝑎𝑣𝑖𝑙𝑎✨️	50432077133	https://pps.whatsapp.net/v/t61.24694-24/624488204_1432801051780375_7088030094294847302_n.jpg?ccb=11-4&oh=01_Q5Aa3wGo6aSdBX1ULhNZnevPY1RGFRimSZNWW76Lsl1_STVatA&oe=69992986&_nc_sid=5e03e0&_nc_cat=111	2026-02-10 23:01:26.195-06	2026-02-10 23:01:50.704-06		f	1	t	whatsapp	t	f	50432077133@s.whatsapp.net	\N	1770786110703.jpeg	t	138	f	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	0	f	unknown
\.


--
-- Data for Name: DialogChatBots; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."DialogChatBots" (id, awaiting, "contactId", "chatbotId", "createdAt", "updatedAt", "queueId") FROM stdin;
\.


--
-- Data for Name: Faturas; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Faturas" (id, "companyId", "contactId", valor, descricao, status, "dataCriacao", "dataVencimento", "dataPagamento", recorrente, intervalo, "proximaCobranca", "limiteRecorrencias", "recorrenciasRealizadas", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Ferramentas; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Ferramentas" (id, nome, descricao, url, metodo, headers, body, query_params, placeholders, status, "createdAt", "updatedAt", "companyId") FROM stdin;
\.


--
-- Data for Name: Files; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Files" (id, "companyId", name, message, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FilesOptions; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."FilesOptions" (id, name, path, "fileId", "createdAt", "updatedAt", "mediaType") FROM stdin;
\.


--
-- Data for Name: FlowAudios; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."FlowAudios" (id, "companyId", "userId", name, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FlowBuilders; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."FlowBuilders" (id, user_id, name, active, flow, "createdAt", "updatedAt", company_id, variables) FROM stdin;
63	142	123	t	\N	2026-02-09 22:14:39.4-06	2026-02-09 22:14:39.4-06	1	\N
\.


--
-- Data for Name: FlowCampaigns; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."FlowCampaigns" (id, "companyId", "userId", name, "flowId", phrase, status, "createdAt", "updatedAt", "whatsappId", phrases, "matchType") FROM stdin;
\.


--
-- Data for Name: FlowDefaults; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."FlowDefaults" (id, "companyId", "userId", "flowIdWelcome", "flowIdNotPhrase", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FlowImgs; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."FlowImgs" (id, "companyId", "userId", name, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: GoogleCalendarIntegrations; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."GoogleCalendarIntegrations" (id, "companyId", "googleUserId", email, "accessToken", "refreshToken", "expiryDate", "calendarId", "createdAt", "updatedAt", "userId") FROM stdin;
\.


--
-- Data for Name: GoogleSheetsTokens; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."GoogleSheetsTokens" (id, "companyId", "googleUserId", email, "accessToken", "refreshToken", "expiryDate", "rawTokens", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Helps; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Helps" (id, title, description, video, link, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: IaWorkflows; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."IaWorkflows" (id, "companyId", "orchestratorPromptId", "agentPromptId", alias, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Integrations; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Integrations" (id, "companyId", name, "isActive", token, "foneContact", "userLogin", "passLogin", "finalCurrentMonth", "initialCurrentMonth", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Invoices; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Invoices" (id, "companyId", "dueDate", detail, status, value, users, connections, queues, "useWhatsapp", "useFacebook", "useInstagram", "useCampaigns", "useSchedules", "useInternalChat", "useExternalApi", "createdAt", "updatedAt", "linkInvoice") FROM stdin;
121	1	2099-12-31T00:00:00-06:00	Plano 1	open	100	10	10	10	t	t	t	t	t	t	t	2026-02-20 18:40:30-06	2026-02-20 18:40:30-06	
\.


--
-- Data for Name: LogTickets; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."LogTickets" (id, "userId", "ticketId", "queueId", type, "createdAt", "updatedAt") FROM stdin;
11626	\N	1824	\N	create	2026-02-10 21:59:34.223-06	2026-02-10 21:59:34.223-06
11649	\N	1829	\N	create	2026-02-10 23:01:26.411-06	2026-02-10 23:01:26.411-06
11650	146	1829	\N	access	2026-02-10 23:01:28.488-06	2026-02-10 23:01:28.488-06
11651	146	1829	\N	open	2026-02-10 23:01:31.469-06	2026-02-10 23:01:31.469-06
11652	146	1829	\N	access	2026-02-10 23:01:56.689-06	2026-02-10 23:01:56.689-06
11653	146	1829	\N	access	2026-02-10 23:01:59.315-06	2026-02-10 23:01:59.315-06
\.


--
-- Data for Name: MediaFiles; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."MediaFiles" (id, folder_id, company_id, original_name, custom_name, mime_type, size, storage_path, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: MediaFolders; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."MediaFolders" (id, name, description, company_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Messages; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Messages" (body, ack, read, "mediaType", "mediaUrl", "ticketId", "createdAt", "updatedAt", "fromMe", "isDeleted", "contactId", "companyId", "remoteJid", "dataJson", participant, "queueId", "ticketTrakingId", "quotedMsgId", wid, id, "isPrivate", "isEdited", "isForwarded", "fromAgent", "userId") FROM stdin;
🎉	2	t	conversation	\N	1824	2026-02-10 21:59:33-06	2026-02-10 21:59:34.298-06	t	f	\N	1	115281301131483@lid	{"key":{"remoteJid":"50489520312@s.whatsapp.net","remoteJidAlt":"115281301131483@lid","fromMe":true,"id":"3EB0731BBFB24A33AE9D5F","participant":"","addressingMode":"pn"},"messageTimestamp":1770782373,"pushName":"fragmented","broadcast":false,"status":2,"message":{"conversation":"🎉"},"verifiedBizName":"fragmented"}		\N	2300	\N	3EB0731BBFB24A33AE9D5F	21498	f	f	f	f	\N
*agente2:*\n123	4	t	extendedTextMessage	\N	1829	2026-02-10 23:01:50-06	2026-02-10 23:01:53.026-06	t	f	\N	1	50432077133@s.whatsapp.net	{"key":{"remoteJid":"50432077133@s.whatsapp.net","fromMe":true,"id":"3EB0491FA8068CFCA79542"},"message":{"extendedTextMessage":{"text":"*agente2:*\\n123","contextInfo":{"forwardingScore":0,"isForwarded":false}}},"messageTimestamp":"1770786110","status":"PENDING"}	\N	\N	2305	\N	3EB0491FA8068CFCA79542	21520	f	f	f	f	146
1	4	f	conversation	\N	1829	2026-02-10 23:01:25-06	2026-02-10 23:03:19.292-06	f	f	2620	1	50432077133@s.whatsapp.net	{"key":{"remoteJid":"143302372384908@lid","remoteJidAlt":"50432077133@s.whatsapp.net","fromMe":false,"id":"AC29ED4477859D4307A8EC2C51FD965B","participant":"","addressingMode":"lid"},"messageTimestamp":1770786085,"pushName":"✨️𝐼𝑎𝑛 𝑑𝑎𝑣𝑖𝑙𝑎✨️","broadcast":false,"message":{"conversation":"1","messageContextInfo":{"deviceListMetadata":{"recipientKeyHash":"408Nmib8/m1Ccw==","recipientTimestamp":"1770782330"},"deviceListMetadataVersion":2,"messageSecret":"ZuChmCgONUkxkiW9Lw1bPVF9pDgROJwBAmXn2I750pE="}}}		\N	2305	\N	AC29ED4477859D4307A8EC2C51FD965B	21519	f	f	f	f	\N
\.


--
-- Data for Name: MobileWebhooks; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."MobileWebhooks" (id, "userId", "companyId", "webhookUrl", "deviceToken", platform, "isActive", "failureCount", "lastUsed", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Negocios; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Negocios" (id, "companyId", name, description, "kanbanBoards", users, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Partners; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Partners" (id, name, phone, email, document, commission, "typeCommission", "walletId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Plans; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Plans" (id, name, users, connections, queues, "createdAt", "updatedAt", amount, "useFacebook", "useInstagram", "useWhatsapp", "useCampaigns", "useExternalApi", "useInternalChat", "useSchedules", "useKanban", "isPublic", recurrence, trial, "trialDays", "useIntegrations", "useOpenAi") FROM stdin;
1	Plano 1	10	10	10	2026-02-08 21:55:03.881-06	2026-02-08 22:30:16.014-06	100	t	t	t	t	t	t	t	t	t	MENSAL	f	0	t	t
5	Basico	10	10	10	2026-02-08 22:42:34.829-06	2026-02-08 22:42:34.829-06	10	t	t	t	t	t	t	t	t	t	MENSAL	f	0	t	t
\.


--
-- Data for Name: Produtos; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Produtos" (id, "companyId", tipo, nome, descricao, valor, status, imagem_principal, galeria, dados_especificos, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PromptToolSettings; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."PromptToolSettings" (id, "companyId", "promptId", "toolName", enabled, "createdAt", "updatedAt") FROM stdin;
838	1	21	send_product	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
839	1	21	execute_tool	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
840	1	21	like_message	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
841	1	21	get_company_schedule	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
842	1	21	send_emoji	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
843	1	21	send_contact_file	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
844	1	21	get_contact_schedules	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
845	1	21	create_contact_schedule	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
846	1	21	update_contact_schedule	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
847	1	21	format_message	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
848	1	21	list_professionals	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
849	1	21	call_prompt_agent	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
850	1	21	update_contact_info	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
851	1	21	get_contact_info	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
852	1	21	execute_command	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
853	1	21	get_asaas_second_copy	t	2026-02-10 11:20:09.69-06	2026-02-10 11:20:09.69-06
\.


--
-- Data for Name: Prompts; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Prompts" (id, name, "apiKey", prompt, "maxTokens", "maxMessages", temperature, "promptTokens", "completionTokens", "totalTokens", voice, "voiceKey", "voiceRegion", "queueId", "companyId", "createdAt", "updatedAt", model, provider, "knowledgeBase") FROM stdin;
21	Admin	12123123135123132132	21332132	100	10	1	0	0	0	texto			54	1	2026-02-10 11:19:33.332-06	2026-02-10 11:20:09.669-06	gpt-3.5-turbo	openai	[]
\.


--
-- Data for Name: QueueIntegrations; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."QueueIntegrations" (id, type, name, "projectName", "jsonContent", language, "createdAt", "updatedAt", "urlN8N", "companyId", "typebotExpires", "typebotKeywordFinish", "typebotUnknownMessage", "typebotSlug", "typebotDelayMessage", "typebotKeywordRestart", "typebotRestartMessage") FROM stdin;
\.


--
-- Data for Name: QueueOptions; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."QueueOptions" (id, title, message, option, "queueId", "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Queues; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Queues" (id, name, color, "greetingMessage", "createdAt", "updatedAt", "companyId", schedules, "outOfHoursMessage", "orderQueue", "tempoRoteador", "ativarRoteador", "integrationId", "fileListId", "closeTicket") FROM stdin;
54	Admin	#C10F0F		2026-02-10 11:18:19.084-06	2026-02-10 11:18:19.084-06	1	[{"weekday": "Lunes", "endTimeA": "12:00", "endTimeB": "23:00", "weekdayEn": "monday", "startTimeA": "08:00", "startTimeB": "12:01"}, {"weekday": "Martes", "endTimeA": "12:00", "endTimeB": "23:00", "weekdayEn": "tuesday", "startTimeA": "08:00", "startTimeB": "12:01"}, {"weekday": "Miércoles", "endTimeA": "12:00", "endTimeB": "23:00", "weekdayEn": "wednesday", "startTimeA": "08:00", "startTimeB": "12:01"}, {"weekday": "Jueves", "endTimeA": "12:00", "endTimeB": "23:00", "weekdayEn": "thursday", "startTimeA": "08:00", "startTimeB": "12:01"}, {"weekday": "Viernes", "endTimeA": "12:00", "endTimeB": "23:00", "weekdayEn": "friday", "startTimeA": "08:00", "startTimeB": "12:01"}, {"weekday": "Sábado", "endTimeA": "12:00", "endTimeB": "23:00", "weekdayEn": "saturday", "startTimeA": "08:00", "startTimeB": "12:01"}, {"weekday": "Domingo", "endTimeA": "12:00", "endTimeB": "23:00", "weekdayEn": "sunday", "startTimeA": "08:00", "startTimeB": "12:01"}]		\N	0	f	\N	\N	f
\.


--
-- Data for Name: QuickMessages; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."QuickMessages" (id, shortcode, message, "companyId", "createdAt", "updatedAt", "userId", "mediaPath", "mediaName", geral, visao) FROM stdin;
12	123	123	1	2026-02-10 21:53:29.749-06	2026-02-10 21:55:21.962-06	145	\N	\N	f	f
13	156	5165	1	2026-02-10 21:55:31.912-06	2026-02-10 21:55:31.912-06	145	\N	\N	f	t
14	55656515	1651651	1	2026-02-10 21:56:14.37-06	2026-02-10 21:56:14.37-06	145	\N	\N	t	t
\.


--
-- Data for Name: ScheduledMessages; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."ScheduledMessages" (id, data_mensagem_programada, id_conexao, intervalo, valor_intervalo, mensagem, tipo_dias_envio, mostrar_usuario_mensagem, criar_ticket, contatos, tags, "companyId", nome, "createdAt", "updatedAt", "mediaPath", "mediaName", tipo_arquivo, usuario_envio, enviar_quantas_vezes) FROM stdin;
\.


--
-- Data for Name: ScheduledMessagesEnvios; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."ScheduledMessagesEnvios" (id, "createdAt", "updatedAt", "mediaPath", "mediaName", mensagem, "companyId", data_envio, scheduledmessages, key) FROM stdin;
\.


--
-- Data for Name: Schedules; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Schedules" (id, body, "sendAt", "sentAt", "contactId", "ticketId", "userId", "companyId", "createdAt", "updatedAt", status, "ticketUserId", "whatsappId", "statusTicket", "queueId", "openTicket", "mediaName", "mediaPath", intervalo, "valorIntervalo", "enviarQuantasVezes", "tipoDias", "contadorEnvio", assinar, "googleEventId") FROM stdin;
\.


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."SequelizeMeta" (name) FROM stdin;
20200717133438-create-users.js
20200717144403-create-contacts.js
20200717145643-create-tickets.js
20200717151645-create-messages.js
20200717170223-create-whatsapps.js
20200723200315-create-contacts-custom-fields.js
20200723202116-add-email-field-to-contacts.js
20200730153237-remove-user-association-from-messages.js
20200730153545-add-fromMe-to-messages.js
20200813114236-change-ticket-lastMessage-column-type.js
20200901235509-add-profile-column-to-users.js
20200903215941-create-settings.js
20200904220257-add-name-to-whatsapp.js
20200906122228-add-name-default-field-to-whatsapp.js
20200906155658-add-whatsapp-field-to-tickets.js
20200919124112-update-default-column-name-on-whatsappp.js
20200927220708-add-isDeleted-column-to-messages.js
20200929145451-add-user-tokenVersion-column.js
20200930162323-add-isGroup-column-to-tickets.js
20200930194808-add-isGroup-column-to-contacts.js
20201004150008-add-contactId-column-to-messages.js
20201004155719-add-vcardContactId-column-to-messages.js
20201004955719-remove-vcardContactId-column-to-messages.js
20201026215410-add-retries-to-whatsapps.js
20201028124427-add-quoted-msg-to-messages.js
20210108001431-add-unreadMessages-to-tickets.js
20210108164404-create-queues.js
20210108164504-add-queueId-to-tickets.js
20210108174594-associate-whatsapp-queue.js
20210108204708-associate-users-queue.js
20210109192513-add-greetingMessage-to-whatsapp.js
20210109192514-create-companies-table.js
20210109192515-add-column-companyId-to-Settings-table.js
20210109192516-add-column-companyId-to-Users-table.js
20210109192517-add-column-companyId-to-Contacts-table.js
20210109192518-add-column-companyId-to-Messages-table.js
20210109192519-add-column-companyId-to-Queues-table.js
20210109192520-add-column-companyId-to-Whatsapps-table.js
20210109192521-add-column-companyId-to-Tickets-table.js
20210109192522-create-plans-table.js
20210109192523-add-column-amount-to-Plan.js
20210109192523-add-column-planId-to-Companies.js
20210109192523-add-column-status-and-schedules-to-Companies.js
20210109192523-create-ticket-notes.js
20210109192524-create-quick-messages.js
20210109192525-add-column-complationMessage-to-whatsapp.js
20210109192526-add-column-outOfHoursMessage-to-whatsapp .js
20210109192527-add-column-super-to-Users-table.js
20210109192528-change-column-message-to-quick-messages-table.js
20210109192529-create-helps.js
20210109192531-create-TicketTracking-table.js
20210109192532-add-column-online-to-Users-table.js
20210109192533-create-UserRatings-table.js
20210109192534-add-rated-to-TicketTraking.js
20210109192536-add-unique-constraint-to-Tickets-table.js
20210818102606-add-uuid-to-tickets.js
20210818102607-remove-unique-indexes-to-Queues-table.js
20210818102608-add-unique-indexes-to-Queues-table.js
20210818102609-add-token-to-Whatsapps.js
20211017014719-create-chatbots.js
20211017014721-create-dialog-chatbot.js
20211205164404-create-queue-options.js
20211212125704-add-chatbot-to-tickets.js
20211227010200-create-schedules.js
20212016014719-add-bot-ticket.js
20212016014719-add-queueId-dialog.js
20220115114088-add-column-userId-to-QuickMessages-table.js
20220117130000-create-tags.js
20220117134400-associate-tickets-tags.js
20220122160900-add-status-to-schedules.js
20220220014719-add-farewellMessage-to-whatsapp.js
20220221014717-add-provider-whatsapp.js
20220221014718-add-remoteJid-messages.js
20220221014719-add-jsonMessage-messages.js
20220221014720-add-participant-messages.js
20220221014721-create-baileys.js
20220315110000-create-ContactLists-table.js
20220315110001-create-ContactListItems-table.js
20220315110002-create-Campaigns-table.js
20220315110004-create-CampaignSettings-table.js
20220315110005-remove-constraint-to-Settings.js
20220321130000-create-CampaignShipping.js
20220404000000-add-column-queueId-to-Messages-table.js
20220406000000-add-column-dueDate-to-Companies.js
20220406000001-add-column-recurrence-to-Companies.js
20220411000000-add-column-startTime-and-endTime-to-Queues.js
20220411000001-remove-column-startTime-and-endTime-to-Queues.js
20220411000002-add-column-schedules-and-outOfHoursMessage-to-Queues.js
20220411000003-create-table-Announcements.js
20220425000000-create-table-Chats.js
20220425000001-create-table-ChatUsers.js
20220425000002-create-table-ChatMessages.js
20220512000001-create-Indexes.js
20220723000001-add-mediaPath-to-quickmessages.js
20220723000002-add-mediaName-to-quickemessages.js
20220723000003-add-geral-to-quickmessages.js
20221123155118-add-acceptAudioMessages-to-contact.js
20221227164300-add-colunms-document-and-paymentMethod-to-companies-table.js
20221229000000-add-column-number-to-Whatsapps.js
20222016014719-add-channel-session.js
20222016014719-add-channel-to-contacts.js
20222016014719-add-channel-to-ticket.js
20222016014719-add-channel-token.js
20222016014719-add-channel-tokenUser.js
20222016014719-add-facebookPageUserId-whatsapp.js
20222016014719-add-facebookUserId-whatsapp.js
20222016014719-add-isAgent-chatbot.js
20230105164900-add-useFacebook-Plans.js
20230105164900-add-useInstagram-Plans.js
20230105164900-add-useWhatsapp-Plans.js
20230106164900-add-useCampaigns-Plans.js
20230106164900-add-useExternalApi-Plans.js
20230106164900-add-useInternalChat-Plans.js
20230106164900-add-useSchedules-Plans.js
20230110072000-create-integrations.js
20230119000002-create-subscriptions.js
20230119000003-create-invoices.js
20230120000000-create-ApiUsage.js
20230123155600-add-colunms-lastLogin-to-companies-table.js
20230124110200-add-endWork-Users.js
20230124110200-add-startWork-Users.js
20230127091500-add-column-active-to-Contacts.js
20230216173900-add-uuid-extension.js
20230301110200-add-color-Users.js
20230301110201-add-farewellMessage-Users.js
20230303223000-add-maxUseBotQueues-to-whatsapp copy.js
20230303223001-add-amountUsedBotQueues-to-tickets.js
20230403193000-add-disable-bot-column-to-contacts.js
20230403193000-add-expiresTicket-fields-to-whatsapp.js
20230411131007-add-allowGroup-whatsapp.js
20230505221007-add-closedAt-TicketTraking.js
20230517221007-add-optQueueId-Chatbots.js
20230517221007-add-optUserId-chatbots.js
20230517221007-add-queueType-Chatbots.js
20230603212335-create-QueueIntegrations.js
20230603212337-add-QueueIntegrations-integrationId-Chatbots.js
20230603212337-add-urlN8N-QueueIntegrations.js
20230612221007-add-remoteJid-Contact.js
20230623095932-add-whatsapp-to-user.js
20230623113000-add-timeUseBotQueues-to-whatsapp.js
20230623133903-add-chatbotAt-ticket-tracking.js
20230626141100-add-column-ticketTrakingId-to-Messages-table.js
20230628134807-add-orderQueue-Queue.js
20230630150600-create-associate-contacttags.js
20230703221100-add-column-queueId-to-TicketTraking-table.js
20230704124428-update-messages.js
20230707221100-add-column-isPrivate-to-Message-table.js
20230708192530-add-unique-constraint-to-Contacts-table.js
20230711080001-create-Index-Message-wid.js
20230711094417-add-column-companyId-to-QueueIntegrations-table.js
20230711111700-add-timeSendQueue-to-whatsapp.js
20230711111701-add-sendIdQueue-to-whatsapp.js
20230713131510-add-tempoRoteador-Queue.js
20230714113901-create-Files.js
20230714113902-create-fileOptions.js
20230716229907-add-ativaRoteador-Queue.js
20230717113705-add-isEdited-to-messages.js
20230717221007-add-optFileId-chatbots.js
20230723301001-add-kanban-to-Tags.js
20230724111007-add-collumns-whatsapp.js
20230724192535-add-column-ratingMessage-to-whatsapp.js
20230726203900-add-allTickets-user.js
20230731214345-create-table-webhooks.js
20230731224345-add-active-table-webhooks.js
20230731331007-add-lgpdAccept-Contact.js
20230808141907-add-collumns-Users.js
20230809081007-add-import-old-messages-to-whatsapp.js
20230809081007-add-import-recent-messages-to-whatsapp.js
20230809081008-add-status-import-to-whatsapp.js
20230809081009-add-closed-tickets-post-imported-to-whatsapp.js
20230809081010-add-import-old-messages-groups-to-whatsapp.js
20230809081011-add-imported-to-tickets.js
20230809081012-change-name-unique-false-to-whatsapp.js
20230810224345-add-company-table-webhooks.js
20230810234345-add-company-table-flowbuilder.js
20230813114236-change-ticket-lastMessage-column-type.js
20230816212401-add-timeCreateNewTicket-to-whatsapp.js
20230823082607-add-urlPicture-Contact.js
20230823114236-add-column-flow-and-location.js
20230823124236-add-column-data.js
20230823134236-add-column-hashflow.js
20230824082607-add-mediaType-FilesOptions.js
20230824134719-add-greetingMediaAtachmentToWhatsapp.js
20230825080921-add-profile-image-to-user.js
20230922212337-add-integrationId-Queues.js
20230922214345-create-table-flow-default.js
20231019113637-add-columns-Campaign.js
20231220080937-add-columns-Whatsapps.js
20231220223517-add-column-whatsappId-to-Contacts.js
20231221080937-change-collectiveVacationMessage-Whatsapps.js
20231229214537-add-defaultTicketsManagerWidth-Users.js
20232010133900-create-Partners-table.js
20240102230240-create-ScheduledMessages.js
20240102230240-create-ScheduledMessagesEnvio.js
20240102230241-create-ContactGroup.js
20240111080937-change-profilePicUrl-contacts.js
20240125080937-change-urlPicture-contacts.js
20240212113637-add-recorrencia-Schedules.js
20240311125600-add-colunms-folderSize-to-companies-table.js
20240322143411-add-queueIdImportMessage-to-whatsapps.js
20240323220001-create-companyId-Index-Message.js
20230801081907-add-collumns-Ticket.js
20230802214345-create-table-flowbuilder.js
20230828143411-add-Integrations-to-tickets.js
20230828143411-add-isOutOfHour-to-tickets.js
20230828144000-create-prompts.js
20230828144100-add-column-promptid-into-whatsapps.js
20230829214345-create-table-imgs-flow.js
20230831093000-add-useKanban-Plans.js
20230901101300-create-CompaniesSettings.js
20230901214345-create-table-audios-flow.js
20230902082607-add-pictureUpdate-Contact.js
20230904214345-create-table-campaign-flow.js
20230905114236-add-column-flow-now.js
20230911113900-add-unaccent-extension.js
20230911143705-add-isForwarded-to-messages.js
20230912112028-insert-CompanieSettings.js
20230913210007-create-table-LogTickets.js
20230915212800-add-public-to-plans.js
20230923000001-create-Indexes-new.js
20230923124428-update-tickets.js
20230924212337-add-fileListId-Queues.js
20230925112401-create-Indexes Tickets.js
20231128123537-add-typebot-QueueIntegrations.js
20231201123411-add-closeTicketOnTransfer-to-CompaniesSettings.js
20231202143411-add-typebotSessionId-to-tickets.js
20231207080337-add-typebotDelayMessage-QueueIntegrations.js
20231207085011-add-typebotStatus-to-tickets.js
20231218160937-add-columns-QueueIntegrations.js
20230807081007-add-lgpdAccept-Ticket.js
20230808135401-add-groupAsTicket-to-whatsapp.js
20230925212337-add-closeTicket-Queues-Chatbots.js
20230926143705-add-isGroup-to-ContactListItems.js
20231008145702-add-column-schedules-to-Whatsapps.js
20231016214537-add-allHistoric-users.js
20240202110037-add-collumns-custommessages-settings.js
20240206110037-add-linkInvoice-to-Invoices.js
20231019113637-add-columns-Schedules.js
20231020125000-add-columns-Plans.js
20231103230445-change-collumn-expiresInactiveMessage.js
20231105221305-add-visao-to-quickMessages.js
20231110214537-add-allUserChat-users.js
20231111185822-add_reset_password_column.js
20231114113637-add-openTicket-Campaign.js
20231114113637-add-openTicket-Schedules.js
20231117000001-add-mediaName-to-schedules.js
20231117000001-add-mediaPath-to-schedules.js
20231121143411-add-isActiveDemand-to-tickets.js
20231122193355-create-table-wallets-contact.js
20231122223411-add-DirectTicketsToWallets-to-CompaniesSettings.js
20231127113000-add-columns-Plans.js
20231213214537-add-permissions-users.js
20240308133648-add-columns-to-Tags.js
20240308133648-add-rollbackLaneId-to-Tags.js
20240422214537-add-permissions-users.js
20240425223411-add-showNotificationPending-to-CompaniesSettings.js
20240425225011-add-typebotSsessionTime-to-tickets.js
20240515221400-create-Versions.js
20240516112028-insert-version.js
20240523083535-create-index.js
20240610083535-create-index.js
20240718030548-add-column-flowIdNotPhrase-to-whatsapp.js
20240718084127-recriate-constraint-integracoes.js
20240719130841-add-column-flowIdWelcome-to-whatsapp.js
20240719174849-add-column-whatsappId-to-flowCampaigns.js
20240924171945-add-variables-column-to-flowbuilders.js
20250124140438-add-wavoip-to-whatsapp.js
20250127132448-add-column-notificameHub-to-CompaniesSettings-table.js
20250127171400-change_message_id_type_from_Messages.js
20250128161327-add-column-notificameHub-to-Whatsapps-table.js
20250914174400-add-provider-model-to-prompts.js.js
20251114003000-create-Negocios-table.js
20251215031800-add-productsSent-to-tickets.js
20241201000000-create-mobile-webhooks.js
20251119083000-create-Produtos-table.js
20251119083500-create-Ferramentas-table.js
20251123190000-create-table-google-calendar-integrations.js
20251123190500-add-column-googleEventId-to-schedules.js
20251125003000-add-extra-fields-to-contacts.js
20251125030500-create-slider-banners.js
20251126010000-create-faturas.js
20251126155000-add-lid-column-to-contacts.js
20251129000000-create-ia-workflows.js
20251203020000-add-video-url-to-tutorial-videos.js
20251204150000-create-slider-home.js
20251205160000-create-profissionais-servicos.js
20251205163000-create-prompt-tool-settings.js
20251214012800-create-automations.js
20251216090000-create-crm-leads.js
20251216090500-create-crm-clients.js
20251216092000-create-financeiro-faturas.js
20251216092500-create-financeiro-pagamentos.js
20251216093000-add-valor-pago-to-financeiro-faturas.js
20251218133500-link-leads-clients-contacts.js
20251219050000-create-media-folders.js
20251219051000-create-media-files.js
20251222170500-create-company-payment-settings.js
20251222171000-add-payment-fields-financeiro-faturas.js
20251222171500-add-asaas-customer-id-to-crm-clients.js
20251222172000-add-checkout-token-to-financeiro-faturas.js
20251223100000-create-company-integration-settings.js
20251223100500-create-company-integration-field-maps.js
20251223103000-create-company-api-keys.js
20251224130000-fix-company-payment-settings-columns.js
20251224170000-create-scheduled-dispatchers.js
20251224170500-create-scheduled-dispatch-logs.js
20251229210000-add-lead-value-to-tickets.js
20251231230000-create-projects-table.js
20251231230100-create-project-services-table.js
20251231230200-create-project-products-table.js
20251231230300-create-project-users-table.js
20251231230400-create-project-tasks-table.js
20251231230500-create-project-task-users-table.js
20260101150000-add-project-id-to-financeiro-faturas.js
20260101160000-create-schedules.js
20260101160100-create-appointments.js
20260101173000-add-professional-fields-to-users.js
20260101173100-create-user-services.js
20260106193000-add-knowledgeBase-to-prompts.js
20260108195000-add-column-phrases-to-flowcampaigns.js
20260108195500-add-column-matchType-to-flowcampaigns.js
20260109215800-add-fromAgent-to-messages.js
20260109223800-add-userId-to-messages.js
20260110223300-add-lid-to-tickets.js
\.


--
-- Data for Name: Settings; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Settings" (key, value, "createdAt", "updatedAt", "companyId", id) FROM stdin;
userCreation	enabled	2026-02-08 21:55:03.958-06	2026-02-08 21:55:03.958-06	\N	98
wtV	disabled	2026-02-08 21:55:04.279-06	2026-02-08 21:55:04.279-06	\N	115
hoursCloseTicketsAuto	9999999999	2026-02-08 21:55:03.979-06	2026-02-08 21:55:03.979-06	\N	99
chatBotType	text	2026-02-08 21:55:03.991-06	2026-02-08 21:55:03.991-06	\N	100
acceptCallWhatsapp	enabled	2026-02-08 21:55:04.001-06	2026-02-08 21:55:04.001-06	\N	101
userRandom	enabled	2026-02-08 21:55:04.024-06	2026-02-08 21:55:04.024-06	\N	102
sendGreetingMessageOneQueues	enabled	2026-02-08 21:55:04.048-06	2026-02-08 21:55:04.048-06	\N	103
sendSignMessage	enabled	2026-02-08 21:55:04.066-06	2026-02-08 21:55:04.066-06	\N	104
sendFarewellWaitingTicket	disabled	2026-02-08 21:55:04.101-06	2026-02-08 21:55:04.101-06	\N	105
userRating	disabled	2026-02-08 21:55:04.13-06	2026-02-08 21:55:04.13-06	\N	106
sendGreetingAccepted	enabled	2026-02-08 21:55:04.145-06	2026-02-08 21:55:04.145-06	\N	107
CheckMsgIsGroup	enabled	2026-02-08 21:55:04.156-06	2026-02-08 21:55:04.156-06	\N	108
sendQueuePosition	enabled	2026-02-08 21:55:04.166-06	2026-02-08 21:55:04.166-06	\N	109
scheduleType	disabled	2026-02-08 21:55:04.202-06	2026-02-08 21:55:04.202-06	\N	110
acceptAudioMessageContact	enabled	2026-02-08 21:55:04.206-06	2026-02-08 21:55:04.206-06	\N	111
enableLGPD	disabled	2026-02-08 21:55:04.237-06	2026-02-08 21:55:04.237-06	\N	112
requiredTag	disabled	2026-02-08 21:55:04.256-06	2026-02-08 21:55:04.256-06	\N	113
downloadLimit	64	2026-02-08 21:55:04.265-06	2026-02-08 21:55:04.265-06	\N	114
asaas		2026-02-08 21:55:04.361-06	2026-02-08 21:55:04.361-06	\N	116
efichavepix		2026-02-08 21:55:04.361-06	2026-02-08 21:55:04.361-06	\N	117
eficlientid		2026-02-08 21:55:04.361-06	2026-02-08 21:55:04.361-06	\N	118
eficlientsecret		2026-02-08 21:55:04.361-06	2026-02-08 21:55:04.361-06	\N	119
mpaccesstoken		2026-02-08 21:55:04.361-06	2026-02-08 21:55:04.361-06	\N	120
stripeprivatekey		2026-02-08 21:55:04.361-06	2026-02-08 21:55:04.361-06	\N	121
asaastoken		2026-02-08 21:55:04.361-06	2026-02-08 21:55:04.361-06	\N	122
openaikeyaudio		2026-02-08 21:55:04.361-06	2026-02-08 21:55:04.361-06	\N	123
campaignsEnabled	true	2026-02-08 22:16:01.074-06	2026-02-08 22:16:01.074-06	1	124
userCreation	enabled	2026-02-08 22:29:47.579-06	2026-02-08 22:29:47.579-06	1	126
appName	whaticket Express Lite	2026-02-08 22:31:36.082-06	2026-02-08 22:31:36.082-06	1	127
versionFrontend	4.0.0	2026-02-08 22:33:14.725291-06	2026-02-08 22:33:14.725291-06	\N	128
appName	Whaticket	2026-02-08 22:33:14.725291-06	2026-02-08 22:33:14.725291-06	\N	129
primaryColorLight	#1976d2	2026-02-08 22:33:14.725291-06	2026-02-08 22:33:14.725291-06	\N	130
primaryColorDark	#1976d2	2026-02-08 22:33:14.725291-06	2026-02-08 22:33:14.725291-06	\N	131
appLogoLight		2026-02-08 22:33:14.725291-06	2026-02-08 22:33:14.725291-06	\N	132
appLogoDark		2026-02-08 22:33:14.725291-06	2026-02-08 22:33:14.725291-06	\N	133
appLogoFavicon		2026-02-08 22:33:14.725291-06	2026-02-08 22:33:14.725291-06	\N	134
allowSignup	true	2026-02-08 22:33:14.725291-06	2026-02-08 22:33:14.725291-06	\N	135
stripeprivatekey	vfdvsdfvsdfvsdfvdfs	2026-02-08 22:41:36.86-06	2026-02-08 22:41:38.116-06	1	138
mpaccesstoken	gvfdvfdsvsdfvsd	2026-02-08 22:41:34.753-06	2026-02-08 22:41:36.001-06	1	137
asaastoken	sdfvsdfvsdfvsdfvsdfvdsf	2026-02-08 22:41:39.107-06	2026-02-08 22:41:40.519-06	1	139
termsText	Terminos de uso	2026-02-08 22:42:54.149-06	2026-02-08 22:42:54.149-06	1	140
welcomeEmailText	Buen dia 	2026-02-08 22:42:58.215-06	2026-02-08 22:42:58.215-06	1	141
welcomeWhatsappText	Hola {nome} 🎉 Bienvenido {empresa}, su acceso ha sido creado	2026-02-08 22:43:11.991-06	2026-02-08 22:44:26.356-06	1	142
primaryColorLight	#202020	2026-02-08 22:25:36.026-06	2026-02-12 18:55:05.826-06	1	125
appLogoLight	WhaTitan-12-2-2026.png	2026-02-12 18:58:38.739-06	2026-02-12 18:58:38.739-06	1	143
appLogoFavicon	WhaTitan-12-2-2026.png	2026-02-12 18:59:46.499-06	2026-02-12 18:59:46.499-06	1	144
verifyToken		2026-02-12 19:00:37.066-06	2026-02-12 19:00:37.066-06	1	145
facebookAppId		2026-02-12 19:00:37.267-06	2026-02-12 19:00:37.267-06	1	146
facebookAppSecret		2026-02-12 19:00:38.456-06	2026-02-12 19:00:38.456-06	1	147
googleClientId		2026-02-12 19:00:39.235-06	2026-02-12 19:00:39.235-06	1	148
googleClientSecret		2026-02-12 19:00:40.535-06	2026-02-12 19:00:40.535-06	1	149
googleRedirectUri		2026-02-12 19:00:46.767-06	2026-02-12 19:00:46.767-06	1	150
ownerCompany	true	2026-02-20 18:40:51.137748-06	2026-02-20 18:40:51.137748-06	1	151
\.


--
-- Data for Name: SliderBanners; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."SliderBanners" (id, image, url, "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Subscriptions; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Subscriptions" (id, "isActive", "expiresAt", "userPriceCents", "whatsPriceCents", "lastInvoiceUrl", "lastPlanChange", "companyId", "providerSubscriptionId", "createdAt", "updatedAt") FROM stdin;
1	t	2099-12-31 00:00:00-06	\N	\N	\N	\N	1	internal-owner	2026-02-20 18:40:32.433785-06	2026-02-20 18:40:32.433785-06
\.


--
-- Data for Name: Tags; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Tags" (id, name, color, "companyId", "createdAt", "updatedAt", kanban, "timeLane", "nextLaneId", "greetingMessageLane", "rollbackLaneId") FROM stdin;
\.


--
-- Data for Name: TicketNotes; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."TicketNotes" (id, note, "userId", "contactId", "ticketId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TicketTags; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."TicketTags" ("ticketId", "tagId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TicketTraking; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."TicketTraking" (id, "ticketId", "companyId", "whatsappId", "userId", "createdAt", "updatedAt", "queuedAt", "startedAt", "finishedAt", "ratingAt", rated, "closedAt", "chatbotAt", "queueId") FROM stdin;
2300	1824	1	138	\N	2026-02-10 21:59:34.264-06	2026-02-10 21:59:34.264-06	\N	\N	\N	\N	f	\N	\N	\N
2301	\N	1	138	146	2026-02-10 22:01:18.491-06	2026-02-10 22:42:57.74-06	2026-02-10 22:38:00.479-06	2026-02-10 22:38:00.511-06	2026-02-10 22:42:57.728-06	\N	f	2026-02-10 22:42:57.729-06	\N	\N
2303	\N	1	138	146	2026-02-10 22:45:26.351-06	2026-02-10 22:55:00.123-06	2026-02-10 22:47:25.981-06	2026-02-10 22:45:56.513-06	2026-02-10 22:55:00.113-06	\N	f	2026-02-10 22:55:00.114-06	\N	54
2304	\N	1	138	146	2026-02-10 22:55:25.994-06	2026-02-10 22:55:52.405-06	2026-02-10 22:55:52.351-06	2026-02-10 22:55:52.374-06	\N	\N	f	\N	\N	\N
2305	1829	1	138	146	2026-02-10 23:01:26.423-06	2026-02-10 23:01:59.083-06	2026-02-10 23:01:59.065-06	2026-02-10 23:01:31.455-06	\N	\N	f	\N	\N	54
\.


--
-- Data for Name: Tickets; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Tickets" (id, status, "lastMessage", "contactId", "userId", "createdAt", "updatedAt", "whatsappId", "isGroup", "unreadMessages", "queueId", "companyId", uuid, chatbot, "queueOptionId", "isBot", channel, "amountUsedBotQueues", "fromMe", "amountUsedBotQueuesNPS", "sendInactiveMessage", "lgpdSendMessageAt", "lgpdAcceptedAt", imported, "flowWebhook", "lastFlowId", "dataWebhook", "hashFlowId", "useIntegration", "integrationId", "isOutOfHour", "flowStopped", "isActiveDemand", "typebotSessionId", "typebotStatus", "typebotSessionTime", "productsSent", crm_lead_id, crm_client_id, "leadValue", lid) FROM stdin;
1824	pending	🎉	2615	\N	2026-02-10 21:59:34.18-06	2026-02-10 21:59:34.37-06	138	f	0	\N	1	49333dc0-f348-4c82-a9f6-d30557b4af57	f	\N	f	whatsapp	0	t	0	f	\N	\N	\N	f	\N	\N	\N	f	\N	f	\N	f	\N	f	\N	[]	1291	\N	\N	\N
1829	open	*agente2:*\n123	2620	146	2026-02-10 23:01:26.382-06	2026-02-10 23:01:59.059-06	138	f	0	54	1	380267e5-4e9c-478b-a68a-c98da6a05225	f	\N	f	whatsapp	0	t	0	f	\N	\N	\N	f	\N	\N	\N	f	\N	f	\N	f	\N	f	\N	[]	1296	\N	\N	\N
\.


--
-- Data for Name: UserDevices; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."UserDevices" (id, "userId", "deviceToken", platform, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: UserGoogleCalendarIntegrations; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."UserGoogleCalendarIntegrations" (id, user_id, company_id, "googleUserId", email, "accessToken", "refreshToken", "expiryDate", "calendarId", active, "syncToken", "lastSyncAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: UserQueues; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."UserQueues" ("userId", "queueId", "createdAt", "updatedAt") FROM stdin;
146	54	2026-02-10 23:00:06.263-06	2026-02-10 23:00:06.263-06
142	54	2026-02-10 23:00:32.657-06	2026-02-10 23:00:32.657-06
\.


--
-- Data for Name: UserRatings; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."UserRatings" (id, "ticketId", "companyId", "userId", rate, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: UserServices; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."UserServices" (id, "userId", "serviceId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Users" (id, name, email, "passwordHash", "createdAt", "updatedAt", profile, "tokenVersion", "companyId", super, online, "endWork", "startWork", color, "farewellMessage", "whatsappId", "allTicket", "allowGroup", "defaultMenu", "defaultTheme", "profileImage", "allHistoric", "allUserChat", "resetPassword", "userClosePendingTicket", "showDashboard", "defaultTicketsManagerWidth", "allowRealTime", "allowConnections", "userType", "workDays", "lunchStart", "lunchEnd") FROM stdin;
145	agente	agente@demo.com	$2a$08$7wCa6WgrfYSSVTcTALvdmOLz0QNfk0cCYqnv/6oSECvK11B9r/MaO	2026-02-10 21:33:03.734-06	2026-02-10 22:57:13.119-06	user	0	1	f	f	23:59	00:00			138	enable	t	open	light	\N	disabled	disabled	\N	disabled	disabled	550	disabled	disabled	attendant	1,2,3,4,5	\N	\N
146	agente2	agente2@demo.com	$2a$08$7fhD1ZnbefGFylEhbzMX1uD8YZ6WSKFEcXEGsEowLqOXIPkrwH4G2	2026-02-10 21:54:25.45-06	2026-02-10 23:07:00.035-06	user	0	1	f	f	23:59	00:00			138	enable	f	open	light	\N	disabled	disabled	\N	disabled	disabled	550	disabled	disabled	attendant	1,2,3,4,5	\N	\N
142	SuperAdmin	admin@admin.com	$2a$08$ZkeY/peVvHpWr3CxkbUFg.5pW.tNhQkARa2wYRoQdJ2uXgg.pLvPq	2026-02-08 22:16:01.028-06	2026-02-20 18:41:01.676-06	admin	0	1	t	t	23:59	00:00			138	enable	t	closed	light	\N	enabled	enabled	\N	enabled	disabled	550	disable	enabled	attendant	1,2,3,4,5	\N	\N
\.


--
-- Data for Name: Versions; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Versions" (id, "versionFrontend", "versionBackend", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Webhooks; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Webhooks" (id, user_id, name, hash_id, config, "createdAt", "updatedAt", active, "requestMonth", "requestAll", company_id) FROM stdin;
13	142	flowbuilder	zAwfpFX0oqfTHcWuLswkp8ryzVIPRXaSkh6KvD1voD	\N	2026-02-09 21:57:31.877-06	2026-02-09 21:57:31.877-06	t	0	0	1
\.


--
-- Data for Name: WhatsappQueues; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."WhatsappQueues" ("whatsappId", "queueId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Whatsapps; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public."Whatsapps" (id, session, qrcode, status, battery, plugged, "createdAt", "updatedAt", name, "isDefault", retries, "greetingMessage", "companyId", "complationMessage", "outOfHoursMessage", token, "farewellMessage", provider, number, channel, "facebookUserToken", "tokenMeta", "facebookPageUserId", "facebookUserId", "maxUseBotQueues", "expiresTicket", "allowGroup", "timeUseBotQueues", "timeSendQueue", "sendIdQueue", "expiresInactiveMessage", "maxUseBotQueuesNPS", "inactiveMessage", "whenExpiresTicket", "expiresTicketNPS", "timeInactiveMessage", "ratingMessage", "groupAsTicket", "importOldMessages", "importRecentMessages", "statusImportMessages", "closedTicketsPostImported", "importOldMessagesGroups", "timeCreateNewTicket", "greetingMediaAttachment", "promptId", "integrationId", schedules, "collectiveVacationEnd", "collectiveVacationStart", "collectiveVacationMessage", "queueIdImportMessages", "flowIdNotPhrase", "flowIdWelcome", wavoip, "notificameHub", "coexistencePhoneNumberId", "coexistenceWabaId", "coexistencePermanentToken", "coexistenceEnabled", "businessAppConnected", "messageRoutingMode", "routingRules", "lastCoexistenceSync") FROM stdin;
138		2@t1r2UXY0/nokiCCf6b1gOZNkWuu7+wBD+MZZXlI6AJei8iFP6Qm0EfSHc8ObptkB1YOzBMCMkSPcea3HcigAZKlu5Ex4QDElXlk=,qJL5TavrEosqdZu6JZV++8Enz3DSuJuRNJVA/gJiTlU=,lhFAgOdfbOVZggFYDKVibtLC1LKjDQAUsrxLvhZXX3k=,IokyWjueW3whvqBcN54JXFIJ7ExXnwtY3ZemVLyyREU=	DISCONNECTED	\N	\N	2026-02-10 21:58:18.216-06	2026-02-10 23:05:22.747-06	1561	t	0		1			BpqLIQ1XgLj6G7TAg15ZQGkWSsBoJt		beta		whatsapp	\N	\N	\N	\N	3	0	f	0	0	54		3		0	0			disabled	\N	\N	\N	\N	\N	0	\N	\N	\N	[{"weekday": "Lunes", "endTimeA": "12:00", "endTimeB": "18:00", "weekdayEn": "monday", "startTimeA": "08:00", "startTimeB": "13:00"}, {"weekday": "Martes", "endTimeA": "12:00", "endTimeB": "18:00", "weekdayEn": "tuesday", "startTimeA": "08:00", "startTimeB": "13:00"}, {"weekday": "Miércoles", "endTimeA": "12:00", "endTimeB": "18:00", "weekdayEn": "wednesday", "startTimeA": "08:00", "startTimeB": "13:00"}, {"weekday": "Jueves", "endTimeA": "12:00", "endTimeB": "18:00", "weekdayEn": "thursday", "startTimeA": "08:00", "startTimeB": "13:00"}, {"weekday": "Viernes", "endTimeA": "12:00", "endTimeB": "18:00", "weekdayEn": "friday", "startTimeA": "08:00", "startTimeB": "13:00"}, {"weekday": "Sábado", "endTimeA": "12:00", "endTimeB": "18:00", "weekdayEn": "saturday", "startTimeA": "08:00", "startTimeB": "13:00"}, {"weekday": "Domingo", "endTimeA": "12:00", "endTimeB": "18:00", "weekdayEn": "sunday", "startTimeA": "08:00", "startTimeB": "13:00"}]				\N	\N	\N	\N	f	\N	\N	\N	f	f	automatic	\N	\N
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.appointments (id, title, description, start_datetime, duration_minutes, status, schedule_id, service_id, client_id, contact_id, company_id, created_at, updated_at, google_event_id) FROM stdin;
\.


--
-- Data for Name: company_api_keys; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.company_api_keys (id, company_id, label, token, webhook_url, webhook_secret, active, last_used_at, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: company_integration_field_maps; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.company_integration_field_maps (id, integration_id, external_field, crm_field, transform_expression, options, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: company_integration_settings; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.company_integration_settings (id, company_id, name, provider, base_url, api_key, api_secret, webhook_secret, metadata, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: company_payment_settings; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.company_payment_settings (id, company_id, provider, token, additional_data, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: crm_client_contacts; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.crm_client_contacts (id, client_id, contact_id, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: crm_clients; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.crm_clients (id, company_id, type, name, company_name, document, birth_date, email, phone, zip_code, address, number, complement, neighborhood, city, state, status, client_since, owner_user_id, notes, created_at, updated_at, contact_id, primary_ticket_id, asaas_customer_id, lid) FROM stdin;
\.


--
-- Data for Name: crm_leads; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.crm_leads (id, company_id, name, email, phone, birth_date, document, company_name, "position", source, campaign, medium, status, score, temperature, owner_user_id, notes, last_activity_at, created_at, updated_at, contact_id, primary_ticket_id, converted_client_id, converted_at, lead_status, lid) FROM stdin;
1291	1	Contato sem nome	\N	5550489520312	\N	\N	\N	\N	\N	\N	\N	new	0	\N	\N	\N	2026-02-10 21:59:34.134-06	2026-02-10 21:59:34.1-06	2026-02-10 21:59:34.135-06	2615	\N	\N	\N	novo	\N
1296	1	✨️𝐼𝑎𝑛 𝑑𝑎𝑣𝑖𝑙𝑎✨️	\N	50432077133	\N	\N	\N	\N	\N	\N	\N	new	0	\N	\N	\N	2026-02-10 23:01:50.739-06	2026-02-10 23:01:26.311-06	2026-02-10 23:01:50.74-06	2620	\N	\N	\N	novo	\N
\.


--
-- Data for Name: financeiro_faturas; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.financeiro_faturas (id, company_id, client_id, descricao, valor, status, data_vencimento, data_pagamento, tipo_referencia, referencia_id, tipo_recorrencia, quantidade_ciclos, ciclo_atual, data_inicio, data_fim, ativa, observacoes, created_at, updated_at, valor_pago, payment_provider, payment_link, payment_external_id, checkout_token, project_id) FROM stdin;
\.


--
-- Data for Name: financeiro_pagamentos; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.financeiro_pagamentos (id, company_id, fatura_id, metodo_pagamento, valor, data_pagamento, observacoes, created_at) FROM stdin;
\.


--
-- Data for Name: media_files; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.media_files (id, folder_id, company_id, original_name, custom_name, mime_type, size, storage_path, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: media_folders; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.media_folders (id, name, description, company_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: profissionais; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.profissionais (id, "companyId", nome, servicos, agenda, ativo, comissao, "valorEmAberto", "valoresRecebidos", "valoresAReceber", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: project_products; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.project_products (id, "companyId", "projectId", "productId", quantity, "unitPrice", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: project_services; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.project_services (id, "companyId", "projectId", "serviceId", quantity, "unitPrice", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: project_task_users; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.project_task_users (id, "companyId", "taskId", "userId", responsibility, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: project_tasks; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.project_tasks (id, "companyId", "projectId", title, description, status, "order", "startDate", "dueDate", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: project_users; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.project_users (id, "companyId", "projectId", "userId", role, "effortAllocation", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.projects (id, "companyId", "clientId", "invoiceId", name, description, "deliveryTime", warranty, terms, status, "startDate", "endDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: scheduled_dispatch_logs; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.scheduled_dispatch_logs (id, dispatcher_id, contact_id, ticket_id, company_id, status, error_message, sent_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scheduled_dispatchers; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.scheduled_dispatchers (id, company_id, title, message_template, event_type, whatsapp_id, start_time, send_interval_seconds, days_before_due, days_after_due, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: servicos; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.servicos (id, "companyId", nome, descricao, "valorOriginal", "possuiDesconto", "valorComDesconto", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: slider_home; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.slider_home (id, name, image, "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tutorial_videos; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.tutorial_videos (id, title, description, video_url, thumbnail_url, company_id, user_id, is_active, views_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_schedules; Type: TABLE DATA; Schema: public; Owner: whaticket
--

COPY public.user_schedules (id, name, description, active, user_id, company_id, created_at, updated_at, user_google_calendar_integration_id) FROM stdin;
\.


--
-- Name: Announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Announcements_id_seq"', 1, true);


--
-- Name: ApiUsages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."ApiUsages_id_seq"', 4, true);


--
-- Name: AutomationActions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."AutomationActions_id_seq"', 7, true);


--
-- Name: AutomationExecutions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."AutomationExecutions_id_seq"', 1, false);


--
-- Name: AutomationLogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."AutomationLogs_id_seq"', 1, false);


--
-- Name: Automations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Automations_id_seq"', 5, true);


--
-- Name: Baileys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Baileys_id_seq"', 3585, true);


--
-- Name: CampaignSettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."CampaignSettings_id_seq"', 16, true);


--
-- Name: CampaignShipping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."CampaignShipping_id_seq"', 594, true);


--
-- Name: Campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Campaigns_id_seq"', 28, true);


--
-- Name: ChatMessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."ChatMessages_id_seq"', 9, true);


--
-- Name: ChatUsers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."ChatUsers_id_seq"', 11, true);


--
-- Name: Chatbots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Chatbots_id_seq"', 1, false);


--
-- Name: Chats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Chats_id_seq"', 4, true);


--
-- Name: CompaniesSettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."CompaniesSettings_id_seq"', 106, true);


--
-- Name: Companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Companies_id_seq"', 145, true);


--
-- Name: ContactCustomFields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."ContactCustomFields_id_seq"', 10, true);


--
-- Name: ContactGroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."ContactGroups_id_seq"', 1, false);


--
-- Name: ContactListItems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."ContactListItems_id_seq"', 599, true);


--
-- Name: ContactLists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."ContactLists_id_seq"', 32, true);


--
-- Name: ContactWallets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."ContactWallets_id_seq"', 1, false);


--
-- Name: Contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Contacts_id_seq"', 2620, true);


--
-- Name: DialogChatBots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."DialogChatBots_id_seq"', 1, false);


--
-- Name: Faturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Faturas_id_seq"', 3, true);


--
-- Name: Ferramentas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Ferramentas_id_seq"', 15, true);


--
-- Name: FilesOptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."FilesOptions_id_seq"', 3, true);


--
-- Name: Files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Files_id_seq"', 3, true);


--
-- Name: FlowAudios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."FlowAudios_id_seq"', 1, false);


--
-- Name: FlowBuilders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."FlowBuilders_id_seq"', 63, true);


--
-- Name: FlowCampaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."FlowCampaigns_id_seq"', 4, true);


--
-- Name: FlowDefaults_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."FlowDefaults_id_seq"', 1, false);


--
-- Name: FlowImgs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."FlowImgs_id_seq"', 18, true);


--
-- Name: GoogleCalendarIntegrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."GoogleCalendarIntegrations_id_seq"', 12, true);


--
-- Name: GoogleSheetsTokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."GoogleSheetsTokens_id_seq"', 1, false);


--
-- Name: Helps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Helps_id_seq"', 1, false);


--
-- Name: IaWorkflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."IaWorkflows_id_seq"', 32, true);


--
-- Name: Integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Integrations_id_seq"', 1, false);


--
-- Name: Invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Invoices_id_seq"', 121, true);


--
-- Name: LogTickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."LogTickets_id_seq"', 11653, true);


--
-- Name: MediaFiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."MediaFiles_id_seq"', 1, false);


--
-- Name: MediaFolders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."MediaFolders_id_seq"', 1, false);


--
-- Name: Messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Messages_id_seq"', 21520, true);


--
-- Name: MobileWebhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."MobileWebhooks_id_seq"', 1, false);


--
-- Name: Negocios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Negocios_id_seq"', 32, true);


--
-- Name: Partners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Partners_id_seq"', 1, false);


--
-- Name: Plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Plans_id_seq"', 5, true);


--
-- Name: Produtos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Produtos_id_seq"', 21, true);


--
-- Name: PromptToolSettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."PromptToolSettings_id_seq"', 853, true);


--
-- Name: Prompts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Prompts_id_seq"', 21, true);


--
-- Name: QueueIntegrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."QueueIntegrations_id_seq"', 13, true);


--
-- Name: QueueOptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."QueueOptions_id_seq"', 1, false);


--
-- Name: Queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Queues_id_seq"', 54, true);


--
-- Name: QuickMessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."QuickMessages_id_seq"', 14, true);


--
-- Name: ScheduledMessagesEnvios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."ScheduledMessagesEnvios_id_seq"', 1, false);


--
-- Name: ScheduledMessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."ScheduledMessages_id_seq"', 1, false);


--
-- Name: Schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Schedules_id_seq"', 32, true);


--
-- Name: Settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Settings_id_seq"', 151, true);


--
-- Name: SliderBanners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."SliderBanners_id_seq"', 1, false);


--
-- Name: Subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Subscriptions_id_seq"', 1, true);


--
-- Name: Tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Tags_id_seq"', 107, true);


--
-- Name: TicketNotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."TicketNotes_id_seq"', 37, true);


--
-- Name: TicketTraking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."TicketTraking_id_seq"', 2305, true);


--
-- Name: Tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Tickets_id_seq"', 1829, true);


--
-- Name: UserDevices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."UserDevices_id_seq"', 1, false);


--
-- Name: UserGoogleCalendarIntegrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."UserGoogleCalendarIntegrations_id_seq"', 5, true);


--
-- Name: UserRatings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."UserRatings_id_seq"', 9, true);


--
-- Name: UserServices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."UserServices_id_seq"', 5, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Users_id_seq"', 146, true);


--
-- Name: Versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Versions_id_seq"', 1, false);


--
-- Name: Webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Webhooks_id_seq"', 13, true);


--
-- Name: Whatsapps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public."Whatsapps_id_seq"', 138, true);


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.appointments_id_seq', 21, true);


--
-- Name: company_api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.company_api_keys_id_seq', 1, true);


--
-- Name: company_integration_field_maps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.company_integration_field_maps_id_seq', 1, false);


--
-- Name: company_integration_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.company_integration_settings_id_seq', 1, false);


--
-- Name: company_payment_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.company_payment_settings_id_seq', 4, true);


--
-- Name: crm_client_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.crm_client_contacts_id_seq', 14, true);


--
-- Name: crm_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.crm_clients_id_seq', 23, true);


--
-- Name: crm_leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.crm_leads_id_seq', 1296, true);


--
-- Name: financeiro_faturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.financeiro_faturas_id_seq', 15, true);


--
-- Name: financeiro_pagamentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.financeiro_pagamentos_id_seq', 6, true);


--
-- Name: media_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.media_files_id_seq', 1, false);


--
-- Name: media_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.media_folders_id_seq', 1, false);


--
-- Name: profissionais_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.profissionais_id_seq', 2, true);


--
-- Name: project_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.project_products_id_seq', 3, true);


--
-- Name: project_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.project_services_id_seq', 3, true);


--
-- Name: project_task_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.project_task_users_id_seq', 4, true);


--
-- Name: project_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.project_tasks_id_seq', 8, true);


--
-- Name: project_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.project_users_id_seq', 7, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.projects_id_seq', 6, true);


--
-- Name: scheduled_dispatch_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.scheduled_dispatch_logs_id_seq', 1, true);


--
-- Name: scheduled_dispatchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.scheduled_dispatchers_id_seq', 2, true);


--
-- Name: servicos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.servicos_id_seq', 7, true);


--
-- Name: slider_home_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.slider_home_id_seq', 8, true);


--
-- Name: tutorial_videos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.tutorial_videos_id_seq', 5, true);


--
-- Name: user_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: whaticket
--

SELECT pg_catalog.setval('public.user_schedules_id_seq', 6, true);


--
-- Name: Announcements Announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Announcements"
    ADD CONSTRAINT "Announcements_pkey" PRIMARY KEY (id);


--
-- Name: ApiUsages ApiUsages_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ApiUsages"
    ADD CONSTRAINT "ApiUsages_pkey" PRIMARY KEY (id);


--
-- Name: AutomationActions AutomationActions_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationActions"
    ADD CONSTRAINT "AutomationActions_pkey" PRIMARY KEY (id);


--
-- Name: AutomationExecutions AutomationExecutions_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationExecutions"
    ADD CONSTRAINT "AutomationExecutions_pkey" PRIMARY KEY (id);


--
-- Name: AutomationLogs AutomationLogs_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationLogs"
    ADD CONSTRAINT "AutomationLogs_pkey" PRIMARY KEY (id);


--
-- Name: Automations Automations_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Automations"
    ADD CONSTRAINT "Automations_pkey" PRIMARY KEY (id);


--
-- Name: Baileys Baileys_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Baileys"
    ADD CONSTRAINT "Baileys_pkey" PRIMARY KEY (id, "whatsappId");


--
-- Name: CampaignSettings CampaignSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."CampaignSettings"
    ADD CONSTRAINT "CampaignSettings_pkey" PRIMARY KEY (id);


--
-- Name: CampaignShipping CampaignShipping_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."CampaignShipping"
    ADD CONSTRAINT "CampaignShipping_pkey" PRIMARY KEY (id);


--
-- Name: Campaigns Campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_pkey" PRIMARY KEY (id);


--
-- Name: ChatMessages ChatMessages_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_pkey" PRIMARY KEY (id);


--
-- Name: ChatUsers ChatUsers_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ChatUsers"
    ADD CONSTRAINT "ChatUsers_pkey" PRIMARY KEY (id);


--
-- Name: Chatbots Chatbots_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_pkey" PRIMARY KEY (id);


--
-- Name: Chats Chats_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chats"
    ADD CONSTRAINT "Chats_pkey" PRIMARY KEY (id);


--
-- Name: CompaniesSettings CompaniesSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."CompaniesSettings"
    ADD CONSTRAINT "CompaniesSettings_pkey" PRIMARY KEY (id);


--
-- Name: Companies Companies_name_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_name_key" UNIQUE (name);


--
-- Name: Companies Companies_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_pkey" PRIMARY KEY (id);


--
-- Name: ContactCustomFields ContactCustomFields_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactCustomFields"
    ADD CONSTRAINT "ContactCustomFields_pkey" PRIMARY KEY (id);


--
-- Name: ContactGroups ContactGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactGroups"
    ADD CONSTRAINT "ContactGroups_pkey" PRIMARY KEY (id);


--
-- Name: ContactListItems ContactListItems_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactListItems"
    ADD CONSTRAINT "ContactListItems_pkey" PRIMARY KEY (id);


--
-- Name: ContactLists ContactLists_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactLists"
    ADD CONSTRAINT "ContactLists_pkey" PRIMARY KEY (id);


--
-- Name: ContactWallets ContactWallets_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactWallets"
    ADD CONSTRAINT "ContactWallets_pkey" PRIMARY KEY (id);


--
-- Name: Contacts Contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT "Contacts_pkey" PRIMARY KEY (id);


--
-- Name: DialogChatBots DialogChatBots_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."DialogChatBots"
    ADD CONSTRAINT "DialogChatBots_pkey" PRIMARY KEY (id);


--
-- Name: Faturas Faturas_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Faturas"
    ADD CONSTRAINT "Faturas_pkey" PRIMARY KEY (id);


--
-- Name: Ferramentas Ferramentas_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Ferramentas"
    ADD CONSTRAINT "Ferramentas_pkey" PRIMARY KEY (id);


--
-- Name: FilesOptions FilesOptions_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FilesOptions"
    ADD CONSTRAINT "FilesOptions_pkey" PRIMARY KEY (id);


--
-- Name: Files Files_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT "Files_pkey" PRIMARY KEY (id);


--
-- Name: FlowAudios FlowAudios_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FlowAudios"
    ADD CONSTRAINT "FlowAudios_pkey" PRIMARY KEY (id);


--
-- Name: FlowBuilders FlowBuilders_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FlowBuilders"
    ADD CONSTRAINT "FlowBuilders_pkey" PRIMARY KEY (id);


--
-- Name: FlowCampaigns FlowCampaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FlowCampaigns"
    ADD CONSTRAINT "FlowCampaigns_pkey" PRIMARY KEY (id);


--
-- Name: FlowDefaults FlowDefaults_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FlowDefaults"
    ADD CONSTRAINT "FlowDefaults_pkey" PRIMARY KEY (id);


--
-- Name: FlowImgs FlowImgs_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FlowImgs"
    ADD CONSTRAINT "FlowImgs_pkey" PRIMARY KEY (id);


--
-- Name: GoogleCalendarIntegrations GoogleCalendarIntegrations_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."GoogleCalendarIntegrations"
    ADD CONSTRAINT "GoogleCalendarIntegrations_pkey" PRIMARY KEY (id);


--
-- Name: GoogleSheetsTokens GoogleSheetsTokens_companyId_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."GoogleSheetsTokens"
    ADD CONSTRAINT "GoogleSheetsTokens_companyId_key" UNIQUE ("companyId");


--
-- Name: GoogleSheetsTokens GoogleSheetsTokens_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."GoogleSheetsTokens"
    ADD CONSTRAINT "GoogleSheetsTokens_pkey" PRIMARY KEY (id);


--
-- Name: Helps Helps_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Helps"
    ADD CONSTRAINT "Helps_pkey" PRIMARY KEY (id);


--
-- Name: IaWorkflows IaWorkflows_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."IaWorkflows"
    ADD CONSTRAINT "IaWorkflows_pkey" PRIMARY KEY (id);


--
-- Name: Integrations Integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Integrations"
    ADD CONSTRAINT "Integrations_pkey" PRIMARY KEY (id);


--
-- Name: Invoices Invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Invoices"
    ADD CONSTRAINT "Invoices_pkey" PRIMARY KEY (id);


--
-- Name: LogTickets LogTickets_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."LogTickets"
    ADD CONSTRAINT "LogTickets_pkey" PRIMARY KEY (id);


--
-- Name: MediaFiles MediaFiles_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."MediaFiles"
    ADD CONSTRAINT "MediaFiles_pkey" PRIMARY KEY (id);


--
-- Name: MediaFolders MediaFolders_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."MediaFolders"
    ADD CONSTRAINT "MediaFolders_pkey" PRIMARY KEY (id);


--
-- Name: Messages Messages_id_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_id_key" UNIQUE (id);


--
-- Name: Messages Messages_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_pkey" PRIMARY KEY (id);


--
-- Name: MobileWebhooks MobileWebhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."MobileWebhooks"
    ADD CONSTRAINT "MobileWebhooks_pkey" PRIMARY KEY (id);


--
-- Name: Negocios Negocios_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Negocios"
    ADD CONSTRAINT "Negocios_pkey" PRIMARY KEY (id);


--
-- Name: Partners Partners_document_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Partners"
    ADD CONSTRAINT "Partners_document_key" UNIQUE (document);


--
-- Name: Partners Partners_name_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Partners"
    ADD CONSTRAINT "Partners_name_key" UNIQUE (name);


--
-- Name: Partners Partners_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Partners"
    ADD CONSTRAINT "Partners_pkey" PRIMARY KEY (id);


--
-- Name: Plans Plans_name_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Plans"
    ADD CONSTRAINT "Plans_name_key" UNIQUE (name);


--
-- Name: Plans Plans_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Plans"
    ADD CONSTRAINT "Plans_pkey" PRIMARY KEY (id);


--
-- Name: Produtos Produtos_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Produtos"
    ADD CONSTRAINT "Produtos_pkey" PRIMARY KEY (id);


--
-- Name: PromptToolSettings PromptToolSettings_company_prompt_tool_unique; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."PromptToolSettings"
    ADD CONSTRAINT "PromptToolSettings_company_prompt_tool_unique" UNIQUE ("companyId", "promptId", "toolName");


--
-- Name: PromptToolSettings PromptToolSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."PromptToolSettings"
    ADD CONSTRAINT "PromptToolSettings_pkey" PRIMARY KEY (id);


--
-- Name: Prompts Prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Prompts"
    ADD CONSTRAINT "Prompts_pkey" PRIMARY KEY (id);


--
-- Name: QueueIntegrations QueueIntegrations_name_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QueueIntegrations"
    ADD CONSTRAINT "QueueIntegrations_name_key" UNIQUE (name);


--
-- Name: QueueIntegrations QueueIntegrations_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QueueIntegrations"
    ADD CONSTRAINT "QueueIntegrations_pkey" PRIMARY KEY (id);


--
-- Name: QueueIntegrations QueueIntegrations_projectName_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QueueIntegrations"
    ADD CONSTRAINT "QueueIntegrations_projectName_key" UNIQUE ("projectName");


--
-- Name: QueueOptions QueueOptions_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QueueOptions"
    ADD CONSTRAINT "QueueOptions_pkey" PRIMARY KEY (id);


--
-- Name: Queues Queues_color_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_color_key" UNIQUE (color, "companyId");


--
-- Name: Queues Queues_name_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_name_key" UNIQUE (name, "companyId");


--
-- Name: Queues Queues_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_pkey" PRIMARY KEY (id);


--
-- Name: QuickMessages QuickMessages_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QuickMessages"
    ADD CONSTRAINT "QuickMessages_pkey" PRIMARY KEY (id);


--
-- Name: ScheduledMessagesEnvios ScheduledMessagesEnvios_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ScheduledMessagesEnvios"
    ADD CONSTRAINT "ScheduledMessagesEnvios_pkey" PRIMARY KEY (id);


--
-- Name: ScheduledMessages ScheduledMessages_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ScheduledMessages"
    ADD CONSTRAINT "ScheduledMessages_pkey" PRIMARY KEY (id);


--
-- Name: Schedules Schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_pkey" PRIMARY KEY (id);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: SliderBanners SliderBanners_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."SliderBanners"
    ADD CONSTRAINT "SliderBanners_pkey" PRIMARY KEY (id);


--
-- Name: Subscriptions Subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Subscriptions"
    ADD CONSTRAINT "Subscriptions_pkey" PRIMARY KEY (id);


--
-- Name: Tags Tags_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tags"
    ADD CONSTRAINT "Tags_pkey" PRIMARY KEY (id);


--
-- Name: TicketNotes TicketNotes_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_pkey" PRIMARY KEY (id);


--
-- Name: TicketTraking TicketTraking_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_pkey" PRIMARY KEY (id);


--
-- Name: Tickets Tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_pkey" PRIMARY KEY (id);


--
-- Name: UserDevices UserDevices_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserDevices"
    ADD CONSTRAINT "UserDevices_pkey" PRIMARY KEY (id);


--
-- Name: UserDevices UserDevices_userId_deviceToken_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserDevices"
    ADD CONSTRAINT "UserDevices_userId_deviceToken_key" UNIQUE ("userId", "deviceToken");


--
-- Name: UserGoogleCalendarIntegrations UserGoogleCalendarIntegrations_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserGoogleCalendarIntegrations"
    ADD CONSTRAINT "UserGoogleCalendarIntegrations_pkey" PRIMARY KEY (id);


--
-- Name: UserQueues UserQueues_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserQueues"
    ADD CONSTRAINT "UserQueues_pkey" PRIMARY KEY ("userId", "queueId");


--
-- Name: UserRatings UserRatings_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_pkey" PRIMARY KEY (id);


--
-- Name: UserServices UserServices_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserServices"
    ADD CONSTRAINT "UserServices_pkey" PRIMARY KEY (id);


--
-- Name: UserServices UserServices_userId_serviceId_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserServices"
    ADD CONSTRAINT "UserServices_userId_serviceId_key" UNIQUE ("userId", "serviceId");


--
-- Name: Users Users_email_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key" UNIQUE (email);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: Versions Versions_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Versions"
    ADD CONSTRAINT "Versions_pkey" PRIMARY KEY (id);


--
-- Name: Webhooks Webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Webhooks"
    ADD CONSTRAINT "Webhooks_pkey" PRIMARY KEY (id);


--
-- Name: WhatsappQueues WhatsappQueues_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."WhatsappQueues"
    ADD CONSTRAINT "WhatsappQueues_pkey" PRIMARY KEY ("whatsappId", "queueId");


--
-- Name: Whatsapps Whatsapps_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_pkey" PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: company_api_keys company_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_api_keys
    ADD CONSTRAINT company_api_keys_pkey PRIMARY KEY (id);


--
-- Name: company_api_keys company_api_keys_token_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_api_keys
    ADD CONSTRAINT company_api_keys_token_key UNIQUE (token);


--
-- Name: company_integration_field_maps company_integration_field_maps_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_integration_field_maps
    ADD CONSTRAINT company_integration_field_maps_pkey PRIMARY KEY (id);


--
-- Name: company_integration_settings company_integration_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_integration_settings
    ADD CONSTRAINT company_integration_settings_pkey PRIMARY KEY (id);


--
-- Name: company_payment_settings company_payment_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_payment_settings
    ADD CONSTRAINT company_payment_settings_pkey PRIMARY KEY (id);


--
-- Name: Tickets contactid_companyid_whatsappid_unique; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT contactid_companyid_whatsappid_unique UNIQUE (id, "contactId", "companyId", "whatsappId");


--
-- Name: Contacts contacts_company_number_unique; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT contacts_company_number_unique UNIQUE ("companyId", number);


--
-- Name: crm_client_contacts crm_client_contacts_client_id_contact_id_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_client_contacts
    ADD CONSTRAINT crm_client_contacts_client_id_contact_id_key UNIQUE (client_id, contact_id);


--
-- Name: crm_client_contacts crm_client_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_client_contacts
    ADD CONSTRAINT crm_client_contacts_pkey PRIMARY KEY (id);


--
-- Name: crm_clients crm_clients_company_id_document_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_company_id_document_key UNIQUE (company_id, document);


--
-- Name: crm_clients crm_clients_company_id_document_unique; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_company_id_document_unique UNIQUE (company_id, document);


--
-- Name: crm_clients crm_clients_company_id_email_unique; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_company_id_email_unique UNIQUE (company_id, email);


--
-- Name: crm_clients crm_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_pkey PRIMARY KEY (id);


--
-- Name: crm_leads crm_leads_company_id_email_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_company_id_email_key UNIQUE (company_id, email);


--
-- Name: crm_leads crm_leads_company_id_email_unique; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_company_id_email_unique UNIQUE (company_id, email);


--
-- Name: crm_leads crm_leads_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_pkey PRIMARY KEY (id);


--
-- Name: financeiro_faturas financeiro_faturas_id_company_unique; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.financeiro_faturas
    ADD CONSTRAINT financeiro_faturas_id_company_unique UNIQUE (id, company_id);


--
-- Name: financeiro_faturas financeiro_faturas_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.financeiro_faturas
    ADD CONSTRAINT financeiro_faturas_pkey PRIMARY KEY (id);


--
-- Name: financeiro_pagamentos financeiro_pagamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.financeiro_pagamentos
    ADD CONSTRAINT financeiro_pagamentos_pkey PRIMARY KEY (id);


--
-- Name: media_files media_files_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_pkey PRIMARY KEY (id);


--
-- Name: media_folders media_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.media_folders
    ADD CONSTRAINT media_folders_pkey PRIMARY KEY (id);


--
-- Name: Contacts number_companyid_unique; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT number_companyid_unique UNIQUE (number, "companyId");


--
-- Name: profissionais profissionais_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.profissionais
    ADD CONSTRAINT profissionais_pkey PRIMARY KEY (id);


--
-- Name: project_products project_products_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_products
    ADD CONSTRAINT project_products_pkey PRIMARY KEY (id);


--
-- Name: project_services project_services_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_services
    ADD CONSTRAINT project_services_pkey PRIMARY KEY (id);


--
-- Name: project_task_users project_task_users_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_task_users
    ADD CONSTRAINT project_task_users_pkey PRIMARY KEY (id);


--
-- Name: project_tasks project_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_pkey PRIMARY KEY (id);


--
-- Name: project_users project_users_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_users
    ADD CONSTRAINT project_users_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: scheduled_dispatch_logs scheduled_dispatch_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.scheduled_dispatch_logs
    ADD CONSTRAINT scheduled_dispatch_logs_pkey PRIMARY KEY (id);


--
-- Name: scheduled_dispatchers scheduled_dispatchers_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.scheduled_dispatchers
    ADD CONSTRAINT scheduled_dispatchers_pkey PRIMARY KEY (id);


--
-- Name: servicos servicos_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.servicos
    ADD CONSTRAINT servicos_pkey PRIMARY KEY (id);


--
-- Name: slider_home slider_home_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.slider_home
    ADD CONSTRAINT slider_home_pkey PRIMARY KEY (id);


--
-- Name: tutorial_videos tutorial_videos_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.tutorial_videos
    ADD CONSTRAINT tutorial_videos_pkey PRIMARY KEY (id);


--
-- Name: user_schedules user_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.user_schedules
    ADD CONSTRAINT user_schedules_pkey PRIMARY KEY (id);


--
-- Name: user_schedules user_schedules_user_id_key; Type: CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.user_schedules
    ADD CONSTRAINT user_schedules_user_id_key UNIQUE (user_id);


--
-- Name: MediaFiles_company_id_idx; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "MediaFiles_company_id_idx" ON public."MediaFiles" USING btree (company_id);


--
-- Name: MediaFiles_folder_id_idx; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "MediaFiles_folder_id_idx" ON public."MediaFiles" USING btree (folder_id);


--
-- Name: MediaFolders_company_id_idx; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "MediaFolders_company_id_idx" ON public."MediaFolders" USING btree (company_id);


--
-- Name: automation_actions_automation_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automation_actions_automation_id ON public."AutomationActions" USING btree ("automationId");


--
-- Name: automation_actions_order; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automation_actions_order ON public."AutomationActions" USING btree ("order");


--
-- Name: automation_executions_automation_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automation_executions_automation_id ON public."AutomationExecutions" USING btree ("automationId");


--
-- Name: automation_executions_contact_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automation_executions_contact_id ON public."AutomationExecutions" USING btree ("contactId");


--
-- Name: automation_executions_scheduled_at; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automation_executions_scheduled_at ON public."AutomationExecutions" USING btree ("scheduledAt");


--
-- Name: automation_executions_status; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automation_executions_status ON public."AutomationExecutions" USING btree (status);


--
-- Name: automation_logs_automation_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automation_logs_automation_id ON public."AutomationLogs" USING btree ("automationId");


--
-- Name: automation_logs_contact_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automation_logs_contact_id ON public."AutomationLogs" USING btree ("contactId");


--
-- Name: automation_logs_executed_at; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automation_logs_executed_at ON public."AutomationLogs" USING btree ("executedAt");


--
-- Name: automation_logs_status; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automation_logs_status ON public."AutomationLogs" USING btree (status);


--
-- Name: automation_logs_ticket_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automation_logs_ticket_id ON public."AutomationLogs" USING btree ("ticketId");


--
-- Name: automations_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automations_company_id ON public."Automations" USING btree ("companyId");


--
-- Name: automations_is_active; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automations_is_active ON public."Automations" USING btree ("isActive");


--
-- Name: automations_trigger_type; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX automations_trigger_type ON public."Automations" USING btree ("triggerType");


--
-- Name: company_api_keys_company_active; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX company_api_keys_company_active ON public.company_api_keys USING btree (company_id, active);


--
-- Name: company_integration_field_maps_unique; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE UNIQUE INDEX company_integration_field_maps_unique ON public.company_integration_field_maps USING btree (integration_id, external_field);


--
-- Name: company_integration_settings_company_name; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE UNIQUE INDEX company_integration_settings_company_name ON public.company_integration_settings USING btree (company_id, name);


--
-- Name: company_payment_settings_company_provider; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE UNIQUE INDEX company_payment_settings_company_provider ON public.company_payment_settings USING btree (company_id, provider);


--
-- Name: contacts_lid_index; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX contacts_lid_index ON public."Contacts" USING btree (lid);


--
-- Name: crm_clients_asaas_customer_id_idx; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE UNIQUE INDEX crm_clients_asaas_customer_id_idx ON public.crm_clients USING btree (asaas_customer_id) WHERE (asaas_customer_id IS NOT NULL);


--
-- Name: financeiro_faturas_checkout_token_idx; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE UNIQUE INDEX financeiro_faturas_checkout_token_idx ON public.financeiro_faturas USING btree (checkout_token) WHERE (checkout_token IS NOT NULL);


--
-- Name: google_calendar_integrations_company_user_unique; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE UNIQUE INDEX google_calendar_integrations_company_user_unique ON public."GoogleCalendarIntegrations" USING btree ("companyId", "userId");


--
-- Name: idx_ContactCustomFields_contact_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_ContactCustomFields_contact_id" ON public."ContactCustomFields" USING btree ("contactId");


--
-- Name: idx_LogTickets_ticket_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_LogTickets_ticket_id" ON public."LogTickets" USING btree ("ticketId");


--
-- Name: idx_Messages_contact_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_Messages_contact_id" ON public."Messages" USING btree ("contactId");


--
-- Name: idx_TicketTags_tag_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_TicketTags_tag_id" ON public."TicketTags" USING btree ("tagId");


--
-- Name: idx_TicketTags_ticket_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_TicketTags_ticket_id" ON public."TicketTags" USING btree ("ticketId");


--
-- Name: idx_TicketTraking_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_TicketTraking_company_id" ON public."TicketTraking" USING btree ("companyId");


--
-- Name: idx_TicketTraking_ticket_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_TicketTraking_ticket_id" ON public."TicketTraking" USING btree ("ticketId");


--
-- Name: idx_appointments_google_event_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_appointments_google_event_id ON public.appointments USING btree (google_event_id);


--
-- Name: idx_client_contacts_contact; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_client_contacts_contact ON public.crm_client_contacts USING btree (contact_id);


--
-- Name: idx_clients_company; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_clients_company ON public.crm_clients USING btree (company_id);


--
-- Name: idx_clients_status; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_clients_status ON public.crm_clients USING btree (company_id, status);


--
-- Name: idx_cont_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_cont_company_id ON public."Contacts" USING btree ("companyId");


--
-- Name: idx_contactTag_contact_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_contactTag_contact_id" ON public."ContactTags" USING btree ("contactId");


--
-- Name: idx_contactTag_tagId; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_contactTag_tagId" ON public."ContactTags" USING btree ("tagId");


--
-- Name: idx_contactTag_tag_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_contactTag_tag_id" ON public."ContactTags" USING btree ("tagId");


--
-- Name: idx_contact_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_contact_company_id ON public."Contacts" USING btree ("companyId");


--
-- Name: idx_contact_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_contact_id ON public."Contacts" USING btree (id);


--
-- Name: idx_contact_name; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_contact_name ON public."Contacts" USING btree (name);


--
-- Name: idx_contact_number; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_contact_number ON public."Contacts" USING btree (number);


--
-- Name: idx_contact_whatsapp_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_contact_whatsapp_id ON public."Contacts" USING btree ("whatsappId");


--
-- Name: idx_cpsh_campaign_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_cpsh_campaign_id ON public."CampaignShipping" USING btree ("campaignId");


--
-- Name: idx_crm_clients_contact_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_crm_clients_contact_id ON public.crm_clients USING btree (contact_id);


--
-- Name: idx_crm_leads_contact_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_crm_leads_contact_id ON public.crm_leads USING btree (contact_id);


--
-- Name: idx_crm_leads_lead_status; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_crm_leads_lead_status ON public.crm_leads USING btree (lead_status);


--
-- Name: idx_ctli_contact_list_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_ctli_contact_list_id ON public."ContactListItems" USING btree ("contactListId");


--
-- Name: idx_faturas_company; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_faturas_company ON public.financeiro_faturas USING btree (company_id);


--
-- Name: idx_faturas_recorrencia; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_faturas_recorrencia ON public.financeiro_faturas USING btree (company_id, tipo_recorrencia, ativa);


--
-- Name: idx_faturas_status; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_faturas_status ON public.financeiro_faturas USING btree (company_id, status);


--
-- Name: idx_financeiro_faturas_company; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_financeiro_faturas_company ON public.financeiro_faturas USING btree (company_id);


--
-- Name: idx_financeiro_faturas_project_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_financeiro_faturas_project_id ON public.financeiro_faturas USING btree (project_id);


--
-- Name: idx_financeiro_faturas_recorrencia; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_financeiro_faturas_recorrencia ON public.financeiro_faturas USING btree (company_id, tipo_recorrencia, ativa);


--
-- Name: idx_financeiro_faturas_status; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_financeiro_faturas_status ON public.financeiro_faturas USING btree (company_id, status);


--
-- Name: idx_financeiro_pagamentos_company; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_financeiro_pagamentos_company ON public.financeiro_pagamentos USING btree (company_id);


--
-- Name: idx_flowbui_id_user_id_active; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_flowbui_id_user_id_active ON public."FlowBuilders" USING btree (id, user_id, active);


--
-- Name: idx_flowcamp_id_company_id_phrase; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_flowcamp_id_company_id_phrase ON public."FlowCampaigns" USING btree (id, "companyId", phrase);


--
-- Name: idx_flowdefa_id_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_flowdefa_id_company_id ON public."FlowDefaults" USING btree (id, "companyId");


--
-- Name: idx_leads_company; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_leads_company ON public.crm_leads USING btree (company_id);


--
-- Name: idx_leads_owner; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_leads_owner ON public.crm_leads USING btree (company_id, owner_user_id);


--
-- Name: idx_leads_status; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_leads_status ON public.crm_leads USING btree (company_id, status);


--
-- Name: idx_message_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_message_company_id ON public."Messages" USING btree ("companyId");


--
-- Name: idx_message_quoted_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_message_quoted_id ON public."Messages" USING btree ("quotedMsgId");


--
-- Name: idx_message_ticket_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_message_ticket_id ON public."Messages" USING btree ("ticketId");


--
-- Name: idx_messages_wid; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_messages_wid ON public."Messages" USING btree (wid);


--
-- Name: idx_ms_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_ms_company_id ON public."Messages" USING btree ("companyId");


--
-- Name: idx_ms_company_id_ticket_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_ms_company_id_ticket_id ON public."Messages" USING btree ("companyId", "ticketId");


--
-- Name: idx_queues_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_queues_id ON public."Queues" USING btree (id);


--
-- Name: idx_sched_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_sched_company_id ON public."Schedules" USING btree ("companyId");


--
-- Name: idx_tg_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_tg_company_id ON public."Tags" USING btree ("companyId");


--
-- Name: idx_ticket_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_ticket_company_id ON public."Tickets" USING btree ("companyId");


--
-- Name: idx_ticket_contact_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_ticket_contact_id ON public."Tickets" USING btree ("contactId");


--
-- Name: idx_ticket_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_ticket_id ON public."Tickets" USING btree (id);


--
-- Name: idx_ticket_queue_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_ticket_queue_id ON public."Tickets" USING btree ("queueId");


--
-- Name: idx_ticket_status; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_ticket_status ON public."Tickets" USING btree (status);


--
-- Name: idx_ticket_user_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_ticket_user_id ON public."Tickets" USING btree ("userId");


--
-- Name: idx_ticket_whatsapp_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_ticket_whatsapp_id ON public."Tickets" USING btree ("whatsappId");


--
-- Name: idx_tickets_crm_client_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_tickets_crm_client_id ON public."Tickets" USING btree (crm_client_id);


--
-- Name: idx_tickets_crm_lead_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_tickets_crm_lead_id ON public."Tickets" USING btree (crm_lead_id);


--
-- Name: idx_tutorial_videos_active; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_tutorial_videos_active ON public.tutorial_videos USING btree (is_active);


--
-- Name: idx_tutorial_videos_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_tutorial_videos_company_id ON public.tutorial_videos USING btree (company_id);


--
-- Name: idx_tutorial_videos_created_at; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_tutorial_videos_created_at ON public.tutorial_videos USING btree (created_at DESC);


--
-- Name: idx_tutorial_videos_user_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_tutorial_videos_user_id ON public.tutorial_videos USING btree (user_id);


--
-- Name: idx_user_devices_deviceToken; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_user_devices_deviceToken" ON public."UserDevices" USING btree ("deviceToken");


--
-- Name: idx_user_devices_userId; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX "idx_user_devices_userId" ON public."UserDevices" USING btree ("userId");


--
-- Name: idx_user_google_calendar_integrations_active; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_user_google_calendar_integrations_active ON public."UserGoogleCalendarIntegrations" USING btree (active);


--
-- Name: idx_user_google_calendar_integrations_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_user_google_calendar_integrations_company_id ON public."UserGoogleCalendarIntegrations" USING btree (company_id);


--
-- Name: idx_user_google_calendar_integrations_email; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_user_google_calendar_integrations_email ON public."UserGoogleCalendarIntegrations" USING btree (email);


--
-- Name: idx_user_schedules_google_calendar_integration_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_user_schedules_google_calendar_integration_id ON public.user_schedules USING btree (user_google_calendar_integration_id);


--
-- Name: idx_userratings_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_userratings_company_id ON public."UserRatings" USING btree ("companyId");


--
-- Name: idx_userratings_ticket_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX idx_userratings_ticket_id ON public."UserRatings" USING btree ("ticketId");


--
-- Name: media_files_company_id_idx; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX media_files_company_id_idx ON public.media_files USING btree (company_id);


--
-- Name: media_files_folder_id_idx; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX media_files_folder_id_idx ON public.media_files USING btree (folder_id);


--
-- Name: media_folders_company_id_idx; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX media_folders_company_id_idx ON public.media_folders USING btree (company_id);


--
-- Name: project_products_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX project_products_company_id ON public.project_products USING btree ("companyId");


--
-- Name: project_products_unique; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE UNIQUE INDEX project_products_unique ON public.project_products USING btree ("projectId", "productId");


--
-- Name: project_services_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX project_services_company_id ON public.project_services USING btree ("companyId");


--
-- Name: project_services_unique; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE UNIQUE INDEX project_services_unique ON public.project_services USING btree ("projectId", "serviceId");


--
-- Name: project_task_users_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX project_task_users_company_id ON public.project_task_users USING btree ("companyId");


--
-- Name: project_task_users_unique; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE UNIQUE INDEX project_task_users_unique ON public.project_task_users USING btree ("taskId", "userId");


--
-- Name: project_tasks_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX project_tasks_company_id ON public.project_tasks USING btree ("companyId");


--
-- Name: project_tasks_project_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX project_tasks_project_id ON public.project_tasks USING btree ("projectId");


--
-- Name: project_tasks_status; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX project_tasks_status ON public.project_tasks USING btree (status);


--
-- Name: project_users_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX project_users_company_id ON public.project_users USING btree ("companyId");


--
-- Name: project_users_unique; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE UNIQUE INDEX project_users_unique ON public.project_users USING btree ("projectId", "userId");


--
-- Name: projects_client_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX projects_client_id ON public.projects USING btree ("clientId");


--
-- Name: projects_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX projects_company_id ON public.projects USING btree ("companyId");


--
-- Name: projects_status; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX projects_status ON public.projects USING btree (status);


--
-- Name: scheduled_dispatch_logs_dispatcher_status; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX scheduled_dispatch_logs_dispatcher_status ON public.scheduled_dispatch_logs USING btree (dispatcher_id, status);


--
-- Name: scheduled_dispatchers_company_event; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX scheduled_dispatchers_company_event ON public.scheduled_dispatchers USING btree (company_id, event_type);


--
-- Name: tickets_uuid_idx; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX tickets_uuid_idx ON public."Tickets" USING btree (uuid);


--
-- Name: tutorial_videos_company_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX tutorial_videos_company_id ON public.tutorial_videos USING btree (company_id);


--
-- Name: tutorial_videos_is_active; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX tutorial_videos_is_active ON public.tutorial_videos USING btree (is_active);


--
-- Name: tutorial_videos_user_id; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE INDEX tutorial_videos_user_id ON public.tutorial_videos USING btree (user_id);


--
-- Name: user_google_calendar_integrations_user_id_unique; Type: INDEX; Schema: public; Owner: whaticket
--

CREATE UNIQUE INDEX user_google_calendar_integrations_user_id_unique ON public."UserGoogleCalendarIntegrations" USING btree (user_id);


--
-- Name: tutorial_videos trigger_tutorial_videos_updated_at; Type: TRIGGER; Schema: public; Owner: whaticket
--

CREATE TRIGGER trigger_tutorial_videos_updated_at BEFORE UPDATE ON public.tutorial_videos FOR EACH ROW EXECUTE FUNCTION public.update_tutorial_videos_updated_at();


--
-- Name: UserDevices update_user_device_updated_at_trigger; Type: TRIGGER; Schema: public; Owner: whaticket
--

CREATE TRIGGER update_user_device_updated_at_trigger BEFORE UPDATE ON public."UserDevices" FOR EACH ROW EXECUTE FUNCTION public.update_user_device_updated_at();


--
-- Name: UserGoogleCalendarIntegrations update_user_google_calendar_integrations_updated_at; Type: TRIGGER; Schema: public; Owner: whaticket
--

CREATE TRIGGER update_user_google_calendar_integrations_updated_at BEFORE UPDATE ON public."UserGoogleCalendarIntegrations" FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: Announcements Announcements_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Announcements"
    ADD CONSTRAINT "Announcements_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationActions AutomationActions_automationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationActions"
    ADD CONSTRAINT "AutomationActions_automationId_fkey" FOREIGN KEY ("automationId") REFERENCES public."Automations"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationExecutions AutomationExecutions_automationActionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationExecutions"
    ADD CONSTRAINT "AutomationExecutions_automationActionId_fkey" FOREIGN KEY ("automationActionId") REFERENCES public."AutomationActions"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationExecutions AutomationExecutions_automationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationExecutions"
    ADD CONSTRAINT "AutomationExecutions_automationId_fkey" FOREIGN KEY ("automationId") REFERENCES public."Automations"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationExecutions AutomationExecutions_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationExecutions"
    ADD CONSTRAINT "AutomationExecutions_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationExecutions AutomationExecutions_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationExecutions"
    ADD CONSTRAINT "AutomationExecutions_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AutomationLogs AutomationLogs_automationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationLogs"
    ADD CONSTRAINT "AutomationLogs_automationId_fkey" FOREIGN KEY ("automationId") REFERENCES public."Automations"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationLogs AutomationLogs_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationLogs"
    ADD CONSTRAINT "AutomationLogs_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AutomationLogs AutomationLogs_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."AutomationLogs"
    ADD CONSTRAINT "AutomationLogs_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Automations Automations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Automations"
    ADD CONSTRAINT "Automations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignSettings CampaignSettings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."CampaignSettings"
    ADD CONSTRAINT "CampaignSettings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignShipping CampaignShipping_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."CampaignShipping"
    ADD CONSTRAINT "CampaignShipping_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public."Campaigns"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignShipping CampaignShipping_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."CampaignShipping"
    ADD CONSTRAINT "CampaignShipping_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."ContactListItems"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Campaigns Campaigns_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Campaigns Campaigns_contactListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_contactListId_fkey" FOREIGN KEY ("contactListId") REFERENCES public."ContactLists"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Campaigns Campaigns_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Campaigns Campaigns_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Campaigns Campaigns_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: ChatMessages ChatMessages_chatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_chatId_fkey" FOREIGN KEY ("chatId") REFERENCES public."Chats"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatMessages ChatMessages_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatUsers ChatUsers_chatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ChatUsers"
    ADD CONSTRAINT "ChatUsers_chatId_fkey" FOREIGN KEY ("chatId") REFERENCES public."Chats"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatUsers ChatUsers_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ChatUsers"
    ADD CONSTRAINT "ChatUsers_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Chatbots Chatbots_chatbotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_chatbotId_fkey" FOREIGN KEY ("chatbotId") REFERENCES public."Chatbots"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Chatbots Chatbots_optFileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_optFileId_fkey" FOREIGN KEY ("optFileId") REFERENCES public."Files"(id);


--
-- Name: Chatbots Chatbots_optIntegrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_optIntegrationId_fkey" FOREIGN KEY ("optIntegrationId") REFERENCES public."QueueIntegrations"(id);


--
-- Name: Chatbots Chatbots_optQueueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_optQueueId_fkey" FOREIGN KEY ("optQueueId") REFERENCES public."Queues"(id);


--
-- Name: Chatbots Chatbots_optUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_optUserId_fkey" FOREIGN KEY ("optUserId") REFERENCES public."Users"(id);


--
-- Name: Chatbots Chatbots_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Chats Chats_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chats"
    ADD CONSTRAINT "Chats_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Chats Chats_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Chats"
    ADD CONSTRAINT "Chats_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CompaniesSettings CompaniesSettings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."CompaniesSettings"
    ADD CONSTRAINT "CompaniesSettings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Companies Companies_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plans"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ContactCustomFields ContactCustomFields_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactCustomFields"
    ADD CONSTRAINT "ContactCustomFields_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactListItems ContactListItems_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactListItems"
    ADD CONSTRAINT "ContactListItems_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactListItems ContactListItems_contactListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactListItems"
    ADD CONSTRAINT "ContactListItems_contactListId_fkey" FOREIGN KEY ("contactListId") REFERENCES public."ContactLists"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactLists ContactLists_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactLists"
    ADD CONSTRAINT "ContactLists_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactTags ContactTags_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactTags"
    ADD CONSTRAINT "ContactTags_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactTags ContactTags_tagId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactTags"
    ADD CONSTRAINT "ContactTags_tagId_fkey" FOREIGN KEY ("tagId") REFERENCES public."Tags"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactWallets ContactWallets_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactWallets"
    ADD CONSTRAINT "ContactWallets_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactWallets ContactWallets_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactWallets"
    ADD CONSTRAINT "ContactWallets_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactWallets ContactWallets_walletId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."ContactWallets"
    ADD CONSTRAINT "ContactWallets_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Contacts Contacts_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT "Contacts_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Contacts Contacts_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT "Contacts_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DialogChatBots DialogChatBots_chatbotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."DialogChatBots"
    ADD CONSTRAINT "DialogChatBots_chatbotId_fkey" FOREIGN KEY ("chatbotId") REFERENCES public."Chatbots"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DialogChatBots DialogChatBots_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."DialogChatBots"
    ADD CONSTRAINT "DialogChatBots_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DialogChatBots DialogChatBots_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."DialogChatBots"
    ADD CONSTRAINT "DialogChatBots_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Faturas Faturas_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Faturas"
    ADD CONSTRAINT "Faturas_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Faturas Faturas_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Faturas"
    ADD CONSTRAINT "Faturas_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Ferramentas Ferramentas_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Ferramentas"
    ADD CONSTRAINT "Ferramentas_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FilesOptions FilesOptions_fileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FilesOptions"
    ADD CONSTRAINT "FilesOptions_fileId_fkey" FOREIGN KEY ("fileId") REFERENCES public."Files"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Files Files_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT "Files_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FlowCampaigns FlowCampaigns_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."FlowCampaigns"
    ADD CONSTRAINT "FlowCampaigns_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: GoogleCalendarIntegrations GoogleCalendarIntegrations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."GoogleCalendarIntegrations"
    ADD CONSTRAINT "GoogleCalendarIntegrations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GoogleCalendarIntegrations GoogleCalendarIntegrations_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."GoogleCalendarIntegrations"
    ADD CONSTRAINT "GoogleCalendarIntegrations_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: GoogleSheetsTokens GoogleSheetsTokens_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."GoogleSheetsTokens"
    ADD CONSTRAINT "GoogleSheetsTokens_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Integrations Integrations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Integrations"
    ADD CONSTRAINT "Integrations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoices Invoices_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Invoices"
    ADD CONSTRAINT "Invoices_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LogTickets LogTickets_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."LogTickets"
    ADD CONSTRAINT "LogTickets_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LogTickets LogTickets_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."LogTickets"
    ADD CONSTRAINT "LogTickets_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LogTickets LogTickets_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."LogTickets"
    ADD CONSTRAINT "LogTickets_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MediaFiles MediaFiles_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."MediaFiles"
    ADD CONSTRAINT "MediaFiles_company_id_fkey" FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON DELETE CASCADE;


--
-- Name: MediaFiles MediaFiles_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."MediaFiles"
    ADD CONSTRAINT "MediaFiles_folder_id_fkey" FOREIGN KEY (folder_id) REFERENCES public."MediaFolders"(id) ON DELETE CASCADE;


--
-- Name: MediaFolders MediaFolders_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."MediaFolders"
    ADD CONSTRAINT "MediaFolders_company_id_fkey" FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON DELETE CASCADE;


--
-- Name: Messages Messages_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Messages Messages_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Messages Messages_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Messages Messages_quotedMsgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_quotedMsgId_fkey" FOREIGN KEY ("quotedMsgId") REFERENCES public."Messages"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Messages Messages_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Messages Messages_ticketTrakingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_ticketTrakingId_fkey" FOREIGN KEY ("ticketTrakingId") REFERENCES public."TicketTraking"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Messages Messages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MobileWebhooks MobileWebhooks_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."MobileWebhooks"
    ADD CONSTRAINT "MobileWebhooks_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MobileWebhooks MobileWebhooks_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."MobileWebhooks"
    ADD CONSTRAINT "MobileWebhooks_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Negocios Negocios_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Negocios"
    ADD CONSTRAINT "Negocios_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Produtos Produtos_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Produtos"
    ADD CONSTRAINT "Produtos_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PromptToolSettings PromptToolSettings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."PromptToolSettings"
    ADD CONSTRAINT "PromptToolSettings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PromptToolSettings PromptToolSettings_promptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."PromptToolSettings"
    ADD CONSTRAINT "PromptToolSettings_promptId_fkey" FOREIGN KEY ("promptId") REFERENCES public."Prompts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Prompts Prompts_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Prompts"
    ADD CONSTRAINT "Prompts_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id);


--
-- Name: Prompts Prompts_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Prompts"
    ADD CONSTRAINT "Prompts_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id);


--
-- Name: QueueIntegrations QueueIntegrations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QueueIntegrations"
    ADD CONSTRAINT "QueueIntegrations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: QueueOptions QueueOptions_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QueueOptions"
    ADD CONSTRAINT "QueueOptions_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."QueueOptions"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: QueueOptions QueueOptions_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QueueOptions"
    ADD CONSTRAINT "QueueOptions_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Queues Queues_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Queues Queues_fileListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_fileListId_fkey" FOREIGN KEY ("fileListId") REFERENCES public."Files"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Queues Queues_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public."QueueIntegrations"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: QuickMessages QuickMessages_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QuickMessages"
    ADD CONSTRAINT "QuickMessages_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: QuickMessages QuickMessages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."QuickMessages"
    ADD CONSTRAINT "QuickMessages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Schedules Schedules_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Schedules Schedules_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Schedules Schedules_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Schedules Schedules_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Schedules Schedules_ticketUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_ticketUserId_fkey" FOREIGN KEY ("ticketUserId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Schedules Schedules_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Schedules Schedules_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Settings Settings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Settings"
    ADD CONSTRAINT "Settings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SliderBanners SliderBanners_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."SliderBanners"
    ADD CONSTRAINT "SliderBanners_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Subscriptions Subscriptions_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Subscriptions"
    ADD CONSTRAINT "Subscriptions_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tags Tags_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tags"
    ADD CONSTRAINT "Tags_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketNotes TicketNotes_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketNotes TicketNotes_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TicketNotes TicketNotes_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TicketTags TicketTags_tagId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketTags"
    ADD CONSTRAINT "TicketTags_tagId_fkey" FOREIGN KEY ("tagId") REFERENCES public."Tags"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketTags TicketTags_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketTags"
    ADD CONSTRAINT "TicketTags_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketTraking TicketTraking_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON DELETE SET NULL;


--
-- Name: TicketTraking TicketTraking_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: TicketTraking TicketTraking_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON DELETE SET NULL;


--
-- Name: TicketTraking TicketTraking_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON DELETE SET NULL;


--
-- Name: TicketTraking TicketTraking_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON DELETE SET NULL;


--
-- Name: Tickets Tickets_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tickets Tickets_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Tickets Tickets_crm_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_crm_client_id_fkey" FOREIGN KEY (crm_client_id) REFERENCES public.crm_clients(id) ON DELETE SET NULL;


--
-- Name: Tickets Tickets_crm_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_crm_lead_id_fkey" FOREIGN KEY (crm_lead_id) REFERENCES public.crm_leads(id) ON DELETE SET NULL;


--
-- Name: Tickets Tickets_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public."QueueIntegrations"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tickets Tickets_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tickets Tickets_queueOptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_queueOptionId_fkey" FOREIGN KEY ("queueOptionId") REFERENCES public."QueueOptions"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Tickets Tickets_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tickets Tickets_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserDevices UserDevices_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserDevices"
    ADD CONSTRAINT "UserDevices_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- Name: UserRatings UserRatings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON DELETE SET NULL;


--
-- Name: UserRatings UserRatings_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON DELETE SET NULL;


--
-- Name: UserRatings UserRatings_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON DELETE SET NULL;


--
-- Name: UserServices UserServices_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserServices"
    ADD CONSTRAINT "UserServices_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public.servicos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserServices UserServices_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserServices"
    ADD CONSTRAINT "UserServices_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Users Users_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Users Users_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_flowIdNotPhrase_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_flowIdNotPhrase_fkey" FOREIGN KEY ("flowIdNotPhrase") REFERENCES public."FlowBuilders"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_flowIdWelcome_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_flowIdWelcome_fkey" FOREIGN KEY ("flowIdWelcome") REFERENCES public."FlowBuilders"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public."QueueIntegrations"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_promptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_promptId_fkey" FOREIGN KEY ("promptId") REFERENCES public."Prompts"(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: Whatsapps Whatsapps_queueIdImportMessages_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_queueIdImportMessages_fkey" FOREIGN KEY ("queueIdImportMessages") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: appointments appointments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.crm_clients(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON DELETE CASCADE;


--
-- Name: appointments appointments_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public."Contacts"(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.user_schedules(id) ON DELETE CASCADE;


--
-- Name: appointments appointments_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.servicos(id) ON DELETE SET NULL;


--
-- Name: company_api_keys company_api_keys_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_api_keys
    ADD CONSTRAINT company_api_keys_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_integration_field_maps company_integration_field_maps_integration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_integration_field_maps
    ADD CONSTRAINT company_integration_field_maps_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES public.company_integration_settings(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_integration_settings company_integration_settings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_integration_settings
    ADD CONSTRAINT company_integration_settings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_payment_settings company_payment_settings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.company_payment_settings
    ADD CONSTRAINT company_payment_settings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: crm_client_contacts crm_client_contacts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_client_contacts
    ADD CONSTRAINT crm_client_contacts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.crm_clients(id) ON DELETE CASCADE;


--
-- Name: crm_client_contacts crm_client_contacts_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_client_contacts
    ADD CONSTRAINT crm_client_contacts_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public."Contacts"(id) ON DELETE CASCADE;


--
-- Name: crm_clients crm_clients_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public."Contacts"(id) ON DELETE SET NULL;


--
-- Name: crm_clients crm_clients_primary_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_primary_ticket_id_fkey FOREIGN KEY (primary_ticket_id) REFERENCES public."Tickets"(id) ON DELETE SET NULL;


--
-- Name: crm_leads crm_leads_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public."Contacts"(id) ON DELETE SET NULL;


--
-- Name: crm_leads crm_leads_converted_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_converted_client_id_fkey FOREIGN KEY (converted_client_id) REFERENCES public.crm_clients(id) ON DELETE SET NULL;


--
-- Name: crm_leads crm_leads_primary_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_primary_ticket_id_fkey FOREIGN KEY (primary_ticket_id) REFERENCES public."Tickets"(id) ON DELETE SET NULL;


--
-- Name: financeiro_faturas financeiro_faturas_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.financeiro_faturas
    ADD CONSTRAINT financeiro_faturas_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: financeiro_pagamentos financeiro_pagamentos_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.financeiro_pagamentos
    ADD CONSTRAINT financeiro_pagamentos_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: financeiro_pagamentos financeiro_pagamentos_fatura_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.financeiro_pagamentos
    ADD CONSTRAINT financeiro_pagamentos_fatura_id_fkey FOREIGN KEY (fatura_id) REFERENCES public.financeiro_faturas(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: financeiro_pagamentos fk_financeiro_pagamentos_fatura; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.financeiro_pagamentos
    ADD CONSTRAINT fk_financeiro_pagamentos_fatura FOREIGN KEY (fatura_id, company_id) REFERENCES public.financeiro_faturas(id, company_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tutorial_videos fk_tutorial_videos_company; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.tutorial_videos
    ADD CONSTRAINT fk_tutorial_videos_company FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON DELETE CASCADE;


--
-- Name: tutorial_videos fk_tutorial_videos_user; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.tutorial_videos
    ADD CONSTRAINT fk_tutorial_videos_user FOREIGN KEY (user_id) REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- Name: UserGoogleCalendarIntegrations fk_user_google_calendar_integrations_company_id; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserGoogleCalendarIntegrations"
    ADD CONSTRAINT fk_user_google_calendar_integrations_company_id FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserGoogleCalendarIntegrations fk_user_google_calendar_integrations_user_id; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public."UserGoogleCalendarIntegrations"
    ADD CONSTRAINT fk_user_google_calendar_integrations_user_id FOREIGN KEY (user_id) REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_schedules fk_user_schedules_google_calendar_integration; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.user_schedules
    ADD CONSTRAINT fk_user_schedules_google_calendar_integration FOREIGN KEY (user_google_calendar_integration_id) REFERENCES public."UserGoogleCalendarIntegrations"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_files media_files_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_files media_files_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.media_folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_folders media_folders_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.media_folders
    ADD CONSTRAINT media_folders_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: profissionais profissionais_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.profissionais
    ADD CONSTRAINT "profissionais_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_products project_products_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_products
    ADD CONSTRAINT "project_products_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_products project_products_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_products
    ADD CONSTRAINT "project_products_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Produtos"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_products project_products_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_products
    ADD CONSTRAINT "project_products_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_services project_services_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_services
    ADD CONSTRAINT "project_services_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_services project_services_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_services
    ADD CONSTRAINT "project_services_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_services project_services_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_services
    ADD CONSTRAINT "project_services_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public.servicos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_task_users project_task_users_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_task_users
    ADD CONSTRAINT "project_task_users_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_task_users project_task_users_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_task_users
    ADD CONSTRAINT "project_task_users_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.project_tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_task_users project_task_users_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_task_users
    ADD CONSTRAINT "project_task_users_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_tasks project_tasks_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT "project_tasks_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_tasks project_tasks_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT "project_tasks_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_users project_users_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_users
    ADD CONSTRAINT "project_users_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_users project_users_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_users
    ADD CONSTRAINT "project_users_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_users project_users_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.project_users
    ADD CONSTRAINT "project_users_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.crm_clients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: projects projects_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoices"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: scheduled_dispatch_logs scheduled_dispatch_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.scheduled_dispatch_logs
    ADD CONSTRAINT scheduled_dispatch_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scheduled_dispatch_logs scheduled_dispatch_logs_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.scheduled_dispatch_logs
    ADD CONSTRAINT scheduled_dispatch_logs_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: scheduled_dispatch_logs scheduled_dispatch_logs_dispatcher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.scheduled_dispatch_logs
    ADD CONSTRAINT scheduled_dispatch_logs_dispatcher_id_fkey FOREIGN KEY (dispatcher_id) REFERENCES public.scheduled_dispatchers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scheduled_dispatch_logs scheduled_dispatch_logs_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.scheduled_dispatch_logs
    ADD CONSTRAINT scheduled_dispatch_logs_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: scheduled_dispatchers scheduled_dispatchers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.scheduled_dispatchers
    ADD CONSTRAINT scheduled_dispatchers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scheduled_dispatchers scheduled_dispatchers_whatsapp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.scheduled_dispatchers
    ADD CONSTRAINT scheduled_dispatchers_whatsapp_id_fkey FOREIGN KEY (whatsapp_id) REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: servicos servicos_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.servicos
    ADD CONSTRAINT "servicos_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: slider_home slider_home_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.slider_home
    ADD CONSTRAINT "slider_home_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_schedules user_schedules_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.user_schedules
    ADD CONSTRAINT user_schedules_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON DELETE CASCADE;


--
-- Name: user_schedules user_schedules_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: whaticket
--

ALTER TABLE ONLY public.user_schedules
    ADD CONSTRAINT user_schedules_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Sezt8VbHelHJrZDLKgeUwuEd5EnhaU9N4hrFWdMAzOFwrS2QncZSui8KcnNlMue

