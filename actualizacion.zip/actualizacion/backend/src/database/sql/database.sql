--
-- PostgreSQL database dump
--

\restrict nqGA0EF3GxDruHC2SYMup7cKXffLkP66zmiCRPp2MYMOe9V9WCi2CbkuCoKMynv

-- Dumped from database version 14.20 (Ubuntu 14.20-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.20 (Ubuntu 14.20-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: enum_MobileWebhooks_platform; Type: TYPE; Schema: public; Owner: empresa
--

CREATE TYPE public."enum_MobileWebhooks_platform" AS ENUM (
    'android',
    'ios'
);


ALTER TYPE public."enum_MobileWebhooks_platform" OWNER TO empresa;

--
-- Name: update_tutorial_videos_updated_at(); Type: FUNCTION; Schema: public; Owner: empresa
--

CREATE FUNCTION public.update_tutorial_videos_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_tutorial_videos_updated_at() OWNER TO empresa;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: empresa
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."updatedAt" = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO empresa;

--
-- Name: update_user_device_updated_at(); Type: FUNCTION; Schema: public; Owner: empresa
--

CREATE FUNCTION public.update_user_device_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."updatedAt" = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_user_device_updated_at() OWNER TO empresa;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Announcements; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Announcements" (
    id integer NOT NULL,
    priority integer,
    title character varying(255) NOT NULL,
    text text NOT NULL,
    "mediaPath" text,
    "mediaName" text,
    "companyId" integer NOT NULL,
    status boolean,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Announcements" OWNER TO empresa;

--
-- Name: Announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Announcements_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Announcements_id_seq" OWNER TO empresa;

--
-- Name: Announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Announcements_id_seq" OWNED BY public."Announcements".id;


--
-- Name: ApiUsages; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."ApiUsages" (
    id integer NOT NULL,
    "companyId" integer DEFAULT 0,
    "dateUsed" text NOT NULL,
    "UsedOnDay" integer DEFAULT 0,
    "usedText" integer DEFAULT 0,
    "usedPDF" integer DEFAULT 0,
    "usedImage" integer DEFAULT 0,
    "usedVideo" integer DEFAULT 0,
    "usedOther" integer DEFAULT 0,
    "usedCheckNumber" integer DEFAULT 0,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ApiUsages" OWNER TO empresa;

--
-- Name: ApiUsages_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."ApiUsages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ApiUsages_id_seq" OWNER TO empresa;

--
-- Name: ApiUsages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."ApiUsages_id_seq" OWNED BY public."ApiUsages".id;


--
-- Name: AutomationActions; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."AutomationActions" (
    id integer NOT NULL,
    "automationId" integer NOT NULL,
    "actionType" character varying(50) NOT NULL,
    "actionConfig" jsonb DEFAULT '{}'::jsonb,
    "order" integer DEFAULT 1,
    "delayMinutes" integer DEFAULT 0,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."AutomationActions" OWNER TO empresa;

--
-- Name: AutomationActions_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."AutomationActions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AutomationActions_id_seq" OWNER TO empresa;

--
-- Name: AutomationActions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."AutomationActions_id_seq" OWNED BY public."AutomationActions".id;


--
-- Name: AutomationExecutions; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."AutomationExecutions" (
    id integer NOT NULL,
    "automationId" integer NOT NULL,
    "automationActionId" integer NOT NULL,
    "contactId" integer,
    "ticketId" integer,
    "scheduledAt" timestamp with time zone NOT NULL,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    attempts integer DEFAULT 0,
    "lastAttemptAt" timestamp with time zone,
    "completedAt" timestamp with time zone,
    error text,
    metadata jsonb DEFAULT '{}'::jsonb,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."AutomationExecutions" OWNER TO empresa;

--
-- Name: AutomationExecutions_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."AutomationExecutions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AutomationExecutions_id_seq" OWNER TO empresa;

--
-- Name: AutomationExecutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."AutomationExecutions_id_seq" OWNED BY public."AutomationExecutions".id;


--
-- Name: AutomationLogs; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."AutomationLogs" (
    id integer NOT NULL,
    "automationId" integer NOT NULL,
    "contactId" integer,
    "ticketId" integer,
    status character varying(20) DEFAULT 'pending'::character varying,
    "executedAt" timestamp with time zone,
    result jsonb DEFAULT '{}'::jsonb,
    error text,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."AutomationLogs" OWNER TO empresa;

--
-- Name: AutomationLogs_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."AutomationLogs_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AutomationLogs_id_seq" OWNER TO empresa;

--
-- Name: AutomationLogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."AutomationLogs_id_seq" OWNED BY public."AutomationLogs".id;


--
-- Name: Automations; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Automations" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    "triggerType" character varying(50) NOT NULL,
    "triggerConfig" jsonb DEFAULT '{}'::jsonb,
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."Automations" OWNER TO empresa;

--
-- Name: Automations_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Automations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Automations_id_seq" OWNER TO empresa;

--
-- Name: Automations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Automations_id_seq" OWNED BY public."Automations".id;


--
-- Name: Baileys; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Baileys" (
    id integer NOT NULL,
    "whatsappId" integer NOT NULL,
    contacts jsonb,
    chats jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Baileys" OWNER TO empresa;

--
-- Name: Baileys_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Baileys_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Baileys_id_seq" OWNER TO empresa;

--
-- Name: Baileys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Baileys_id_seq" OWNED BY public."Baileys".id;


--
-- Name: CampaignSettings; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."CampaignSettings" (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    value text,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."CampaignSettings" OWNER TO empresa;

--
-- Name: CampaignSettings_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."CampaignSettings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."CampaignSettings_id_seq" OWNER TO empresa;

--
-- Name: CampaignSettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."CampaignSettings_id_seq" OWNED BY public."CampaignSettings".id;


--
-- Name: CampaignShipping; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."CampaignShipping" (
    id integer NOT NULL,
    "jobId" character varying(255),
    number character varying(255) NOT NULL,
    message text NOT NULL,
    "confirmationMessage" text,
    confirmation boolean,
    "contactId" integer,
    "campaignId" integer NOT NULL,
    "confirmationRequestedAt" timestamp with time zone,
    "confirmedAt" timestamp with time zone,
    "deliveredAt" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."CampaignShipping" OWNER TO empresa;

--
-- Name: CampaignShipping_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."CampaignShipping_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."CampaignShipping_id_seq" OWNER TO empresa;

--
-- Name: CampaignShipping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."CampaignShipping_id_seq" OWNED BY public."CampaignShipping".id;


--
-- Name: Campaigns; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Campaigns" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    message1 text DEFAULT ''::text,
    message2 text DEFAULT ''::text,
    message3 text DEFAULT ''::text,
    message4 text DEFAULT ''::text,
    message5 text DEFAULT ''::text,
    "confirmationMessage1" text DEFAULT ''::text,
    "confirmationMessage2" text DEFAULT ''::text,
    "confirmationMessage3" text DEFAULT ''::text,
    "confirmationMessage4" text DEFAULT ''::text,
    "confirmationMessage5" text DEFAULT ''::text,
    status character varying(255),
    confirmation boolean DEFAULT false,
    "mediaPath" text,
    "mediaName" text,
    "companyId" integer NOT NULL,
    "contactListId" integer,
    "whatsappId" integer,
    "scheduledAt" timestamp with time zone,
    "completedAt" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "userId" integer,
    "queueId" integer,
    "statusTicket" character varying(255) DEFAULT 'closed'::character varying,
    "openTicket" character varying(255) DEFAULT 'disabled'::character varying
);


ALTER TABLE public."Campaigns" OWNER TO empresa;

--
-- Name: Campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Campaigns_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Campaigns_id_seq" OWNER TO empresa;

--
-- Name: Campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Campaigns_id_seq" OWNED BY public."Campaigns".id;


--
-- Name: ChatMessages; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."ChatMessages" (
    id integer NOT NULL,
    "chatId" integer NOT NULL,
    "senderId" integer NOT NULL,
    message text DEFAULT ''::text,
    "mediaPath" text,
    "mediaName" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ChatMessages" OWNER TO empresa;

--
-- Name: ChatMessages_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."ChatMessages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ChatMessages_id_seq" OWNER TO empresa;

--
-- Name: ChatMessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."ChatMessages_id_seq" OWNED BY public."ChatMessages".id;


--
-- Name: ChatUsers; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."ChatUsers" (
    id integer NOT NULL,
    "chatId" integer NOT NULL,
    "userId" integer NOT NULL,
    unreads integer DEFAULT 0,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ChatUsers" OWNER TO empresa;

--
-- Name: ChatUsers_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."ChatUsers_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ChatUsers_id_seq" OWNER TO empresa;

--
-- Name: ChatUsers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."ChatUsers_id_seq" OWNED BY public."ChatUsers".id;


--
-- Name: Chatbots; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Chatbots" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "queueId" integer,
    "chatbotId" integer,
    "greetingMessage" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isAgent" boolean DEFAULT false,
    "optQueueId" integer,
    "optUserId" integer,
    "queueType" character varying(255) DEFAULT 'text'::character varying NOT NULL,
    "optIntegrationId" integer,
    "optFileId" integer,
    "closeTicket" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Chatbots" OWNER TO empresa;

--
-- Name: Chatbots_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Chatbots_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Chatbots_id_seq" OWNER TO empresa;

--
-- Name: Chatbots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Chatbots_id_seq" OWNED BY public."Chatbots".id;


--
-- Name: Chats; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Chats" (
    id integer NOT NULL,
    title text DEFAULT ''::text,
    uuid character varying(255) DEFAULT ''::character varying,
    "ownerId" integer NOT NULL,
    "lastMessage" text,
    "companyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Chats" OWNER TO empresa;

--
-- Name: Chats_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Chats_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Chats_id_seq" OWNER TO empresa;

--
-- Name: Chats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Chats_id_seq" OWNED BY public."Chats".id;


--
-- Name: Companies; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Companies" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(255),
    email character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "planId" integer,
    status boolean DEFAULT true,
    schedules jsonb DEFAULT '[]'::jsonb,
    "dueDate" timestamp with time zone,
    recurrence character varying(255) DEFAULT ''::character varying,
    document character varying(255) DEFAULT ''::character varying,
    "paymentMethod" character varying(255) DEFAULT ''::character varying,
    "lastLogin" timestamp with time zone,
    "folderSize" character varying(255),
    "numberFileFolder" character varying(255),
    "updatedAtFolder" character varying(255),
    type character varying(10) DEFAULT 'pf'::character varying NOT NULL,
    segment character varying(50) DEFAULT 'outros'::character varying NOT NULL,
    "loadingImage" character varying(255)
);


ALTER TABLE public."Companies" OWNER TO empresa;

--
-- Name: CompaniesSettings; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."CompaniesSettings" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "hoursCloseTicketsAuto" character varying(255) NOT NULL,
    "chatBotType" character varying(255) NOT NULL,
    "acceptCallWhatsapp" character varying(255) NOT NULL,
    "userRandom" character varying(255) NOT NULL,
    "sendGreetingMessageOneQueues" character varying(255) NOT NULL,
    "sendSignMessage" character varying(255) NOT NULL,
    "sendFarewellWaitingTicket" character varying(255) NOT NULL,
    "userRating" character varying(255) NOT NULL,
    "sendGreetingAccepted" character varying(255) NOT NULL,
    "CheckMsgIsGroup" character varying(255) NOT NULL,
    "sendQueuePosition" character varying(255) NOT NULL,
    "scheduleType" character varying(255) NOT NULL,
    "acceptAudioMessageContact" character varying(255) NOT NULL,
    "enableLGPD" character varying(255) NOT NULL,
    "sendMsgTransfTicket" character varying(255) NOT NULL,
    "requiredTag" character varying(255) NOT NULL,
    "lgpdDeleteMessage" character varying(255) NOT NULL,
    "lgpdHideNumber" character varying(255) NOT NULL,
    "lgpdConsent" character varying(255) NOT NULL,
    "lgpdLink" character varying(255),
    "lgpdMessage" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "DirectTicketsToWallets" boolean DEFAULT false,
    "closeTicketOnTransfer" boolean DEFAULT false,
    "greetingAcceptedMessage" text DEFAULT ''::text,
    "AcceptCallWhatsappMessage" text DEFAULT ''::text,
    "sendQueuePositionMessage" text DEFAULT ''::text,
    "transferMessage" text DEFAULT ''::text,
    "showNotificationPending" boolean DEFAULT false NOT NULL,
    "notificameHub" character varying(255),
    "autoSaveContacts" character varying(20) DEFAULT 'disabled'::character varying,
    "autoSaveContactsScore" integer DEFAULT 7,
    "autoSaveContactsReason" character varying(50) DEFAULT 'high_potential'::character varying
);


ALTER TABLE public."CompaniesSettings" OWNER TO empresa;

--
-- Name: CompaniesSettings_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."CompaniesSettings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."CompaniesSettings_id_seq" OWNER TO empresa;

--
-- Name: CompaniesSettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."CompaniesSettings_id_seq" OWNED BY public."CompaniesSettings".id;


--
-- Name: Companies_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Companies_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Companies_id_seq" OWNER TO empresa;

--
-- Name: Companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Companies_id_seq" OWNED BY public."Companies".id;


--
-- Name: ContactCustomFields; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."ContactCustomFields" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    "contactId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ContactCustomFields" OWNER TO empresa;

--
-- Name: ContactCustomFields_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."ContactCustomFields_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ContactCustomFields_id_seq" OWNER TO empresa;

--
-- Name: ContactCustomFields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."ContactCustomFields_id_seq" OWNED BY public."ContactCustomFields".id;


--
-- Name: ContactGroups; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."ContactGroups" (
    id integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "contactId" integer,
    "companyId" integer,
    "userId" integer
);


ALTER TABLE public."ContactGroups" OWNER TO empresa;

--
-- Name: ContactGroups_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."ContactGroups_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ContactGroups_id_seq" OWNER TO empresa;

--
-- Name: ContactGroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."ContactGroups_id_seq" OWNED BY public."ContactGroups".id;


--
-- Name: ContactListItems; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."ContactListItems" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    number character varying(255) NOT NULL,
    email character varying(255),
    "contactListId" integer NOT NULL,
    "isWhatsappValid" boolean DEFAULT false,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isGroup" boolean DEFAULT false
);


ALTER TABLE public."ContactListItems" OWNER TO empresa;

--
-- Name: ContactListItems_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."ContactListItems_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ContactListItems_id_seq" OWNER TO empresa;

--
-- Name: ContactListItems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."ContactListItems_id_seq" OWNED BY public."ContactListItems".id;


--
-- Name: ContactLists; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."ContactLists" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ContactLists" OWNER TO empresa;

--
-- Name: ContactLists_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."ContactLists_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ContactLists_id_seq" OWNER TO empresa;

--
-- Name: ContactLists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."ContactLists_id_seq" OWNED BY public."ContactLists".id;


--
-- Name: ContactTags; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."ContactTags" (
    "contactId" integer NOT NULL,
    "tagId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ContactTags" OWNER TO empresa;

--
-- Name: ContactWallets; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."ContactWallets" (
    id integer NOT NULL,
    "walletId" integer NOT NULL,
    "contactId" integer NOT NULL,
    "companyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ContactWallets" OWNER TO empresa;

--
-- Name: ContactWallets_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."ContactWallets_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ContactWallets_id_seq" OWNER TO empresa;

--
-- Name: ContactWallets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."ContactWallets_id_seq" OWNED BY public."ContactWallets".id;


--
-- Name: Contacts; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Contacts" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    number character varying(255) NOT NULL,
    "profilePicUrl" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    "isGroup" boolean DEFAULT false NOT NULL,
    "companyId" integer,
    "acceptAudioMessage" boolean DEFAULT true NOT NULL,
    channel text DEFAULT 'whatsapp'::text,
    active boolean DEFAULT true,
    "disableBot" boolean DEFAULT false NOT NULL,
    "remoteJid" character varying(255) DEFAULT NULL::character varying,
    "lgpdAcceptedAt" timestamp with time zone,
    "urlPicture" text,
    "pictureUpdated" boolean DEFAULT false NOT NULL,
    "whatsappId" integer,
    "isLid" boolean DEFAULT false NOT NULL,
    birthday timestamp without time zone,
    anniversary timestamp without time zone,
    info text,
    files jsonb,
    "cpfCnpj" character varying(32),
    address character varying(255),
    lid character varying(255),
    "savedToPhone" boolean DEFAULT false,
    "savedToPhoneAt" timestamp with time zone,
    "savedToPhoneReason" character varying(100),
    "potentialScore" integer DEFAULT 0,
    "isPotential" boolean DEFAULT false,
    "lidStability" character varying(20) DEFAULT 'unknown'::character varying
);


ALTER TABLE public."Contacts" OWNER TO empresa;

--
-- Name: Contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Contacts_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Contacts_id_seq" OWNER TO empresa;

--
-- Name: Contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Contacts_id_seq" OWNED BY public."Contacts".id;


--
-- Name: DialogChatBots; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."DialogChatBots" (
    id integer NOT NULL,
    awaiting integer DEFAULT 0 NOT NULL,
    "contactId" integer,
    "chatbotId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "queueId" integer
);


ALTER TABLE public."DialogChatBots" OWNER TO empresa;

--
-- Name: DialogChatBots_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."DialogChatBots_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DialogChatBots_id_seq" OWNER TO empresa;

--
-- Name: DialogChatBots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."DialogChatBots_id_seq" OWNED BY public."DialogChatBots".id;


--
-- Name: Faturas; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Faturas" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "contactId" integer NOT NULL,
    valor numeric(12,2) NOT NULL,
    descricao text,
    status character varying(20) DEFAULT 'pendente'::character varying NOT NULL,
    "dataCriacao" timestamp without time zone DEFAULT now(),
    "dataVencimento" timestamp without time zone NOT NULL,
    "dataPagamento" timestamp without time zone,
    recorrente boolean DEFAULT false NOT NULL,
    intervalo character varying(20),
    "proximaCobranca" timestamp without time zone,
    "limiteRecorrencias" integer,
    "recorrenciasRealizadas" integer DEFAULT 0,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now()
);


ALTER TABLE public."Faturas" OWNER TO empresa;

--
-- Name: Faturas_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Faturas_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Faturas_id_seq" OWNER TO empresa;

--
-- Name: Faturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Faturas_id_seq" OWNED BY public."Faturas".id;


--
-- Name: Ferramentas; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Ferramentas" (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    descricao text,
    url text NOT NULL,
    metodo character varying(10) NOT NULL,
    headers jsonb,
    body jsonb,
    query_params jsonb,
    placeholders jsonb,
    status character varying(20) DEFAULT 'ativo'::character varying,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now(),
    "companyId" integer
);


ALTER TABLE public."Ferramentas" OWNER TO empresa;

--
-- Name: Ferramentas_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Ferramentas_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Ferramentas_id_seq" OWNER TO empresa;

--
-- Name: Ferramentas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Ferramentas_id_seq" OWNED BY public."Ferramentas".id;


--
-- Name: Files; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Files" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    name character varying(255) NOT NULL,
    message text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Files" OWNER TO empresa;

--
-- Name: FilesOptions; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."FilesOptions" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    "fileId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "mediaType" character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public."FilesOptions" OWNER TO empresa;

--
-- Name: FilesOptions_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."FilesOptions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."FilesOptions_id_seq" OWNER TO empresa;

--
-- Name: FilesOptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."FilesOptions_id_seq" OWNED BY public."FilesOptions".id;


--
-- Name: Files_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Files_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Files_id_seq" OWNER TO empresa;

--
-- Name: Files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Files_id_seq" OWNED BY public."Files".id;


--
-- Name: FlowAudios; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."FlowAudios" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    name character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."FlowAudios" OWNER TO empresa;

--
-- Name: FlowAudios_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."FlowAudios_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."FlowAudios_id_seq" OWNER TO empresa;

--
-- Name: FlowAudios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."FlowAudios_id_seq" OWNED BY public."FlowAudios".id;


--
-- Name: FlowBuilders; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."FlowBuilders" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(255) NOT NULL,
    active boolean DEFAULT true,
    flow json,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    company_id integer DEFAULT 0 NOT NULL,
    variables json
);


ALTER TABLE public."FlowBuilders" OWNER TO empresa;

--
-- Name: FlowBuilders_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."FlowBuilders_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."FlowBuilders_id_seq" OWNER TO empresa;

--
-- Name: FlowBuilders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."FlowBuilders_id_seq" OWNED BY public."FlowBuilders".id;


--
-- Name: FlowCampaigns; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."FlowCampaigns" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    name character varying(255) NOT NULL,
    "flowId" integer NOT NULL,
    phrase character varying(255) NOT NULL,
    status boolean DEFAULT true NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "whatsappId" integer,
    phrases text,
    "matchType" character varying(20)
);


ALTER TABLE public."FlowCampaigns" OWNER TO empresa;

--
-- Name: FlowCampaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."FlowCampaigns_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."FlowCampaigns_id_seq" OWNER TO empresa;

--
-- Name: FlowCampaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."FlowCampaigns_id_seq" OWNED BY public."FlowCampaigns".id;


--
-- Name: FlowDefaults; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."FlowDefaults" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    "flowIdWelcome" integer,
    "flowIdNotPhrase" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."FlowDefaults" OWNER TO empresa;

--
-- Name: FlowDefaults_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."FlowDefaults_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."FlowDefaults_id_seq" OWNER TO empresa;

--
-- Name: FlowDefaults_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."FlowDefaults_id_seq" OWNED BY public."FlowDefaults".id;


--
-- Name: FlowImgs; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."FlowImgs" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    name character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."FlowImgs" OWNER TO empresa;

--
-- Name: FlowImgs_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."FlowImgs_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."FlowImgs_id_seq" OWNER TO empresa;

--
-- Name: FlowImgs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."FlowImgs_id_seq" OWNED BY public."FlowImgs".id;


--
-- Name: GoogleCalendarIntegrations; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."GoogleCalendarIntegrations" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "googleUserId" character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "accessToken" text NOT NULL,
    "refreshToken" text NOT NULL,
    "expiryDate" timestamp with time zone,
    "calendarId" character varying(255) DEFAULT 'primary'::character varying,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "userId" integer
);


ALTER TABLE public."GoogleCalendarIntegrations" OWNER TO empresa;

--
-- Name: GoogleCalendarIntegrations_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."GoogleCalendarIntegrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."GoogleCalendarIntegrations_id_seq" OWNER TO empresa;

--
-- Name: GoogleCalendarIntegrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."GoogleCalendarIntegrations_id_seq" OWNED BY public."GoogleCalendarIntegrations".id;


--
-- Name: GoogleSheetsTokens; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."GoogleSheetsTokens" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "googleUserId" character varying,
    email character varying,
    "accessToken" text,
    "refreshToken" text,
    "expiryDate" timestamp without time zone,
    "rawTokens" jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."GoogleSheetsTokens" OWNER TO empresa;

--
-- Name: GoogleSheetsTokens_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."GoogleSheetsTokens_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."GoogleSheetsTokens_id_seq" OWNER TO empresa;

--
-- Name: GoogleSheetsTokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."GoogleSheetsTokens_id_seq" OWNED BY public."GoogleSheetsTokens".id;


--
-- Name: Helps; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Helps" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    video character varying(255),
    link text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Helps" OWNER TO empresa;

--
-- Name: Helps_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Helps_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Helps_id_seq" OWNER TO empresa;

--
-- Name: Helps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Helps_id_seq" OWNED BY public."Helps".id;


--
-- Name: IaWorkflows; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."IaWorkflows" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "orchestratorPromptId" integer NOT NULL,
    "agentPromptId" integer NOT NULL,
    alias character varying(255) NOT NULL,
    "createdAt" timestamp(6) without time zone NOT NULL,
    "updatedAt" timestamp(6) without time zone NOT NULL
);


ALTER TABLE public."IaWorkflows" OWNER TO empresa;

--
-- Name: IaWorkflows_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."IaWorkflows_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."IaWorkflows_id_seq" OWNER TO empresa;

--
-- Name: IaWorkflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."IaWorkflows_id_seq" OWNED BY public."IaWorkflows".id;


--
-- Name: Integrations; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Integrations" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    name character varying(255) NOT NULL,
    "isActive" boolean DEFAULT false,
    token text,
    "foneContact" character varying(255),
    "userLogin" character varying(255),
    "passLogin" character varying(255),
    "finalCurrentMonth" integer,
    "initialCurrentMonth" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Integrations" OWNER TO empresa;

--
-- Name: Integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Integrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Integrations_id_seq" OWNER TO empresa;

--
-- Name: Integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Integrations_id_seq" OWNED BY public."Integrations".id;


--
-- Name: Invoices; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Invoices" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "dueDate" character varying(255),
    detail character varying(255),
    status character varying(255),
    value double precision,
    users integer DEFAULT 0,
    connections integer DEFAULT 0,
    queues integer DEFAULT 0,
    "useWhatsapp" boolean DEFAULT true,
    "useFacebook" boolean DEFAULT true,
    "useInstagram" boolean DEFAULT true,
    "useCampaigns" boolean DEFAULT true,
    "useSchedules" boolean DEFAULT true,
    "useInternalChat" boolean DEFAULT true,
    "useExternalApi" boolean DEFAULT true,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "linkInvoice" text DEFAULT ''::text
);


ALTER TABLE public."Invoices" OWNER TO empresa;

--
-- Name: Invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Invoices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Invoices_id_seq" OWNER TO empresa;

--
-- Name: Invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Invoices_id_seq" OWNED BY public."Invoices".id;


--
-- Name: LogTickets; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."LogTickets" (
    id integer NOT NULL,
    "userId" integer,
    "ticketId" integer NOT NULL,
    "queueId" integer,
    type character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."LogTickets" OWNER TO empresa;

--
-- Name: LogTickets_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."LogTickets_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."LogTickets_id_seq" OWNER TO empresa;

--
-- Name: LogTickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."LogTickets_id_seq" OWNED BY public."LogTickets".id;


--
-- Name: MediaFiles; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."MediaFiles" (
    id integer NOT NULL,
    folder_id integer NOT NULL,
    company_id integer NOT NULL,
    original_name character varying(255) NOT NULL,
    custom_name character varying(255),
    mime_type character varying(128) NOT NULL,
    size bigint NOT NULL,
    storage_path text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."MediaFiles" OWNER TO empresa;

--
-- Name: MediaFiles_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."MediaFiles_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."MediaFiles_id_seq" OWNER TO empresa;

--
-- Name: MediaFiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."MediaFiles_id_seq" OWNED BY public."MediaFiles".id;


--
-- Name: MediaFolders; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."MediaFolders" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."MediaFolders" OWNER TO empresa;

--
-- Name: MediaFolders_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."MediaFolders_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."MediaFolders_id_seq" OWNER TO empresa;

--
-- Name: MediaFolders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."MediaFolders_id_seq" OWNED BY public."MediaFolders".id;


--
-- Name: Messages; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Messages" (
    body text NOT NULL,
    ack integer DEFAULT 0 NOT NULL,
    read boolean DEFAULT false NOT NULL,
    "mediaType" character varying(255),
    "mediaUrl" character varying(255),
    "ticketId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "fromMe" boolean DEFAULT false NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "contactId" integer,
    "companyId" integer,
    "remoteJid" text,
    "dataJson" text,
    participant text,
    "queueId" integer,
    "ticketTrakingId" integer,
    "quotedMsgId" integer,
    wid character varying(255),
    id integer NOT NULL,
    "isPrivate" boolean DEFAULT false,
    "isEdited" boolean DEFAULT false,
    "isForwarded" boolean DEFAULT false,
    "fromAgent" boolean DEFAULT false NOT NULL,
    "userId" integer
);


ALTER TABLE public."Messages" OWNER TO empresa;

--
-- Name: Messages_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Messages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Messages_id_seq" OWNER TO empresa;

--
-- Name: Messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Messages_id_seq" OWNED BY public."Messages".id;


--
-- Name: MobileWebhooks; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."MobileWebhooks" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "companyId" integer NOT NULL,
    "webhookUrl" character varying(255) NOT NULL,
    "deviceToken" character varying(255) NOT NULL,
    platform public."enum_MobileWebhooks_platform" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "failureCount" integer DEFAULT 0 NOT NULL,
    "lastUsed" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."MobileWebhooks" OWNER TO empresa;

--
-- Name: MobileWebhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."MobileWebhooks_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."MobileWebhooks_id_seq" OWNER TO empresa;

--
-- Name: MobileWebhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."MobileWebhooks_id_seq" OWNED BY public."MobileWebhooks".id;


--
-- Name: Negocios; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Negocios" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    "kanbanBoards" jsonb,
    users jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."Negocios" OWNER TO empresa;

--
-- Name: Negocios_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Negocios_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Negocios_id_seq" OWNER TO empresa;

--
-- Name: Negocios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Negocios_id_seq" OWNED BY public."Negocios".id;


--
-- Name: Partners; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Partners" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(255),
    email character varying(255),
    document character varying(255),
    commission numeric(10,2) NOT NULL,
    "typeCommission" character varying(255) NOT NULL,
    "walletId" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Partners" OWNER TO empresa;

--
-- Name: Partners_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Partners_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Partners_id_seq" OWNER TO empresa;

--
-- Name: Partners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Partners_id_seq" OWNED BY public."Partners".id;


--
-- Name: Plans; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Plans" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    users integer DEFAULT 0,
    connections integer DEFAULT 0,
    queues integer DEFAULT 0,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    amount character varying(255),
    "useFacebook" boolean DEFAULT true,
    "useInstagram" boolean DEFAULT true,
    "useWhatsapp" boolean DEFAULT true,
    "useCampaigns" boolean DEFAULT true,
    "useExternalApi" boolean DEFAULT true,
    "useInternalChat" boolean DEFAULT true,
    "useSchedules" boolean DEFAULT true,
    "useKanban" boolean DEFAULT true,
    "isPublic" boolean DEFAULT true NOT NULL,
    recurrence character varying(255),
    trial boolean DEFAULT false,
    "trialDays" integer DEFAULT 0,
    "useIntegrations" boolean DEFAULT true,
    "useOpenAi" boolean DEFAULT true
);


ALTER TABLE public."Plans" OWNER TO empresa;

--
-- Name: Plans_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Plans_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Plans_id_seq" OWNER TO empresa;

--
-- Name: Plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Plans_id_seq" OWNED BY public."Plans".id;


--
-- Name: Produtos; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Produtos" (
    id integer NOT NULL,
    "companyId" integer,
    tipo character varying(20) NOT NULL,
    nome character varying(255) NOT NULL,
    descricao text,
    valor numeric(12,2),
    status character varying(20) DEFAULT 'disponivel'::character varying,
    imagem_principal text,
    galeria jsonb,
    dados_especificos jsonb,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now()
);


ALTER TABLE public."Produtos" OWNER TO empresa;

--
-- Name: Produtos_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Produtos_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Produtos_id_seq" OWNER TO empresa;

--
-- Name: Produtos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Produtos_id_seq" OWNED BY public."Produtos".id;


--
-- Name: PromptToolSettings; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."PromptToolSettings" (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "promptId" integer,
    "toolName" character varying(255) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."PromptToolSettings" OWNER TO empresa;

--
-- Name: PromptToolSettings_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."PromptToolSettings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."PromptToolSettings_id_seq" OWNER TO empresa;

--
-- Name: PromptToolSettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."PromptToolSettings_id_seq" OWNED BY public."PromptToolSettings".id;


--
-- Name: Prompts; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Prompts" (
    id integer NOT NULL,
    name text NOT NULL,
    "apiKey" text NOT NULL,
    prompt text NOT NULL,
    "maxTokens" integer DEFAULT 100 NOT NULL,
    "maxMessages" integer DEFAULT 10 NOT NULL,
    temperature integer DEFAULT 1 NOT NULL,
    "promptTokens" integer DEFAULT 0 NOT NULL,
    "completionTokens" integer DEFAULT 0 NOT NULL,
    "totalTokens" integer DEFAULT 0 NOT NULL,
    voice text,
    "voiceKey" text,
    "voiceRegion" text,
    "queueId" integer NOT NULL,
    "companyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    model character varying(255),
    provider character varying(255) DEFAULT 'openai'::character varying,
    "knowledgeBase" jsonb DEFAULT '[]'::jsonb
);


ALTER TABLE public."Prompts" OWNER TO empresa;

--
-- Name: Prompts_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Prompts_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Prompts_id_seq" OWNER TO empresa;

--
-- Name: Prompts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Prompts_id_seq" OWNED BY public."Prompts".id;


--
-- Name: QueueIntegrations; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."QueueIntegrations" (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "projectName" character varying(255) NOT NULL,
    "jsonContent" text NOT NULL,
    language character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "urlN8N" character varying(255) DEFAULT true NOT NULL,
    "companyId" integer,
    "typebotExpires" integer DEFAULT 0 NOT NULL,
    "typebotKeywordFinish" character varying(255) DEFAULT ''::character varying NOT NULL,
    "typebotUnknownMessage" character varying(255) DEFAULT ''::character varying NOT NULL,
    "typebotSlug" character varying(255) DEFAULT ''::character varying NOT NULL,
    "typebotDelayMessage" integer DEFAULT 1000 NOT NULL,
    "typebotKeywordRestart" character varying(255) DEFAULT ''::character varying,
    "typebotRestartMessage" character varying(255) DEFAULT ''::character varying
);


ALTER TABLE public."QueueIntegrations" OWNER TO empresa;

--
-- Name: QueueIntegrations_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."QueueIntegrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."QueueIntegrations_id_seq" OWNER TO empresa;

--
-- Name: QueueIntegrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."QueueIntegrations_id_seq" OWNED BY public."QueueIntegrations".id;


--
-- Name: QueueOptions; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."QueueOptions" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    message text,
    option text,
    "queueId" integer,
    "parentId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."QueueOptions" OWNER TO empresa;

--
-- Name: QueueOptions_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."QueueOptions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."QueueOptions_id_seq" OWNER TO empresa;

--
-- Name: QueueOptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."QueueOptions_id_seq" OWNED BY public."QueueOptions".id;


--
-- Name: Queues; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Queues" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    color character varying(255) NOT NULL,
    "greetingMessage" text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "companyId" integer,
    schedules jsonb DEFAULT '[]'::jsonb,
    "outOfHoursMessage" text,
    "orderQueue" integer,
    "tempoRoteador" integer DEFAULT 0 NOT NULL,
    "ativarRoteador" boolean DEFAULT false NOT NULL,
    "integrationId" integer,
    "fileListId" integer,
    "closeTicket" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Queues" OWNER TO empresa;

--
-- Name: Queues_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Queues_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Queues_id_seq" OWNER TO empresa;

--
-- Name: Queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Queues_id_seq" OWNED BY public."Queues".id;


--
-- Name: QuickMessages; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."QuickMessages" (
    id integer NOT NULL,
    shortcode character varying(255) NOT NULL,
    message text,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "userId" integer,
    "mediaPath" character varying(255) DEFAULT NULL::character varying,
    "mediaName" character varying(255) DEFAULT NULL::character varying,
    geral boolean DEFAULT false NOT NULL,
    visao boolean DEFAULT true
);


ALTER TABLE public."QuickMessages" OWNER TO empresa;

--
-- Name: QuickMessages_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."QuickMessages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."QuickMessages_id_seq" OWNER TO empresa;

--
-- Name: QuickMessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."QuickMessages_id_seq" OWNED BY public."QuickMessages".id;


--
-- Name: ScheduledMessages; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."ScheduledMessages" (
    id integer NOT NULL,
    data_mensagem_programada timestamp with time zone,
    id_conexao character varying(255),
    intervalo character varying(255),
    valor_intervalo character varying(255),
    mensagem text,
    tipo_dias_envio character varying(255),
    mostrar_usuario_mensagem boolean DEFAULT false,
    criar_ticket boolean DEFAULT false,
    contatos jsonb,
    tags jsonb,
    "companyId" integer,
    nome character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "mediaPath" character varying(255),
    "mediaName" character varying(255),
    tipo_arquivo character varying(255),
    usuario_envio character varying(255),
    enviar_quantas_vezes character varying(255)
);


ALTER TABLE public."ScheduledMessages" OWNER TO empresa;

--
-- Name: ScheduledMessagesEnvios; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."ScheduledMessagesEnvios" (
    id integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "mediaPath" character varying(255),
    "mediaName" character varying(255),
    mensagem text,
    "companyId" integer,
    data_envio timestamp with time zone,
    scheduledmessages integer,
    key character varying(255)
);


ALTER TABLE public."ScheduledMessagesEnvios" OWNER TO empresa;

--
-- Name: ScheduledMessagesEnvios_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."ScheduledMessagesEnvios_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ScheduledMessagesEnvios_id_seq" OWNER TO empresa;

--
-- Name: ScheduledMessagesEnvios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."ScheduledMessagesEnvios_id_seq" OWNED BY public."ScheduledMessagesEnvios".id;


--
-- Name: ScheduledMessages_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."ScheduledMessages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ScheduledMessages_id_seq" OWNER TO empresa;

--
-- Name: ScheduledMessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."ScheduledMessages_id_seq" OWNED BY public."ScheduledMessages".id;


--
-- Name: Schedules; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Schedules" (
    id integer NOT NULL,
    body text NOT NULL,
    "sendAt" timestamp with time zone,
    "sentAt" timestamp with time zone,
    "contactId" integer,
    "ticketId" integer,
    "userId" integer,
    "companyId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    status character varying(255),
    "ticketUserId" integer,
    "whatsappId" integer,
    "statusTicket" character varying(255) DEFAULT 'closed'::character varying,
    "queueId" integer,
    "openTicket" character varying(255) DEFAULT 'disabled'::character varying,
    "mediaName" character varying(255) DEFAULT NULL::character varying,
    "mediaPath" character varying(255) DEFAULT NULL::character varying,
    intervalo integer DEFAULT 1,
    "valorIntervalo" integer DEFAULT 0,
    "enviarQuantasVezes" integer DEFAULT 1,
    "tipoDias" integer DEFAULT 4,
    "contadorEnvio" integer DEFAULT 0,
    assinar boolean DEFAULT false,
    "googleEventId" character varying(255)
);


ALTER TABLE public."Schedules" OWNER TO empresa;

--
-- Name: Schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Schedules_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Schedules_id_seq" OWNER TO empresa;

--
-- Name: Schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Schedules_id_seq" OWNED BY public."Schedules".id;


--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO empresa;

--
-- Name: Settings; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Settings" (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "companyId" integer,
    id integer NOT NULL
);


ALTER TABLE public."Settings" OWNER TO empresa;

--
-- Name: Settings_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Settings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Settings_id_seq" OWNER TO empresa;

--
-- Name: Settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Settings_id_seq" OWNED BY public."Settings".id;


--
-- Name: SliderBanners; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."SliderBanners" (
    id integer NOT NULL,
    image text NOT NULL,
    url text,
    "companyId" integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now(),
    CONSTRAINT slider_company_only_one CHECK (("companyId" = 1))
);


ALTER TABLE public."SliderBanners" OWNER TO empresa;

--
-- Name: SliderBanners_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."SliderBanners_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."SliderBanners_id_seq" OWNER TO empresa;

--
-- Name: SliderBanners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."SliderBanners_id_seq" OWNED BY public."SliderBanners".id;


--
-- Name: Subscriptions; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Subscriptions" (
    id integer NOT NULL,
    "isActive" boolean DEFAULT false,
    "expiresAt" timestamp with time zone NOT NULL,
    "userPriceCents" integer,
    "whatsPriceCents" integer,
    "lastInvoiceUrl" character varying(255),
    "lastPlanChange" timestamp with time zone,
    "companyId" integer NOT NULL,
    "providerSubscriptionId" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Subscriptions" OWNER TO empresa;

--
-- Name: Subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Subscriptions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Subscriptions_id_seq" OWNER TO empresa;

--
-- Name: Subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Subscriptions_id_seq" OWNED BY public."Subscriptions".id;


--
-- Name: Tags; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Tags" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    color character varying(255),
    "companyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    kanban integer,
    "timeLane" integer DEFAULT 0,
    "nextLaneId" integer,
    "greetingMessageLane" text,
    "rollbackLaneId" integer DEFAULT 0
);


ALTER TABLE public."Tags" OWNER TO empresa;

--
-- Name: Tags_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Tags_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Tags_id_seq" OWNER TO empresa;

--
-- Name: Tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Tags_id_seq" OWNED BY public."Tags".id;


--
-- Name: TicketNotes; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."TicketNotes" (
    id integer NOT NULL,
    note character varying(255) NOT NULL,
    "userId" integer,
    "contactId" integer NOT NULL,
    "ticketId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."TicketNotes" OWNER TO empresa;

--
-- Name: TicketNotes_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."TicketNotes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."TicketNotes_id_seq" OWNER TO empresa;

--
-- Name: TicketNotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."TicketNotes_id_seq" OWNED BY public."TicketNotes".id;


--
-- Name: TicketTags; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."TicketTags" (
    "ticketId" integer NOT NULL,
    "tagId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."TicketTags" OWNER TO empresa;

--
-- Name: TicketTraking; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."TicketTraking" (
    id integer NOT NULL,
    "ticketId" integer,
    "companyId" integer,
    "whatsappId" integer,
    "userId" integer,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    "queuedAt" timestamp with time zone,
    "startedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone,
    "ratingAt" timestamp with time zone,
    rated boolean DEFAULT false,
    "closedAt" timestamp with time zone,
    "chatbotAt" timestamp with time zone,
    "queueId" integer
);


ALTER TABLE public."TicketTraking" OWNER TO empresa;

--
-- Name: TicketTraking_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."TicketTraking_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."TicketTraking_id_seq" OWNER TO empresa;

--
-- Name: TicketTraking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."TicketTraking_id_seq" OWNED BY public."TicketTraking".id;


--
-- Name: Tickets; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Tickets" (
    id integer NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    "lastMessage" text DEFAULT ''::text,
    "contactId" integer,
    "userId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "whatsappId" integer,
    "isGroup" boolean DEFAULT false NOT NULL,
    "unreadMessages" integer,
    "queueId" integer,
    "companyId" integer,
    uuid uuid,
    chatbot boolean DEFAULT false,
    "queueOptionId" integer,
    "isBot" boolean,
    channel text DEFAULT 'whatsapp'::text,
    "amountUsedBotQueues" integer,
    "fromMe" boolean DEFAULT false NOT NULL,
    "amountUsedBotQueuesNPS" integer DEFAULT 0 NOT NULL,
    "sendInactiveMessage" boolean DEFAULT false NOT NULL,
    "lgpdSendMessageAt" timestamp with time zone,
    "lgpdAcceptedAt" timestamp with time zone,
    imported timestamp with time zone,
    "flowWebhook" boolean DEFAULT false NOT NULL,
    "lastFlowId" character varying(255),
    "dataWebhook" json,
    "hashFlowId" character varying(255),
    "useIntegration" boolean DEFAULT false,
    "integrationId" integer,
    "isOutOfHour" boolean DEFAULT false,
    "flowStopped" character varying(255),
    "isActiveDemand" boolean DEFAULT false,
    "typebotSessionId" character varying(255) DEFAULT NULL::character varying,
    "typebotStatus" boolean DEFAULT false NOT NULL,
    "typebotSessionTime" timestamp with time zone,
    "productsSent" jsonb DEFAULT '[]'::jsonb NOT NULL,
    crm_lead_id bigint,
    crm_client_id bigint,
    "leadValue" numeric(10,2),
    lid character varying
);


ALTER TABLE public."Tickets" OWNER TO empresa;

--
-- Name: Tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Tickets_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Tickets_id_seq" OWNER TO empresa;

--
-- Name: Tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Tickets_id_seq" OWNED BY public."Tickets".id;


--
-- Name: UserDevices; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."UserDevices" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "deviceToken" text NOT NULL,
    platform character varying(10) NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT "UserDevices_platform_check" CHECK (((platform)::text = ANY (ARRAY[('ios'::character varying)::text, ('android'::character varying)::text])))
);


ALTER TABLE public."UserDevices" OWNER TO empresa;

--
-- Name: UserDevices_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."UserDevices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UserDevices_id_seq" OWNER TO empresa;

--
-- Name: UserDevices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."UserDevices_id_seq" OWNED BY public."UserDevices".id;


--
-- Name: UserGoogleCalendarIntegrations; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."UserGoogleCalendarIntegrations" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    company_id integer NOT NULL,
    "googleUserId" character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "accessToken" text NOT NULL,
    "refreshToken" text NOT NULL,
    "expiryDate" timestamp without time zone,
    "calendarId" character varying(255) DEFAULT 'primary'::character varying NOT NULL,
    active boolean DEFAULT true,
    "syncToken" text,
    "lastSyncAt" timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserGoogleCalendarIntegrations" OWNER TO empresa;

--
-- Name: TABLE "UserGoogleCalendarIntegrations"; Type: COMMENT; Schema: public; Owner: empresa
--

COMMENT ON TABLE public."UserGoogleCalendarIntegrations" IS 'Tabela de integrações individuais do Google Calendar por usuário';


--
-- Name: UserGoogleCalendarIntegrations_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."UserGoogleCalendarIntegrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UserGoogleCalendarIntegrations_id_seq" OWNER TO empresa;

--
-- Name: UserGoogleCalendarIntegrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."UserGoogleCalendarIntegrations_id_seq" OWNED BY public."UserGoogleCalendarIntegrations".id;


--
-- Name: UserQueues; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."UserQueues" (
    "userId" integer NOT NULL,
    "queueId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."UserQueues" OWNER TO empresa;

--
-- Name: UserRatings; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."UserRatings" (
    id integer NOT NULL,
    "ticketId" integer,
    "companyId" integer,
    "userId" integer,
    rate integer DEFAULT 0,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone
);


ALTER TABLE public."UserRatings" OWNER TO empresa;

--
-- Name: UserRatings_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."UserRatings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UserRatings_id_seq" OWNER TO empresa;

--
-- Name: UserRatings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."UserRatings_id_seq" OWNED BY public."UserRatings".id;


--
-- Name: UserServices; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."UserServices" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "serviceId" integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."UserServices" OWNER TO empresa;

--
-- Name: UserServices_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."UserServices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UserServices_id_seq" OWNER TO empresa;

--
-- Name: UserServices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."UserServices_id_seq" OWNED BY public."UserServices".id;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "passwordHash" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    profile character varying(255) DEFAULT 'admin'::character varying NOT NULL,
    "tokenVersion" integer DEFAULT 0 NOT NULL,
    "companyId" integer,
    super boolean DEFAULT false,
    online boolean DEFAULT false,
    "endWork" character varying(255) DEFAULT '23:59'::character varying,
    "startWork" character varying(255) DEFAULT '00:00'::character varying,
    color character varying(255),
    "farewellMessage" text,
    "whatsappId" integer,
    "allTicket" character varying(255) DEFAULT 'disable'::character varying NOT NULL,
    "allowGroup" boolean DEFAULT false NOT NULL,
    "defaultMenu" character varying(255) DEFAULT 'closed'::character varying NOT NULL,
    "defaultTheme" character varying(255) DEFAULT 'light'::character varying NOT NULL,
    "profileImage" character varying(255),
    "allHistoric" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "allUserChat" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "resetPassword" character varying(255),
    "userClosePendingTicket" character varying(255) DEFAULT 'enabled'::character varying NOT NULL,
    "showDashboard" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "defaultTicketsManagerWidth" integer DEFAULT 550 NOT NULL,
    "allowRealTime" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "allowConnections" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "userType" character varying(255) DEFAULT 'attendant'::character varying,
    "workDays" character varying(255) DEFAULT '1,2,3,4,5'::character varying,
    "lunchStart" character varying(255) DEFAULT NULL::character varying,
    "lunchEnd" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."Users" OWNER TO empresa;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_id_seq" OWNER TO empresa;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: Versions; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Versions" (
    id integer NOT NULL,
    "versionFrontend" text NOT NULL,
    "versionBackend" text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Versions" OWNER TO empresa;

--
-- Name: Versions_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Versions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Versions_id_seq" OWNER TO empresa;

--
-- Name: Versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Versions_id_seq" OWNED BY public."Versions".id;


--
-- Name: Webhooks; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Webhooks" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(255) NOT NULL,
    hash_id character varying(255) NOT NULL,
    config json,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    active boolean DEFAULT false,
    "requestMonth" integer DEFAULT 0,
    "requestAll" integer DEFAULT 0,
    company_id integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."Webhooks" OWNER TO empresa;

--
-- Name: Webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Webhooks_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Webhooks_id_seq" OWNER TO empresa;

--
-- Name: Webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Webhooks_id_seq" OWNED BY public."Webhooks".id;


--
-- Name: WhatsappQueues; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."WhatsappQueues" (
    "whatsappId" integer NOT NULL,
    "queueId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."WhatsappQueues" OWNER TO empresa;

--
-- Name: Whatsapps; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public."Whatsapps" (
    id integer NOT NULL,
    session text,
    qrcode text,
    status character varying(255),
    battery character varying(255),
    plugged boolean,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    retries integer DEFAULT 0 NOT NULL,
    "greetingMessage" text,
    "companyId" integer,
    "complationMessage" text,
    "outOfHoursMessage" text,
    token text,
    "farewellMessage" text,
    provider text DEFAULT 'stable'::text,
    number text,
    channel text,
    "facebookUserToken" text,
    "tokenMeta" text,
    "facebookPageUserId" text,
    "facebookUserId" text,
    "maxUseBotQueues" integer,
    "expiresTicket" integer DEFAULT 0,
    "allowGroup" boolean DEFAULT false NOT NULL,
    "timeUseBotQueues" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "timeSendQueue" integer,
    "sendIdQueue" integer,
    "expiresInactiveMessage" text,
    "maxUseBotQueuesNPS" integer DEFAULT 0,
    "inactiveMessage" character varying(255) DEFAULT ''::character varying,
    "whenExpiresTicket" character varying(255) DEFAULT ''::character varying,
    "expiresTicketNPS" character varying(255) DEFAULT ''::character varying,
    "timeInactiveMessage" character varying(255) DEFAULT ''::character varying,
    "ratingMessage" text,
    "groupAsTicket" character varying(255) DEFAULT 'disabled'::character varying NOT NULL,
    "importOldMessages" text,
    "importRecentMessages" text,
    "statusImportMessages" character varying(255),
    "closedTicketsPostImported" boolean,
    "importOldMessagesGroups" boolean,
    "timeCreateNewTicket" integer,
    "greetingMediaAttachment" character varying(255) DEFAULT NULL::character varying,
    "promptId" integer,
    "integrationId" integer,
    schedules jsonb DEFAULT '[]'::jsonb,
    "collectiveVacationEnd" character varying(255) DEFAULT NULL::character varying,
    "collectiveVacationStart" character varying(255) DEFAULT NULL::character varying,
    "collectiveVacationMessage" text,
    "queueIdImportMessages" integer,
    "flowIdNotPhrase" integer,
    "flowIdWelcome" integer,
    wavoip text,
    "notificameHub" boolean DEFAULT false NOT NULL,
    "coexistencePhoneNumberId" text,
    "coexistenceWabaId" text,
    "coexistencePermanentToken" text,
    "coexistenceEnabled" boolean DEFAULT false NOT NULL,
    "businessAppConnected" boolean DEFAULT false NOT NULL,
    "messageRoutingMode" character varying(255) DEFAULT 'automatic'::character varying NOT NULL,
    "routingRules" jsonb,
    "lastCoexistenceSync" timestamp without time zone
);


ALTER TABLE public."Whatsapps" OWNER TO empresa;

--
-- Name: Whatsapps_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public."Whatsapps_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Whatsapps_id_seq" OWNER TO empresa;

--
-- Name: Whatsapps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public."Whatsapps_id_seq" OWNED BY public."Whatsapps".id;


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    start_datetime timestamp without time zone NOT NULL,
    duration_minutes integer DEFAULT 60,
    status character varying(20) DEFAULT 'scheduled'::character varying,
    schedule_id integer NOT NULL,
    service_id integer,
    client_id integer,
    contact_id integer,
    company_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    google_event_id character varying(255)
);


ALTER TABLE public.appointments OWNER TO empresa;

--
-- Name: COLUMN appointments.google_event_id; Type: COMMENT; Schema: public; Owner: empresa
--

COMMENT ON COLUMN public.appointments.google_event_id IS 'ID do evento correspondente no Google Calendar';


--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.appointments_id_seq OWNER TO empresa;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: company_api_keys; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.company_api_keys (
    id integer NOT NULL,
    company_id integer NOT NULL,
    label character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    webhook_url character varying(255),
    webhook_secret character varying(255),
    active boolean DEFAULT true NOT NULL,
    last_used_at timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.company_api_keys OWNER TO empresa;

--
-- Name: company_api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.company_api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_api_keys_id_seq OWNER TO empresa;

--
-- Name: company_api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.company_api_keys_id_seq OWNED BY public.company_api_keys.id;


--
-- Name: company_integration_field_maps; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.company_integration_field_maps (
    id integer NOT NULL,
    integration_id integer NOT NULL,
    external_field character varying(255) NOT NULL,
    crm_field character varying(255),
    transform_expression text,
    options jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.company_integration_field_maps OWNER TO empresa;

--
-- Name: company_integration_field_maps_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.company_integration_field_maps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_integration_field_maps_id_seq OWNER TO empresa;

--
-- Name: company_integration_field_maps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.company_integration_field_maps_id_seq OWNED BY public.company_integration_field_maps.id;


--
-- Name: company_integration_settings; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.company_integration_settings (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name character varying(255) NOT NULL,
    provider character varying(255),
    base_url character varying(255),
    api_key text,
    api_secret text,
    webhook_secret text,
    metadata jsonb,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.company_integration_settings OWNER TO empresa;

--
-- Name: company_integration_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.company_integration_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_integration_settings_id_seq OWNER TO empresa;

--
-- Name: company_integration_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.company_integration_settings_id_seq OWNED BY public.company_integration_settings.id;


--
-- Name: company_payment_settings; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.company_payment_settings (
    id integer NOT NULL,
    company_id integer NOT NULL,
    provider character varying(255) NOT NULL,
    token text NOT NULL,
    additional_data jsonb,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.company_payment_settings OWNER TO empresa;

--
-- Name: company_payment_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.company_payment_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_payment_settings_id_seq OWNER TO empresa;

--
-- Name: company_payment_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.company_payment_settings_id_seq OWNED BY public.company_payment_settings.id;


--
-- Name: crm_client_contacts; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.crm_client_contacts (
    id bigint NOT NULL,
    client_id bigint NOT NULL,
    contact_id bigint NOT NULL,
    role character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.crm_client_contacts OWNER TO empresa;

--
-- Name: crm_client_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.crm_client_contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.crm_client_contacts_id_seq OWNER TO empresa;

--
-- Name: crm_client_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.crm_client_contacts_id_seq OWNED BY public.crm_client_contacts.id;


--
-- Name: crm_clients; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.crm_clients (
    id bigint NOT NULL,
    company_id bigint NOT NULL,
    type character varying(20) DEFAULT 'pf'::character varying NOT NULL,
    name character varying(150) NOT NULL,
    company_name character varying(150),
    document character varying(30),
    birth_date date,
    email character varying(150),
    phone character varying(30),
    zip_code character varying(15),
    address character varying(150),
    number character varying(20),
    complement character varying(100),
    neighborhood character varying(100),
    city character varying(100),
    state character varying(2),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    client_since date,
    owner_user_id bigint,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    contact_id bigint,
    primary_ticket_id bigint,
    asaas_customer_id character varying(255),
    lid character varying
);


ALTER TABLE public.crm_clients OWNER TO empresa;

--
-- Name: crm_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.crm_clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.crm_clients_id_seq OWNER TO empresa;

--
-- Name: crm_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.crm_clients_id_seq OWNED BY public.crm_clients.id;


--
-- Name: crm_leads; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.crm_leads (
    id bigint NOT NULL,
    company_id bigint NOT NULL,
    name character varying(150) NOT NULL,
    email character varying(150),
    phone character varying(30),
    birth_date date,
    document character varying(30),
    company_name character varying(150),
    "position" character varying(100),
    source character varying(60),
    campaign character varying(100),
    medium character varying(50),
    status character varying(30) DEFAULT 'new'::character varying NOT NULL,
    score integer DEFAULT 0,
    temperature character varying(20),
    owner_user_id bigint,
    notes text,
    last_activity_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    contact_id bigint,
    primary_ticket_id bigint,
    converted_client_id bigint,
    converted_at timestamp with time zone,
    lead_status character varying(32) DEFAULT 'novo'::character varying,
    lid character varying(255)
);


ALTER TABLE public.crm_leads OWNER TO empresa;

--
-- Name: crm_leads_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.crm_leads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.crm_leads_id_seq OWNER TO empresa;

--
-- Name: crm_leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.crm_leads_id_seq OWNED BY public.crm_leads.id;


--
-- Name: financeiro_faturas; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.financeiro_faturas (
    id bigint NOT NULL,
    company_id bigint NOT NULL,
    client_id bigint NOT NULL,
    descricao character varying(255) NOT NULL,
    valor numeric(14,2) NOT NULL,
    status character varying(20) DEFAULT 'aberta'::character varying NOT NULL,
    data_vencimento date NOT NULL,
    data_pagamento timestamp with time zone,
    tipo_referencia character varying(20),
    referencia_id bigint,
    tipo_recorrencia character varying(20) DEFAULT 'unica'::character varying NOT NULL,
    quantidade_ciclos integer,
    ciclo_atual integer DEFAULT 1 NOT NULL,
    data_inicio date DEFAULT CURRENT_DATE NOT NULL,
    data_fim date,
    ativa boolean DEFAULT true NOT NULL,
    observacoes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    valor_pago numeric(14,2) DEFAULT 0 NOT NULL,
    payment_provider character varying(255),
    payment_link text,
    payment_external_id character varying(255),
    checkout_token character varying(64),
    project_id integer,
    CONSTRAINT chk_financeiro_faturas_referencia CHECK ((((tipo_referencia IS NULL) AND (referencia_id IS NULL)) OR ((tipo_referencia IS NOT NULL) AND (referencia_id IS NOT NULL)))),
    CONSTRAINT chk_recorrencia CHECK ((((tipo_recorrencia)::text = 'unica'::text) OR (((tipo_recorrencia)::text = ANY (ARRAY[('mensal'::character varying)::text, ('anual'::character varying)::text])) AND (data_inicio IS NOT NULL)))),
    CONSTRAINT chk_referencia_opcional CHECK ((((tipo_referencia IS NULL) AND (referencia_id IS NULL)) OR ((tipo_referencia IS NOT NULL) AND (referencia_id IS NOT NULL))))
);


ALTER TABLE public.financeiro_faturas OWNER TO empresa;

--
-- Name: financeiro_faturas_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.financeiro_faturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.financeiro_faturas_id_seq OWNER TO empresa;

--
-- Name: financeiro_faturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.financeiro_faturas_id_seq OWNED BY public.financeiro_faturas.id;


--
-- Name: financeiro_pagamentos; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.financeiro_pagamentos (
    id bigint NOT NULL,
    company_id bigint NOT NULL,
    fatura_id bigint NOT NULL,
    metodo_pagamento character varying(20) NOT NULL,
    valor numeric(14,2) NOT NULL,
    data_pagamento timestamp without time zone DEFAULT now() NOT NULL,
    observacoes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.financeiro_pagamentos OWNER TO empresa;

--
-- Name: financeiro_pagamentos_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.financeiro_pagamentos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.financeiro_pagamentos_id_seq OWNER TO empresa;

--
-- Name: financeiro_pagamentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.financeiro_pagamentos_id_seq OWNED BY public.financeiro_pagamentos.id;


--
-- Name: media_files; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.media_files (
    id integer NOT NULL,
    folder_id integer NOT NULL,
    company_id integer NOT NULL,
    original_name character varying(255) NOT NULL,
    custom_name character varying(255),
    mime_type character varying(255) NOT NULL,
    size bigint NOT NULL,
    storage_path text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.media_files OWNER TO empresa;

--
-- Name: media_files_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.media_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_files_id_seq OWNER TO empresa;

--
-- Name: media_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.media_files_id_seq OWNED BY public.media_files.id;


--
-- Name: media_folders; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.media_folders (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    company_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.media_folders OWNER TO empresa;

--
-- Name: media_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.media_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_folders_id_seq OWNER TO empresa;

--
-- Name: media_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.media_folders_id_seq OWNED BY public.media_folders.id;


--
-- Name: profissionais; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.profissionais (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    nome character varying(255) NOT NULL,
    servicos jsonb DEFAULT '[]'::jsonb NOT NULL,
    agenda jsonb DEFAULT '{}'::jsonb NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    comissao numeric(10,2) DEFAULT 0 NOT NULL,
    "valorEmAberto" numeric(12,2) DEFAULT 0 NOT NULL,
    "valoresRecebidos" numeric(12,2) DEFAULT 0 NOT NULL,
    "valoresAReceber" numeric(12,2) DEFAULT 0 NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.profissionais OWNER TO empresa;

--
-- Name: profissionais_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.profissionais_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.profissionais_id_seq OWNER TO empresa;

--
-- Name: profissionais_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.profissionais_id_seq OWNED BY public.profissionais.id;


--
-- Name: project_products; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.project_products (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "projectId" integer NOT NULL,
    "productId" integer NOT NULL,
    quantity integer DEFAULT 1,
    "unitPrice" numeric(10,2),
    notes text,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_products OWNER TO empresa;

--
-- Name: project_products_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.project_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_products_id_seq OWNER TO empresa;

--
-- Name: project_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.project_products_id_seq OWNED BY public.project_products.id;


--
-- Name: project_services; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.project_services (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "projectId" integer NOT NULL,
    "serviceId" integer NOT NULL,
    quantity integer DEFAULT 1,
    "unitPrice" numeric(10,2),
    notes text,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_services OWNER TO empresa;

--
-- Name: project_services_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.project_services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_services_id_seq OWNER TO empresa;

--
-- Name: project_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.project_services_id_seq OWNED BY public.project_services.id;


--
-- Name: project_task_users; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.project_task_users (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "taskId" integer NOT NULL,
    "userId" integer NOT NULL,
    responsibility character varying(255),
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_task_users OWNER TO empresa;

--
-- Name: project_task_users_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.project_task_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_task_users_id_seq OWNER TO empresa;

--
-- Name: project_task_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.project_task_users_id_seq OWNED BY public.project_task_users.id;


--
-- Name: project_tasks; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.project_tasks (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "projectId" integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'pending'::character varying,
    "order" integer DEFAULT 0,
    "startDate" timestamp with time zone,
    "dueDate" timestamp with time zone,
    "completedAt" timestamp with time zone,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_tasks OWNER TO empresa;

--
-- Name: project_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.project_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_tasks_id_seq OWNER TO empresa;

--
-- Name: project_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.project_tasks_id_seq OWNED BY public.project_tasks.id;


--
-- Name: project_users; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.project_users (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "projectId" integer NOT NULL,
    "userId" integer NOT NULL,
    role character varying(100),
    "effortAllocation" integer,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_users OWNER TO empresa;

--
-- Name: project_users_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.project_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_users_id_seq OWNER TO empresa;

--
-- Name: project_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.project_users_id_seq OWNED BY public.project_users.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "clientId" integer,
    "invoiceId" integer,
    name character varying(255) NOT NULL,
    description text,
    "deliveryTime" timestamp with time zone,
    warranty text,
    terms text,
    status character varying(50) DEFAULT 'draft'::character varying,
    "startDate" timestamp with time zone,
    "endDate" timestamp with time zone,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.projects OWNER TO empresa;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO empresa;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: scheduled_dispatch_logs; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.scheduled_dispatch_logs (
    id integer NOT NULL,
    dispatcher_id integer NOT NULL,
    contact_id integer,
    ticket_id integer,
    company_id integer NOT NULL,
    status character varying(32) NOT NULL,
    error_message text,
    sent_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scheduled_dispatch_logs OWNER TO empresa;

--
-- Name: scheduled_dispatch_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.scheduled_dispatch_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduled_dispatch_logs_id_seq OWNER TO empresa;

--
-- Name: scheduled_dispatch_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.scheduled_dispatch_logs_id_seq OWNED BY public.scheduled_dispatch_logs.id;


--
-- Name: scheduled_dispatchers; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.scheduled_dispatchers (
    id integer NOT NULL,
    company_id integer NOT NULL,
    title character varying(255) NOT NULL,
    message_template text NOT NULL,
    event_type character varying(32) NOT NULL,
    whatsapp_id integer,
    start_time character(5) DEFAULT '08:00'::bpchar NOT NULL,
    send_interval_seconds integer DEFAULT 30 NOT NULL,
    days_before_due integer,
    days_after_due integer,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scheduled_dispatchers OWNER TO empresa;

--
-- Name: scheduled_dispatchers_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.scheduled_dispatchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scheduled_dispatchers_id_seq OWNER TO empresa;

--
-- Name: scheduled_dispatchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.scheduled_dispatchers_id_seq OWNED BY public.scheduled_dispatchers.id;


--
-- Name: servicos; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.servicos (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    nome character varying(255) NOT NULL,
    descricao text,
    "valorOriginal" numeric(10,2) DEFAULT 0 NOT NULL,
    "possuiDesconto" boolean DEFAULT false NOT NULL,
    "valorComDesconto" numeric(10,2),
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.servicos OWNER TO empresa;

--
-- Name: servicos_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.servicos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.servicos_id_seq OWNER TO empresa;

--
-- Name: servicos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.servicos_id_seq OWNED BY public.servicos.id;


--
-- Name: slider_home; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.slider_home (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    image text NOT NULL,
    "companyId" integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT slider_home_company_only_one CHECK (("companyId" = 1))
);


ALTER TABLE public.slider_home OWNER TO empresa;

--
-- Name: slider_home_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.slider_home_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.slider_home_id_seq OWNER TO empresa;

--
-- Name: slider_home_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.slider_home_id_seq OWNED BY public.slider_home.id;


--
-- Name: tutorial_videos; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.tutorial_videos (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    video_url character varying(500) NOT NULL,
    thumbnail_url character varying(500),
    company_id integer NOT NULL,
    user_id integer NOT NULL,
    is_active boolean DEFAULT true,
    views_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tutorial_videos_description_check CHECK ((char_length(description) <= 300))
);


ALTER TABLE public.tutorial_videos OWNER TO empresa;

--
-- Name: tutorial_videos_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.tutorial_videos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tutorial_videos_id_seq OWNER TO empresa;

--
-- Name: tutorial_videos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.tutorial_videos_id_seq OWNED BY public.tutorial_videos.id;


--
-- Name: user_schedules; Type: TABLE; Schema: public; Owner: empresa
--

CREATE TABLE public.user_schedules (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    active boolean DEFAULT true,
    user_id integer NOT NULL,
    company_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    user_google_calendar_integration_id integer
);


ALTER TABLE public.user_schedules OWNER TO empresa;

--
-- Name: COLUMN user_schedules.user_google_calendar_integration_id; Type: COMMENT; Schema: public; Owner: empresa
--

COMMENT ON COLUMN public.user_schedules.user_google_calendar_integration_id IS 'ID da integração Google Calendar vinculada a esta agenda';


--
-- Name: user_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: empresa
--

CREATE SEQUENCE public.user_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_schedules_id_seq OWNER TO empresa;

--
-- Name: user_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: empresa
--

ALTER SEQUENCE public.user_schedules_id_seq OWNED BY public.user_schedules.id;


--
-- Name: Announcements id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Announcements" ALTER COLUMN id SET DEFAULT nextval('public."Announcements_id_seq"'::regclass);


--
-- Name: ApiUsages id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ApiUsages" ALTER COLUMN id SET DEFAULT nextval('public."ApiUsages_id_seq"'::regclass);


--
-- Name: AutomationActions id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationActions" ALTER COLUMN id SET DEFAULT nextval('public."AutomationActions_id_seq"'::regclass);


--
-- Name: AutomationExecutions id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationExecutions" ALTER COLUMN id SET DEFAULT nextval('public."AutomationExecutions_id_seq"'::regclass);


--
-- Name: AutomationLogs id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationLogs" ALTER COLUMN id SET DEFAULT nextval('public."AutomationLogs_id_seq"'::regclass);


--
-- Name: Automations id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Automations" ALTER COLUMN id SET DEFAULT nextval('public."Automations_id_seq"'::regclass);


--
-- Name: Baileys id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Baileys" ALTER COLUMN id SET DEFAULT nextval('public."Baileys_id_seq"'::regclass);


--
-- Name: CampaignSettings id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."CampaignSettings" ALTER COLUMN id SET DEFAULT nextval('public."CampaignSettings_id_seq"'::regclass);


--
-- Name: CampaignShipping id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."CampaignShipping" ALTER COLUMN id SET DEFAULT nextval('public."CampaignShipping_id_seq"'::regclass);


--
-- Name: Campaigns id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Campaigns" ALTER COLUMN id SET DEFAULT nextval('public."Campaigns_id_seq"'::regclass);


--
-- Name: ChatMessages id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ChatMessages" ALTER COLUMN id SET DEFAULT nextval('public."ChatMessages_id_seq"'::regclass);


--
-- Name: ChatUsers id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ChatUsers" ALTER COLUMN id SET DEFAULT nextval('public."ChatUsers_id_seq"'::regclass);


--
-- Name: Chatbots id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chatbots" ALTER COLUMN id SET DEFAULT nextval('public."Chatbots_id_seq"'::regclass);


--
-- Name: Chats id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chats" ALTER COLUMN id SET DEFAULT nextval('public."Chats_id_seq"'::regclass);


--
-- Name: Companies id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Companies" ALTER COLUMN id SET DEFAULT nextval('public."Companies_id_seq"'::regclass);


--
-- Name: CompaniesSettings id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."CompaniesSettings" ALTER COLUMN id SET DEFAULT nextval('public."CompaniesSettings_id_seq"'::regclass);


--
-- Name: ContactCustomFields id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactCustomFields" ALTER COLUMN id SET DEFAULT nextval('public."ContactCustomFields_id_seq"'::regclass);


--
-- Name: ContactGroups id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactGroups" ALTER COLUMN id SET DEFAULT nextval('public."ContactGroups_id_seq"'::regclass);


--
-- Name: ContactListItems id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactListItems" ALTER COLUMN id SET DEFAULT nextval('public."ContactListItems_id_seq"'::regclass);


--
-- Name: ContactLists id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactLists" ALTER COLUMN id SET DEFAULT nextval('public."ContactLists_id_seq"'::regclass);


--
-- Name: ContactWallets id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactWallets" ALTER COLUMN id SET DEFAULT nextval('public."ContactWallets_id_seq"'::regclass);


--
-- Name: Contacts id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Contacts" ALTER COLUMN id SET DEFAULT nextval('public."Contacts_id_seq"'::regclass);


--
-- Name: DialogChatBots id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."DialogChatBots" ALTER COLUMN id SET DEFAULT nextval('public."DialogChatBots_id_seq"'::regclass);


--
-- Name: Faturas id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Faturas" ALTER COLUMN id SET DEFAULT nextval('public."Faturas_id_seq"'::regclass);


--
-- Name: Ferramentas id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Ferramentas" ALTER COLUMN id SET DEFAULT nextval('public."Ferramentas_id_seq"'::regclass);


--
-- Name: Files id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Files" ALTER COLUMN id SET DEFAULT nextval('public."Files_id_seq"'::regclass);


--
-- Name: FilesOptions id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FilesOptions" ALTER COLUMN id SET DEFAULT nextval('public."FilesOptions_id_seq"'::regclass);


--
-- Name: FlowAudios id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FlowAudios" ALTER COLUMN id SET DEFAULT nextval('public."FlowAudios_id_seq"'::regclass);


--
-- Name: FlowBuilders id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FlowBuilders" ALTER COLUMN id SET DEFAULT nextval('public."FlowBuilders_id_seq"'::regclass);


--
-- Name: FlowCampaigns id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FlowCampaigns" ALTER COLUMN id SET DEFAULT nextval('public."FlowCampaigns_id_seq"'::regclass);


--
-- Name: FlowDefaults id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FlowDefaults" ALTER COLUMN id SET DEFAULT nextval('public."FlowDefaults_id_seq"'::regclass);


--
-- Name: FlowImgs id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FlowImgs" ALTER COLUMN id SET DEFAULT nextval('public."FlowImgs_id_seq"'::regclass);


--
-- Name: GoogleCalendarIntegrations id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."GoogleCalendarIntegrations" ALTER COLUMN id SET DEFAULT nextval('public."GoogleCalendarIntegrations_id_seq"'::regclass);


--
-- Name: GoogleSheetsTokens id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."GoogleSheetsTokens" ALTER COLUMN id SET DEFAULT nextval('public."GoogleSheetsTokens_id_seq"'::regclass);


--
-- Name: Helps id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Helps" ALTER COLUMN id SET DEFAULT nextval('public."Helps_id_seq"'::regclass);


--
-- Name: IaWorkflows id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."IaWorkflows" ALTER COLUMN id SET DEFAULT nextval('public."IaWorkflows_id_seq"'::regclass);


--
-- Name: Integrations id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Integrations" ALTER COLUMN id SET DEFAULT nextval('public."Integrations_id_seq"'::regclass);


--
-- Name: Invoices id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Invoices" ALTER COLUMN id SET DEFAULT nextval('public."Invoices_id_seq"'::regclass);


--
-- Name: LogTickets id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."LogTickets" ALTER COLUMN id SET DEFAULT nextval('public."LogTickets_id_seq"'::regclass);


--
-- Name: MediaFiles id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."MediaFiles" ALTER COLUMN id SET DEFAULT nextval('public."MediaFiles_id_seq"'::regclass);


--
-- Name: MediaFolders id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."MediaFolders" ALTER COLUMN id SET DEFAULT nextval('public."MediaFolders_id_seq"'::regclass);


--
-- Name: Messages id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Messages" ALTER COLUMN id SET DEFAULT nextval('public."Messages_id_seq"'::regclass);


--
-- Name: MobileWebhooks id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."MobileWebhooks" ALTER COLUMN id SET DEFAULT nextval('public."MobileWebhooks_id_seq"'::regclass);


--
-- Name: Negocios id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Negocios" ALTER COLUMN id SET DEFAULT nextval('public."Negocios_id_seq"'::regclass);


--
-- Name: Partners id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Partners" ALTER COLUMN id SET DEFAULT nextval('public."Partners_id_seq"'::regclass);


--
-- Name: Plans id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Plans" ALTER COLUMN id SET DEFAULT nextval('public."Plans_id_seq"'::regclass);


--
-- Name: Produtos id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Produtos" ALTER COLUMN id SET DEFAULT nextval('public."Produtos_id_seq"'::regclass);


--
-- Name: PromptToolSettings id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."PromptToolSettings" ALTER COLUMN id SET DEFAULT nextval('public."PromptToolSettings_id_seq"'::regclass);


--
-- Name: Prompts id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Prompts" ALTER COLUMN id SET DEFAULT nextval('public."Prompts_id_seq"'::regclass);


--
-- Name: QueueIntegrations id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QueueIntegrations" ALTER COLUMN id SET DEFAULT nextval('public."QueueIntegrations_id_seq"'::regclass);


--
-- Name: QueueOptions id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QueueOptions" ALTER COLUMN id SET DEFAULT nextval('public."QueueOptions_id_seq"'::regclass);


--
-- Name: Queues id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Queues" ALTER COLUMN id SET DEFAULT nextval('public."Queues_id_seq"'::regclass);


--
-- Name: QuickMessages id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QuickMessages" ALTER COLUMN id SET DEFAULT nextval('public."QuickMessages_id_seq"'::regclass);


--
-- Name: ScheduledMessages id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ScheduledMessages" ALTER COLUMN id SET DEFAULT nextval('public."ScheduledMessages_id_seq"'::regclass);


--
-- Name: ScheduledMessagesEnvios id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ScheduledMessagesEnvios" ALTER COLUMN id SET DEFAULT nextval('public."ScheduledMessagesEnvios_id_seq"'::regclass);


--
-- Name: Schedules id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Schedules" ALTER COLUMN id SET DEFAULT nextval('public."Schedules_id_seq"'::regclass);


--
-- Name: Settings id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Settings" ALTER COLUMN id SET DEFAULT nextval('public."Settings_id_seq"'::regclass);


--
-- Name: SliderBanners id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."SliderBanners" ALTER COLUMN id SET DEFAULT nextval('public."SliderBanners_id_seq"'::regclass);


--
-- Name: Subscriptions id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Subscriptions" ALTER COLUMN id SET DEFAULT nextval('public."Subscriptions_id_seq"'::regclass);


--
-- Name: Tags id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tags" ALTER COLUMN id SET DEFAULT nextval('public."Tags_id_seq"'::regclass);


--
-- Name: TicketNotes id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketNotes" ALTER COLUMN id SET DEFAULT nextval('public."TicketNotes_id_seq"'::regclass);


--
-- Name: TicketTraking id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketTraking" ALTER COLUMN id SET DEFAULT nextval('public."TicketTraking_id_seq"'::regclass);


--
-- Name: Tickets id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets" ALTER COLUMN id SET DEFAULT nextval('public."Tickets_id_seq"'::regclass);


--
-- Name: UserDevices id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserDevices" ALTER COLUMN id SET DEFAULT nextval('public."UserDevices_id_seq"'::regclass);


--
-- Name: UserGoogleCalendarIntegrations id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserGoogleCalendarIntegrations" ALTER COLUMN id SET DEFAULT nextval('public."UserGoogleCalendarIntegrations_id_seq"'::regclass);


--
-- Name: UserRatings id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserRatings" ALTER COLUMN id SET DEFAULT nextval('public."UserRatings_id_seq"'::regclass);


--
-- Name: UserServices id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserServices" ALTER COLUMN id SET DEFAULT nextval('public."UserServices_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Name: Versions id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Versions" ALTER COLUMN id SET DEFAULT nextval('public."Versions_id_seq"'::regclass);


--
-- Name: Webhooks id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Webhooks" ALTER COLUMN id SET DEFAULT nextval('public."Webhooks_id_seq"'::regclass);


--
-- Name: Whatsapps id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Whatsapps" ALTER COLUMN id SET DEFAULT nextval('public."Whatsapps_id_seq"'::regclass);


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: company_api_keys id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_api_keys ALTER COLUMN id SET DEFAULT nextval('public.company_api_keys_id_seq'::regclass);


--
-- Name: company_integration_field_maps id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_integration_field_maps ALTER COLUMN id SET DEFAULT nextval('public.company_integration_field_maps_id_seq'::regclass);


--
-- Name: company_integration_settings id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_integration_settings ALTER COLUMN id SET DEFAULT nextval('public.company_integration_settings_id_seq'::regclass);


--
-- Name: company_payment_settings id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_payment_settings ALTER COLUMN id SET DEFAULT nextval('public.company_payment_settings_id_seq'::regclass);


--
-- Name: crm_client_contacts id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_client_contacts ALTER COLUMN id SET DEFAULT nextval('public.crm_client_contacts_id_seq'::regclass);


--
-- Name: crm_clients id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_clients ALTER COLUMN id SET DEFAULT nextval('public.crm_clients_id_seq'::regclass);


--
-- Name: crm_leads id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_leads ALTER COLUMN id SET DEFAULT nextval('public.crm_leads_id_seq'::regclass);


--
-- Name: financeiro_faturas id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.financeiro_faturas ALTER COLUMN id SET DEFAULT nextval('public.financeiro_faturas_id_seq'::regclass);


--
-- Name: financeiro_pagamentos id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.financeiro_pagamentos ALTER COLUMN id SET DEFAULT nextval('public.financeiro_pagamentos_id_seq'::regclass);


--
-- Name: media_files id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.media_files ALTER COLUMN id SET DEFAULT nextval('public.media_files_id_seq'::regclass);


--
-- Name: media_folders id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.media_folders ALTER COLUMN id SET DEFAULT nextval('public.media_folders_id_seq'::regclass);


--
-- Name: profissionais id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.profissionais ALTER COLUMN id SET DEFAULT nextval('public.profissionais_id_seq'::regclass);


--
-- Name: project_products id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_products ALTER COLUMN id SET DEFAULT nextval('public.project_products_id_seq'::regclass);


--
-- Name: project_services id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_services ALTER COLUMN id SET DEFAULT nextval('public.project_services_id_seq'::regclass);


--
-- Name: project_task_users id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_task_users ALTER COLUMN id SET DEFAULT nextval('public.project_task_users_id_seq'::regclass);


--
-- Name: project_tasks id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_tasks ALTER COLUMN id SET DEFAULT nextval('public.project_tasks_id_seq'::regclass);


--
-- Name: project_users id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_users ALTER COLUMN id SET DEFAULT nextval('public.project_users_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: scheduled_dispatch_logs id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.scheduled_dispatch_logs ALTER COLUMN id SET DEFAULT nextval('public.scheduled_dispatch_logs_id_seq'::regclass);


--
-- Name: scheduled_dispatchers id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.scheduled_dispatchers ALTER COLUMN id SET DEFAULT nextval('public.scheduled_dispatchers_id_seq'::regclass);


--
-- Name: servicos id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.servicos ALTER COLUMN id SET DEFAULT nextval('public.servicos_id_seq'::regclass);


--
-- Name: slider_home id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.slider_home ALTER COLUMN id SET DEFAULT nextval('public.slider_home_id_seq'::regclass);


--
-- Name: tutorial_videos id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.tutorial_videos ALTER COLUMN id SET DEFAULT nextval('public.tutorial_videos_id_seq'::regclass);


--
-- Name: user_schedules id; Type: DEFAULT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.user_schedules ALTER COLUMN id SET DEFAULT nextval('public.user_schedules_id_seq'::regclass);


--
-- Data for Name: Announcements; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Announcements" (id, priority, title, text, "mediaPath", "mediaName", "companyId", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ApiUsages; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."ApiUsages" (id, "companyId", "dateUsed", "UsedOnDay", "usedText", "usedPDF", "usedImage", "usedVideo", "usedOther", "usedCheckNumber", "createdAt", "updatedAt") FROM stdin;
1   1   21/11/2025  1   0   1   0   0   0   0   2025-11-21 03:35:08.607+00  2025-11-21 03:35:08.613+00
2   1   02/12/2025  23  23  0   0   0   0   0   2025-12-02 19:22:44.499+00  2025-12-03 02:50:43.55+00
3   1   10/12/2025  1   1   0   0   0   0   0   2025-12-10 19:51:20.438+00  2025-12-10 19:51:20.443+00
4   5   16/01/2026  3   3   0   0   0   0   0   2026-01-16 07:04:45.814+00  2026-01-16 07:27:28.54+00
\.


--
-- Data for Name: AutomationActions; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."AutomationActions" (id, "automationId", "actionType", "actionConfig", "order", "delayMinutes", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AutomationExecutions; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."AutomationExecutions" (id, "automationId", "automationActionId", "contactId", "ticketId", "scheduledAt", status, attempts, "lastAttemptAt", "completedAt", error, metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AutomationLogs; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."AutomationLogs" (id, "automationId", "contactId", "ticketId", status, "executedAt", result, error, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Automations; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Automations" (id, "companyId", name, description, "triggerType", "triggerConfig", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Baileys; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Baileys" (id, "whatsappId", contacts, chats, "createdAt", "updatedAt") FROM stdin;
9   32  []  \N  2025-11-20 17:18:53.85+00   2025-11-20 17:18:53.85+00
10  51  []  \N  2025-11-24 20:40:14.279+00  2025-11-24 20:40:14.279+00
28  53  []  \N  2025-11-26 17:19:25.13+00   2025-11-26 17:19:25.13+00
29  53  []  \N  2025-11-26 17:19:25.13+00   2025-11-26 17:19:25.13+00
30  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
31  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
32  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
33  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
34  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
35  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
36  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
38  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
39  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
40  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
41  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
42  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
43  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
44  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
45  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
46  53  []  \N  2025-11-26 17:19:25.287+00  2025-11-26 17:19:25.287+00
47  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
48  53  []  \N  2025-11-26 17:19:25.125+00  2025-11-26 17:19:25.125+00
49  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
37  53  []  \N  2025-11-26 17:19:25.244+00  2025-11-26 17:19:25.244+00
50  53  []  \N  2025-11-26 17:19:25.287+00  2025-11-26 17:19:25.287+00
51  53  []  \N  2025-11-26 17:19:25.287+00  2025-11-26 17:19:25.287+00
52  53  []  \N  2025-11-26 17:19:25.288+00  2025-11-26 17:19:25.288+00
53  53  []  \N  2025-11-26 17:19:25.288+00  2025-11-26 17:19:25.288+00
54  53  []  \N  2025-11-26 17:19:25.288+00  2025-11-26 17:19:25.288+00
55  53  []  \N  2025-11-26 17:19:25.392+00  2025-11-26 17:19:25.392+00
56  53  []  \N  2025-11-26 17:19:25.392+00  2025-11-26 17:19:25.392+00
57  53  []  \N  2025-11-26 17:19:25.392+00  2025-11-26 17:19:25.392+00
58  53  []  \N  2025-11-26 17:19:25.288+00  2025-11-26 17:19:25.288+00
59  53  []  \N  2025-11-26 17:19:25.288+00  2025-11-26 17:19:25.288+00
60  53  []  \N  2025-11-26 17:19:25.307+00  2025-11-26 17:19:25.307+00
61  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
62  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
63  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
64  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
65  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
66  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
67  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
68  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
69  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
70  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
71  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
72  53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
73  53  []  \N  2025-11-26 17:19:25.352+00  2025-11-26 17:19:25.352+00
74  53  []  \N  2025-11-26 17:19:25.352+00  2025-11-26 17:19:25.352+00
75  53  []  \N  2025-11-26 17:19:25.352+00  2025-11-26 17:19:25.352+00
76  53  []  \N  2025-11-26 17:19:25.352+00  2025-11-26 17:19:25.352+00
77  53  []  \N  2025-11-26 17:19:25.38+00   2025-11-26 17:19:25.38+00
78  53  []  \N  2025-11-26 17:19:25.38+00   2025-11-26 17:19:25.38+00
79  53  []  \N  2025-11-26 17:19:25.391+00  2025-11-26 17:19:25.391+00
80  53  []  \N  2025-11-26 17:19:25.412+00  2025-11-26 17:19:25.412+00
81  53  []  \N  2025-11-26 17:19:25.412+00  2025-11-26 17:19:25.412+00
82  53  []  \N  2025-11-26 17:19:25.391+00  2025-11-26 17:19:25.391+00
83  53  []  \N  2025-11-26 17:19:25.391+00  2025-11-26 17:19:25.391+00
84  53  []  \N  2025-11-26 17:19:25.391+00  2025-11-26 17:19:25.391+00
85  53  []  \N  2025-11-26 17:19:25.392+00  2025-11-26 17:19:25.392+00
86  53  []  \N  2025-11-26 17:19:25.392+00  2025-11-26 17:19:25.392+00
87  53  []  \N  2025-11-26 17:19:25.412+00  2025-11-26 17:19:25.412+00
88  53  []  \N  2025-11-26 17:19:25.391+00  2025-11-26 17:19:25.391+00
89  53  []  \N  2025-11-26 17:19:25.288+00  2025-11-26 17:19:25.288+00
90  53  []  \N  2025-11-26 17:19:25.288+00  2025-11-26 17:19:25.288+00
91  53  []  \N  2025-11-26 17:19:25.288+00  2025-11-26 17:19:25.288+00
93  53  []  \N  2025-11-26 17:19:25.287+00  2025-11-26 17:19:25.287+00
94  53  []  \N  2025-11-26 17:19:25.287+00  2025-11-26 17:19:25.287+00
96  53  []  \N  2025-11-26 17:19:25.412+00  2025-11-26 17:19:25.412+00
97  53  []  \N  2025-11-26 17:19:25.418+00  2025-11-26 17:19:25.418+00
98  53  []  \N  2025-11-26 17:19:25.42+00   2025-11-26 17:19:25.42+00
99  53  []  \N  2025-11-26 17:19:25.42+00   2025-11-26 17:19:25.42+00
100 53  []  \N  2025-11-26 17:19:25.421+00  2025-11-26 17:19:25.421+00
101 53  []  \N  2025-11-26 17:19:25.425+00  2025-11-26 17:19:25.425+00
102 53  []  \N  2025-11-26 17:19:25.425+00  2025-11-26 17:19:25.425+00
103 53  []  \N  2025-11-26 17:19:25.425+00  2025-11-26 17:19:25.425+00
105 53  []  \N  2025-11-26 17:19:25.425+00  2025-11-26 17:19:25.425+00
106 53  []  \N  2025-11-26 17:19:25.425+00  2025-11-26 17:19:25.425+00
107 53  []  \N  2025-11-26 17:19:25.425+00  2025-11-26 17:19:25.425+00
108 53  []  \N  2025-11-26 17:19:25.425+00  2025-11-26 17:19:25.425+00
109 53  []  \N  2025-11-26 17:19:25.435+00  2025-11-26 17:19:25.435+00
110 53  []  \N  2025-11-26 17:19:25.435+00  2025-11-26 17:19:25.435+00
111 53  []  \N  2025-11-26 17:19:25.435+00  2025-11-26 17:19:25.435+00
112 53  []  \N  2025-11-26 17:19:25.435+00  2025-11-26 17:19:25.435+00
113 53  []  \N  2025-11-26 17:19:25.435+00  2025-11-26 17:19:25.435+00
114 53  []  \N  2025-11-26 17:19:25.435+00  2025-11-26 17:19:25.435+00
115 53  []  \N  2025-11-26 17:19:25.435+00  2025-11-26 17:19:25.435+00
116 53  []  \N  2025-11-26 17:19:25.435+00  2025-11-26 17:19:25.435+00
117 53  []  \N  2025-11-26 17:19:25.436+00  2025-11-26 17:19:25.436+00
118 53  []  \N  2025-11-26 17:19:25.436+00  2025-11-26 17:19:25.436+00
119 53  []  \N  2025-11-26 17:19:25.436+00  2025-11-26 17:19:25.436+00
132 53  []  \N  2025-11-26 17:19:25.442+00  2025-11-26 17:19:25.442+00
143 53  []  \N  2025-11-26 17:19:25.47+00   2025-11-26 17:19:25.47+00
153 53  []  \N  2025-11-26 17:19:25.471+00  2025-11-26 17:19:25.471+00
170 53  []  \N  2025-11-26 17:19:25.502+00  2025-11-26 17:19:25.502+00
186 53  []  \N  2025-11-26 17:19:25.51+00   2025-11-26 17:19:25.51+00
203 53  []  \N  2025-11-26 17:19:25.517+00  2025-11-26 17:19:25.517+00
209 53  []  \N  2025-11-26 17:19:25.533+00  2025-11-26 17:19:25.533+00
215 53  []  \N  2025-11-26 17:19:25.534+00  2025-11-26 17:19:25.534+00
239 53  []  \N  2025-11-26 17:19:25.55+00   2025-11-26 17:19:25.55+00
246 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
249 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
284 53  []  \N  2025-11-26 17:19:25.564+00  2025-11-26 17:19:25.564+00
295 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
310 53  []  \N  2025-11-26 17:19:25.588+00  2025-11-26 17:19:25.588+00
315 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
316 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
348 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
364 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
393 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
400 53  []  \N  2025-11-26 17:19:25.659+00  2025-11-26 17:19:25.659+00
412 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
414 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
450 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
453 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
460 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
485 53  []  \N  2025-11-26 17:19:25.733+00  2025-11-26 17:19:25.733+00
491 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
531 53  []  \N  2025-11-26 17:19:25.834+00  2025-11-26 17:19:25.834+00
534 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
573 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
582 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
597 53  []  \N  2025-11-26 17:19:25.875+00  2025-11-26 17:19:25.875+00
126 53  []  \N  2025-11-26 17:19:25.392+00  2025-11-26 17:19:25.392+00
2150    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2245    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2347    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2439    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
133 53  []  \N  2025-11-26 17:19:25.442+00  2025-11-26 17:19:25.442+00
144 53  []  \N  2025-11-26 17:19:25.442+00  2025-11-26 17:19:25.442+00
154 53  []  \N  2025-11-26 17:19:25.47+00   2025-11-26 17:19:25.47+00
171 53  []  \N  2025-11-26 17:19:25.504+00  2025-11-26 17:19:25.504+00
187 53  []  \N  2025-11-26 17:19:25.504+00  2025-11-26 17:19:25.504+00
208 53  []  \N  2025-11-26 17:19:25.517+00  2025-11-26 17:19:25.517+00
219 53  []  \N  2025-11-26 17:19:25.533+00  2025-11-26 17:19:25.533+00
222 53  []  \N  2025-11-26 17:19:25.529+00  2025-11-26 17:19:25.529+00
234 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
242 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
254 53  []  \N  2025-11-26 17:19:25.555+00  2025-11-26 17:19:25.555+00
276 53  []  \N  2025-11-26 17:19:25.564+00  2025-11-26 17:19:25.564+00
294 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
325 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
327 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
363 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
381 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
382 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
407 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
428 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
433 53  []  \N  2025-11-26 17:19:25.659+00  2025-11-26 17:19:25.659+00
435 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
488 53  []  \N  2025-11-26 17:19:25.733+00  2025-11-26 17:19:25.733+00
499 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
511 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
532 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
558 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
562 53  []  \N  2025-11-26 17:19:25.872+00  2025-11-26 17:19:25.872+00
569 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
599 53  []  \N  2025-11-26 17:19:25.875+00  2025-11-26 17:19:25.875+00
123 53  []  \N  2025-11-26 17:19:25.441+00  2025-11-26 17:19:25.441+00
1633    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1667    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1745    83  []  \N  2026-01-13 21:09:21.412+00  2026-01-13 21:09:21.412+00
1836    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1933    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2041    83  []  \N  2026-01-13 21:09:21.626+00  2026-01-13 21:09:21.626+00
2141    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2254    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2339    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2440    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
134 53  []  \N  2025-11-26 17:19:25.461+00  2025-11-26 17:19:25.461+00
145 53  []  \N  2025-11-26 17:19:25.47+00   2025-11-26 17:19:25.47+00
155 53  []  \N  2025-11-26 17:19:25.479+00  2025-11-26 17:19:25.479+00
172 53  []  \N  2025-11-26 17:19:25.504+00  2025-11-26 17:19:25.504+00
188 53  []  \N  2025-11-26 17:19:25.51+00   2025-11-26 17:19:25.51+00
199 53  []  \N  2025-11-26 17:19:25.517+00  2025-11-26 17:19:25.517+00
211 53  []  \N  2025-11-26 17:19:25.533+00  2025-11-26 17:19:25.533+00
217 53  []  \N  2025-11-26 17:19:25.534+00  2025-11-26 17:19:25.534+00
240 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
241 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
250 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
275 53  []  \N  2025-11-26 17:19:25.563+00  2025-11-26 17:19:25.563+00
293 53  []  \N  2025-11-26 17:19:25.575+00  2025-11-26 17:19:25.575+00
314 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
318 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
319 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
331 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
362 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
385 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
394 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
402 53  []  \N  2025-11-26 17:19:25.659+00  2025-11-26 17:19:25.659+00
427 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
432 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
454 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
470 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
473 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
501 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
505 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
544 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
552 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
559 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
567 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
581 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
125 53  []  \N  2025-11-26 17:19:25.442+00  2025-11-26 17:19:25.442+00
1592    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1661    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1735    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1830    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1911    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2033    83  []  \N  2026-01-13 21:09:21.625+00  2026-01-13 21:09:21.625+00
2133    83  []  \N  2026-01-13 21:09:21.761+00  2026-01-13 21:09:21.761+00
2220    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2279    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2384    83  []  \N  2026-01-13 21:09:21.98+00   2026-01-13 21:09:21.98+00
2475    83  []  \N  2026-01-13 21:09:22.145+00  2026-01-13 21:09:22.145+00
135 53  []  \N  2025-11-26 17:19:25.466+00  2025-11-26 17:19:25.466+00
147 53  []  \N  2025-11-26 17:19:25.461+00  2025-11-26 17:19:25.461+00
156 53  []  \N  2025-11-26 17:19:25.47+00   2025-11-26 17:19:25.47+00
173 53  []  \N  2025-11-26 17:19:25.504+00  2025-11-26 17:19:25.504+00
189 53  []  \N  2025-11-26 17:19:25.51+00   2025-11-26 17:19:25.51+00
202 53  []  \N  2025-11-26 17:19:25.517+00  2025-11-26 17:19:25.517+00
210 53  []  \N  2025-11-26 17:19:25.533+00  2025-11-26 17:19:25.533+00
221 53  []  \N  2025-11-26 17:19:25.529+00  2025-11-26 17:19:25.529+00
235 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
238 53  []  \N  2025-11-26 17:19:25.546+00  2025-11-26 17:19:25.546+00
247 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
274 53  []  \N  2025-11-26 17:19:25.562+00  2025-11-26 17:19:25.562+00
290 53  []  \N  2025-11-26 17:19:25.575+00  2025-11-26 17:19:25.575+00
309 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
317 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
330 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
359 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
378 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
384 53  []  \N  2025-11-26 17:19:25.646+00  2025-11-26 17:19:25.646+00
388 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
401 53  []  \N  2025-11-26 17:19:25.659+00  2025-11-26 17:19:25.659+00
445 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
462 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
471 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
484 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
496 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
509 53  []  \N  2025-11-26 17:19:25.739+00  2025-11-26 17:19:25.739+00
510 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
541 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
548 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
556 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
561 53  []  \N  2025-11-26 17:19:25.872+00  2025-11-26 17:19:25.872+00
578 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
122 53  []  \N  2025-11-26 17:19:25.441+00  2025-11-26 17:19:25.441+00
1610    83  []  \N  2026-01-13 21:09:21.176+00  2026-01-13 21:09:21.176+00
1681    83  []  \N  2026-01-13 21:09:21.279+00  2026-01-13 21:09:21.279+00
1817    83  []  \N  2026-01-13 21:09:21.449+00  2026-01-13 21:09:21.449+00
1922    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2022    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2120    83  []  \N  2026-01-13 21:09:21.76+00   2026-01-13 21:09:21.76+00
2223    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2320    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2382    83  []  \N  2026-01-13 21:09:21.98+00   2026-01-13 21:09:21.98+00
2474    83  []  \N  2026-01-13 21:09:22.144+00  2026-01-13 21:09:22.144+00
136 53  []  \N  2025-11-26 17:19:25.466+00  2025-11-26 17:19:25.466+00
146 53  []  \N  2025-11-26 17:19:25.471+00  2025-11-26 17:19:25.471+00
157 53  []  \N  2025-11-26 17:19:25.47+00   2025-11-26 17:19:25.47+00
174 53  []  \N  2025-11-26 17:19:25.504+00  2025-11-26 17:19:25.504+00
190 53  []  \N  2025-11-26 17:19:25.51+00   2025-11-26 17:19:25.51+00
200 53  []  \N  2025-11-26 17:19:25.517+00  2025-11-26 17:19:25.517+00
213 53  []  \N  2025-11-26 17:19:25.534+00  2025-11-26 17:19:25.534+00
225 53  []  \N  2025-11-26 17:19:25.533+00  2025-11-26 17:19:25.533+00
243 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
252 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
255 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
273 53  []  \N  2025-11-26 17:19:25.562+00  2025-11-26 17:19:25.562+00
291 53  []  \N  2025-11-26 17:19:25.575+00  2025-11-26 17:19:25.575+00
312 53  []  \N  2025-11-26 17:19:25.592+00  2025-11-26 17:19:25.592+00
323 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
324 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
326 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
360 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
431 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
440 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
447 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
449 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
452 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
506 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
515 53  []  \N  2025-11-26 17:19:25.739+00  2025-11-26 17:19:25.739+00
520 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
542 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
555 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
563 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
589 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
592 53  []  \N  2025-11-26 17:19:25.875+00  2025-11-26 17:19:25.875+00
121 53  []  \N  2025-11-26 17:19:25.441+00  2025-11-26 17:19:25.441+00
1559    30  []  \N  2025-12-31 16:40:15.777+00  2025-12-31 16:40:15.777+00
1598    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1695    83  []  \N  2026-01-13 21:09:21.297+00  2026-01-13 21:09:21.297+00
1776    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1849    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1941    83  []  \N  2026-01-13 21:09:21.578+00  2026-01-13 21:09:21.578+00
2061    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2136    83  []  \N  2026-01-13 21:09:21.769+00  2026-01-13 21:09:21.769+00
2230    83  []  \N  2026-01-13 21:09:21.882+00  2026-01-13 21:09:21.882+00
2361    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2463    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3245    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3345    135 []  \N  2026-02-04 03:31:34.394+00  2026-02-04 03:31:34.394+00
3442    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3542    135 []  \N  2026-02-04 03:31:34.565+00  2026-02-04 03:31:34.565+00
137 53  []  \N  2025-11-26 17:19:25.466+00  2025-11-26 17:19:25.466+00
148 53  []  \N  2025-11-26 17:19:25.471+00  2025-11-26 17:19:25.471+00
158 53  []  \N  2025-11-26 17:19:25.479+00  2025-11-26 17:19:25.479+00
175 53  []  \N  2025-11-26 17:19:25.504+00  2025-11-26 17:19:25.504+00
191 53  []  \N  2025-11-26 17:19:25.51+00   2025-11-26 17:19:25.51+00
201 53  []  \N  2025-11-26 17:19:25.517+00  2025-11-26 17:19:25.517+00
207 53  []  \N  2025-11-26 17:19:25.529+00  2025-11-26 17:19:25.529+00
212 53  []  \N  2025-11-26 17:19:25.534+00  2025-11-26 17:19:25.534+00
232 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
244 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
253 53  []  \N  2025-11-26 17:19:25.555+00  2025-11-26 17:19:25.555+00
260 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
272 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
289 53  []  \N  2025-11-26 17:19:25.573+00  2025-11-26 17:19:25.573+00
311 53  []  \N  2025-11-26 17:19:25.588+00  2025-11-26 17:19:25.588+00
313 53  []  \N  2025-11-26 17:19:25.592+00  2025-11-26 17:19:25.592+00
332 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
343 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
358 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
387 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
429 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
430 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
436 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
459 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
464 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
500 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
503 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
508 53  []  \N  2025-11-26 17:19:25.739+00  2025-11-26 17:19:25.739+00
551 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
557 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
560 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
579 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
583 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
130 53  []  \N  2025-11-26 17:19:25.352+00  2025-11-26 17:19:25.352+00
1616    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1676    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1819    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1914    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2026    83  []  \N  2026-01-13 21:09:21.625+00  2026-01-13 21:09:21.625+00
2122    83  []  \N  2026-01-13 21:09:21.76+00   2026-01-13 21:09:21.76+00
2225    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2322    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2428    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3007    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3006    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3096    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3099    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3187    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3197    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3270    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3288    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3376    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3386    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3483    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
3557    135 []  \N  2026-02-04 03:31:34.567+00  2026-02-04 03:31:34.567+00
139 53  []  \N  2025-11-26 17:19:25.47+00   2025-11-26 17:19:25.47+00
149 53  []  \N  2025-11-26 17:19:25.442+00  2025-11-26 17:19:25.442+00
160 53  []  \N  2025-11-26 17:19:25.479+00  2025-11-26 17:19:25.479+00
176 53  []  \N  2025-11-26 17:19:25.504+00  2025-11-26 17:19:25.504+00
192 53  []  \N  2025-11-26 17:19:25.516+00  2025-11-26 17:19:25.516+00
204 53  []  \N  2025-11-26 17:19:25.521+00  2025-11-26 17:19:25.521+00
220 53  []  \N  2025-11-26 17:19:25.529+00  2025-11-26 17:19:25.529+00
237 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
245 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
271 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
283 53  []  \N  2025-11-26 17:19:25.573+00  2025-11-26 17:19:25.573+00
305 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
322 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
333 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
344 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
374 53  []  \N  2025-11-26 17:19:25.646+00  2025-11-26 17:19:25.646+00
380 53  []  \N  2025-11-26 17:19:25.588+00  2025-11-26 17:19:25.588+00
391 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
404 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
437 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
446 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
448 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
458 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
474 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
507 53  []  \N  2025-11-26 17:19:25.739+00  2025-11-26 17:19:25.739+00
512 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
518 53  []  \N  2025-11-26 17:19:25.739+00  2025-11-26 17:19:25.739+00
545 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
554 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
572 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
585 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
603 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
131 53  []  \N  2025-11-26 17:19:25.287+00  2025-11-26 17:19:25.287+00
1617    83  []  \N  2026-01-13 21:09:21.139+00  2026-01-13 21:09:21.139+00
1704    83  []  \N  2026-01-13 21:09:21.306+00  2026-01-13 21:09:21.306+00
1770    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1846    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1949    83  []  \N  2026-01-13 21:09:21.578+00  2026-01-13 21:09:21.578+00
2047    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2151    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2248    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2355    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2453    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3008    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3011    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3100    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3103    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3186    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3198    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3274    135 []  \N  2026-02-04 03:31:34.287+00  2026-02-04 03:31:34.287+00
3289    135 []  \N  2026-02-04 03:31:34.345+00  2026-02-04 03:31:34.345+00
3359    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3389    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3458    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3503    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
3578    135 []  \N  2026-02-04 03:31:34.635+00  2026-02-04 03:31:34.635+00
140 53  []  \N  2025-11-26 17:19:25.47+00   2025-11-26 17:19:25.47+00
150 53  []  \N  2025-11-26 17:19:25.479+00  2025-11-26 17:19:25.479+00
161 53  []  \N  2025-11-26 17:19:25.479+00  2025-11-26 17:19:25.479+00
177 53  []  \N  2025-11-26 17:19:25.494+00  2025-11-26 17:19:25.494+00
193 53  []  \N  2025-11-26 17:19:25.516+00  2025-11-26 17:19:25.516+00
205 53  []  \N  2025-11-26 17:19:25.517+00  2025-11-26 17:19:25.517+00
214 53  []  \N  2025-11-26 17:19:25.534+00  2025-11-26 17:19:25.534+00
258 53  []  \N  2025-11-26 17:19:25.557+00  2025-11-26 17:19:25.557+00
259 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
270 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
292 53  []  \N  2025-11-26 17:19:25.575+00  2025-11-26 17:19:25.575+00
304 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
336 53  []  \N  2025-11-26 17:19:25.607+00  2025-11-26 17:19:25.607+00
345 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
347 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
361 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
373 53  []  \N  2025-11-26 17:19:25.646+00  2025-11-26 17:19:25.646+00
392 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
397 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
410 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
420 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
421 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
457 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
472 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
476 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
478 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
487 53  []  \N  2025-11-26 17:19:25.733+00  2025-11-26 17:19:25.733+00
521 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
522 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
525 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
543 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
571 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
587 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
588 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
590 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
127 53  []  \N  2025-11-26 17:19:25.336+00  2025-11-26 17:19:25.336+00
1619    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1682    83  []  \N  2026-01-13 21:09:21.279+00  2026-01-13 21:09:21.279+00
1765    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1853    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1947    83  []  \N  2026-01-13 21:09:21.578+00  2026-01-13 21:09:21.578+00
2055    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2155    83  []  \N  2026-01-13 21:09:21.771+00  2026-01-13 21:09:21.771+00
2244    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2348    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2450    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3009    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3012    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3097    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3098    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3192    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3196    135 []  \N  2026-02-04 03:31:34.174+00  2026-02-04 03:31:34.174+00
3268    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3275    135 []  \N  2026-02-04 03:31:34.287+00  2026-02-04 03:31:34.287+00
3360    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3365    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3460    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3467    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3579    135 []  \N  2026-02-04 03:31:34.635+00  2026-02-04 03:31:34.635+00
3580    135 []  \N  2026-02-04 03:31:34.635+00  2026-02-04 03:31:34.635+00
141 53  []  \N  2025-11-26 17:19:25.47+00   2025-11-26 17:19:25.47+00
151 53  []  \N  2025-11-26 17:19:25.466+00  2025-11-26 17:19:25.466+00
162 53  []  \N  2025-11-26 17:19:25.494+00  2025-11-26 17:19:25.494+00
178 53  []  \N  2025-11-26 17:19:25.504+00  2025-11-26 17:19:25.504+00
194 53  []  \N  2025-11-26 17:19:25.516+00  2025-11-26 17:19:25.516+00
206 53  []  \N  2025-11-26 17:19:25.525+00  2025-11-26 17:19:25.525+00
224 53  []  \N  2025-11-26 17:19:25.533+00  2025-11-26 17:19:25.533+00
251 53  []  \N  2025-11-26 17:19:25.557+00  2025-11-26 17:19:25.557+00
257 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
269 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
282 53  []  \N  2025-11-26 17:19:25.568+00  2025-11-26 17:19:25.568+00
303 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
321 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
337 53  []  \N  2025-11-26 17:19:25.622+00  2025-11-26 17:19:25.622+00
346 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
352 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
372 53  []  \N  2025-11-26 17:19:25.646+00  2025-11-26 17:19:25.646+00
386 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
403 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
419 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
423 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
424 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
463 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
468 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
483 53  []  \N  2025-11-26 17:19:25.733+00  2025-11-26 17:19:25.733+00
524 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
540 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
564 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
565 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
577 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
594 53  []  \N  2025-11-26 17:19:25.875+00  2025-11-26 17:19:25.875+00
128 53  []  \N  2025-11-26 17:19:25.287+00  2025-11-26 17:19:25.287+00
1638    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1719    83  []  \N  2026-01-13 21:09:21.337+00  2026-01-13 21:09:21.337+00
1761    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1840    83  []  \N  2026-01-13 21:09:21.496+00  2026-01-13 21:09:21.496+00
1951    83  []  \N  2026-01-13 21:09:21.578+00  2026-01-13 21:09:21.578+00
2064    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2161    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2241    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2349    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2452    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3013    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3010    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3101    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3102    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3194    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3195    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3273    135 []  \N  2026-02-04 03:31:34.287+00  2026-02-04 03:31:34.287+00
3276    135 []  \N  2026-02-04 03:31:34.287+00  2026-02-04 03:31:34.287+00
3364    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3378    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3463    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3473    135 []  \N  2026-02-04 03:31:34.528+00  2026-02-04 03:31:34.528+00
3560    135 []  \N  2026-02-04 03:31:34.567+00  2026-02-04 03:31:34.567+00
3569    135 []  \N  2026-02-04 03:31:34.634+00  2026-02-04 03:31:34.634+00
138 53  []  \N  2025-11-26 17:19:25.442+00  2025-11-26 17:19:25.442+00
142 53  []  \N  2025-11-26 17:19:25.47+00   2025-11-26 17:19:25.47+00
152 53  []  \N  2025-11-26 17:19:25.47+00   2025-11-26 17:19:25.47+00
163 53  []  \N  2025-11-26 17:19:25.494+00  2025-11-26 17:19:25.494+00
179 53  []  \N  2025-11-26 17:19:25.504+00  2025-11-26 17:19:25.504+00
195 53  []  \N  2025-11-26 17:19:25.516+00  2025-11-26 17:19:25.516+00
216 53  []  \N  2025-11-26 17:19:25.534+00  2025-11-26 17:19:25.534+00
223 53  []  \N  2025-11-26 17:19:25.529+00  2025-11-26 17:19:25.529+00
228 53  []  \N  2025-11-26 17:19:25.534+00  2025-11-26 17:19:25.534+00
233 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
248 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
262 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
264 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
268 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
281 53  []  \N  2025-11-26 17:19:25.568+00  2025-11-26 17:19:25.568+00
302 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
320 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
335 53  []  \N  2025-11-26 17:19:25.606+00  2025-11-26 17:19:25.606+00
339 53  []  \N  2025-11-26 17:19:25.627+00  2025-11-26 17:19:25.627+00
349 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
355 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
371 53  []  \N  2025-11-26 17:19:25.646+00  2025-11-26 17:19:25.646+00
390 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
405 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
406 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
413 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
438 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
442 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
461 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
475 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
490 53  []  \N  2025-11-26 17:19:25.733+00  2025-11-26 17:19:25.733+00
493 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
504 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
517 53  []  \N  2025-11-26 17:19:25.739+00  2025-11-26 17:19:25.739+00
529 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
530 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
553 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
574 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
576 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
591 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
598 53  []  \N  2025-11-26 17:19:25.875+00  2025-11-26 17:19:25.875+00
92  53  []  \N  2025-11-26 17:19:25.287+00  2025-11-26 17:19:25.287+00
1565    30  []  \N  2025-12-31 16:40:15.777+00  2025-12-31 16:40:15.777+00
1588    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1679    83  []  \N  2026-01-13 21:09:21.209+00  2026-01-13 21:09:21.209+00
1820    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1910    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2014    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2096    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2176    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2269    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2368    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2465    83  []  \N  2026-01-13 21:09:22.102+00  2026-01-13 21:09:22.102+00
3014    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3104    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3185    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3256    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3367    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3465    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3562    135 []  \N  2026-02-04 03:31:34.634+00  2026-02-04 03:31:34.634+00
164 53  []  \N  2025-11-26 17:19:25.494+00  2025-11-26 17:19:25.494+00
180 53  []  \N  2025-11-26 17:19:25.51+00   2025-11-26 17:19:25.51+00
196 53  []  \N  2025-11-26 17:19:25.516+00  2025-11-26 17:19:25.516+00
267 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
286 53  []  \N  2025-11-26 17:19:25.567+00  2025-11-26 17:19:25.567+00
301 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
329 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
340 53  []  \N  2025-11-26 17:19:25.627+00  2025-11-26 17:19:25.627+00
370 53  []  \N  2025-11-26 17:19:25.645+00  2025-11-26 17:19:25.645+00
389 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
409 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
425 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
466 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
480 53  []  \N  2025-11-26 17:19:25.733+00  2025-11-26 17:19:25.733+00
498 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
536 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
537 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
549 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
602 53  []  \N  2025-11-26 17:19:25.875+00  2025-11-26 17:19:25.875+00
104 53  []  \N  2025-11-26 17:19:25.425+00  2025-11-26 17:19:25.425+00
1601    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1677    83  []  \N  2026-01-13 21:09:21.209+00  2026-01-13 21:09:21.209+00
1801    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1888    83  []  \N  2026-01-13 21:09:21.558+00  2026-01-13 21:09:21.558+00
1999    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2075    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2169    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2314    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2406    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
2999    121 []  \N  2026-01-26 18:03:47.881+00  2026-01-26 18:03:47.881+00
3015    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3106    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3193    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3291    135 []  \N  2026-02-04 03:31:34.345+00  2026-02-04 03:31:34.345+00
3400    135 []  \N  2026-02-04 03:31:34.431+00  2026-02-04 03:31:34.431+00
3493    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
165 53  []  \N  2025-11-26 17:19:25.494+00  2025-11-26 17:19:25.494+00
181 53  []  \N  2025-11-26 17:19:25.51+00   2025-11-26 17:19:25.51+00
197 53  []  \N  2025-11-26 17:19:25.516+00  2025-11-26 17:19:25.516+00
266 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
280 53  []  \N  2025-11-26 17:19:25.566+00  2025-11-26 17:19:25.566+00
300 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
334 53  []  \N  2025-11-26 17:19:25.606+00  2025-11-26 17:19:25.606+00
341 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
369 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
395 53  []  \N  2025-11-26 17:19:25.659+00  2025-11-26 17:19:25.659+00
422 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
443 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
455 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
489 53  []  \N  2025-11-26 17:19:25.733+00  2025-11-26 17:19:25.733+00
514 53  []  \N  2025-11-26 17:19:25.739+00  2025-11-26 17:19:25.739+00
533 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
568 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
600 53  []  \N  2025-11-26 17:19:25.875+00  2025-11-26 17:19:25.875+00
124 53  []  \N  2025-11-26 17:19:25.442+00  2025-11-26 17:19:25.442+00
1570    30  []  \N  2025-12-31 16:40:15.777+00  2025-12-31 16:40:15.777+00
1620    83  []  \N  2026-01-13 21:09:21.139+00  2026-01-13 21:09:21.139+00
1668    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1795    83  []  \N  2026-01-13 21:09:21.449+00  2026-01-13 21:09:21.449+00
1876    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
1995    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2084    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2197    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2297    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2418    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3005    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3107    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3190    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3271    135 []  \N  2026-02-04 03:31:34.279+00  2026-02-04 03:31:34.279+00
3366    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3466    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3576    135 []  \N  2026-02-04 03:31:34.635+00  2026-02-04 03:31:34.635+00
166 53  []  \N  2025-11-26 17:19:25.494+00  2025-11-26 17:19:25.494+00
182 53  []  \N  2025-11-26 17:19:25.51+00   2025-11-26 17:19:25.51+00
198 53  []  \N  2025-11-26 17:19:25.516+00  2025-11-26 17:19:25.516+00
265 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
279 53  []  \N  2025-11-26 17:19:25.566+00  2025-11-26 17:19:25.566+00
299 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
338 53  []  \N  2025-11-26 17:19:25.627+00  2025-11-26 17:19:25.627+00
351 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
368 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
434 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
441 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
502 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
516 53  []  \N  2025-11-26 17:19:25.739+00  2025-11-26 17:19:25.739+00
550 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
584 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
95  53  []  \N  2025-11-26 17:19:25.412+00  2025-11-26 17:19:25.412+00
606 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
1543    30  []  \N  2025-12-31 16:40:15.748+00  2025-12-31 16:40:15.748+00
1569    30  []  \N  2025-12-31 16:40:15.777+00  2025-12-31 16:40:15.777+00
1585    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1724    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1803    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1885    83  []  \N  2026-01-13 21:09:21.549+00  2026-01-13 21:09:21.549+00
1971    83  []  \N  2026-01-13 21:09:21.587+00  2026-01-13 21:09:21.587+00
2108    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2196    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2289    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2387    83  []  \N  2026-01-13 21:09:22.007+00  2026-01-13 21:09:22.007+00
2483    83  []  \N  2026-01-13 21:09:22.145+00  2026-01-13 21:09:22.145+00
3016    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3109    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3191    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3314    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3416    135 []  \N  2026-02-04 03:31:34.463+00  2026-02-04 03:31:34.463+00
3514    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
159 53  []  \N  2025-11-26 17:19:25.442+00  2025-11-26 17:19:25.442+00
167 53  []  \N  2025-11-26 17:19:25.494+00  2025-11-26 17:19:25.494+00
183 53  []  \N  2025-11-26 17:19:25.51+00   2025-11-26 17:19:25.51+00
218 53  []  \N  2025-11-26 17:19:25.523+00  2025-11-26 17:19:25.523+00
256 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
285 53  []  \N  2025-11-26 17:19:25.566+00  2025-11-26 17:19:25.566+00
298 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
306 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
328 53  []  \N  2025-11-26 17:19:25.593+00  2025-11-26 17:19:25.593+00
353 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
367 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
376 53  []  \N  2025-11-26 17:19:25.646+00  2025-11-26 17:19:25.646+00
396 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
399 53  []  \N  2025-11-26 17:19:25.659+00  2025-11-26 17:19:25.659+00
408 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
444 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
456 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
469 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
494 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
538 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
546 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
570 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
575 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
129 53  []  \N  2025-11-26 17:19:25.435+00  2025-11-26 17:19:25.435+00
1544    30  []  \N  2025-12-31 16:40:15.748+00  2025-12-31 16:40:15.748+00
1564    30  []  \N  2025-12-31 16:40:15.777+00  2025-12-31 16:40:15.777+00
1589    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1669    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1796    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1877    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
1996    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2068    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2184    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2277    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2377    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2479    83  []  \N  2026-01-13 21:09:22.144+00  2026-01-13 21:09:22.144+00
3017    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3118    135 []  \N  2026-02-04 03:31:34.024+00  2026-02-04 03:31:34.024+00
3209    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3299    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3394    135 []  \N  2026-02-04 03:31:34.431+00  2026-02-04 03:31:34.431+00
3490    135 []  \N  2026-02-04 03:31:34.55+00   2026-02-04 03:31:34.55+00
168 53  []  \N  2025-11-26 17:19:25.494+00  2025-11-26 17:19:25.494+00
184 53  []  \N  2025-11-26 17:19:25.51+00   2025-11-26 17:19:25.51+00
227 53  []  \N  2025-11-26 17:19:25.494+00  2025-11-26 17:19:25.494+00
236 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
278 53  []  \N  2025-11-26 17:19:25.564+00  2025-11-26 17:19:25.564+00
297 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
342 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
366 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
379 53  []  \N  2025-11-26 17:19:25.588+00  2025-11-26 17:19:25.588+00
416 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
418 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
439 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
482 53  []  \N  2025-11-26 17:19:25.733+00  2025-11-26 17:19:25.733+00
486 53  []  \N  2025-11-26 17:19:25.733+00  2025-11-26 17:19:25.733+00
513 53  []  \N  2025-11-26 17:19:25.739+00  2025-11-26 17:19:25.739+00
526 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
527 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
593 53  []  \N  2025-11-26 17:19:25.875+00  2025-11-26 17:19:25.875+00
595 53  []  \N  2025-11-26 17:19:25.875+00  2025-11-26 17:19:25.875+00
604 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
807 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
902 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1014    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1164    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1296    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1469    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1545    30  []  \N  2025-12-31 16:40:15.748+00  2025-12-31 16:40:15.748+00
1561    30  []  \N  2025-12-31 16:40:15.777+00  2025-12-31 16:40:15.777+00
1625    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1670    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1791    83  []  \N  2026-01-13 21:09:21.449+00  2026-01-13 21:09:21.449+00
1875    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
1992    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2077    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2183    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2300    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2404    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3018    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3114    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3199    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3317    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3412    135 []  \N  2026-02-04 03:31:34.463+00  2026-02-04 03:31:34.463+00
3508    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
169 53  []  \N  2025-11-26 17:19:25.494+00  2025-11-26 17:19:25.494+00
185 53  []  \N  2025-11-26 17:19:25.51+00   2025-11-26 17:19:25.51+00
277 53  []  \N  2025-11-26 17:19:25.564+00  2025-11-26 17:19:25.564+00
296 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
350 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
365 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
398 53  []  \N  2025-11-26 17:19:25.658+00  2025-11-26 17:19:25.658+00
417 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
467 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
479 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
535 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
539 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
612 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
714 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
813 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
913 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1012    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1162    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1284    60  []  \N  2025-12-08 23:22:49.661+00  2025-12-08 23:22:49.661+00
1467    60  []  \N  2025-12-08 23:22:49.705+00  2025-12-08 23:22:49.705+00
1546    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1566    30  []  \N  2025-12-31 16:40:15.777+00  2025-12-31 16:40:15.777+00
1626    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1672    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1790    83  []  \N  2026-01-13 21:09:21.449+00  2026-01-13 21:09:21.449+00
1902    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
1997    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2099    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2205    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2312    83  []  \N  2026-01-13 21:09:21.953+00  2026-01-13 21:09:21.953+00
2417    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3019    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3116    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3202    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3319    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3415    135 []  \N  2026-02-04 03:31:34.463+00  2026-02-04 03:31:34.463+00
3513    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
614 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
711 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
814 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
914 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1013    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1163    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1285    60  []  \N  2025-12-08 23:22:49.661+00  2025-12-08 23:22:49.661+00
1468    60  []  \N  2025-12-08 23:22:49.705+00  2025-12-08 23:22:49.705+00
1547    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1562    30  []  \N  2025-12-31 16:40:15.777+00  2025-12-31 16:40:15.777+00
1621    83  []  \N  2026-01-13 21:09:21.139+00  2026-01-13 21:09:21.139+00
1692    83  []  \N  2026-01-13 21:09:21.297+00  2026-01-13 21:09:21.297+00
1766    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1856    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1955    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2049    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2154    83  []  \N  2026-01-13 21:09:21.771+00  2026-01-13 21:09:21.771+00
2237    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2343    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2446    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3020    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3115    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3200    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3316    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3413    135 []  \N  2026-02-04 03:31:34.463+00  2026-02-04 03:31:34.463+00
3525    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
613 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
712 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
811 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
910 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1009    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1112    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1282    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1464    60  []  \N  2025-12-08 23:22:49.705+00  2025-12-08 23:22:49.705+00
1548    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1622    83  []  \N  2026-01-13 21:09:21.176+00  2026-01-13 21:09:21.176+00
1700    83  []  \N  2026-01-13 21:09:21.305+00  2026-01-13 21:09:21.305+00
1789    83  []  \N  2026-01-13 21:09:21.449+00  2026-01-13 21:09:21.449+00
1880    83  []  \N  2026-01-13 21:09:21.549+00  2026-01-13 21:09:21.549+00
1991    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2079    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2206    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2311    83  []  \N  2026-01-13 21:09:21.953+00  2026-01-13 21:09:21.953+00
2424    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3021    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3110    135 []  \N  2026-02-04 03:31:34.024+00  2026-02-04 03:31:34.024+00
3201    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3287    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3385    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3479    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
3566    135 []  \N  2026-02-04 03:31:34.634+00  2026-02-04 03:31:34.634+00
611 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
713 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
812 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
912 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1011    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1117    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1283    60  []  \N  2025-12-08 23:22:49.661+00  2025-12-08 23:22:49.661+00
1466    60  []  \N  2025-12-08 23:22:49.705+00  2025-12-08 23:22:49.705+00
1549    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1568    30  []  \N  2025-12-31 16:40:15.777+00  2025-12-31 16:40:15.777+00
1599    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1673    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1811    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1898    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
1994    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2070    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2168    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2270    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2369    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2467    83  []  \N  2026-01-13 21:09:22.102+00  2026-01-13 21:09:22.102+00
3022    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3108    135 []  \N  2026-02-04 03:31:34.024+00  2026-02-04 03:31:34.024+00
3189    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3269    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3363    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3464    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3559    135 []  \N  2026-02-04 03:31:34.567+00  2026-02-04 03:31:34.567+00
226 53  []  \N  2025-11-26 17:19:25.534+00  2025-11-26 17:19:25.534+00
261 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
354 53  []  \N  2025-11-26 17:19:25.628+00  2025-11-26 17:19:25.628+00
411 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
477 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
523 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
596 53  []  \N  2025-11-26 17:19:25.875+00  2025-11-26 17:19:25.875+00
615 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
715 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
821 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
922 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1047    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1150    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1267    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1361    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1516    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1550    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1611    83  []  \N  2026-01-13 21:09:21.177+00  2026-01-13 21:09:21.177+00
1701    83  []  \N  2026-01-13 21:09:21.305+00  2026-01-13 21:09:21.305+00
1771    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1844    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1945    83  []  \N  2026-01-13 21:09:21.578+00  2026-01-13 21:09:21.578+00
2045    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2143    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2232    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2357    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2461    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3023    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3126    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3237    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3337    135 []  \N  2026-02-04 03:31:34.351+00  2026-02-04 03:31:34.351+00
3436    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3531    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
616 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
716 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
815 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
915 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1015    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1113    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1281    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1463    60  []  \N  2025-12-08 23:22:49.705+00  2025-12-08 23:22:49.705+00
1551    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1594    83  []  \N  2026-01-13 21:09:21.176+00  2026-01-13 21:09:21.176+00
1685    83  []  \N  2026-01-13 21:09:21.279+00  2026-01-13 21:09:21.279+00
1807    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1889    83  []  \N  2026-01-13 21:09:21.558+00  2026-01-13 21:09:21.558+00
1993    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2069    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2172    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2280    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2399    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3024    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3217    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3310    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3410    135 []  \N  2026-02-04 03:31:34.463+00  2026-02-04 03:31:34.463+00
3509    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
617 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
718 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
819 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
920 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1025    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1141    60  []  \N  2025-12-08 23:22:49.588+00  2025-12-08 23:22:49.588+00
1254    60  []  \N  2025-12-08 23:22:49.639+00  2025-12-08 23:22:49.639+00
1351    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1432    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1526    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1552    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1563    30  []  \N  2025-12-31 16:40:15.777+00  2025-12-31 16:40:15.777+00
1586    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1683    83  []  \N  2026-01-13 21:09:21.279+00  2026-01-13 21:09:21.279+00
1799    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1891    83  []  \N  2026-01-13 21:09:21.558+00  2026-01-13 21:09:21.558+00
1969    83  []  \N  2026-01-13 21:09:21.587+00  2026-01-13 21:09:21.587+00
2102    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2204    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2292    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2381    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2488    83  []  \N  2026-01-13 21:09:22.145+00  2026-01-13 21:09:22.145+00
3025    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3111    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3188    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3272    135 []  \N  2026-02-04 03:31:34.287+00  2026-02-04 03:31:34.287+00
3358    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3457    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3556    135 []  \N  2026-02-04 03:31:34.567+00  2026-02-04 03:31:34.567+00
618 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
721 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
820 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
923 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1054    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1152    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1265    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1362    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1507    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1553    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1606    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1689    83  []  \N  2026-01-13 21:09:21.297+00  2026-01-13 21:09:21.297+00
1794    83  []  \N  2026-01-13 21:09:21.449+00  2026-01-13 21:09:21.449+00
1886    83  []  \N  2026-01-13 21:09:21.549+00  2026-01-13 21:09:21.549+00
1970    83  []  \N  2026-01-13 21:09:21.587+00  2026-01-13 21:09:21.587+00
2095    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2175    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2275    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2411    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3026    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3206    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3297    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3404    135 []  \N  2026-02-04 03:31:34.462+00  2026-02-04 03:31:34.462+00
3499    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
229 53  []  \N  2025-11-26 17:19:25.539+00  2025-11-26 17:19:25.539+00
230 53  []  \N  2025-11-26 17:19:25.541+00  2025-11-26 17:19:25.541+00
263 53  []  \N  2025-11-26 17:19:25.542+00  2025-11-26 17:19:25.542+00
307 53  []  \N  2025-11-26 17:19:25.576+00  2025-11-26 17:19:25.576+00
356 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
375 53  []  \N  2025-11-26 17:19:25.646+00  2025-11-26 17:19:25.646+00
415 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
426 53  []  \N  2025-11-26 17:19:25.684+00  2025-11-26 17:19:25.684+00
481 53  []  \N  2025-11-26 17:19:25.733+00  2025-11-26 17:19:25.733+00
519 53  []  \N  2025-11-26 17:19:25.739+00  2025-11-26 17:19:25.739+00
528 53  []  \N  2025-11-26 17:19:25.74+00   2025-11-26 17:19:25.74+00
586 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
601 53  []  \N  2025-11-26 17:19:25.875+00  2025-11-26 17:19:25.875+00
619 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
719 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
816 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
916 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1016    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1110    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1213    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1305    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1378    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1436    60  []  \N  2025-12-08 23:22:49.761+00  2025-12-08 23:22:49.761+00
1554    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1624    83  []  \N  2026-01-13 21:09:21.139+00  2026-01-13 21:09:21.139+00
1671    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1786    83  []  \N  2026-01-13 21:09:21.449+00  2026-01-13 21:09:21.449+00
1873    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
1967    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2067    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2167    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2324    83  []  \N  2026-01-13 21:09:21.976+00  2026-01-13 21:09:21.976+00
2430    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3027    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3128    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3232    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3331    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3429    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3511    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
620 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
720 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
817 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
917 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1017    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1111    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1277    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1450    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1555    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1567    30  []  \N  2025-12-31 16:40:15.777+00  2025-12-31 16:40:15.777+00
1604    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1687    83  []  \N  2026-01-13 21:09:21.279+00  2026-01-13 21:09:21.279+00
1805    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1887    83  []  \N  2026-01-13 21:09:21.558+00  2026-01-13 21:09:21.558+00
1968    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2110    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2209    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2282    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2376    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2477    83  []  \N  2026-01-13 21:09:22.106+00  2026-01-13 21:09:22.106+00
3028    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3154    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3262    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3346    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3447    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3551    135 []  \N  2026-02-04 03:31:34.565+00  2026-02-04 03:31:34.565+00
621 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
717 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
818 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
918 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1020    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1127    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1236    60  []  \N  2025-12-08 23:22:49.639+00  2025-12-08 23:22:49.639+00
1346    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1424    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1556    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1603    83  []  \N  2026-01-13 21:09:21.139+00  2026-01-13 21:09:21.139+00
1703    83  []  \N  2026-01-13 21:09:21.306+00  2026-01-13 21:09:21.306+00
1777    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1855    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1939    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2027    83  []  \N  2026-01-13 21:09:21.625+00  2026-01-13 21:09:21.625+00
2113    83  []  \N  2026-01-13 21:09:21.692+00  2026-01-13 21:09:21.692+00
2214    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2301    83  []  \N  2026-01-13 21:09:21.904+00  2026-01-13 21:09:21.904+00
2394    83  []  \N  2026-01-13 21:09:22.051+00  2026-01-13 21:09:22.051+00
2489    83  []  \N  2026-01-13 21:09:22.145+00  2026-01-13 21:09:22.145+00
3029    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3136    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3285    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3387    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3484    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
622 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
723 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
823 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
924 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1055    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1153    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1269    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1371    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1512    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1557    30  []  \N  2025-12-31 16:40:15.749+00  2025-12-31 16:40:15.749+00
1593    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1675    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1792    83  []  \N  2026-01-13 21:09:21.449+00  2026-01-13 21:09:21.449+00
1879    83  []  \N  2026-01-13 21:09:21.549+00  2026-01-13 21:09:21.549+00
1985    83  []  \N  2026-01-13 21:09:21.597+00  2026-01-13 21:09:21.597+00
2091    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2203    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2296    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2386    83  []  \N  2026-01-13 21:09:21.98+00   2026-01-13 21:09:21.98+00
2485    83  []  \N  2026-01-13 21:09:22.145+00  2026-01-13 21:09:22.145+00
3030    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3163    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3320    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3423    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3516    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
287 53  []  \N  2025-11-26 17:19:25.541+00  2025-11-26 17:19:25.541+00
288 53  []  \N  2025-11-26 17:19:25.541+00  2025-11-26 17:19:25.541+00
231 53  []  \N  2025-11-26 17:19:25.534+00  2025-11-26 17:19:25.534+00
308 53  []  \N  2025-11-26 17:19:25.558+00  2025-11-26 17:19:25.558+00
357 53  []  \N  2025-11-26 17:19:25.629+00  2025-11-26 17:19:25.629+00
377 53  []  \N  2025-11-26 17:19:25.646+00  2025-11-26 17:19:25.646+00
383 53  []  \N  2025-11-26 17:19:25.646+00  2025-11-26 17:19:25.646+00
451 53  []  \N  2025-11-26 17:19:25.685+00  2025-11-26 17:19:25.685+00
465 53  []  \N  2025-11-26 17:19:25.712+00  2025-11-26 17:19:25.712+00
492 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
495 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
547 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
566 53  []  \N  2025-11-26 17:19:25.873+00  2025-11-26 17:19:25.873+00
580 53  []  \N  2025-11-26 17:19:25.874+00  2025-11-26 17:19:25.874+00
623 60  []  \N  2025-12-08 23:22:49.202+00  2025-12-08 23:22:49.202+00
722 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
822 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
919 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1019    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1114    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1209    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1302    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1373    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1419    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1517    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1630    83  []  \N  2026-01-13 21:09:21.18+00   2026-01-13 21:09:21.18+00
1693    83  []  \N  2026-01-13 21:09:21.297+00  2026-01-13 21:09:21.297+00
1797    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1882    83  []  \N  2026-01-13 21:09:21.549+00  2026-01-13 21:09:21.549+00
1981    83  []  \N  2026-01-13 21:09:21.597+00  2026-01-13 21:09:21.597+00
2107    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2188    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2285    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2380    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2481    83  []  \N  2026-01-13 21:09:22.144+00  2026-01-13 21:09:22.144+00
3031    135 []  \N  2026-02-04 03:31:33.879+00  2026-02-04 03:31:33.879+00
3162    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3318    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3417    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3526    135 []  \N  2026-02-04 03:31:34.552+00  2026-02-04 03:31:34.552+00
624 60  []  \N  2025-12-08 23:22:49.212+00  2025-12-08 23:22:49.212+00
724 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
824 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
921 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1018    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1116    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1272    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1440    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1600    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1674    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1802    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1884    83  []  \N  2026-01-13 21:09:21.549+00  2026-01-13 21:09:21.549+00
1988    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2088    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2191    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2288    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2408    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3033    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3145    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3281    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3368    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3481    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3577    135 []  \N  2026-02-04 03:31:34.635+00  2026-02-04 03:31:34.635+00
625 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
725 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
825 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
925 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1021    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1115    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1211    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1304    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1376    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1416    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1503    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1613    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1705    83  []  \N  2026-01-13 21:09:21.306+00  2026-01-13 21:09:21.306+00
1768    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1848    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1944    83  []  \N  2026-01-13 21:09:21.578+00  2026-01-13 21:09:21.578+00
2048    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2146    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2251    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2336    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2412    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3034    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3131    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3224    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3323    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3431    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3529    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
626 60  []  \N  2025-12-08 23:22:49.217+00  2025-12-08 23:22:49.217+00
726 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
827 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
928 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1022    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1159    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1274    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1444    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1587    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1698    83  []  \N  2026-01-13 21:09:21.297+00  2026-01-13 21:09:21.297+00
1813    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1896    83  []  \N  2026-01-13 21:09:21.558+00  2026-01-13 21:09:21.558+00
1984    83  []  \N  2026-01-13 21:09:21.597+00  2026-01-13 21:09:21.597+00
2105    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2186    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2318    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2413    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3035    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3125    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3230    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3330    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3433    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3530    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
627 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
727 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
826 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
926 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1026    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1149    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1262    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1368    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1509    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1575    72  []  \N  2026-01-02 21:24:15.454+00  2026-01-02 21:24:15.454+00
1618    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1680    83  []  \N  2026-01-13 21:09:21.279+00  2026-01-13 21:09:21.279+00
1763    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1841    83  []  \N  2026-01-13 21:09:21.496+00  2026-01-13 21:09:21.496+00
1953    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2063    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2159    83  []  \N  2026-01-13 21:09:21.822+00  2026-01-13 21:09:21.822+00
2243    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2330    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2426    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3036    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3138    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3241    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3341    135 []  \N  2026-02-04 03:31:34.357+00  2026-02-04 03:31:34.357+00
3444    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3541    135 []  \N  2026-02-04 03:31:34.565+00  2026-02-04 03:31:34.565+00
628 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
728 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
828 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
927 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1023    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1126    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1226    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1340    60  []  \N  2025-12-08 23:22:49.703+00  2025-12-08 23:22:49.703+00
1410    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1498    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1596    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1688    83  []  \N  2026-01-13 21:09:21.279+00  2026-01-13 21:09:21.279+00
1821    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1918    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2039    83  []  \N  2026-01-13 21:09:21.626+00  2026-01-13 21:09:21.626+00
2157    83  []  \N  2026-01-13 21:09:21.801+00  2026-01-13 21:09:21.801+00
2236    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2335    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2436    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3037    135 []  \N  2026-02-04 03:31:33.879+00  2026-02-04 03:31:33.879+00
3149    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3225    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3326    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3421    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3519    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
629 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
729 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
829 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
929 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1024    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1142    60  []  \N  2025-12-08 23:22:49.588+00  2025-12-08 23:22:49.588+00
1252    60  []  \N  2025-12-08 23:22:49.639+00  2025-12-08 23:22:49.639+00
1349    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1430    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1525    60  []  \N  2025-12-08 23:22:49.799+00  2025-12-08 23:22:49.799+00
1597    83  []  \N  2026-01-13 21:09:21.176+00  2026-01-13 21:09:21.176+00
1690    83  []  \N  2026-01-13 21:09:21.297+00  2026-01-13 21:09:21.297+00
1793    83  []  \N  2026-01-13 21:09:21.449+00  2026-01-13 21:09:21.449+00
1878    83  []  \N  2026-01-13 21:09:21.533+00  2026-01-13 21:09:21.533+00
1987    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2104    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2187    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2284    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2375    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2480    83  []  \N  2026-01-13 21:09:22.144+00  2026-01-13 21:09:22.144+00
3038    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3133    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3282    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3373    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3470    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3565    135 []  \N  2026-02-04 03:31:34.634+00  2026-02-04 03:31:34.634+00
630 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
730 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
830 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
930 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1034    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1134    60  []  \N  2025-12-08 23:22:49.588+00  2025-12-08 23:22:49.588+00
1227    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1339    60  []  \N  2025-12-08 23:22:49.703+00  2025-12-08 23:22:49.703+00
1411    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1499    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1609    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1678    83  []  \N  2026-01-13 21:09:21.209+00  2026-01-13 21:09:21.209+00
1788    83  []  \N  2026-01-13 21:09:21.449+00  2026-01-13 21:09:21.449+00
1874    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
1986    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2073    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2171    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2268    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2366    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2456    83  []  \N  2026-01-13 21:09:22.102+00  2026-01-13 21:09:22.102+00
3039    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3134    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3260    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3369    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3468    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3573    135 []  \N  2026-02-04 03:31:34.635+00  2026-02-04 03:31:34.635+00
631 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
731 60  []  \N  2025-12-08 23:22:49.32+00   2025-12-08 23:22:49.32+00
832 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
932 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1027    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1119    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1210    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1301    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1374    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1415    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1501    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1623    83  []  \N  2026-01-13 21:09:21.176+00  2026-01-13 21:09:21.176+00
1699    83  []  \N  2026-01-13 21:09:21.298+00  2026-01-13 21:09:21.298+00
1775    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1851    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1943    83  []  \N  2026-01-13 21:09:21.578+00  2026-01-13 21:09:21.578+00
2054    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2149    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2249    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2334    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2414    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3040    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3127    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3283    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3361    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3461    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3567    135 []  \N  2026-02-04 03:31:34.634+00  2026-02-04 03:31:34.634+00
632 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
737 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
837 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
934 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1041    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1143    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1255    60  []  \N  2025-12-08 23:22:49.658+00  2025-12-08 23:22:49.658+00
1353    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1434    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1527    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1605    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1712    83  []  \N  2026-01-13 21:09:21.307+00  2026-01-13 21:09:21.307+00
1787    83  []  \N  2026-01-13 21:09:21.449+00  2026-01-13 21:09:21.449+00
1881    83  []  \N  2026-01-13 21:09:21.549+00  2026-01-13 21:09:21.549+00
1983    83  []  \N  2026-01-13 21:09:21.597+00  2026-01-13 21:09:21.597+00
2093    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2180    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2305    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2397    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3041    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3129    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3228    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3328    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3422    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3518    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
633 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
733 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
833 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
933 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1030    60  []  \N  2025-12-08 23:22:49.539+00  2025-12-08 23:22:49.539+00
1122    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1216    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1348    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1427    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1636    83  []  \N  2026-01-13 21:09:21.177+00  2026-01-13 21:09:21.177+00
1702    83  []  \N  2026-01-13 21:09:21.306+00  2026-01-13 21:09:21.306+00
1809    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1899    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
1977    83  []  \N  2026-01-13 21:09:21.597+00  2026-01-13 21:09:21.597+00
2106    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2193    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2281    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2396    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3042    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3144    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3233    135 []  \N  2026-02-04 03:31:34.182+00  2026-02-04 03:31:34.182+00
3334    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3432    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3532    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
634 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
735 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
835 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
936 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1031    60  []  \N  2025-12-08 23:22:49.539+00  2025-12-08 23:22:49.539+00
1123    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1223    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1335    60  []  \N  2025-12-08 23:22:49.703+00  2025-12-08 23:22:49.703+00
1407    60  []  \N  2025-12-08 23:22:49.756+00  2025-12-08 23:22:49.756+00
1495    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1582    81  []  \N  2026-01-12 21:59:00.959+00  2026-01-12 21:59:00.959+00
1615    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1691    83  []  \N  2026-01-13 21:09:21.297+00  2026-01-13 21:09:21.297+00
1806    83  []  \N  2026-01-13 21:09:21.459+00  2026-01-13 21:09:21.459+00
1890    83  []  \N  2026-01-13 21:09:21.558+00  2026-01-13 21:09:21.558+00
1972    83  []  \N  2026-01-13 21:09:21.587+00  2026-01-13 21:09:21.587+00
2090    83  []  \N  2026-01-13 21:09:21.668+00  2026-01-13 21:09:21.668+00
2199    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2313    83  []  \N  2026-01-13 21:09:21.976+00  2026-01-13 21:09:21.976+00
2403    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3043    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3151    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3286    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3388    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3485    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
635 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
732 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
831 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
931 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1029    60  []  \N  2025-12-08 23:22:49.539+00  2025-12-08 23:22:49.539+00
1118    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1214    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1442    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1635    83  []  \N  2026-01-13 21:09:21.177+00  2026-01-13 21:09:21.177+00
1721    83  []  \N  2026-01-13 21:09:21.337+00  2026-01-13 21:09:21.337+00
1769    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1845    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1950    83  []  \N  2026-01-13 21:09:21.578+00  2026-01-13 21:09:21.578+00
2052    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2153    83  []  \N  2026-01-13 21:09:21.771+00  2026-01-13 21:09:21.771+00
2258    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2362    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2464    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3044    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3140    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3249    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3374    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3553    135 []  \N  2026-02-04 03:31:34.566+00  2026-02-04 03:31:34.566+00
636 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
734 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
834 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
935 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1028    60  []  \N  2025-12-08 23:22:49.539+00  2025-12-08 23:22:49.539+00
1120    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1212    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1303    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1375    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1414    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1504    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1595    83  []  \N  2026-01-13 21:09:21.176+00  2026-01-13 21:09:21.176+00
1696    83  []  \N  2026-01-13 21:09:21.297+00  2026-01-13 21:09:21.297+00
1798    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1893    83  []  \N  2026-01-13 21:09:21.558+00  2026-01-13 21:09:21.558+00
1974    83  []  \N  2026-01-13 21:09:21.597+00  2026-01-13 21:09:21.597+00
2080    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2179    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2274    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2402    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3045    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3135    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3227    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3327    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3424    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3520    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
637 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
736 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
836 60  []  \N  2025-12-08 23:22:49.426+00  2025-12-08 23:22:49.426+00
938 60  []  \N  2025-12-08 23:22:49.488+00  2025-12-08 23:22:49.488+00
1033    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1128    60  []  \N  2025-12-08 23:22:49.588+00  2025-12-08 23:22:49.588+00
1220    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1333    60  []  \N  2025-12-08 23:22:49.683+00  2025-12-08 23:22:49.683+00
1405    60  []  \N  2025-12-08 23:22:49.73+00   2025-12-08 23:22:49.73+00
1492    60  []  \N  2025-12-08 23:22:49.797+00  2025-12-08 23:22:49.797+00
1590    83  []  \N  2026-01-13 21:09:21.176+00  2026-01-13 21:09:21.176+00
1697    83  []  \N  2026-01-13 21:09:21.297+00  2026-01-13 21:09:21.297+00
1812    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1895    83  []  \N  2026-01-13 21:09:21.558+00  2026-01-13 21:09:21.558+00
1980    83  []  \N  2026-01-13 21:09:21.597+00  2026-01-13 21:09:21.597+00
2097    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2208    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2299    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2405    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3046    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3124    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3220    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3306    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3395    135 []  \N  2026-02-04 03:31:34.431+00  2026-02-04 03:31:34.431+00
3505    135 []  \N  2026-02-04 03:31:34.55+00   2026-02-04 03:31:34.55+00
638 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
738 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
839 60  []  \N  2025-12-08 23:22:49.427+00  2025-12-08 23:22:49.427+00
939 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1035    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1147    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1260    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1358    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1460    60  []  \N  2025-12-08 23:22:49.761+00  2025-12-08 23:22:49.761+00
1602    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1694    83  []  \N  2026-01-13 21:09:21.297+00  2026-01-13 21:09:21.297+00
1814    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1900    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
1975    83  []  \N  2026-01-13 21:09:21.597+00  2026-01-13 21:09:21.597+00
2078    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2194    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2317    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2454    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3047    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3139    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3234    135 []  \N  2026-02-04 03:31:34.276+00  2026-02-04 03:31:34.276+00
3333    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3430    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3535    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
639 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
741 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
841 60  []  \N  2025-12-08 23:22:49.444+00  2025-12-08 23:22:49.444+00
941 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1037    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1124    60  []  \N  2025-12-08 23:22:49.588+00  2025-12-08 23:22:49.588+00
1218    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1329    60  []  \N  2025-12-08 23:22:49.683+00  2025-12-08 23:22:49.683+00
1401    60  []  \N  2025-12-08 23:22:49.729+00  2025-12-08 23:22:49.729+00
1486    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
1591    83  []  \N  2026-01-13 21:09:21.176+00  2026-01-13 21:09:21.176+00
1713    83  []  \N  2026-01-13 21:09:21.307+00  2026-01-13 21:09:21.307+00
1774    83  []  \N  2026-01-13 21:09:21.436+00  2026-01-13 21:09:21.436+00
1857    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1956    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2043    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2144    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2253    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2342    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2437    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3048    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3137    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3255    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3371    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3482    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3581    135 []  \N  2026-02-04 03:31:34.673+00  2026-02-04 03:31:34.673+00
640 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
740 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
848 60  []  \N  2025-12-08 23:22:49.444+00  2025-12-08 23:22:49.444+00
952 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1049    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1137    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1224    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1336    60  []  \N  2025-12-08 23:22:49.703+00  2025-12-08 23:22:49.703+00
1406    60  []  \N  2025-12-08 23:22:49.73+00   2025-12-08 23:22:49.73+00
1493    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1628    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1708    83  []  \N  2026-01-13 21:09:21.306+00  2026-01-13 21:09:21.306+00
1767    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1852    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1966    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2056    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2164    83  []  \N  2026-01-13 21:09:21.771+00  2026-01-13 21:09:21.771+00
2259    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2363    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2466    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3049    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3152    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3253    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3379    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3480    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
3574    135 []  \N  2026-02-04 03:31:34.635+00  2026-02-04 03:31:34.635+00
641 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
739 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
838 60  []  \N  2025-12-08 23:22:49.427+00  2025-12-08 23:22:49.427+00
937 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1036    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1133    60  []  \N  2025-12-08 23:22:49.588+00  2025-12-08 23:22:49.588+00
1229    60  []  \N  2025-12-08 23:22:49.639+00  2025-12-08 23:22:49.639+00
1341    60  []  \N  2025-12-08 23:22:49.703+00  2025-12-08 23:22:49.703+00
1412    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1497    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1584    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1710    83  []  \N  2026-01-13 21:09:21.306+00  2026-01-13 21:09:21.306+00
1815    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1901    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
1973    83  []  \N  2026-01-13 21:09:21.597+00  2026-01-13 21:09:21.597+00
2074    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2177    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2276    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2388    83  []  \N  2026-01-13 21:09:22.007+00  2026-01-13 21:09:22.007+00
2486    83  []  \N  2026-01-13 21:09:22.145+00  2026-01-13 21:09:22.145+00
3050    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3130    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3231    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3332    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3427    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3522    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
642 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
745 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
843 60  []  \N  2025-12-08 23:22:49.444+00  2025-12-08 23:22:49.444+00
944 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1042    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1130    60  []  \N  2025-12-08 23:22:49.605+00  2025-12-08 23:22:49.605+00
1217    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1331    60  []  \N  2025-12-08 23:22:49.683+00  2025-12-08 23:22:49.683+00
1403    60  []  \N  2025-12-08 23:22:49.729+00  2025-12-08 23:22:49.729+00
1489    60  []  \N  2025-12-08 23:22:49.797+00  2025-12-08 23:22:49.797+00
1629    83  []  \N  2026-01-13 21:09:21.139+00  2026-01-13 21:09:21.139+00
1714    83  []  \N  2026-01-13 21:09:21.307+00  2026-01-13 21:09:21.307+00
1779    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1854    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1965    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2053    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2148    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2257    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2344    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2444    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3051    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3141    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3235    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3335    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3425    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3521    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
643 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
755 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
855 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
953 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1052    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1148    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1261    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1359    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1461    60  []  \N  2025-12-08 23:22:49.761+00  2025-12-08 23:22:49.761+00
1612    83  []  \N  2026-01-13 21:09:21.139+00  2026-01-13 21:09:21.139+00
1686    83  []  \N  2026-01-13 21:09:21.307+00  2026-01-13 21:09:21.307+00
1816    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1903    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2001    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2115    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2215    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2309    83  []  \N  2026-01-13 21:09:21.953+00  2026-01-13 21:09:21.953+00
2400    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3052    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3142    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3238    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3338    135 []  \N  2026-02-04 03:31:34.351+00  2026-02-04 03:31:34.351+00
3437    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3536    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
497 53  []  \N  2025-11-26 17:19:25.734+00  2025-11-26 17:19:25.734+00
644 60  []  \N  2025-12-08 23:22:49.218+00  2025-12-08 23:22:49.218+00
749 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
844 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
942 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1038    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1121    60  []  \N  2025-12-08 23:22:49.588+00  2025-12-08 23:22:49.588+00
1215    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1314    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1447    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1627    83  []  \N  2026-01-13 21:09:21.18+00   2026-01-13 21:09:21.18+00
1707    83  []  \N  2026-01-13 21:09:21.306+00  2026-01-13 21:09:21.306+00
1804    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1892    83  []  \N  2026-01-13 21:09:21.558+00  2026-01-13 21:09:21.558+00
1978    83  []  \N  2026-01-13 21:09:21.597+00  2026-01-13 21:09:21.597+00
2092    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2195    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2294    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2385    83  []  \N  2026-01-13 21:09:21.98+00   2026-01-13 21:09:21.98+00
2484    83  []  \N  2026-01-13 21:09:22.145+00  2026-01-13 21:09:22.145+00
3053    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3146    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3226    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3325    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3420    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3515    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
645 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
766 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
866 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
965 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1071    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1207    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1311    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1465    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1634    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1709    83  []  \N  2026-01-13 21:09:21.306+00  2026-01-13 21:09:21.306+00
1800    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1883    83  []  \N  2026-01-13 21:09:21.549+00  2026-01-13 21:09:21.549+00
1982    83  []  \N  2026-01-13 21:09:21.597+00  2026-01-13 21:09:21.597+00
2109    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2198    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2293    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2383    83  []  \N  2026-01-13 21:09:21.98+00   2026-01-13 21:09:21.98+00
2487    83  []  \N  2026-01-13 21:09:22.145+00  2026-01-13 21:09:22.145+00
3054    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3143    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3244    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3344    135 []  \N  2026-02-04 03:31:34.394+00  2026-02-04 03:31:34.394+00
3445    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3548    135 []  \N  2026-02-04 03:31:34.565+00  2026-02-04 03:31:34.565+00
646 60  []  \N  2025-12-08 23:22:49.26+00   2025-12-08 23:22:49.26+00
746 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
845 60  []  \N  2025-12-08 23:22:49.444+00  2025-12-08 23:22:49.444+00
946 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1039    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1132    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1219    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1328    60  []  \N  2025-12-08 23:22:49.683+00  2025-12-08 23:22:49.683+00
1400    60  []  \N  2025-12-08 23:22:49.729+00  2025-12-08 23:22:49.729+00
1488    60  []  \N  2025-12-08 23:22:49.797+00  2025-12-08 23:22:49.797+00
1614    83  []  \N  2026-01-13 21:09:21.176+00  2026-01-13 21:09:21.176+00
1711    83  []  \N  2026-01-13 21:09:21.306+00  2026-01-13 21:09:21.306+00
1810    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1894    83  []  \N  2026-01-13 21:09:21.558+00  2026-01-13 21:09:21.558+00
1990    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2072    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2173    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2283    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2401    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3055    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3148    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3229    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3329    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3428    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3523    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
647 60  []  \N  2025-12-08 23:22:49.26+00   2025-12-08 23:22:49.26+00
747 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
846 60  []  \N  2025-12-08 23:22:49.444+00  2025-12-08 23:22:49.444+00
951 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1048    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1136    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1228    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1338    60  []  \N  2025-12-08 23:22:49.703+00  2025-12-08 23:22:49.703+00
1413    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1502    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1607    83  []  \N  2026-01-13 21:09:21.207+00  2026-01-13 21:09:21.207+00
1723    83  []  \N  2026-01-13 21:09:21.307+00  2026-01-13 21:09:21.307+00
1808    83  []  \N  2026-01-13 21:09:21.45+00   2026-01-13 21:09:21.45+00
1897    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
1989    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2071    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2174    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2273    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2373    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2476    83  []  \N  2026-01-13 21:09:22.106+00  2026-01-13 21:09:22.106+00
3056    135 []  \N  2026-02-04 03:31:33.882+00  2026-02-04 03:31:33.882+00
3153    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3252    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3370    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3471    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3563    135 []  \N  2026-02-04 03:31:34.634+00  2026-02-04 03:31:34.634+00
648 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
743 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
850 60  []  \N  2025-12-08 23:22:49.444+00  2025-12-08 23:22:49.444+00
954 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1060    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1165    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1312    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1470    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1608    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1716    83  []  \N  2026-01-13 21:09:21.307+00  2026-01-13 21:09:21.307+00
1822    83  []  \N  2026-01-13 21:09:21.477+00  2026-01-13 21:09:21.477+00
1915    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2023    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2112    83  []  \N  2026-01-13 21:09:21.692+00  2026-01-13 21:09:21.692+00
2211    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2290    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2393    83  []  \N  2026-01-13 21:09:22.051+00  2026-01-13 21:09:22.051+00
3057    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3150    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3257    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3372    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3469    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3575    135 []  \N  2026-02-04 03:31:34.635+00  2026-02-04 03:31:34.635+00
649 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
742 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
840 60  []  \N  2025-12-08 23:22:49.444+00  2025-12-08 23:22:49.444+00
940 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1032    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1125    60  []  \N  2025-12-08 23:22:49.588+00  2025-12-08 23:22:49.588+00
1258    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1356    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1458    60  []  \N  2025-12-08 23:22:49.761+00  2025-12-08 23:22:49.761+00
1637    83  []  \N  2026-01-13 21:09:21.14+00   2026-01-13 21:09:21.14+00
1718    83  []  \N  2026-01-13 21:09:21.307+00  2026-01-13 21:09:21.307+00
1778    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1850    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1942    83  []  \N  2026-01-13 21:09:21.578+00  2026-01-13 21:09:21.578+00
2034    83  []  \N  2026-01-13 21:09:21.626+00  2026-01-13 21:09:21.626+00
2134    83  []  \N  2026-01-13 21:09:21.761+00  2026-01-13 21:09:21.761+00
2222    83  []  \N  2026-01-13 21:09:21.882+00  2026-01-13 21:09:21.882+00
2326    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2415    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3058    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3165    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3259    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3362    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3462    135 []  \N  2026-02-04 03:31:34.502+00  2026-02-04 03:31:34.502+00
3561    135 []  \N  2026-02-04 03:31:34.634+00  2026-02-04 03:31:34.634+00
650 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
748 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
842 60  []  \N  2025-12-08 23:22:49.444+00  2025-12-08 23:22:49.444+00
943 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1044    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1129    60  []  \N  2025-12-08 23:22:49.605+00  2025-12-08 23:22:49.605+00
1225    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1337    60  []  \N  2025-12-08 23:22:49.703+00  2025-12-08 23:22:49.703+00
1409    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1500    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1639    83  []  \N  2026-01-13 21:09:21.207+00  2026-01-13 21:09:21.207+00
1706    83  []  \N  2026-01-13 21:09:21.306+00  2026-01-13 21:09:21.306+00
1785    83  []  \N  2026-01-13 21:09:21.412+00  2026-01-13 21:09:21.412+00
1927    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2016    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2123    83  []  \N  2026-01-13 21:09:21.761+00  2026-01-13 21:09:21.761+00
2226    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2323    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2429    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3059    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3157    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3254    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3375    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3472    135 []  \N  2026-02-04 03:31:34.528+00  2026-02-04 03:31:34.528+00
3572    135 []  \N  2026-02-04 03:31:34.635+00  2026-02-04 03:31:34.635+00
651 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
744 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
851 60  []  \N  2025-12-08 23:22:49.444+00  2025-12-08 23:22:49.444+00
955 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1062    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1166    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1313    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1471    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1631    83  []  \N  2026-01-13 21:09:21.141+00  2026-01-13 21:09:21.141+00
1720    83  []  \N  2026-01-13 21:09:21.337+00  2026-01-13 21:09:21.337+00
1772    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1843    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1954    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2046    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2147    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2250    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2358    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2457    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3060    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3132    135 []  \N  2026-02-04 03:31:34.071+00  2026-02-04 03:31:34.071+00
3222    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3308    135 []  \N  2026-02-04 03:31:34.347+00  2026-02-04 03:31:34.347+00
3403    135 []  \N  2026-02-04 03:31:34.462+00  2026-02-04 03:31:34.462+00
3502    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
652 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
750 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
847 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
945 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1040    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1131    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1234    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1370    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1511    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1632    83  []  \N  2026-01-13 21:09:21.176+00  2026-01-13 21:09:21.176+00
1715    83  []  \N  2026-01-13 21:09:21.307+00  2026-01-13 21:09:21.307+00
1762    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1839    83  []  \N  2026-01-13 21:09:21.496+00  2026-01-13 21:09:21.496+00
1957    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2044    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2145    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2233    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2353    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2448    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3061    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3158    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3247    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3383    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3478    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
3558    135 []  \N  2026-02-04 03:31:34.567+00  2026-02-04 03:31:34.567+00
653 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
752 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
852 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
948 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1045    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1135    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1264    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1456    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1640    83  []  \N  2026-01-13 21:09:21.207+00  2026-01-13 21:09:21.207+00
1717    83  []  \N  2026-01-13 21:09:21.307+00  2026-01-13 21:09:21.307+00
1773    83  []  \N  2026-01-13 21:09:21.435+00  2026-01-13 21:09:21.435+00
1847    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1946    83  []  \N  2026-01-13 21:09:21.578+00  2026-01-13 21:09:21.578+00
2050    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2152    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2238    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2333    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2435    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3062    135 []  \N  2026-02-04 03:31:33.881+00  2026-02-04 03:31:33.881+00
3155    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3290    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3407    135 []  \N  2026-02-04 03:31:34.462+00  2026-02-04 03:31:34.462+00
3506    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
654 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
751 60  []  \N  2025-12-08 23:22:49.336+00  2025-12-08 23:22:49.336+00
849 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
947 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1043    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1144    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1256    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1352    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1433    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1641    83  []  \N  2026-01-13 21:09:21.207+00  2026-01-13 21:09:21.207+00
1684    83  []  \N  2026-01-13 21:09:21.306+00  2026-01-13 21:09:21.306+00
1818    83  []  \N  2026-01-13 21:09:21.46+00   2026-01-13 21:09:21.46+00
1912    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2025    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2121    83  []  \N  2026-01-13 21:09:21.76+00   2026-01-13 21:09:21.76+00
2221    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2321    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2427    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3063    135 []  \N  2026-02-04 03:31:33.879+00  2026-02-04 03:31:33.879+00
3156    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3236    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3336    135 []  \N  2026-02-04 03:31:34.35+00   2026-02-04 03:31:34.35+00
3440    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3537    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
655 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
753 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
853 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
949 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1046    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1145    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1257    60  []  \N  2025-12-08 23:22:49.639+00  2025-12-08 23:22:49.639+00
1355    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1435    60  []  \N  2025-12-08 23:22:49.761+00  2025-12-08 23:22:49.761+00
1528    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1642    83  []  \N  2026-01-13 21:09:21.207+00  2026-01-13 21:09:21.207+00
1750    83  []  \N  2026-01-13 21:09:21.412+00  2026-01-13 21:09:21.412+00
1858    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1964    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2062    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2163    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2239    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2345    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2442    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3064    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3159    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3248    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3380    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3475    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
3568    135 []  \N  2026-02-04 03:31:34.634+00  2026-02-04 03:31:34.634+00
656 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
754 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
854 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
950 60  []  \N  2025-12-08 23:22:49.512+00  2025-12-08 23:22:49.512+00
1050    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1146    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1259    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1357    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1459    60  []  \N  2025-12-08 23:22:49.761+00  2025-12-08 23:22:49.761+00
1643    83  []  \N  2026-01-13 21:09:21.177+00  2026-01-13 21:09:21.177+00
1782    83  []  \N  2026-01-13 21:09:21.361+00  2026-01-13 21:09:21.361+00
1934    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2030    83  []  \N  2026-01-13 21:09:21.625+00  2026-01-13 21:09:21.625+00
2129    83  []  \N  2026-01-13 21:09:21.761+00  2026-01-13 21:09:21.761+00
2263    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2354    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2447    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3065    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3324    135 []  \N  2026-02-04 03:31:34.347+00  2026-02-04 03:31:34.347+00
3426    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3527    135 []  \N  2026-02-04 03:31:34.552+00  2026-02-04 03:31:34.552+00
657 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
756 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
856 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
956 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1053    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1151    60  []  \N  2025-12-08 23:22:49.606+00  2025-12-08 23:22:49.606+00
1268    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1369    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1510    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1644    83  []  \N  2026-01-13 21:09:21.177+00  2026-01-13 21:09:21.177+00
1752    83  []  \N  2026-01-13 21:09:21.363+00  2026-01-13 21:09:21.363+00
1869    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1959    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2058    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2137    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2231    83  []  \N  2026-01-13 21:09:21.882+00  2026-01-13 21:09:21.882+00
2360    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2459    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3066    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3160    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3292    135 []  \N  2026-02-04 03:31:34.345+00  2026-02-04 03:31:34.345+00
3397    135 []  \N  2026-02-04 03:31:34.431+00  2026-02-04 03:31:34.431+00
3489    135 []  \N  2026-02-04 03:31:34.55+00   2026-02-04 03:31:34.55+00
658 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
757 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
858 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
958 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1051    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1158    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1275    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1446    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1646    83  []  \N  2026-01-13 21:09:21.207+00  2026-01-13 21:09:21.207+00
1754    83  []  \N  2026-01-13 21:09:21.363+00  2026-01-13 21:09:21.363+00
1871    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1998    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2087    83  []  \N  2026-01-13 21:09:21.668+00  2026-01-13 21:09:21.668+00
2212    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2286    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2379    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2478    83  []  \N  2026-01-13 21:09:22.144+00  2026-01-13 21:09:22.144+00
3067    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3161    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3315    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3414    135 []  \N  2026-02-04 03:31:34.463+00  2026-02-04 03:31:34.463+00
3517    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
659 60  []  \N  2025-12-08 23:22:49.261+00  2025-12-08 23:22:49.261+00
759 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
861 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
961 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1059    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1155    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1271    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1372    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1514    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1647    83  []  \N  2026-01-13 21:09:21.207+00  2026-01-13 21:09:21.207+00
1755    83  []  \N  2026-01-13 21:09:21.363+00  2026-01-13 21:09:21.363+00
1926    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
2012    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2116    83  []  \N  2026-01-13 21:09:21.692+00  2026-01-13 21:09:21.692+00
2216    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2306    83  []  \N  2026-01-13 21:09:21.904+00  2026-01-13 21:09:21.904+00
2395    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3068    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3164    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3280    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3377    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3474    135 []  \N  2026-02-04 03:31:34.528+00  2026-02-04 03:31:34.528+00
3570    135 []  \N  2026-02-04 03:31:34.634+00  2026-02-04 03:31:34.634+00
660 60  []  \N  2025-12-08 23:22:49.278+00  2025-12-08 23:22:49.278+00
758 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
857 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
957 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1061    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1160    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1278    60  []  \N  2025-12-08 23:22:49.661+00  2025-12-08 23:22:49.661+00
1451    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1648    83  []  \N  2026-01-13 21:09:21.207+00  2026-01-13 21:09:21.207+00
1742    83  []  \N  2026-01-13 21:09:21.363+00  2026-01-13 21:09:21.363+00
1837    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1958    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2065    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2162    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2242    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2346    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2443    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3069    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3177    135 []  \N  2026-02-04 03:31:34.072+00  2026-02-04 03:31:34.072+00
3284    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3384    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3486    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
661 60  []  \N  2025-12-08 23:22:49.278+00  2025-12-08 23:22:49.278+00
762 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
862 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
962 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1056    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1154    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1270    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1441    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1649    83  []  \N  2026-01-13 21:09:21.207+00  2026-01-13 21:09:21.207+00
1751    83  []  \N  2026-01-13 21:09:21.412+00  2026-01-13 21:09:21.412+00
1859    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1963    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2057    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2140    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2252    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2337    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2438    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3070    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3178    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3279    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3381    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3476    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
3564    135 []  \N  2026-02-04 03:31:34.634+00  2026-02-04 03:31:34.634+00
605 53  []  \N  2025-11-26 17:19:25.835+00  2025-11-26 17:19:25.835+00
662 60  []  \N  2025-12-08 23:22:49.278+00  2025-12-08 23:22:49.278+00
761 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
859 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
959 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1065    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1190    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1308    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1448    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1650    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1726    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1834    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1913    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2011    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2094    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2170    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2267    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2367    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2458    83  []  \N  2026-01-13 21:09:22.102+00  2026-01-13 21:09:22.102+00
3071    135 []  \N  2026-02-04 03:31:33.88+00   2026-02-04 03:31:33.88+00
3322    135 []  \N  2026-02-04 03:31:34.347+00  2026-02-04 03:31:34.347+00
3419    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3512    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
663 60  []  \N  2025-12-08 23:22:49.278+00  2025-12-08 23:22:49.278+00
763 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
863 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
963 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1057    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1157    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1273    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1443    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1651    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1737    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1824    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1908    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2003    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2085    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2182    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2310    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2422    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3072    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3166    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3264    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3351    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3451    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3546    135 []  \N  2026-02-04 03:31:34.566+00  2026-02-04 03:31:34.566+00
664 60  []  \N  2025-12-08 23:22:49.278+00  2025-12-08 23:22:49.278+00
760 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
860 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
960 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1058    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1156    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1276    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1449    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1652    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1740    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1863    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
1937    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2028    83  []  \N  2026-01-13 21:09:21.625+00  2026-01-13 21:09:21.625+00
2126    83  []  \N  2026-01-13 21:09:21.692+00  2026-01-13 21:09:21.692+00
2229    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2328    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2423    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3073    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3168    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3250    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3354    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3454    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3550    135 []  \N  2026-02-04 03:31:34.566+00  2026-02-04 03:31:34.566+00
665 60  []  \N  2025-12-08 23:22:49.278+00  2025-12-08 23:22:49.278+00
764 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
864 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
964 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1063    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1161    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1279    60  []  \N  2025-12-08 23:22:49.661+00  2025-12-08 23:22:49.661+00
1452    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1653    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1736    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1826    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1906    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2002    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2083    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2189    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2291    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2389    83  []  \N  2026-01-13 21:09:21.98+00   2026-01-13 21:09:21.98+00
2490    83  []  \N  2026-01-13 21:09:22.145+00  2026-01-13 21:09:22.145+00
3075    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3169    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3263    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3352    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3452    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3547    135 []  \N  2026-02-04 03:31:34.566+00  2026-02-04 03:31:34.566+00
666 60  []  \N  2025-12-08 23:22:49.278+00  2025-12-08 23:22:49.278+00
765 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
865 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
966 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1066    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1206    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1310    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1455    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1654    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1732    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1832    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1917    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2038    83  []  \N  2026-01-13 21:09:21.626+00  2026-01-13 21:09:21.626+00
2158    83  []  \N  2026-01-13 21:09:21.802+00  2026-01-13 21:09:21.802+00
2247    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2331    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2433    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3074    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3167    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3251    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3356    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3455    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3552    135 []  \N  2026-02-04 03:31:34.566+00  2026-02-04 03:31:34.566+00
667 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
767 60  []  \N  2025-12-08 23:22:49.351+00  2025-12-08 23:22:49.351+00
867 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
967 60  []  \N  2025-12-08 23:22:49.513+00  2025-12-08 23:22:49.513+00
1064    60  []  \N  2025-12-08 23:22:49.559+00  2025-12-08 23:22:49.559+00
1189    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1297    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1438    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1655    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1738    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1823    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1916    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2018    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2103    83  []  \N  2026-01-13 21:09:21.692+00  2026-01-13 21:09:21.692+00
2200    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2287    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2374    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2482    83  []  \N  2026-01-13 21:09:22.144+00  2026-01-13 21:09:22.144+00
3076    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3171    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3240    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3340    135 []  \N  2026-02-04 03:31:34.351+00  2026-02-04 03:31:34.351+00
3438    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3534    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
668 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
769 60  []  \N  2025-12-08 23:22:49.37+00   2025-12-08 23:22:49.37+00
869 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
970 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1069    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1138    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1253    60  []  \N  2025-12-08 23:22:49.639+00  2025-12-08 23:22:49.639+00
1350    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1431    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1656    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1731    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1828    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1921    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2024    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2119    83  []  \N  2026-01-13 21:09:21.76+00   2026-01-13 21:09:21.76+00
2219    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2319    83  []  \N  2026-01-13 21:09:21.976+00  2026-01-13 21:09:21.976+00
2378    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2473    83  []  \N  2026-01-13 21:09:22.106+00  2026-01-13 21:09:22.106+00
3077    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3170    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3246    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3382    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3477    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
3555    135 []  \N  2026-02-04 03:31:34.567+00  2026-02-04 03:31:34.567+00
669 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
770 60  []  \N  2025-12-08 23:22:49.37+00   2025-12-08 23:22:49.37+00
868 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
969 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1068    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1169    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1245    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1332    60  []  \N  2025-12-08 23:22:49.683+00  2025-12-08 23:22:49.683+00
1404    60  []  \N  2025-12-08 23:22:49.729+00  2025-12-08 23:22:49.729+00
1491    60  []  \N  2025-12-08 23:22:49.797+00  2025-12-08 23:22:49.797+00
1657    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1734    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1833    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1909    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2006    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2082    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2190    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2298    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2410    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3078    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3321    135 []  \N  2026-02-04 03:31:34.347+00  2026-02-04 03:31:34.347+00
3435    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3539    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
670 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
768 60  []  \N  2025-12-08 23:22:49.37+00   2025-12-08 23:22:49.37+00
870 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
968 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1067    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1167    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1235    60  []  \N  2025-12-08 23:22:49.661+00  2025-12-08 23:22:49.661+00
1322    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1395    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1479    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
1658    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1730    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1829    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1919    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2042    83  []  \N  2026-01-13 21:09:21.626+00  2026-01-13 21:09:21.626+00
2142    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2234    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2351    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2451    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3079    135 []  \N  2026-02-04 03:31:33.947+00  2026-02-04 03:31:33.947+00
3174    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3258    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3357    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3459    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
671 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
772 60  []  \N  2025-12-08 23:22:49.37+00   2025-12-08 23:22:49.37+00
872 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
972 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1075    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1139    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1222    60  []  \N  2025-12-08 23:22:49.639+00  2025-12-08 23:22:49.639+00
1323    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1392    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1477    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
1659    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1728    83  []  \N  2026-01-13 21:09:21.361+00  2026-01-13 21:09:21.361+00
1827    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1907    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2005    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2081    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2202    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2307    83  []  \N  2026-01-13 21:09:21.952+00  2026-01-13 21:09:21.952+00
2409    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3080    135 []  \N  2026-02-04 03:31:33.948+00  2026-02-04 03:31:33.948+00
3176    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3265    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3350    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3450    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3545    135 []  \N  2026-02-04 03:31:34.566+00  2026-02-04 03:31:34.566+00
672 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
771 60  []  \N  2025-12-08 23:22:49.37+00   2025-12-08 23:22:49.37+00
871 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
971 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1070    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1188    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1293    60  []  \N  2025-12-08 23:22:49.681+00  2025-12-08 23:22:49.681+00
1379    60  []  \N  2025-12-08 23:22:49.722+00  2025-12-08 23:22:49.722+00
1506    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1660    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1733    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1835    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1904    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2007    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2089    83  []  \N  2026-01-13 21:09:21.692+00  2026-01-13 21:09:21.692+00
2192    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2304    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2398    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3081    135 []  \N  2026-02-04 03:31:33.948+00  2026-02-04 03:31:33.948+00
3172    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3261    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3348    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3446    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3543    135 []  \N  2026-02-04 03:31:34.565+00  2026-02-04 03:31:34.565+00
673 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
773 60  []  \N  2025-12-08 23:22:49.37+00   2025-12-08 23:22:49.37+00
873 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
973 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1072    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1168    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1238    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1320    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1390    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1476    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
1662    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1729    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1825    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1905    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2004    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2086    83  []  \N  2026-01-13 21:09:21.691+00  2026-01-13 21:09:21.691+00
2201    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2308    83  []  \N  2026-01-13 21:09:21.952+00  2026-01-13 21:09:21.952+00
2419    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3082    135 []  \N  2026-02-04 03:31:33.948+00  2026-02-04 03:31:33.948+00
3175    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3239    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3339    135 []  \N  2026-02-04 03:31:34.351+00  2026-02-04 03:31:34.351+00
3439    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3533    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
674 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
776 60  []  \N  2025-12-08 23:22:49.37+00   2025-12-08 23:22:49.37+00
877 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
976 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1081    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1177    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1239    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1330    60  []  \N  2025-12-08 23:22:49.683+00  2025-12-08 23:22:49.683+00
1402    60  []  \N  2025-12-08 23:22:49.729+00  2025-12-08 23:22:49.729+00
1490    60  []  \N  2025-12-08 23:22:49.797+00  2025-12-08 23:22:49.797+00
1663    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1727    83  []  \N  2026-01-13 21:09:21.361+00  2026-01-13 21:09:21.361+00
1831    83  []  \N  2026-01-13 21:09:21.478+00  2026-01-13 21:09:21.478+00
1920    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2021    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2101    83  []  \N  2026-01-13 21:09:21.692+00  2026-01-13 21:09:21.692+00
2210    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2295    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2392    83  []  \N  2026-01-13 21:09:22.007+00  2026-01-13 21:09:22.007+00
3083    135 []  \N  2026-02-04 03:31:33.948+00  2026-02-04 03:31:33.948+00
3173    135 []  \N  2026-02-04 03:31:34.122+00  2026-02-04 03:31:34.122+00
3243    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3343    135 []  \N  2026-02-04 03:31:34.357+00  2026-02-04 03:31:34.357+00
3441    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3528    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
675 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
775 60  []  \N  2025-12-08 23:22:49.37+00   2025-12-08 23:22:49.37+00
875 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
975 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1076    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1173    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1232    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1316    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1389    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1481    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
1664    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1746    83  []  \N  2026-01-13 21:09:21.363+00  2026-01-13 21:09:21.363+00
1838    83  []  \N  2026-01-13 21:09:21.496+00  2026-01-13 21:09:21.496+00
1952    83  []  \N  2026-01-13 21:09:21.578+00  2026-01-13 21:09:21.578+00
2066    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2160    83  []  \N  2026-01-13 21:09:21.822+00  2026-01-13 21:09:21.822+00
2240    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2341    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2441    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3084    135 []  \N  2026-02-04 03:31:33.948+00  2026-02-04 03:31:33.948+00
3210    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3293    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3393    135 []  \N  2026-02-04 03:31:34.431+00  2026-02-04 03:31:34.431+00
3491    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
676 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
774 60  []  \N  2025-12-08 23:22:49.37+00   2025-12-08 23:22:49.37+00
874 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
974 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1074    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1172    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1263    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1354    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1399    60  []  \N  2025-12-08 23:22:49.729+00  2025-12-08 23:22:49.729+00
1487    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
1665    83  []  \N  2026-01-13 21:09:21.207+00  2026-01-13 21:09:21.207+00
1783    83  []  \N  2026-01-13 21:09:21.363+00  2026-01-13 21:09:21.363+00
1929    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
2008    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2130    83  []  \N  2026-01-13 21:09:21.761+00  2026-01-13 21:09:21.761+00
2262    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2352    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2469    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3085    135 []  \N  2026-02-04 03:31:34.018+00  2026-02-04 03:31:34.018+00
3179    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3242    135 []  \N  2026-02-04 03:31:34.277+00  2026-02-04 03:31:34.277+00
3342    135 []  \N  2026-02-04 03:31:34.357+00  2026-02-04 03:31:34.357+00
3443    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3540    135 []  \N  2026-02-04 03:31:34.565+00  2026-02-04 03:31:34.565+00
677 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
777 60  []  \N  2025-12-08 23:22:49.37+00   2025-12-08 23:22:49.37+00
876 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
977 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1073    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1140    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1221    60  []  \N  2025-12-08 23:22:49.639+00  2025-12-08 23:22:49.639+00
1317    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1387    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1475    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
1645    83  []  \N  2026-01-13 21:09:21.177+00  2026-01-13 21:09:21.177+00
1753    83  []  \N  2026-01-13 21:09:21.363+00  2026-01-13 21:09:21.363+00
1870    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
2000    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2076    83  []  \N  2026-01-13 21:09:21.667+00  2026-01-13 21:09:21.667+00
2185    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2278    83  []  \N  2026-01-13 21:09:21.903+00  2026-01-13 21:09:21.903+00
2391    83  []  \N  2026-01-13 21:09:22.007+00  2026-01-13 21:09:22.007+00
3086    135 []  \N  2026-02-04 03:31:33.948+00  2026-02-04 03:31:33.948+00
3184    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3277    135 []  \N  2026-02-04 03:31:34.287+00  2026-02-04 03:31:34.287+00
3355    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3456    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3571    135 []  \N  2026-02-04 03:31:34.635+00  2026-02-04 03:31:34.635+00
678 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
780 60  []  \N  2025-12-08 23:22:49.371+00  2025-12-08 23:22:49.371+00
880 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
978 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1078    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1174    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1231    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1385    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1494    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1666    83  []  \N  2026-01-13 21:09:21.208+00  2026-01-13 21:09:21.208+00
1743    83  []  \N  2026-01-13 21:09:21.363+00  2026-01-13 21:09:21.363+00
1864    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
1938    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2029    83  []  \N  2026-01-13 21:09:21.625+00  2026-01-13 21:09:21.625+00
2128    83  []  \N  2026-01-13 21:09:21.761+00  2026-01-13 21:09:21.761+00
2261    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2350    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2445    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3087    135 []  \N  2026-02-04 03:31:33.948+00  2026-02-04 03:31:33.948+00
3183    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3278    135 []  \N  2026-02-04 03:31:34.287+00  2026-02-04 03:31:34.287+00
3347    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3448    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3549    135 []  \N  2026-02-04 03:31:34.565+00  2026-02-04 03:31:34.565+00
679 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
779 60  []  \N  2025-12-08 23:22:49.371+00  2025-12-08 23:22:49.371+00
881 60  []  \N  2025-12-08 23:22:49.467+00  2025-12-08 23:22:49.467+00
980 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1079    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1175    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1237    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1318    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1388    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1482    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
1725    83  []  \N  2026-01-13 21:09:21.337+00  2026-01-13 21:09:21.337+00
1861    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1961    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2040    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2156    83  []  \N  2026-01-13 21:09:21.771+00  2026-01-13 21:09:21.771+00
2235    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2332    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2416    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3088    135 []  \N  2026-02-04 03:31:34.018+00  2026-02-04 03:31:34.018+00
3180    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3221    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3307    135 []  \N  2026-02-04 03:31:34.347+00  2026-02-04 03:31:34.347+00
3402    135 []  \N  2026-02-04 03:31:34.462+00  2026-02-04 03:31:34.462+00
3497    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
680 60  []  \N  2025-12-08 23:22:49.279+00  2025-12-08 23:22:49.279+00
778 60  []  \N  2025-12-08 23:22:49.371+00  2025-12-08 23:22:49.371+00
878 60  []  \N  2025-12-08 23:22:49.445+00  2025-12-08 23:22:49.445+00
982 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1084    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1179    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1246    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1334    60  []  \N  2025-12-08 23:22:49.703+00  2025-12-08 23:22:49.703+00
1408    60  []  \N  2025-12-08 23:22:49.756+00  2025-12-08 23:22:49.756+00
1496    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1739    83  []  \N  2026-01-13 21:09:21.361+00  2026-01-13 21:09:21.361+00
1923    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
2010    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2111    83  []  \N  2026-01-13 21:09:21.692+00  2026-01-13 21:09:21.692+00
2207    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2303    83  []  \N  2026-01-13 21:09:21.904+00  2026-01-13 21:09:21.904+00
2407    83  []  \N  2026-01-13 21:09:22.052+00  2026-01-13 21:09:22.052+00
3089    135 []  \N  2026-02-04 03:31:33.948+00  2026-02-04 03:31:33.948+00
3212    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3302    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3390    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3487    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
681 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
781 60  []  \N  2025-12-08 23:22:49.371+00  2025-12-08 23:22:49.371+00
879 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
979 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1077    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1170    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1230    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1319    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1391    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1474    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
1744    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1862    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1960    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2060    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2139    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2255    83  []  \N  2026-01-13 21:09:21.901+00  2026-01-13 21:09:21.901+00
2340    83  []  \N  2026-01-13 21:09:21.978+00  2026-01-13 21:09:21.978+00
2455    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3090    135 []  \N  2026-02-04 03:31:33.948+00  2026-02-04 03:31:33.948+00
3203    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3295    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3406    135 []  \N  2026-02-04 03:31:34.462+00  2026-02-04 03:31:34.462+00
3495    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
682 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
782 60  []  \N  2025-12-08 23:22:49.371+00  2025-12-08 23:22:49.371+00
883 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
981 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1082    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1176    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1291    60  []  \N  2025-12-08 23:22:49.681+00  2025-12-08 23:22:49.681+00
1377    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1457    60  []  \N  2025-12-08 23:22:49.761+00  2025-12-08 23:22:49.761+00
1747    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1868    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
1979    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2100    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2181    83  []  \N  2026-01-13 21:09:21.824+00  2026-01-13 21:09:21.824+00
2272    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2371    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2471    83  []  \N  2026-01-13 21:09:22.106+00  2026-01-13 21:09:22.106+00
3091    135 []  \N  2026-02-04 03:31:33.948+00  2026-02-04 03:31:33.948+00
3182    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3266    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3349    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3449    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3544    135 []  \N  2026-02-04 03:31:34.565+00  2026-02-04 03:31:34.565+00
683 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
783 60  []  \N  2025-12-08 23:22:49.371+00  2025-12-08 23:22:49.371+00
882 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
983 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1083    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1171    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1233    60  []  \N  2025-12-08 23:22:49.661+00  2025-12-08 23:22:49.661+00
1321    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1393    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1478    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
1748    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1930    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
2019    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2125    83  []  \N  2026-01-13 21:09:21.761+00  2026-01-13 21:09:21.761+00
2228    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2327    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2420    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3092    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3207    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3298    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3401    135 []  \N  2026-02-04 03:31:34.431+00  2026-02-04 03:31:34.431+00
3492    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
684 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
784 60  []  \N  2025-12-08 23:22:49.371+00  2025-12-08 23:22:49.371+00
885 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
985 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1080    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1178    60  []  \N  2025-12-08 23:22:49.607+00  2025-12-08 23:22:49.607+00
1295    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1382    60  []  \N  2025-12-08 23:22:49.722+00  2025-12-08 23:22:49.722+00
1513    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1749    83  []  \N  2026-01-13 21:09:21.337+00  2026-01-13 21:09:21.337+00
1867    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
2020    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2127    83  []  \N  2026-01-13 21:09:21.761+00  2026-01-13 21:09:21.761+00
2260    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2364    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2468    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3093    135 []  \N  2026-02-04 03:31:34.018+00  2026-02-04 03:31:34.018+00
3181    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3267    135 []  \N  2026-02-04 03:31:34.278+00  2026-02-04 03:31:34.278+00
3353    135 []  \N  2026-02-04 03:31:34.429+00  2026-02-04 03:31:34.429+00
3453    135 []  \N  2026-02-04 03:31:34.501+00  2026-02-04 03:31:34.501+00
3554    135 []  \N  2026-02-04 03:31:34.567+00  2026-02-04 03:31:34.567+00
685 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
785 60  []  \N  2025-12-08 23:22:49.371+00  2025-12-08 23:22:49.371+00
884 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
984 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1087    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1183    60  []  \N  2025-12-08 23:22:49.608+00  2025-12-08 23:22:49.608+00
1250    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1344    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1422    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1522    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1741    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1860    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
1962    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2059    83  []  \N  2026-01-13 21:09:21.642+00  2026-01-13 21:09:21.642+00
2138    83  []  \N  2026-01-13 21:09:21.77+00   2026-01-13 21:09:21.77+00
2256    83  []  \N  2026-01-13 21:09:21.882+00  2026-01-13 21:09:21.882+00
2338    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2432    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3094    135 []  \N  2026-02-04 03:31:34.018+00  2026-02-04 03:31:34.018+00
3215    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3305    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3391    135 []  \N  2026-02-04 03:31:34.43+00   2026-02-04 03:31:34.43+00
3488    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
686 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
786 60  []  \N  2025-12-08 23:22:49.371+00  2025-12-08 23:22:49.371+00
886 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
986 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1090    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1187    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1249    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1345    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1420    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1521    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1756    83  []  \N  2026-01-13 21:09:21.361+00  2026-01-13 21:09:21.361+00
1866    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
1976    83  []  \N  2026-01-13 21:09:21.598+00  2026-01-13 21:09:21.598+00
2098    83  []  \N  2026-01-13 21:09:21.643+00  2026-01-13 21:09:21.643+00
2178    83  []  \N  2026-01-13 21:09:21.823+00  2026-01-13 21:09:21.823+00
2271    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2370    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2470    83  []  \N  2026-01-13 21:09:22.106+00  2026-01-13 21:09:22.106+00
3095    135 []  \N  2026-02-04 03:31:34.018+00  2026-02-04 03:31:34.018+00
3214    135 []  \N  2026-02-04 03:31:34.173+00  2026-02-04 03:31:34.173+00
3304    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3399    135 []  \N  2026-02-04 03:31:34.431+00  2026-02-04 03:31:34.431+00
3494    135 []  \N  2026-02-04 03:31:34.55+00   2026-02-04 03:31:34.55+00
687 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
787 60  []  \N  2025-12-08 23:22:49.371+00  2025-12-08 23:22:49.371+00
888 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
989 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1088    60  []  \N  2025-12-08 23:22:49.586+00  2025-12-08 23:22:49.586+00
1180    60  []  \N  2025-12-08 23:22:49.608+00  2025-12-08 23:22:49.608+00
1266    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1360    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1462    60  []  \N  2025-12-08 23:22:49.761+00  2025-12-08 23:22:49.761+00
1758    83  []  \N  2026-01-13 21:09:21.337+00  2026-01-13 21:09:21.337+00
1865    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
1940    83  []  \N  2026-01-13 21:09:21.586+00  2026-01-13 21:09:21.586+00
2036    83  []  \N  2026-01-13 21:09:21.626+00  2026-01-13 21:09:21.626+00
2165    83  []  \N  2026-01-13 21:09:21.802+00  2026-01-13 21:09:21.802+00
2264    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2356    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2449    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3105    135 []  \N  2026-02-04 03:31:34.019+00  2026-02-04 03:31:34.019+00
3208    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3300    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3398    135 []  \N  2026-02-04 03:31:34.431+00  2026-02-04 03:31:34.431+00
3498    135 []  \N  2026-02-04 03:31:34.55+00   2026-02-04 03:31:34.55+00
688 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
788 60  []  \N  2025-12-08 23:22:49.371+00  2025-12-08 23:22:49.371+00
887 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
987 60  []  \N  2025-12-08 23:22:49.514+00  2025-12-08 23:22:49.514+00
1086    60  []  \N  2025-12-08 23:22:49.56+00   2025-12-08 23:22:49.56+00
1181    60  []  \N  2025-12-08 23:22:49.608+00  2025-12-08 23:22:49.608+00
1247    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1342    60  []  \N  2025-12-08 23:22:49.703+00  2025-12-08 23:22:49.703+00
1417    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1519    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1759    83  []  \N  2026-01-13 21:09:21.361+00  2026-01-13 21:09:21.361+00
1924    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
2013    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2117    83  []  \N  2026-01-13 21:09:21.692+00  2026-01-13 21:09:21.692+00
2217    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2315    83  []  \N  2026-01-13 21:09:21.976+00  2026-01-13 21:09:21.976+00
2425    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3112    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3213    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3303    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3405    135 []  \N  2026-02-04 03:31:34.462+00  2026-02-04 03:31:34.462+00
3501    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
689 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
789 60  []  \N  2025-12-08 23:22:49.394+00  2025-12-08 23:22:49.394+00
889 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
988 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1085    60  []  \N  2025-12-08 23:22:49.586+00  2025-12-08 23:22:49.586+00
1182    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1294    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1439    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1530    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1764    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1872    83  []  \N  2026-01-13 21:09:21.504+00  2026-01-13 21:09:21.504+00
2009    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2114    83  []  \N  2026-01-13 21:09:21.692+00  2026-01-13 21:09:21.692+00
2213    83  []  \N  2026-01-13 21:09:21.825+00  2026-01-13 21:09:21.825+00
2302    83  []  \N  2026-01-13 21:09:21.904+00  2026-01-13 21:09:21.904+00
2390    83  []  \N  2026-01-13 21:09:22.007+00  2026-01-13 21:09:22.007+00
3113    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3211    135 []  \N  2026-02-04 03:31:34.18+00   2026-02-04 03:31:34.18+00
3301    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3392    135 []  \N  2026-02-04 03:31:34.431+00  2026-02-04 03:31:34.431+00
3496    135 []  \N  2026-02-04 03:31:34.529+00  2026-02-04 03:31:34.529+00
690 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
790 60  []  \N  2025-12-08 23:22:49.394+00  2025-12-08 23:22:49.394+00
890 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
990 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1089    60  []  \N  2025-12-08 23:22:49.586+00  2025-12-08 23:22:49.586+00
1184    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1248    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1343    60  []  \N  2025-12-08 23:22:49.703+00  2025-12-08 23:22:49.703+00
1418    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1518    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1780    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1925    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
2015    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2118    83  []  \N  2026-01-13 21:09:21.76+00   2026-01-13 21:09:21.76+00
2218    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2316    83  []  \N  2026-01-13 21:09:21.976+00  2026-01-13 21:09:21.976+00
2421    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3117    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3216    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3309    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3409    135 []  \N  2026-02-04 03:31:34.463+00  2026-02-04 03:31:34.463+00
3504    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
691 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
792 60  []  \N  2025-12-08 23:22:49.394+00  2025-12-08 23:22:49.394+00
893 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
993 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1093    60  []  \N  2025-12-08 23:22:49.586+00  2025-12-08 23:22:49.586+00
1202    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1298    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1383    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1515    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1781    83  []  \N  2026-01-13 21:09:21.362+00  2026-01-13 21:09:21.362+00
1928    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
2017    83  []  \N  2026-01-13 21:09:21.61+00   2026-01-13 21:09:21.61+00
2124    83  []  \N  2026-01-13 21:09:21.761+00  2026-01-13 21:09:21.761+00
2227    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2325    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2431    83  []  \N  2026-01-13 21:09:22.053+00  2026-01-13 21:09:22.053+00
3119    135 []  \N  2026-02-04 03:31:34.024+00  2026-02-04 03:31:34.024+00
3218    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3311    135 []  \N  2026-02-04 03:31:34.347+00  2026-02-04 03:31:34.347+00
3411    135 []  \N  2026-02-04 03:31:34.463+00  2026-02-04 03:31:34.463+00
3510    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
692 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
791 60  []  \N  2025-12-08 23:22:49.394+00  2025-12-08 23:22:49.394+00
894 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
994 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1094    60  []  \N  2025-12-08 23:22:49.586+00  2025-12-08 23:22:49.586+00
1203    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1300    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1381    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1472    60  []  \N  2025-12-08 23:22:49.761+00  2025-12-08 23:22:49.761+00
1757    83  []  \N  2026-01-13 21:09:21.412+00  2026-01-13 21:09:21.412+00
1931    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
2035    83  []  \N  2026-01-13 21:09:21.626+00  2026-01-13 21:09:21.626+00
2135    83  []  \N  2026-01-13 21:09:21.769+00  2026-01-13 21:09:21.769+00
2224    83  []  \N  2026-01-13 21:09:21.882+00  2026-01-13 21:09:21.882+00
2329    83  []  \N  2026-01-13 21:09:21.977+00  2026-01-13 21:09:21.977+00
2434    83  []  \N  2026-01-13 21:09:22.054+00  2026-01-13 21:09:22.054+00
3120    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3219    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3312    135 []  \N  2026-02-04 03:31:34.347+00  2026-02-04 03:31:34.347+00
3418    135 []  \N  2026-02-04 03:31:34.463+00  2026-02-04 03:31:34.463+00
3524    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
693 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
793 60  []  \N  2025-12-08 23:22:49.394+00  2025-12-08 23:22:49.394+00
892 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
992 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1092    60  []  \N  2025-12-08 23:22:49.586+00  2025-12-08 23:22:49.586+00
1200    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1292    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1384    60  []  \N  2025-12-08 23:22:49.722+00  2025-12-08 23:22:49.722+00
1505    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
1784    83  []  \N  2026-01-13 21:09:21.412+00  2026-01-13 21:09:21.412+00
1935    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2031    83  []  \N  2026-01-13 21:09:21.625+00  2026-01-13 21:09:21.625+00
2131    83  []  \N  2026-01-13 21:09:21.761+00  2026-01-13 21:09:21.761+00
2265    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2365    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2460    83  []  \N  2026-01-13 21:09:22.102+00  2026-01-13 21:09:22.102+00
3121    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3223    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3313    135 []  \N  2026-02-04 03:31:34.347+00  2026-02-04 03:31:34.347+00
3434    135 []  \N  2026-02-04 03:31:34.477+00  2026-02-04 03:31:34.477+00
3538    135 []  \N  2026-02-04 03:31:34.564+00  2026-02-04 03:31:34.564+00
694 60  []  \N  2025-12-08 23:22:49.294+00  2025-12-08 23:22:49.294+00
794 60  []  \N  2025-12-08 23:22:49.394+00  2025-12-08 23:22:49.394+00
891 60  []  \N  2025-12-08 23:22:49.468+00  2025-12-08 23:22:49.468+00
1000    60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1099    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1193    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1243    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1326    60  []  \N  2025-12-08 23:22:49.683+00  2025-12-08 23:22:49.683+00
1397    60  []  \N  2025-12-08 23:22:49.729+00  2025-12-08 23:22:49.729+00
1484    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
1932    83  []  \N  2026-01-13 21:09:21.532+00  2026-01-13 21:09:21.532+00
2032    83  []  \N  2026-01-13 21:09:21.625+00  2026-01-13 21:09:21.625+00
2132    83  []  \N  2026-01-13 21:09:21.761+00  2026-01-13 21:09:21.761+00
2266    83  []  \N  2026-01-13 21:09:21.826+00  2026-01-13 21:09:21.826+00
2372    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2472    83  []  \N  2026-01-13 21:09:22.106+00  2026-01-13 21:09:22.106+00
3122    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3205    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3296    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3408    135 []  \N  2026-02-04 03:31:34.462+00  2026-02-04 03:31:34.462+00
3507    135 []  \N  2026-02-04 03:31:34.551+00  2026-02-04 03:31:34.551+00
695 60  []  \N  2025-12-08 23:22:49.295+00  2025-12-08 23:22:49.295+00
798 60  []  \N  2025-12-08 23:22:49.394+00  2025-12-08 23:22:49.394+00
903 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1004    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1103    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1197    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1288    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1365    60  []  \N  2025-12-08 23:22:49.722+00  2025-12-08 23:22:49.722+00
1426    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1936    83  []  \N  2026-01-13 21:09:21.559+00  2026-01-13 21:09:21.559+00
2037    83  []  \N  2026-01-13 21:09:21.626+00  2026-01-13 21:09:21.626+00
2166    83  []  \N  2026-01-13 21:09:21.802+00  2026-01-13 21:09:21.802+00
2246    83  []  \N  2026-01-13 21:09:21.902+00  2026-01-13 21:09:21.902+00
2359    83  []  \N  2026-01-13 21:09:21.979+00  2026-01-13 21:09:21.979+00
2462    83  []  \N  2026-01-13 21:09:22.055+00  2026-01-13 21:09:22.055+00
3123    135 []  \N  2026-02-04 03:31:34.05+00   2026-02-04 03:31:34.05+00
3204    135 []  \N  2026-02-04 03:31:34.181+00  2026-02-04 03:31:34.181+00
3294    135 []  \N  2026-02-04 03:31:34.346+00  2026-02-04 03:31:34.346+00
3396    135 []  \N  2026-02-04 03:31:34.431+00  2026-02-04 03:31:34.431+00
3500    135 []  \N  2026-02-04 03:31:34.55+00   2026-02-04 03:31:34.55+00
696 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
796 60  []  \N  2025-12-08 23:22:49.394+00  2025-12-08 23:22:49.394+00
900 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1001    60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1101    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1195    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1286    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1363    60  []  \N  2025-12-08 23:22:49.705+00  2025-12-08 23:22:49.705+00
1421    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1520    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
2492    86  []  \N  2026-01-20 19:26:52.399+00  2026-01-20 19:26:52.399+00
2573    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2642    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2736    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2831    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2926    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
697 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
802 60  []  \N  2025-12-08 23:22:49.396+00  2025-12-08 23:22:49.396+00
899 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
998 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1097    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1185    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1244    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1327    60  []  \N  2025-12-08 23:22:49.683+00  2025-12-08 23:22:49.683+00
1398    60  []  \N  2025-12-08 23:22:49.729+00  2025-12-08 23:22:49.729+00
1485    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
2493    86  []  \N  2026-01-20 19:26:52.4+00    2026-01-20 19:26:52.4+00
2603    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2697    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2789    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2886    86  []  \N  2026-01-20 19:26:52.997+00  2026-01-20 19:26:52.997+00
698 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
803 60  []  \N  2025-12-08 23:22:49.396+00  2025-12-08 23:22:49.396+00
905 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1003    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1102    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1194    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1287    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1364    60  []  \N  2025-12-08 23:22:49.705+00  2025-12-08 23:22:49.705+00
1423    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1523    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
2494    86  []  \N  2026-01-20 19:26:52.4+00    2026-01-20 19:26:52.4+00
2574    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2643    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2739    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2835    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2938    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
699 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
797 60  []  \N  2025-12-08 23:22:49.395+00  2025-12-08 23:22:49.395+00
895 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
996 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1107    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1204    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1306    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1437    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1529    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
2495    86  []  \N  2026-01-20 19:26:52.4+00    2026-01-20 19:26:52.4+00
2570    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2644    86  []  \N  2026-01-20 19:26:52.843+00  2026-01-20 19:26:52.843+00
2737    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2834    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2923    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
700 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
799 60  []  \N  2025-12-08 23:22:49.395+00  2025-12-08 23:22:49.395+00
896 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
999 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1095    60  []  \N  2025-12-08 23:22:49.586+00  2025-12-08 23:22:49.586+00
1191    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1242    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1325    60  []  \N  2025-12-08 23:22:49.683+00  2025-12-08 23:22:49.683+00
1396    60  []  \N  2025-12-08 23:22:49.729+00  2025-12-08 23:22:49.729+00
1483    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
2496    86  []  \N  2026-01-20 19:26:52.4+00    2026-01-20 19:26:52.4+00
2600    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2696    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2794    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2887    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
701 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
800 60  []  \N  2025-12-08 23:22:49.396+00  2025-12-08 23:22:49.396+00
897 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
991 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1091    60  []  \N  2025-12-08 23:22:49.586+00  2025-12-08 23:22:49.586+00
1205    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1309    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1454    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
2497    86  []  \N  2026-01-20 19:26:52.4+00    2026-01-20 19:26:52.4+00
2572    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2645    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2741    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2836    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2934    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
702 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
795 60  []  \N  2025-12-08 23:22:49.395+00  2025-12-08 23:22:49.395+00
909 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1008    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1108    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1208    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1307    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1445    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
2498    86  []  \N  2026-01-20 19:26:52.4+00    2026-01-20 19:26:52.4+00
2602    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2695    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2793    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2889    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2981    86  []  \N  2026-01-20 19:26:53.047+00  2026-01-20 19:26:53.047+00
703 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
801 60  []  \N  2025-12-08 23:22:49.396+00  2025-12-08 23:22:49.396+00
898 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
997 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1098    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1192    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1241    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1324    60  []  \N  2025-12-08 23:22:49.683+00  2025-12-08 23:22:49.683+00
1394    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1480    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
2499    86  []  \N  2026-01-20 19:26:52.4+00    2026-01-20 19:26:52.4+00
2571    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2646    86  []  \N  2026-01-20 19:26:52.843+00  2026-01-20 19:26:52.843+00
2738    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2832    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2924    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
704 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
805 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
901 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
995 60  []  \N  2025-12-08 23:22:49.537+00  2025-12-08 23:22:49.537+00
1096    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1186    60  []  \N  2025-12-08 23:22:49.637+00  2025-12-08 23:22:49.637+00
1240    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1315    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1386    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1473    60  []  \N  2025-12-08 23:22:49.762+00  2025-12-08 23:22:49.762+00
2500    86  []  \N  2026-01-20 19:26:52.4+00    2026-01-20 19:26:52.4+00
2592    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2652    86  []  \N  2026-01-20 19:26:52.843+00  2026-01-20 19:26:52.843+00
2744    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2843    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2937    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
705 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
808 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
908 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1007    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1106    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1201    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1299    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1380    60  []  \N  2025-12-08 23:22:49.723+00  2025-12-08 23:22:49.723+00
1508    60  []  \N  2025-12-08 23:22:49.798+00  2025-12-08 23:22:49.798+00
2501    86  []  \N  2026-01-20 19:26:52.402+00  2026-01-20 19:26:52.402+00
2597    86  []  \N  2026-01-20 19:26:52.762+00  2026-01-20 19:26:52.762+00
2691    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2784    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2869    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2958    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
706 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
806 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
904 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1005    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1104    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1198    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1290    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1366    60  []  \N  2025-12-08 23:22:49.722+00  2025-12-08 23:22:49.722+00
1428    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
2491    86  []  \N  2026-01-20 19:26:52.399+00  2026-01-20 19:26:52.399+00
2605    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2693    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2785    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2875    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2971    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
707 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
804 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
911 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1010    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1109    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1280    60  []  \N  2025-12-08 23:22:49.659+00  2025-12-08 23:22:49.659+00
1453    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
2502    86  []  \N  2026-01-20 19:26:52.402+00  2026-01-20 19:26:52.402+00
2599    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2699    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2796    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2893    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2980    86  []  \N  2026-01-20 19:26:53.047+00  2026-01-20 19:26:53.047+00
708 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
809 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
906 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1002    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1100    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1196    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1251    60  []  \N  2025-12-08 23:22:49.662+00  2025-12-08 23:22:49.662+00
1347    60  []  \N  2025-12-08 23:22:49.704+00  2025-12-08 23:22:49.704+00
1425    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
2503    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2601    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2698    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2797    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2890    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
710 60  []  \N  2025-12-08 23:22:49.305+00  2025-12-08 23:22:49.305+00
810 60  []  \N  2025-12-08 23:22:49.409+00  2025-12-08 23:22:49.409+00
907 60  []  \N  2025-12-08 23:22:49.487+00  2025-12-08 23:22:49.487+00
1006    60  []  \N  2025-12-08 23:22:49.538+00  2025-12-08 23:22:49.538+00
1105    60  []  \N  2025-12-08 23:22:49.587+00  2025-12-08 23:22:49.587+00
1199    60  []  \N  2025-12-08 23:22:49.638+00  2025-12-08 23:22:49.638+00
1289    60  []  \N  2025-12-08 23:22:49.682+00  2025-12-08 23:22:49.682+00
1367    60  []  \N  2025-12-08 23:22:49.722+00  2025-12-08 23:22:49.722+00
1429    60  []  \N  2025-12-08 23:22:49.757+00  2025-12-08 23:22:49.757+00
1524    60  []  \N  2025-12-08 23:22:49.799+00  2025-12-08 23:22:49.799+00
2504    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2595    86  []  \N  2026-01-20 19:26:52.762+00  2026-01-20 19:26:52.762+00
2648    86  []  \N  2026-01-20 19:26:52.843+00  2026-01-20 19:26:52.843+00
2746    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2842    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2939    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2505    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2598    86  []  \N  2026-01-20 19:26:52.762+00  2026-01-20 19:26:52.762+00
2690    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2787    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2879    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2963    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2506    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2596    86  []  \N  2026-01-20 19:26:52.762+00  2026-01-20 19:26:52.762+00
2692    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2791    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2894    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2507    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2594    86  []  \N  2026-01-20 19:26:52.762+00  2026-01-20 19:26:52.762+00
2683    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2779    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2874    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2962    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2508    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2593    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2651    86  []  \N  2026-01-20 19:26:52.843+00  2026-01-20 19:26:52.843+00
2743    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2838    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2936    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2509    86  []  \N  2026-01-20 19:26:52.4+00    2026-01-20 19:26:52.4+00
2604    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2694    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2800    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2891    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2982    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2510    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2606    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2701    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2790    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2885    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2511    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2636    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2731    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2824    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2916    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2512    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2615    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2706    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2809    86  []  \N  2026-01-20 19:26:52.939+00  2026-01-20 19:26:52.939+00
2910    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2513    86  []  \N  2026-01-20 19:26:52.55+00   2026-01-20 19:26:52.55+00
2611    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2709    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2808    86  []  \N  2026-01-20 19:26:52.939+00  2026-01-20 19:26:52.939+00
2903    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2514    86  []  \N  2026-01-20 19:26:52.55+00   2026-01-20 19:26:52.55+00
2702    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2802    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2902    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2515    86  []  \N  2026-01-20 19:26:52.55+00   2026-01-20 19:26:52.55+00
2639    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2728    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2816    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2904    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2516    86  []  \N  2026-01-20 19:26:52.55+00   2026-01-20 19:26:52.55+00
2638    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2729    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2814    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2905    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2517    86  []  \N  2026-01-20 19:26:52.55+00   2026-01-20 19:26:52.55+00
2633    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2725    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2818    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2918    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2518    86  []  \N  2026-01-20 19:26:52.551+00  2026-01-20 19:26:52.551+00
2624    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2723    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2826    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2927    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2519    86  []  \N  2026-01-20 19:26:52.551+00  2026-01-20 19:26:52.551+00
2610    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2704    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2798    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2900    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2520    86  []  \N  2026-01-20 19:26:52.55+00   2026-01-20 19:26:52.55+00
2623    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2726    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2820    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2915    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2521    86  []  \N  2026-01-20 19:26:52.551+00  2026-01-20 19:26:52.551+00
2609    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2708    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2801    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2898    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2522    86  []  \N  2026-01-20 19:26:52.55+00   2026-01-20 19:26:52.55+00
2627    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2716    86  []  \N  2026-01-20 19:26:52.909+00  2026-01-20 19:26:52.909+00
2825    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2914    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2523    86  []  \N  2026-01-20 19:26:52.55+00   2026-01-20 19:26:52.55+00
2630    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2720    86  []  \N  2026-01-20 19:26:52.909+00  2026-01-20 19:26:52.909+00
2811    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2909    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2524    86  []  \N  2026-01-20 19:26:52.562+00  2026-01-20 19:26:52.562+00
2626    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2718    86  []  \N  2026-01-20 19:26:52.909+00  2026-01-20 19:26:52.909+00
2822    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2913    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2525    86  []  \N  2026-01-20 19:26:52.563+00  2026-01-20 19:26:52.563+00
2625    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2714    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2810    86  []  \N  2026-01-20 19:26:52.939+00  2026-01-20 19:26:52.939+00
2911    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2526    86  []  \N  2026-01-20 19:26:52.549+00  2026-01-20 19:26:52.549+00
2629    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2722    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2813    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2907    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2527    86  []  \N  2026-01-20 19:26:52.55+00   2026-01-20 19:26:52.55+00
2631    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2734    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2812    86  []  \N  2026-01-20 19:26:52.939+00  2026-01-20 19:26:52.939+00
2912    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2528    86  []  \N  2026-01-20 19:26:52.561+00  2026-01-20 19:26:52.561+00
2632    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2724    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2819    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2917    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2529    86  []  \N  2026-01-20 19:26:52.404+00  2026-01-20 19:26:52.404+00
2614    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2707    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2807    86  []  \N  2026-01-20 19:26:52.939+00  2026-01-20 19:26:52.939+00
2906    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2530    86  []  \N  2026-01-20 19:26:52.549+00  2026-01-20 19:26:52.549+00
2637    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2732    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2817    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2921    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2531    86  []  \N  2026-01-20 19:26:52.562+00  2026-01-20 19:26:52.562+00
2613    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2703    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2795    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2899    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2532    86  []  \N  2026-01-20 19:26:52.549+00  2026-01-20 19:26:52.549+00
2628    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2715    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2829    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2935    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2533    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2635    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2727    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2821    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2919    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2534    86  []  \N  2026-01-20 19:26:52.563+00  2026-01-20 19:26:52.563+00
2607    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2711    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2803    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2901    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2535    86  []  \N  2026-01-20 19:26:52.563+00  2026-01-20 19:26:52.563+00
2608    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2710    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2805    86  []  \N  2026-01-20 19:26:52.939+00  2026-01-20 19:26:52.939+00
2897    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2536    86  []  \N  2026-01-20 19:26:52.563+00  2026-01-20 19:26:52.563+00
2616    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2700    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2799    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2888    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2537    86  []  \N  2026-01-20 19:26:52.562+00  2026-01-20 19:26:52.562+00
2622    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2719    86  []  \N  2026-01-20 19:26:52.909+00  2026-01-20 19:26:52.909+00
2827    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2925    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2538    86  []  \N  2026-01-20 19:26:52.562+00  2026-01-20 19:26:52.562+00
2612    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2705    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2792    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2895    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2539    86  []  \N  2026-01-20 19:26:52.403+00  2026-01-20 19:26:52.403+00
2634    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2733    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2828    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2928    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2540    86  []  \N  2026-01-20 19:26:52.563+00  2026-01-20 19:26:52.563+00
2640    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2730    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2892    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2983    86  []  \N  2026-01-20 19:26:53.047+00  2026-01-20 19:26:53.047+00
2541    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2619    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2735    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2830    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2933    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2542    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2618    86  []  \N  2026-01-20 19:26:52.778+00  2026-01-20 19:26:52.778+00
2712    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2806    86  []  \N  2026-01-20 19:26:52.939+00  2026-01-20 19:26:52.939+00
2896    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2543    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2621    86  []  \N  2026-01-20 19:26:52.794+00  2026-01-20 19:26:52.794+00
2717    86  []  \N  2026-01-20 19:26:52.909+00  2026-01-20 19:26:52.909+00
2823    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2920    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2544    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2620    86  []  \N  2026-01-20 19:26:52.778+00  2026-01-20 19:26:52.778+00
2721    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2815    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2908    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2545    86  []  \N  2026-01-20 19:26:52.564+00  2026-01-20 19:26:52.564+00
2617    86  []  \N  2026-01-20 19:26:52.763+00  2026-01-20 19:26:52.763+00
2713    86  []  \N  2026-01-20 19:26:52.892+00  2026-01-20 19:26:52.892+00
2804    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2884    86  []  \N  2026-01-20 19:26:52.998+00  2026-01-20 19:26:52.998+00
2979    86  []  \N  2026-01-20 19:26:53.047+00  2026-01-20 19:26:53.047+00
2546    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2641    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2742    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2840    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2931    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2547    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2682    86  []  \N  2026-01-20 19:26:52.864+00  2026-01-20 19:26:52.864+00
2778    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2876    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2969    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2548    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2678    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2770    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2868    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2959    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2549    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2680    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2775    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2863    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2964    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2550    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2674    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2766    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2854    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2946    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2551    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2688    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2782    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2870    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2952    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2552    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2685    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2786    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2877    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2965    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2553    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2689    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2788    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2878    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2953    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2554    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2675    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2772    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2880    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2966    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2555    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2673    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2769    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2883    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2968    86  []  \N  2026-01-20 19:26:53.047+00  2026-01-20 19:26:53.047+00
2556    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2686    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2780    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2872    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2951    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2557    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2662    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2755    86  []  \N  2026-01-20 19:26:52.931+00  2026-01-20 19:26:52.931+00
2852    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2944    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2558    86  []  \N  2026-01-20 19:26:52.679+00  2026-01-20 19:26:52.679+00
2679    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2776    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2881    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2954    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2559    86  []  \N  2026-01-20 19:26:52.679+00  2026-01-20 19:26:52.679+00
2669    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2763    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2855    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2956    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2560    86  []  \N  2026-01-20 19:26:52.679+00  2026-01-20 19:26:52.679+00
2665    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2757    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2851    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2947    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2561    86  []  \N  2026-01-20 19:26:52.679+00  2026-01-20 19:26:52.679+00
2667    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2765    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2856    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2978    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2562    86  []  \N  2026-01-20 19:26:52.679+00  2026-01-20 19:26:52.679+00
2650    86  []  \N  2026-01-20 19:26:52.843+00  2026-01-20 19:26:52.843+00
2748    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2844    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2940    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2563    86  []  \N  2026-01-20 19:26:52.716+00  2026-01-20 19:26:52.716+00
2666    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2759    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2847    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2943    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2564    86  []  \N  2026-01-20 19:26:52.716+00  2026-01-20 19:26:52.716+00
2656    86  []  \N  2026-01-20 19:26:52.844+00  2026-01-20 19:26:52.844+00
2753    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2860    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2975    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2565    86  []  \N  2026-01-20 19:26:52.716+00  2026-01-20 19:26:52.716+00
2659    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2760    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2849    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2949    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2566    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2670    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2764    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2861    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2973    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2567    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2647    86  []  \N  2026-01-20 19:26:52.843+00  2026-01-20 19:26:52.843+00
2740    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2833    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2922    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2568    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2677    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2771    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2866    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2960    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2569    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2654    86  []  \N  2026-01-20 19:26:52.843+00  2026-01-20 19:26:52.843+00
2752    86  []  \N  2026-01-20 19:26:52.931+00  2026-01-20 19:26:52.931+00
2846    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2942    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2575    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2777    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2865    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2970    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2576    86  []  \N  2026-01-20 19:26:52.716+00  2026-01-20 19:26:52.716+00
2668    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2762    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2859    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2974    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2577    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2657    86  []  \N  2026-01-20 19:26:52.862+00  2026-01-20 19:26:52.862+00
2751    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2848    86  []  \N  2026-01-20 19:26:52.964+00  2026-01-20 19:26:52.964+00
2578    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2661    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2754    86  []  \N  2026-01-20 19:26:52.931+00  2026-01-20 19:26:52.931+00
2858    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2976    86  []  \N  2026-01-20 19:26:53.047+00  2026-01-20 19:26:53.047+00
2579    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2653    86  []  \N  2026-01-20 19:26:52.843+00  2026-01-20 19:26:52.843+00
2747    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2845    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2929    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2984    86  []  \N  2026-01-20 19:26:52.818+00  2026-01-20 19:26:52.818+00
2985    86  []  \N  2026-01-20 19:26:52.938+00  2026-01-20 19:26:52.938+00
2986    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2580    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2672    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2767    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2867    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2961    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2581    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2649    86  []  \N  2026-01-20 19:26:52.843+00  2026-01-20 19:26:52.843+00
2745    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2841    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2932    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2582    86  []  \N  2026-01-20 19:26:52.716+00  2026-01-20 19:26:52.716+00
2658    86  []  \N  2026-01-20 19:26:52.862+00  2026-01-20 19:26:52.862+00
2749    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2839    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2941    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2583    86  []  \N  2026-01-20 19:26:52.716+00  2026-01-20 19:26:52.716+00
2663    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2758    86  []  \N  2026-01-20 19:26:52.931+00  2026-01-20 19:26:52.931+00
2850    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2945    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2584    86  []  \N  2026-01-20 19:26:52.716+00  2026-01-20 19:26:52.716+00
2671    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2768    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2882    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2977    86  []  \N  2026-01-20 19:26:53.047+00  2026-01-20 19:26:53.047+00
2585    86  []  \N  2026-01-20 19:26:52.679+00  2026-01-20 19:26:52.679+00
2684    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2781    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2871    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2955    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2586    86  []  \N  2026-01-20 19:26:52.679+00  2026-01-20 19:26:52.679+00
2676    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2773    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2862    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2967    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2587    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2664    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2756    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2853    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2948    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2588    86  []  \N  2026-01-20 19:26:52.678+00  2026-01-20 19:26:52.678+00
2660    86  []  \N  2026-01-20 19:26:52.863+00  2026-01-20 19:26:52.863+00
2761    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2857    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2950    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2589    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2655    86  []  \N  2026-01-20 19:26:52.862+00  2026-01-20 19:26:52.862+00
2750    86  []  \N  2026-01-20 19:26:52.91+00   2026-01-20 19:26:52.91+00
2837    86  []  \N  2026-01-20 19:26:52.963+00  2026-01-20 19:26:52.963+00
2930    86  []  \N  2026-01-20 19:26:53.027+00  2026-01-20 19:26:53.027+00
2590    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2681    86  []  \N  2026-01-20 19:26:52.864+00  2026-01-20 19:26:52.864+00
2774    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2864    86  []  \N  2026-01-20 19:26:52.994+00  2026-01-20 19:26:52.994+00
2972    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
2591    86  []  \N  2026-01-20 19:26:52.717+00  2026-01-20 19:26:52.717+00
2687    86  []  \N  2026-01-20 19:26:52.891+00  2026-01-20 19:26:52.891+00
2783    86  []  \N  2026-01-20 19:26:52.932+00  2026-01-20 19:26:52.932+00
2873    86  []  \N  2026-01-20 19:26:52.995+00  2026-01-20 19:26:52.995+00
2957    86  []  \N  2026-01-20 19:26:53.046+00  2026-01-20 19:26:53.046+00
120 53  []  \N  2025-11-26 17:19:25.441+00  2025-11-26 17:19:25.441+00
\.


--
-- Data for Name: CampaignSettings; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."CampaignSettings" (id, key, value, "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignShipping; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."CampaignShipping" (id, "jobId", number, message, "confirmationMessage", confirmation, "contactId", "campaignId", "confirmationRequestedAt", "confirmedAt", "deliveredAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Campaigns; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Campaigns" (id, name, message1, message2, message3, message4, message5, "confirmationMessage1", "confirmationMessage2", "confirmationMessage3", "confirmationMessage4", "confirmationMessage5", status, confirmation, "mediaPath", "mediaName", "companyId", "contactListId", "whatsappId", "scheduledAt", "completedAt", "createdAt", "updatedAt", "userId", "queueId", "statusTicket", "openTicket") FROM stdin;
\.


--
-- Data for Name: ChatMessages; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."ChatMessages" (id, "chatId", "senderId", message, "mediaPath", "mediaName", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ChatUsers; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."ChatUsers" (id, "chatId", "userId", unreads, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Chatbots; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Chatbots" (id, name, "queueId", "chatbotId", "greetingMessage", "createdAt", "updatedAt", "isAgent", "optQueueId", "optUserId", "queueType", "optIntegrationId", "optFileId", "closeTicket") FROM stdin;
\.


--
-- Data for Name: Chats; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Chats" (id, title, uuid, "ownerId", "lastMessage", "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Companies; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Companies" (id, name, phone, email, "createdAt", "updatedAt", "planId", status, schedules, "dueDate", recurrence, document, "paymentMethod", "lastLogin", "folderSize", "numberFileFolder", "updatedAtFolder", type, segment, "loadingImage") FROM stdin;
1   Empresa Admin - Não Deletar \N  \N  2025-10-10 02:50:00.266+00  2026-02-06 21:31:24.366+00  1   t   []  2099-12-31 03:00:00+00              2026-02-06 21:31:24.366+00  \N  \N  \N  pf  outros  \N
\.


--
-- Data for Name: CompaniesSettings; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."CompaniesSettings" (id, "companyId", "hoursCloseTicketsAuto", "chatBotType", "acceptCallWhatsapp", "userRandom", "sendGreetingMessageOneQueues", "sendSignMessage", "sendFarewellWaitingTicket", "userRating", "sendGreetingAccepted", "CheckMsgIsGroup", "sendQueuePosition", "scheduleType", "acceptAudioMessageContact", "enableLGPD", "sendMsgTransfTicket", "requiredTag", "lgpdDeleteMessage", "lgpdHideNumber", "lgpdConsent", "lgpdLink", "lgpdMessage", "createdAt", "updatedAt", "DirectTicketsToWallets", "closeTicketOnTransfer", "greetingAcceptedMessage", "AcceptCallWhatsappMessage", "sendQueuePositionMessage", "transferMessage", "showNotificationPending", "notificameHub", "autoSaveContacts", "autoSaveContactsScore", "autoSaveContactsReason") FROM stdin;
1   1   9999999999  text    enabled enabled enabled enabled disabled    disabled    enabled enabled enabled disabled    enabled disabled    enabled disabled    disabled    disabled    disabled            2025-10-10 02:50:00.34+00   2026-01-25 00:12:15.718+00  f   f                   f       enabled 7   message_analysis
\.


--
-- Data for Name: ContactCustomFields; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."ContactCustomFields" (id, name, value, "contactId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ContactGroups; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."ContactGroups" (id, "createdAt", "updatedAt", "contactId", "companyId", "userId") FROM stdin;
\.


--
-- Data for Name: ContactListItems; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."ContactListItems" (id, name, number, email, "contactListId", "isWhatsappValid", "companyId", "createdAt", "updatedAt", "isGroup") FROM stdin;
\.


--
-- Data for Name: ContactLists; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."ContactLists" (id, name, "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ContactTags; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."ContactTags" ("contactId", "tagId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ContactWallets; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."ContactWallets" (id, "walletId", "contactId", "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Contacts; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Contacts" (id, name, number, "profilePicUrl", "createdAt", "updatedAt", email, "isGroup", "companyId", "acceptAudioMessage", channel, active, "disableBot", "remoteJid", "lgpdAcceptedAt", "urlPicture", "pictureUpdated", "whatsappId", "isLid", birthday, anniversary, info, files, "cpfCnpj", address, lid, "savedToPhone", "savedToPhoneAt", "savedToPhoneReason", "potentialScore", "isPotential", "lidStability") FROM stdin;
2100    Rafael Silva    lid-24908420808828706   https://platform-lookaside.fbsbx.com/platform/profilepic/?eai=Aa28sU8KQn-3KcQC7vIKqM3xv4DXdoBYn-07Y0GrGMAEqO0QuNG7H2Ux2Bsr2NVnyJmQjw_rlnUH&psid=24908420808828706&width=1024&ext=1770915579&hash=AT8D1mZssusy43g8AAu28tKt   2026-01-13 16:59:39.754+00  2026-01-13 16:59:40.071+00      f   1   t   facebook    t   f   lid-24908420808828706@s.whatsapp.net    \N  1768323580071.jpeg  t   \N  f   \N  \N  \N  \N  \N  \N  \N  f   \N  \N  0   f   unknown
2068    StackLab - Soluções Digitais    363337449922588 https://app.faedeveloper.com.br/nopicture.png   2026-01-12 12:54:13.281+00  2026-01-12 12:54:13.281+00      t   1   t   whatsapp    t   f   120363337449922588@g.us \N      f   \N  f   \N  \N  \N  \N  \N  \N  120363337449922588  f   \N  \N  0   f   unknown
2042    Desenvolvimento sistema de entregas sob demanda     363375001630421 https://app.faedeveloper.com.br/nopicture.png   2026-01-09 17:33:13.088+00  2026-01-10 13:11:55.432+00      t   1   t   whatsapp    t   f   120363375001630421@g.us \N      f   \N  f   \N  \N  \N  \N  \N  \N  120363375001630421  f   \N  \N  0   f   unknown
2052    Rascunho    071231617917053 https://app.faedeveloper.com.br/nopicture.png   2026-01-09 22:32:36.067+00  2026-01-10 03:29:53.394+00      t   1   t   whatsapp    t   f   5524993207123-1617917053@g.us   \N      f   \N  f   \N  \N  \N  \N  \N  \N  55249932071231617917053 f   \N  \N  0   f   unknown
\.


--
-- Data for Name: DialogChatBots; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."DialogChatBots" (id, awaiting, "contactId", "chatbotId", "createdAt", "updatedAt", "queueId") FROM stdin;
\.


--
-- Data for Name: Faturas; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Faturas" (id, "companyId", "contactId", valor, descricao, status, "dataCriacao", "dataVencimento", "dataPagamento", recorrente, intervalo, "proximaCobranca", "limiteRecorrencias", "recorrenciasRealizadas", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Ferramentas; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Ferramentas" (id, nome, descricao, url, metodo, headers, body, query_params, placeholders, status, "createdAt", "updatedAt", "companyId") FROM stdin;
7   VerificarCep    Consulta CEP usando a API ViaCEP.\n\nUse com a função execute_tool:\n- ferramentaNome: "ConsultaCEP"\n- cep: string com 8 dígitos numéricos (sem traço).\n\nExemplo correto:\n{\n  "ferramentaNome": "ConsultaCEP",\n  "cep": "27537284"\n}\n\nA URL usa o placeholder {{cep}}: https://viacep.com.br/ws/{{cep}}/json/\nCampos relevantes da resposta:\n- logradouro\n- bairro\n- localidade\n- uf\n- cep   https://viacep.com.br/ws/{{cep}}/json/  GET {}  {}  {}  {}  ativo   2025-11-18 01:52:05.656 2025-11-18 01:52:05.656 \N
15  CEP Você é um assistente de atendimento no WhatsApp.\n\nFluxo obrigatório para consulta de CEP:\n\n1. Sempre que o usuário demonstrar interesse em saber endereço, rua, bairro, cidade ou informações por CEP, faça a seguinte pergunta:\n   "Por favor, me informe o CEP (somente números) para que eu possa consultar o endereço."\n\n2. Aguarde o usuário responder com um CEP válido de 8 dígitos (exemplo: 01001000).\n   - Ignore pontos, traços ou espaços.\n   - Se o CEP tiver menos ou mais de 8 números, peça novamente educadamente.\n\n3. Quando receber um CEP válido, faça uma requisição HTTP GET para a seguinte API:\n   https://viacep.com.br/ws/{CEP}/json/\n\n4. Analise a resposta da API:\n   - Se o campo "erro" existir ou estiver como true, responda:\n     "Não encontrei informações para esse CEP. Poderia conferir se está correto?"\n\n5. Se a resposta for válida, retorne ao usuário as informações formatadas da seguinte forma:\n\n   📍 *Endereço encontrado*\n   • Rua: {logradouro}\n   • Bairro: {bairro}\n   • Cidade: {localidade}\n   • Estado: {uf}\n   • CEP: {cep}\n\n6. Após responder, pergunte:\n   "Posso te ajudar com mais alguma coisa?"\n\n7. Não invente dados. Use exclusivamente as informações retornadas pela API.\n  https://viacep.com.br/ws/{{cep}}/json/?callback=callback_name   GET {}  {}  {}  {}  ativo   2026-02-05 23:50:08.088 2026-02-05 23:50:08.088 1
\.


--
-- Data for Name: Files; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Files" (id, "companyId", name, message, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FilesOptions; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."FilesOptions" (id, name, path, "fileId", "createdAt", "updatedAt", "mediaType") FROM stdin;
\.


--
-- Data for Name: FlowAudios; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."FlowAudios" (id, "companyId", "userId", name, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FlowBuilders; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."FlowBuilders" (id, user_id, name, active, flow, "createdAt", "updatedAt", company_id, variables) FROM stdin;
2   2   vxv t   \N  2025-10-10 05:11:31.309+00  2025-10-10 05:11:31.309+00  2   \N
6   13  teste   t   \N  2025-10-20 03:12:14.174+00  2025-10-20 03:12:14.174+00  9   \N
5   3   teste   t   {"nodes":[{"id":"1","position":{"x":-40,"y":36.5},"data":{"label":"Inicio do fluxo"},"type":"start","width":280,"height":228,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"},"positionAbsolute":{"x":-40,"y":36.5},"dragging":false},{"id":"PnlN8cEYX36WJrz99umPq4Yv3dHPab","position":{"x":759.9617700487375,"y":-66.79097164952915},"data":{"message":"Em que posso ajudar?","arrayOption":[{"number":1,"value":"Vendas"},{"number":2,"value":"Financeiro"}]},"type":"menu","width":280,"height":325,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"},"selected":false,"positionAbsolute":{"x":759.9617700487375,"y":-66.79097164952915},"dragging":false},{"id":"tp7j8Cts7sPzmktdPvb7EJMQ14Mx40","position":{"x":224.45352193176734,"y":-230.67079839920854},"data":{"seq":["message0"],"elements":[{"type":"message","value":"{{firstName}}, seja bem vndo ao chatbot","number":"message0"}]},"type":"singleBlock","width":300,"height":228,"selected":false,"positionAbsolute":{"x":224.45352193176734,"y":-230.67079839920854},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"XorWtCD9nR27H04lM5t7b0Anf8kQZG","position":{"x":1169.0497189235225,"y":-102.90008601810257},"data":{"data":{"id":4,"name":"aaaa","color":"#BA0909","greetingMessage":"aaaaaaaaaaa","orderQueue":null,"ativarRoteador":true,"tempoRoteador":2,"outOfHoursMessage":"","schedules":[{"weekday":"Segunda-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"monday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Terça-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"tuesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quarta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"wednesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quinta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"thursday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sexta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"friday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sábado","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"saturday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Domingo","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"sunday","startTimeA":"08:00","startTimeB":"12:01"}],"companyId":3,"integrationId":null,"fileListId":null,"closeTicket":false,"createdAt":"2025-10-21T18:21:04.149Z","updatedAt":"2025-10-21T18:21:04.149Z"}},"type":"ticket","width":280,"height":290,"selected":false,"positionAbsolute":{"x":1169.0497189235225,"y":-102.90008601810257},"dragging":false}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1425","source":"1","sourceHandle":"a","target":"tp7j8Cts7sPzmktdPvb7EJMQ14Mx40","targetHandle":null,"id":"reactflow__edge-1a-tp7j8Cts7sPzmktdPvb7EJMQ14Mx40","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1425","source":"tp7j8Cts7sPzmktdPvb7EJMQ14Mx40","sourceHandle":"a","target":"PnlN8cEYX36WJrz99umPq4Yv3dHPab","targetHandle":null,"id":"reactflow__edge-tp7j8Cts7sPzmktdPvb7EJMQ14Mx40a-PnlN8cEYX36WJrz99umPq4Yv3dHPab","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1425","source":"PnlN8cEYX36WJrz99umPq4Yv3dHPab","sourceHandle":"a1","target":"XorWtCD9nR27H04lM5t7b0Anf8kQZG","targetHandle":null,"id":"reactflow__edge-PnlN8cEYX36WJrz99umPq4Yv3dHPaba1-XorWtCD9nR27H04lM5t7b0Anf8kQZG"},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1425","source":"PnlN8cEYX36WJrz99umPq4Yv3dHPab","sourceHandle":"a2","target":"XorWtCD9nR27H04lM5t7b0Anf8kQZG","targetHandle":null,"id":"reactflow__edge-PnlN8cEYX36WJrz99umPq4Yv3dHPaba2-XorWtCD9nR27H04lM5t7b0Anf8kQZG"}]}    2025-10-11 22:45:37.959+00  2025-10-21 18:27:47.948+00  3   \N
7   3   rapido  t   \N  2025-10-28 21:42:12.109+00  2025-10-28 21:42:12.109+00  3   \N
8   22  Teste   t   \N  2025-11-13 17:09:11.345+00  2025-11-13 17:09:11.345+00  18  \N
9   25  teste   t   \N  2025-11-16 16:14:50.141+00  2025-11-16 16:14:50.141+00  26  \N
10  25  rrr t   \N  2025-11-17 19:38:02.675+00  2025-11-17 19:38:02.675+00  26  \N
11  34  teste   t   \N  2025-11-19 15:40:36.263+00  2025-11-19 15:40:36.263+00  35  \N
12  27  fluxo 01    t   \N  2025-11-19 22:39:52.578+00  2025-11-19 22:39:52.578+00  28  \N
13  39  fer t   \N  2025-11-24 00:31:57.814+00  2025-11-24 00:31:57.814+00  40  \N
14  41  teste   t   \N  2025-11-24 20:14:33.085+00  2025-11-24 20:14:33.085+00  42  \N
15  46  comercial   t   \N  2025-11-26 19:51:44.662+00  2025-11-26 19:51:44.662+00  46  \N
16  43  Jefferson   t   {"nodes":[{"id":"1","position":{"x":250,"y":100},"data":{"label":"Inicio do fluxo"},"type":"start","width":280,"height":229,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"},"selected":false},{"id":"l8EUG2gXHP9cOHS3VEIymgqaqYW8ha","position":{"x":570,"y":100},"data":{"message":"Selecione","arrayOption":[{"number":1,"value":"Fatura"},{"number":2,"value":"Suporte"},{"number":3,"value":"Comercial"}]},"type":"menu","width":280,"height":384,"selected":false,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"}},{"id":"O8pOB61sN5q7WGbUZmsHSlyrGOkrEe","position":{"x":890,"y":100},"data":{"seq":["message0"],"elements":[{"type":"message","value":"Em breve você será atendido aguarde..","number":"message0"}]},"type":"singleBlock","width":300,"height":228,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1178","source":"1","sourceHandle":"a","target":"l8EUG2gXHP9cOHS3VEIymgqaqYW8ha","targetHandle":null,"id":"reactflow__edge-1a-l8EUG2gXHP9cOHS3VEIymgqaqYW8ha","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1178","source":"l8EUG2gXHP9cOHS3VEIymgqaqYW8ha","sourceHandle":"a2","target":"O8pOB61sN5q7WGbUZmsHSlyrGOkrEe","targetHandle":null,"id":"reactflow__edge-l8EUG2gXHP9cOHS3VEIymgqaqYW8haa2-O8pOB61sN5q7WGbUZmsHSlyrGOkrEe","selected":false}]}   2025-11-27 16:38:58.763+00  2025-11-27 16:42:02.427+00  44  \N
19  67  teste   t   {"nodes":[{"id":"1","position":{"x":-377,"y":-175.5},"data":{"label":"Inicio do fluxo"},"type":"start","width":280,"height":229,"selected":false,"positionAbsolute":{"x":-377,"y":-175.5},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"d4TXklDIc0IVgzREZsFYnZHoJP7Kbk","position":{"x":-43,"y":-159},"data":{"seq":["message0"],"elements":[{"type":"message","value":"olá tudo bem?","number":"message0"}]},"type":"singleBlock","width":302,"height":220,"selected":false,"positionAbsolute":{"x":-43,"y":-159},"dragging":false,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"}},{"id":"VPLV48355gJlBSyscRTQiikYU4TQXx","position":{"x":299,"y":-159},"data":{"seq":["interval0"],"elements":[{"type":"interval","value":"02","number":"interval0"}]},"type":"singleBlock","width":300,"height":218}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1430","source":"1","sourceHandle":"a","target":"d4TXklDIc0IVgzREZsFYnZHoJP7Kbk","targetHandle":null,"id":"reactflow__edge-1a-d4TXklDIc0IVgzREZsFYnZHoJP7Kbk","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1430","source":"d4TXklDIc0IVgzREZsFYnZHoJP7Kbk","sourceHandle":"a","target":"VPLV48355gJlBSyscRTQiikYU4TQXx","targetHandle":null,"id":"reactflow__edge-d4TXklDIc0IVgzREZsFYnZHoJP7Kbka-VPLV48355gJlBSyscRTQiikYU4TQXx"}]}    2025-12-12 12:43:58.539+00  2025-12-12 12:45:24.96+00   67  \N
20  59  fda t   \N  2025-12-12 18:52:25.375+00  2025-12-12 18:52:25.375+00  59  \N
21  70  ae  t   {"nodes":[{"id":"1","position":{"x":-361.8000896399266,"y":-191.6525412168405},"data":{"label":"Inicio do fluxo"},"type":"start","width":280,"height":228,"selected":false,"positionAbsolute":{"x":-361.8000896399266,"y":-191.6525412168405},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"DCZKmLWzQrCb8VOpPoHjBVxMOmlJMk","position":{"x":25.05150388409629,"y":-186.9612013204178},"data":{"key":"Nome","condition":1,"value":"Nome"},"type":"condition","width":280,"height":221,"selected":true,"positionAbsolute":{"x":25.05150388409629,"y":-186.9612013204178},"dragging":false,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"}}],"connections":[]}  2025-12-18 19:41:01.712+00  2026-01-02 10:53:42.304+00  70  \N
17  51  TEste   t   \N  2025-11-30 04:03:09.439+00  2025-11-30 04:03:09.439+00  51  \N
18  58  asa t   {"nodes":[{"id":"1","position":{"x":250,"y":100},"data":{"label":"Inicio do fluxo"},"type":"start","width":280,"height":228,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"FaaiFnrGaOjfOOlvsCLaKHNzamnGqu","position":{"x":570,"y":100},"data":{"seq":[],"elements":[]},"type":"singleBlock","width":300,"height":155,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"EhZwzExNM70wpR34HPYLBRZsuUNGiA","position":{"x":694.730516212747,"y":358.9960976815389},"data":{"seq":[],"elements":[]},"type":"singleBlock","width":300,"height":155,"selected":false,"positionAbsolute":{"x":694.730516212747,"y":358.9960976815389},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"OSFmaHxZs3ftUiwcEfUYjazsPpRRLp","position":{"x":1056.3897873270957,"y":494.46069185306567},"data":{"seq":[],"elements":[]},"type":"singleBlock","width":300,"height":155,"selected":false,"positionAbsolute":{"x":1056.3897873270957,"y":494.46069185306567},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"QjkK5UIsCPcoorlN9PAnkiM6ndDba0","position":{"x":1396.3897873270957,"y":494.46069185306567},"data":{"seq":[],"elements":[]},"type":"singleBlock","width":300,"height":155,"selected":false,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"}}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss816","source":"1","sourceHandle":"a","target":"FaaiFnrGaOjfOOlvsCLaKHNzamnGqu","targetHandle":null,"id":"reactflow__edge-1a-FaaiFnrGaOjfOOlvsCLaKHNzamnGqu","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss816","source":"FaaiFnrGaOjfOOlvsCLaKHNzamnGqu","sourceHandle":"a","target":"EhZwzExNM70wpR34HPYLBRZsuUNGiA","targetHandle":null,"id":"reactflow__edge-FaaiFnrGaOjfOOlvsCLaKHNzamnGqua-EhZwzExNM70wpR34HPYLBRZsuUNGiA","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss816","source":"EhZwzExNM70wpR34HPYLBRZsuUNGiA","sourceHandle":"a","target":"OSFmaHxZs3ftUiwcEfUYjazsPpRRLp","targetHandle":null,"id":"reactflow__edge-EhZwzExNM70wpR34HPYLBRZsuUNGiAa-OSFmaHxZs3ftUiwcEfUYjazsPpRRLp","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss816","source":"OSFmaHxZs3ftUiwcEfUYjazsPpRRLp","sourceHandle":"a","target":"QjkK5UIsCPcoorlN9PAnkiM6ndDba0","targetHandle":null,"id":"reactflow__edge-OSFmaHxZs3ftUiwcEfUYjazsPpRRLpa-QjkK5UIsCPcoorlN9PAnkiM6ndDba0"}]}  2025-12-08 01:46:57.614+00  2025-12-08 05:04:37.029+00  58  \N
22  73  dfgggggg    t   \N  2026-01-01 15:56:00.615+00  2026-01-01 15:56:00.615+00  73  \N
53  127 teste   t   {"nodes":[{"id":"1","position":{"x":-192.94299346591214,"y":-196.04507473480248},"data":{"label":"Inicio do fluxo","title":"Início do Fluxo"},"type":"start","width":280,"height":229,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"},"positionAbsolute":{"x":-192.94299346591214,"y":-196.04507473480248},"dragging":false},{"width":302,"height":220,"id":"6D6mb1dsGe5J1407ABSY3oHSr6BzzK","position":{"x":1007.420009263546,"y":117.36493094742585},"data":{"seq":["message0"],"elements":[{"type":"message","value":"{{usuario}}\\n{{senha}}\\n{{link}}","number":"message0"}],"title":"Conteúdo"},"type":"singleBlock","selected":false,"positionAbsolute":{"x":1007.420009263546,"y":117.36493094742585},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"JNAckuzl4wMRQNK7FW3B7lwYCj3mRz","position":{"x":186.01878532860485,"y":-433.43663717830844},"data":{"message":"Menu","arrayOption":[{"number":1,"value":"Teste"}],"title":"Menu"},"type":"menu","width":280,"height":268,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"},"positionAbsolute":{"x":186.01878532860485,"y":-433.43663717830844},"dragging":false},{"id":"NbWilk8p3Sx0QhL5a9X3R0ZDuTN2PQ","position":{"x":583.3972509905343,"y":-71.46033212695544},"data":{"data":{"method":"POST","url":"https://opatv.sigma.vin/api/chatbot/7V01pdM1dO/ZVdWXjL3qk","headers":"","body":"","saveResponse":"api_toptv","savedVariables":[{"path":"usuario","name":"user"},{"path":"senha","name":"senha"},{"path":"link","name":"link"}]},"title":"API Request"},"type":"apiRequest","width":280,"height":306,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"},"positionAbsolute":{"x":583.3972509905343,"y":-71.46033212695544},"dragging":false}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1616","source":"1","sourceHandle":"a","target":"JNAckuzl4wMRQNK7FW3B7lwYCj3mRz","targetHandle":null,"id":"reactflow__edge-1a-JNAckuzl4wMRQNK7FW3B7lwYCj3mRz","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1616","source":"JNAckuzl4wMRQNK7FW3B7lwYCj3mRz","sourceHandle":"a1","target":"NbWilk8p3Sx0QhL5a9X3R0ZDuTN2PQ","targetHandle":null,"id":"reactflow__edge-JNAckuzl4wMRQNK7FW3B7lwYCj3mRza1-NbWilk8p3Sx0QhL5a9X3R0ZDuTN2PQ","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1616","source":"NbWilk8p3Sx0QhL5a9X3R0ZDuTN2PQ","sourceHandle":"a","target":"6D6mb1dsGe5J1407ABSY3oHSr6BzzK","targetHandle":null,"id":"reactflow__edge-NbWilk8p3Sx0QhL5a9X3R0ZDuTN2PQa-6D6mb1dsGe5J1407ABSY3oHSr6BzzK","selected":false}]}    2026-01-30 16:58:27.41+00   2026-01-30 17:08:45.326+00  129 \N
23  74  Atendimento t   \N  2026-01-02 21:05:03.228+00  2026-01-02 21:05:03.228+00  74  \N
24  82  teste   t   \N  2026-01-05 12:13:48.456+00  2026-01-05 12:13:48.456+00  84  \N
26  87  teste   t   {"nodes":[{"id":"1","position":{"x":-91.79408574809474,"y":13.604155708907285},"data":{"label":"Inicio do fluxo","title":"Início do Fluxo"},"type":"start","width":282,"height":231,"selected":false,"positionAbsolute":{"x":-91.79408574809474,"y":13.604155708907285},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"pgVwBtgAmmiQwYBTgPy3GXeylo7giu","position":{"x":228.20591425190526,"y":13.604155708907285},"data":{"message":"Por favor escolha uma das opções","arrayOption":[{"number":1,"value":"Suporte"},{"number":2,"value":"Vendas"}],"title":"Menu"},"type":"menu","width":280,"height":340,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"hQX2e3lkMThxzNsIvsHPhWmd8qTOLR","position":{"x":548.2059142519053,"y":13.604155708907285},"data":{"seq":["message0"],"elements":[{"type":"message","value":"Bem vindo ao suporte","number":"message0"}],"title":"Conteúdo"},"type":"singleBlock","width":300,"height":218,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"dZiKCJg6YUbnYjpY83wps6qU1ivMvX","position":{"x":888.2059142519053,"y":13.604155708907285},"data":{"typebotIntegration":{"message":"Qual seu nome?","answerKey":"nome"},"title":"Pergunta"},"type":"question","width":280,"height":240,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"width":280,"height":240,"id":"97Vo8vDMhApZ0gqlBYgFHt30DUgKsn","position":{"x":1653.6563934851322,"y":39.14664772168683},"data":{"typebotIntegration":{"message":"Qual sua cidade?","answerKey":"cidade"},"title":"Pergunta"},"type":"question","selected":true,"positionAbsolute":{"x":1653.6563934851322,"y":39.14664772168683},"dragging":false,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"}},{"id":"Ei6gqHbfyeTkS2szTGeHXwDy8Cpxzm","position":{"x":1258.4666171273045,"y":90.23163174724593},"data":{"seq":["message0"],"elements":[{"type":"message","value":"ok {{nome}}","number":"message0"}],"title":"Conteúdo"},"type":"singleBlock","width":300,"height":228,"selected":false,"positionAbsolute":{"x":1258.4666171273045,"y":90.23163174724593},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss911","source":"1","sourceHandle":"a","target":"pgVwBtgAmmiQwYBTgPy3GXeylo7giu","targetHandle":null,"id":"reactflow__edge-1a-pgVwBtgAmmiQwYBTgPy3GXeylo7giu","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1650","source":"pgVwBtgAmmiQwYBTgPy3GXeylo7giu","sourceHandle":"a1","target":"hQX2e3lkMThxzNsIvsHPhWmd8qTOLR","targetHandle":null,"id":"reactflow__edge-pgVwBtgAmmiQwYBTgPy3GXeylo7giua1-hQX2e3lkMThxzNsIvsHPhWmd8qTOLR","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1650","source":"hQX2e3lkMThxzNsIvsHPhWmd8qTOLR","sourceHandle":"a","target":"dZiKCJg6YUbnYjpY83wps6qU1ivMvX","targetHandle":null,"id":"reactflow__edge-hQX2e3lkMThxzNsIvsHPhWmd8qTOLRa-dZiKCJg6YUbnYjpY83wps6qU1ivMvX","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss853","source":"dZiKCJg6YUbnYjpY83wps6qU1ivMvX","sourceHandle":"a","target":"Ei6gqHbfyeTkS2szTGeHXwDy8Cpxzm","targetHandle":null,"id":"reactflow__edge-dZiKCJg6YUbnYjpY83wps6qU1ivMvXa-Ei6gqHbfyeTkS2szTGeHXwDy8Cpxzm","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss853","source":"Ei6gqHbfyeTkS2szTGeHXwDy8Cpxzm","sourceHandle":"a","target":"97Vo8vDMhApZ0gqlBYgFHt30DUgKsn","targetHandle":null,"id":"reactflow__edge-Ei6gqHbfyeTkS2szTGeHXwDy8Cpxzma-97Vo8vDMhApZ0gqlBYgFHt30DUgKsn","selected":false}]}    2026-01-07 19:09:48.285+00  2026-01-08 01:36:38.606+00  88  \N
27  90  Teste   t   \N  2026-01-08 19:16:36.518+00  2026-01-08 19:16:36.518+00  91  \N
28  104 Fluxo teste t   \N  2026-01-14 16:11:53.256+00  2026-01-14 16:11:53.256+00  104 \N
30  5   agendamento t   {"nodes":[{"id":"1","position":{"x":-284.01246386956836,"y":-591.9846175804789},"data":{"label":"Inicio do fluxo","title":"Início do Fluxo"},"type":"start","width":280,"height":229,"selected":false,"positionAbsolute":{"x":-284.01246386956836,"y":-591.9846175804789},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"width":300,"height":218,"id":"MIHEqkKQhAt1C27VahIbQlCcHneKg9","position":{"x":-123.33498979409285,"y":-116.83826992853301},"data":{"seq":["message0"],"elements":[{"type":"message","value":"😊 Será um prazer atendê-lo(a)!\\n\\nPara que nossa secretaria possa entrar em contato e realizar o agendamento, \\nvou precisar de algumas informações, tudo bem?","number":"message0"}],"title":"Conteúdo"},"type":"singleBlock","selected":false,"positionAbsolute":{"x":-123.33498979409285,"y":-116.83826992853301},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"width":280,"height":277,"id":"D3xk5w7zsHU6xVc7xlJEHXjYwx4rw9","position":{"x":274.66501020590715,"y":-676.838269928533},"data":{"typebotIntegration":{"message":"📅 Qual o melhor dia da semana para você?\\n\\n😊 Segue nossa grade de horários disponíveis: \\n🗓️ Segunda: 14h às 17h30 \\n🗓️ Terça: 10h às 12h30 | 14h às 17h \\n🗓️ Quarta: 10h às 12h30 | 14h às 17h \\n🗓️ Quinta: 10h às 12h30 | 14h às 17h \\n🗓️ Sexta: 10h às 12h30 | 14h às 18h ","answerKey":"diadasemana"},"title":"Pergunta"},"type":"question","selected":false,"positionAbsolute":{"x":274.66501020590715,"y":-676.838269928533},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"width":280,"height":258,"id":"sWrhy8Y9bKTDu6A1IYdfrvX7ktzH3J","position":{"x":246.66501020590715,"y":-58.83826992853301},"data":{"typebotIntegration":{"message":"⏰ Qual o HORÁRIO de sua preferência?","answerKey":"horario"},"title":"Pergunta"},"type":"question","selected":false,"positionAbsolute":{"x":246.66501020590715,"y":-58.83826992853301},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"width":280,"height":277,"id":"peHE9HA7APlOFooVv2C9QzN4Y5OZK8","position":{"x":754.6650102059073,"y":-508.838269928533},"data":{"typebotIntegration":{"message":"📍 Em qual local você prefere o atendimento?\\n\\n1️⃣ Clínica Monte Sinai  \\n2️⃣ Centro Empresarial (Sala 608)","answerKey":"local"},"title":"Pergunta"},"type":"question","selected":false,"positionAbsolute":{"x":754.6650102059073,"y":-508.838269928533},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"width":280,"height":277,"id":"9lOiZJ9eWqI953AeGw07XM9gn6tmAf","position":{"x":742.6650102059073,"y":-70.83826992853301},"data":{"typebotIntegration":{"message":"💳 O atendimento será PARTICULAR ou por CONVÊNIO?","answerKey":"convenio"},"title":"Pergunta"},"type":"question","selected":false,"positionAbsolute":{"x":742.6650102059073,"y":-70.83826992853301},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"width":280,"height":277,"id":"O5kJgcV8Nj0y8aOwIyNbWcS7TBQttC","position":{"x":1144.6650102059073,"y":-252.838269928533},"data":{"typebotIntegration":{"message":"📞 Qual o melhor número de telefone para retorno da nossa secretaria?\\n","answerKey":"numero"},"title":"Pergunta"},"type":"question","selected":false,"positionAbsolute":{"x":1144.6650102059073,"y":-252.838269928533},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"kmCsB9HP3NN7MwZWlv8MhgYnnnJviO","position":{"x":1568.6650102059073,"y":-396.838269928533},"data":{"seq":["message0"],"elements":[{"type":"message","value":"😊 Perfeito! Obrigado pelas informações {{name}} !\\n\\nNossa secretaria irá analisar a disponibilidade e entrar em contato com você \\nem breve para finalizar o agendamento.\\n\\nFicamos à disposição! 👁️✨","number":"message0"}],"title":"Conteúdo"},"type":"singleBlock","width":300,"height":228,"selected":true,"positionAbsolute":{"x":1568.6650102059073,"y":-396.838269928533},"dragging":false,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"}},{"id":"l1Q3mx3Wrba3ErdAuSks6dYtdzNYV4","position":{"x":2148.6650102059075,"y":-446.838269928533},"data":{"data":{"id":2,"name":"Agendamento","color":"#1A13EC","greetingMessage":"","orderQueue":null,"ativarRoteador":false,"tempoRoteador":0,"outOfHoursMessage":"","schedules":[{"weekday":"Segunda-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"monday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Terça-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"tuesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quarta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"wednesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quinta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"thursday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sexta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"friday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sábado","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"saturday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Domingo","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"sunday","startTimeA":"08:00","startTimeB":"12:01"}],"companyId":5,"integrationId":null,"fileListId":null,"closeTicket":false,"createdAt":"2025-10-10T17:56:59.183Z","updatedAt":"2025-10-10T17:56:59.183Z"},"title":"Ticket"},"type":"ticket","width":280,"height":291,"selected":false,"positionAbsolute":{"x":2148.6650102059075,"y":-446.838269928533},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss525","source":"MIHEqkKQhAt1C27VahIbQlCcHneKg9","sourceHandle":"a","target":"D3xk5w7zsHU6xVc7xlJEHXjYwx4rw9","targetHandle":null,"id":"reactflow__edge-MIHEqkKQhAt1C27VahIbQlCcHneKg9a-D3xk5w7zsHU6xVc7xlJEHXjYwx4rw9","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss850","source":"1","sourceHandle":"a","target":"MIHEqkKQhAt1C27VahIbQlCcHneKg9","targetHandle":null,"id":"reactflow__edge-1a-MIHEqkKQhAt1C27VahIbQlCcHneKg9","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1327","source":"D3xk5w7zsHU6xVc7xlJEHXjYwx4rw9","sourceHandle":"a","target":"sWrhy8Y9bKTDu6A1IYdfrvX7ktzH3J","targetHandle":null,"id":"reactflow__edge-D3xk5w7zsHU6xVc7xlJEHXjYwx4rw9a-sWrhy8Y9bKTDu6A1IYdfrvX7ktzH3J","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1327","source":"sWrhy8Y9bKTDu6A1IYdfrvX7ktzH3J","sourceHandle":"a","target":"peHE9HA7APlOFooVv2C9QzN4Y5OZK8","targetHandle":null,"id":"reactflow__edge-sWrhy8Y9bKTDu6A1IYdfrvX7ktzH3Ja-peHE9HA7APlOFooVv2C9QzN4Y5OZK8","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1327","source":"peHE9HA7APlOFooVv2C9QzN4Y5OZK8","sourceHandle":"a","target":"9lOiZJ9eWqI953AeGw07XM9gn6tmAf","targetHandle":null,"id":"reactflow__edge-peHE9HA7APlOFooVv2C9QzN4Y5OZK8a-9lOiZJ9eWqI953AeGw07XM9gn6tmAf","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1327","source":"9lOiZJ9eWqI953AeGw07XM9gn6tmAf","sourceHandle":"a","target":"O5kJgcV8Nj0y8aOwIyNbWcS7TBQttC","targetHandle":null,"id":"reactflow__edge-9lOiZJ9eWqI953AeGw07XM9gn6tmAfa-O5kJgcV8Nj0y8aOwIyNbWcS7TBQttC","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1327","source":"O5kJgcV8Nj0y8aOwIyNbWcS7TBQttC","sourceHandle":"a","target":"kmCsB9HP3NN7MwZWlv8MhgYnnnJviO","targetHandle":null,"id":"reactflow__edge-O5kJgcV8Nj0y8aOwIyNbWcS7TBQttCa-kmCsB9HP3NN7MwZWlv8MhgYnnnJviO","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss447","source":"kmCsB9HP3NN7MwZWlv8MhgYnnnJviO","sourceHandle":"a","target":"l1Q3mx3Wrba3ErdAuSks6dYtdzNYV4","targetHandle":null,"id":"reactflow__edge-kmCsB9HP3NN7MwZWlv8MhgYnnnJviOa-l1Q3mx3Wrba3ErdAuSks6dYtdzNYV4"}]}  2026-01-16 06:26:12.457+00  2026-01-16 07:44:40.135+00  5   \N
25  5   bot t   {"nodes":[{"id":"1","position":{"x":-376.01246386956836,"y":-5.984617580478869},"data":{"label":"Inicio do fluxo","title":"Início do Fluxo"},"type":"start","width":280,"height":229,"selected":false,"positionAbsolute":{"x":-376.01246386956836,"y":-5.984617580478869},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"width":280,"height":572,"id":"aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcP","position":{"x":-49.334989794092735,"y":-160.838269928533},"data":{"message":"Olá tudo bem!?\\nEm que podemos te ajudar!?","arrayOption":[{"number":1,"value":"Marcar consulta"},{"number":2,"value":"Marcar cirurgia"},{"number":3,"value":"Marcar exames"},{"number":4,"value":"Enviar exames solicitados"},{"number":5,"value":"Tirar dúvidas"},{"number":6,"value":"Falar direto com a secretaria"}],"title":"Menu"},"type":"menu","selected":false,"positionAbsolute":{"x":-49.334989794092735,"y":-160.838269928533},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"02olkCNw6zLRhLWG6YJ9qs0W1VRnxE","position":{"x":508.57929592019286,"y":-29.746841357104458},"data":{"seq":["message0"],"elements":[{"type":"message","value":"😊 Certinho! Vou te encaminhar agora para nossa secretaria.","number":"message0"}],"title":"Conteúdo"},"type":"singleBlock","width":300,"height":218,"selected":false,"positionAbsolute":{"x":508.57929592019286,"y":-29.746841357104458},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"X8trwO6VtXLDwFEi1FUFavcASEmjlo","position":{"x":349.1307244916211,"y":567.5188729286099},"data":{"data":{"id":3,"name":"Duvidas","color":"#151414","greetingMessage":"","orderQueue":null,"ativarRoteador":false,"tempoRoteador":0,"outOfHoursMessage":"","schedules":[{"weekday":"Segunda-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"monday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Terça-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"tuesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quarta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"wednesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quinta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"thursday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sexta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"friday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sábado","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"saturday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Domingo","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"sunday","startTimeA":"08:00","startTimeB":"12:01"}],"companyId":5,"integrationId":null,"fileListId":null,"closeTicket":false,"createdAt":"2025-10-10T17:57:21.456Z","updatedAt":"2025-10-10T17:57:21.456Z"},"title":"Ticket"},"type":"ticket","width":280,"height":291,"selected":false,"positionAbsolute":{"x":349.1307244916211,"y":567.5188729286099},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"LJEl4dIwkCXwFiGLYIZqx2vcRaoeFK","position":{"x":1005.5735816344786,"y":-103.1211270713901},"data":{"data":{"id":2,"name":"Agendamento","color":"#1A13EC","greetingMessage":"","orderQueue":null,"ativarRoteador":false,"tempoRoteador":0,"outOfHoursMessage":"","schedules":[{"weekday":"Segunda-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"monday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Terça-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"tuesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quarta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"wednesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quinta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"thursday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sexta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"friday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sábado","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"saturday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Domingo","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"sunday","startTimeA":"08:00","startTimeB":"12:01"}],"companyId":5,"integrationId":null,"fileListId":null,"closeTicket":false,"createdAt":"2025-10-10T17:56:59.183Z","updatedAt":"2025-10-10T17:56:59.183Z"},"title":"Ticket"},"type":"ticket","width":280,"height":291,"selected":false,"positionAbsolute":{"x":1005.5735816344786,"y":-103.1211270713901},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"Caf0tehxNvzN9l5KJQdVqzxtFtfcfz","position":{"x":578.6650102059073,"y":-358.83826992853295},"data":{"data":{"flowId":30,"flowName":"agendamento"},"title":"Transferir Fluxo"},"type":"transferFlow","width":280,"height":291,"selected":false,"positionAbsolute":{"x":578.6650102059073,"y":-358.83826992853295},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"pth9B97SF9MjawdUPiC0uKlpLXBpyt","position":{"x":1147.0450102059071,"y":425.80744435718157},"data":{"data":{"id":3,"name":"Duvidas","color":"#151414","greetingMessage":"","orderQueue":null,"ativarRoteador":false,"tempoRoteador":0,"outOfHoursMessage":"","schedules":[{"weekday":"Segunda-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"monday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Terça-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"tuesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quarta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"wednesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quinta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"thursday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sexta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"friday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sábado","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"saturday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Domingo","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"sunday","startTimeA":"08:00","startTimeB":"12:01"}],"companyId":5,"integrationId":null,"fileListId":null,"closeTicket":false,"createdAt":"2025-10-10T17:57:21.456Z","updatedAt":"2025-10-10T17:57:21.456Z"},"title":"Ticket"},"type":"ticket","width":280,"height":291,"selected":false,"positionAbsolute":{"x":1147.0450102059071,"y":425.80744435718157},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"VHPO14kaY5xhFhApHHSHyycS0B2vGi","position":{"x":591.0364387773357,"y":386.396015785753},"data":{"seq":["message0"],"elements":[{"type":"message","value":"Qual a sua duvida?","number":"message0"}],"title":"Conteúdo"},"type":"singleBlock","width":300,"height":218,"selected":false,"positionAbsolute":{"x":591.0364387773357,"y":386.396015785753},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"width":302,"height":220,"id":"wzVFyuHKh2U5B42LZKjImUs5D928Yr","position":{"x":471.04501020590715,"y":196.39601578575304},"data":{"seq":["message0"],"elements":[{"type":"message","value":"😊 Perfeito!\\nVocê pode enviar seus exames por aqui mesmo.","number":"message0"}],"title":"Conteúdo"},"type":"singleBlock","selected":true,"positionAbsolute":{"x":471.04501020590715,"y":196.39601578575304},"dragging":false,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"}}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1223","source":"1","sourceHandle":"a","target":"aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcP","targetHandle":null,"id":"reactflow__edge-1a-aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcP","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss525","source":"aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcP","sourceHandle":"a2","target":"02olkCNw6zLRhLWG6YJ9qs0W1VRnxE","targetHandle":null,"id":"reactflow__edge-aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcPa2-02olkCNw6zLRhLWG6YJ9qs0W1VRnxE","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss525","source":"aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcP","sourceHandle":"a6","target":"X8trwO6VtXLDwFEi1FUFavcASEmjlo","targetHandle":null,"id":"reactflow__edge-aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcPa6-X8trwO6VtXLDwFEi1FUFavcASEmjlo","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss525","source":"02olkCNw6zLRhLWG6YJ9qs0W1VRnxE","sourceHandle":"a","target":"LJEl4dIwkCXwFiGLYIZqx2vcRaoeFK","targetHandle":null,"id":"reactflow__edge-02olkCNw6zLRhLWG6YJ9qs0W1VRnxEa-LJEl4dIwkCXwFiGLYIZqx2vcRaoeFK","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1086","source":"aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcP","sourceHandle":"a1","target":"Caf0tehxNvzN9l5KJQdVqzxtFtfcfz","targetHandle":null,"id":"reactflow__edge-aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcPa1-Caf0tehxNvzN9l5KJQdVqzxtFtfcfz","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1086","source":"aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcP","sourceHandle":"a3","target":"02olkCNw6zLRhLWG6YJ9qs0W1VRnxE","targetHandle":null,"id":"reactflow__edge-aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcPa3-02olkCNw6zLRhLWG6YJ9qs0W1VRnxE","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss717","source":"aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcP","sourceHandle":"a5","target":"VHPO14kaY5xhFhApHHSHyycS0B2vGi","targetHandle":null,"id":"reactflow__edge-aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcPa5-VHPO14kaY5xhFhApHHSHyycS0B2vGi","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss717","source":"VHPO14kaY5xhFhApHHSHyycS0B2vGi","sourceHandle":"a","target":"pth9B97SF9MjawdUPiC0uKlpLXBpyt","targetHandle":null,"id":"reactflow__edge-VHPO14kaY5xhFhApHHSHyycS0B2vGia-pth9B97SF9MjawdUPiC0uKlpLXBpyt","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss717","source":"aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcP","sourceHandle":"a4","target":"wzVFyuHKh2U5B42LZKjImUs5D928Yr","targetHandle":null,"id":"reactflow__edge-aRdjr9Zc5mbq6kFzjzUqYIeGWSRKcPa4-wzVFyuHKh2U5B42LZKjImUs5D928Yr","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss717","source":"wzVFyuHKh2U5B42LZKjImUs5D928Yr","sourceHandle":"a","target":"pth9B97SF9MjawdUPiC0uKlpLXBpyt","targetHandle":null,"id":"reactflow__edge-wzVFyuHKh2U5B42LZKjImUs5D928Yra-pth9B97SF9MjawdUPiC0uKlpLXBpyt"}]}    2026-01-07 16:28:00.045+00  2026-01-16 08:06:19.212+00  5   \N
31  108 TEste   t   \N  2026-01-20 19:07:26.927+00  2026-01-20 19:07:26.927+00  107 \N
37  110 teste   t   {"nodes":[{"id":"1","position":{"x":-132.6028655542264,"y":112.05911610629369},"data":{"label":"Inicio do fluxo","title":"Início do Fluxo"},"type":"start","width":280,"height":227,"selected":false,"positionAbsolute":{"x":-132.6028655542264,"y":112.05911610629369},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"width":302,"height":218,"id":"iTv2yIcYeH63Cqoo4meczzFiIrE8on","position":{"x":250.98156482441306,"y":66.01521824589969},"data":{"seq":["message0"],"elements":[{"type":"message","value":"teste","number":"message0"}],"title":"Conteúdo"},"type":"singleBlock","selected":false,"positionAbsolute":{"x":250.98156482441306,"y":66.01521824589969},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"vGbU551oK86YfU8WUQ0S1jFiksX67f","position":{"x":686.1656438275913,"y":78.07433435219338},"data":{"typebotIntegration":{"message":"Você aceita?","answerKey":"Sim"},"title":"Pergunta"},"type":"question","width":280,"height":239,"selected":false,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"},"positionAbsolute":{"x":686.1656438275913,"y":78.07433435219338},"dragging":false}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1124","source":"1","sourceHandle":"a","target":"iTv2yIcYeH63Cqoo4meczzFiIrE8on","targetHandle":null,"id":"reactflow__edge-1a-iTv2yIcYeH63Cqoo4meczzFiIrE8on","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1124","source":"iTv2yIcYeH63Cqoo4meczzFiIrE8on","sourceHandle":"a","target":"vGbU551oK86YfU8WUQ0S1jFiksX67f","targetHandle":null,"id":"reactflow__edge-iTv2yIcYeH63Cqoo4meczzFiIrE8ona-vGbU551oK86YfU8WUQ0S1jFiksX67f"}]}    2026-01-24 14:04:34.904+00  2026-01-24 14:06:44.241+00  109 \N
32  109 teste   t   \N  2026-01-23 23:01:00.332+00  2026-01-23 23:01:00.332+00  108 \N
39  113 FluxoComIa  t   \N  2026-01-25 23:31:56.792+00  2026-01-25 23:31:56.792+00  112 \N
38  113 fluxo1  t   {"nodes":[{"id":"1","position":{"x":250,"y":100},"data":{"label":"Inicio do fluxo","title":"Início do Fluxo"},"type":"start","width":280,"height":229,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"fHzuzjsmmvALcNDf1IKuH7j42C10V6","position":{"x":636.2006938088675,"y":188.89326835073945},"data":{"data":{"id":90,"name":"Fase1","color":"#667eea"},"title":"Tag Kanban"},"type":"addTagKanban","width":280,"height":226,"selected":false,"positionAbsolute":{"x":636.2006938088675,"y":188.89326835073945},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"3w0vniVFXNXa6fs74abSeY2zycB1BU","position":{"x":1007.6678683326666,"y":-29.639218454499996},"data":{"data":{"id":89,"name":"g5e-site","color":"#764ba2"},"title":"Adicionar Tag"},"type":"addTag","width":280,"height":226,"selected":false,"positionAbsolute":{"x":1007.6678683326666,"y":-29.639218454499996},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"qKXNU3e3L52BU4WSZIRg4qGCnfWLtI","position":{"x":1881.5619534098323,"y":-57.92950774607566},"data":{"message":"qual servico voce precisa?","arrayOption":[{"number":1,"value":"mkt"},{"number":2,"value":"vendas"},{"number":3,"value":"redes sociais"}],"title":"Menu"},"type":"menu","width":280,"height":384,"selected":false,"positionAbsolute":{"x":1881.5619534098323,"y":-57.92950774607566},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"n3FrDffZT47xwx0EgGaHeTd3KuUpBZ","position":{"x":1436.2351799429957,"y":-40.061956614554184},"data":{"seq":["message0"],"elements":[{"type":"message","value":"Voce já demais por estar aqui {{firstName}}.","number":"message0"}],"title":"Conteúdo"},"type":"singleBlock","width":300,"height":218,"selected":false,"positionAbsolute":{"x":1436.2351799429957,"y":-40.061956614554184},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1209","source":"1","sourceHandle":"a","target":"fHzuzjsmmvALcNDf1IKuH7j42C10V6","targetHandle":null,"id":"reactflow__edge-1a-fHzuzjsmmvALcNDf1IKuH7j42C10V6","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1224","source":"fHzuzjsmmvALcNDf1IKuH7j42C10V6","sourceHandle":"a","target":"3w0vniVFXNXa6fs74abSeY2zycB1BU","targetHandle":null,"id":"reactflow__edge-fHzuzjsmmvALcNDf1IKuH7j42C10V6a-3w0vniVFXNXa6fs74abSeY2zycB1BU","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1024","source":"3w0vniVFXNXa6fs74abSeY2zycB1BU","sourceHandle":"a","target":"n3FrDffZT47xwx0EgGaHeTd3KuUpBZ","targetHandle":null,"id":"reactflow__edge-3w0vniVFXNXa6fs74abSeY2zycB1BUa-n3FrDffZT47xwx0EgGaHeTd3KuUpBZ","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1024","source":"n3FrDffZT47xwx0EgGaHeTd3KuUpBZ","sourceHandle":"a","target":"qKXNU3e3L52BU4WSZIRg4qGCnfWLtI","targetHandle":null,"id":"reactflow__edge-n3FrDffZT47xwx0EgGaHeTd3KuUpBZa-qKXNU3e3L52BU4WSZIRg4qGCnfWLtI","selected":false}]}   2026-01-25 03:01:11.162+00  2026-02-05 02:55:49.927+00  112 \N
49  125 Autmacao2   t   \N  2026-01-29 23:29:47.266+00  2026-01-29 23:29:47.266+00  122 \N
50  125 Automacao3  t   \N  2026-01-29 23:29:53.635+00  2026-01-29 23:29:53.635+00  122 \N
48  125 Automacao1  t   {"nodes":[{"id":"1","position":{"x":250,"y":100},"data":{"label":"Inicio do fluxo","title":"Início do Fluxo"},"type":"start","width":280,"height":229,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"width":300,"height":156,"id":"3oNBqUxROAxNF54tW0HgBDgBCy3DO1","position":{"x":610.0453259116218,"y":91.29449436703874},"data":{"seq":[],"elements":[],"title":"Conteúdo"},"type":"singleBlock","selected":false,"positionAbsolute":{"x":610.0453259116218,"y":91.29449436703874},"dragging":false,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"}},{"id":"QvFrxBsbyNZm9TCM08FwjrGa087Zaq","position":{"x":1038.8414833678264,"y":14.686044796979843},"data":{"typebotIntegration":{"message":"Qual o seu nome?","answerKey":"name"},"title":"Pergunta"},"type":"question","width":280,"height":240,"selected":false,"positionAbsolute":{"x":1038.8414833678264,"y":14.686044796979843},"dragging":false}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1093","source":"1","sourceHandle":"a","target":"3oNBqUxROAxNF54tW0HgBDgBCy3DO1","targetHandle":null,"id":"reactflow__edge-1a-3oNBqUxROAxNF54tW0HgBDgBCy3DO1","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1093","source":"3oNBqUxROAxNF54tW0HgBDgBCy3DO1","sourceHandle":"a","target":"QvFrxBsbyNZm9TCM08FwjrGa087Zaq","targetHandle":null,"id":"reactflow__edge-3oNBqUxROAxNF54tW0HgBDgBCy3DO1a-QvFrxBsbyNZm9TCM08FwjrGa087Zaq","selected":false}]}    2026-01-29 23:29:39.523+00  2026-01-29 23:32:14.816+00  122 \N
51  125 teste   t   \N  2026-01-29 23:43:45.69+00   2026-01-29 23:43:45.69+00   122 \N
56  131 czxczx  t   \N  2026-02-03 04:37:54.007+00  2026-02-03 04:37:54.007+00  132 \N
57  132 Admin   t   {"nodes":[{"id":"1","position":{"x":-47.51287394423224,"y":-111.36049731945447},"data":{"label":"Inicio do fluxo","title":"Início do Fluxo"},"type":"start","width":280,"height":229,"selected":false,"positionAbsolute":{"x":-47.51287394423224,"y":-111.36049731945447},"dragging":false}],"connections":[]}  2026-02-03 18:28:08.922+00  2026-02-03 18:28:27.888+00  133 \N
55  129 Fluxo Principal Vellui  t   {"nodes":[{"id":"1","position":{"x":-393.0108923035442,"y":36.28254112507415},"data":{"label":"Inicio do fluxo","title":"Início do Fluxo"},"type":"start","width":282,"height":229,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"},"positionAbsolute":{"x":-393.0108923035442,"y":36.28254112507415},"dragging":false},{"width":280,"height":511,"id":"12ScPP6rLUhwNKR3m5CX5lKfhb32RR","position":{"x":18.71118570159507,"y":-30.02265199729196},"data":{"message":"👋 Olá! Seja bem-vindo(a) à Vellui.\\n\\nSomos especialistas em gestão de atendimento e WhatsApp empresarial, ajudando empresas a organizar conversas, centralizar canais e ter mais controle e eficiência no relacionamento com seus clientes.\\n\\nPara agilizar seu atendimento, escolha uma das opções abaixo 👇","arrayOption":[{"number":1,"value":" Vellui Omnichannel – Gestão de WhatsApp e Atendimento"},{"number":2,"value":"Suporte técnico / Cliente ativo"},{"number":3,"value":"Comercial / Novos projetos"},{"number":4,"value":"Financeiro"},{"number":5,"value":"Falar com um especialista"}],"title":"Menu"},"type":"menu","selected":true,"positionAbsolute":{"x":18.71118570159507,"y":-30.02265199729196},"dragging":false,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"}},{"id":"PvEA2pvYU8ZkOuOtBepeqOzgCYYCrW","position":{"x":338.71118570159507,"y":-30.02265199729196},"data":{"data":{"id":47,"name":"Comerial","color":"#1D93CA","greetingMessage":"","orderQueue":null,"ativarRoteador":true,"tempoRoteador":0,"outOfHoursMessage":"","schedules":[{"weekday":"Segunda-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"monday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Terça-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"tuesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quarta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"wednesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quinta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"thursday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sexta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"friday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sábado","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"saturday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Domingo","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"sunday","startTimeA":"08:00","startTimeB":"12:01"}],"companyId":131,"integrationId":null,"fileListId":null,"closeTicket":false,"createdAt":"2026-02-02T11:15:44.416Z","updatedAt":"2026-02-02T11:15:44.416Z"},"title":"Ticket"},"type":"ticket","width":280,"height":290,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss889","source":"1","sourceHandle":"a","target":"12ScPP6rLUhwNKR3m5CX5lKfhb32RR","targetHandle":null,"id":"reactflow__edge-1a-12ScPP6rLUhwNKR3m5CX5lKfhb32RR"},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss932","source":"12ScPP6rLUhwNKR3m5CX5lKfhb32RR","sourceHandle":"a1","target":"PvEA2pvYU8ZkOuOtBepeqOzgCYYCrW","targetHandle":null,"id":"reactflow__edge-12ScPP6rLUhwNKR3m5CX5lKfhb32RRa1-PvEA2pvYU8ZkOuOtBepeqOzgCYYCrW"}]}  2026-02-02 03:38:13.722+00  2026-02-03 22:55:21.556+00  131 \N
58  136 teste   t   {"nodes":[{"id":"1","position":{"x":-510.45093205716523,"y":-26.07020858548435},"data":{"label":"Inicio do fluxo","title":"Início do Fluxo"},"type":"start","width":280,"height":229,"selected":false,"positionAbsolute":{"x":-510.45093205716523,"y":-26.07020858548435},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"SmPeJh0VbzboWiUBg83v7WnD6TtsNw","position":{"x":-183.05690279229276,"y":-9.609257935573282},"data":{"message":"Olá, seja bem vindo ao nosso atendimento","arrayOption":[{"number":1,"value":"Suporte"},{"number":2,"value":"Vendas"}],"title":"Menu"},"type":"menu","width":280,"height":340,"selected":false,"positionAbsolute":{"x":-183.05690279229276,"y":-9.609257935573282},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"KXJm5K0lZ1Pugat6VjV2BORMRfsv4k","position":{"x":221.24961946286885,"y":385.9490379109993},"data":{"data":{"id":51,"name":"Vendas","color":"#AA2F2F","greetingMessage":"","orderQueue":1,"ativarRoteador":false,"tempoRoteador":0,"outOfHoursMessage":"","schedules":[{"weekday":"Segunda-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"monday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Terça-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"tuesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quarta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"wednesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quinta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"thursday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sexta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"friday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sábado","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"saturday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Domingo","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"sunday","startTimeA":"08:00","startTimeB":"12:01"}],"companyId":139,"integrationId":null,"fileListId":null,"closeTicket":false,"createdAt":"2026-02-04T02:15:14.105Z","updatedAt":"2026-02-04T02:15:14.105Z"},"title":"Ticket"},"type":"ticket","width":280,"height":291,"selected":false,"positionAbsolute":{"x":221.24961946286885,"y":385.9490379109993},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"NBn3GVx3qa4xvGtP41iRDbXzSMRMHB","position":{"x":248.94510859695492,"y":-83.84295495703557},"data":{"data":{"id":52,"name":"Suporte","color":"#D11D1D","greetingMessage":"","orderQueue":2,"ativarRoteador":false,"tempoRoteador":0,"outOfHoursMessage":"","schedules":[{"weekday":"Segunda-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"monday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Terça-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"tuesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quarta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"wednesday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Quinta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"thursday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sexta-feira","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"friday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Sábado","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"saturday","startTimeA":"08:00","startTimeB":"12:01"},{"weekday":"Domingo","endTimeA":"12:00","endTimeB":"23:00","weekdayEn":"sunday","startTimeA":"08:00","startTimeB":"12:01"}],"companyId":139,"integrationId":null,"fileListId":null,"closeTicket":false,"createdAt":"2026-02-04T02:15:37.102Z","updatedAt":"2026-02-04T02:15:37.102Z"},"title":"Ticket"},"type":"ticket","width":280,"height":291,"selected":false,"positionAbsolute":{"x":248.94510859695492,"y":-83.84295495703557},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"mCL55UZvkDJTy4zrInrbxQ62oZyzrK","position":{"x":843.5754164085233,"y":428.25233536055254},"data":{"title":"🛍️ Nossos Produtos e Serviços","listType":"selected","selectedItems":["service_6"]},"type":"productList","width":280,"height":130,"selected":false,"positionAbsolute":{"x":843.5754164085233,"y":428.25233536055254},"dragging":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}},{"id":"directOpenai-1770173601904","type":"directOpenai","position":{"x":577.9788033615918,"y":25.31581197475134},"data":{"provider":"gemini","apiKey":"AIzaSyApowhSfMVrNbGDfFvcmiJygxZ9Fh3curk","model":"gemini-2.0-flash","prompt":"Você é o assistente oficial do negócio Salão Nota 100.\\nSua comunicação deve seguir estas regras UNIVERSAIS e OBRIGATÓRIAS:\\n\\n• Não use emojis.\\n• Não utilize linguagem de vendedor ou linguagem de venda agressiva/apelativa.\\n• Não faça várias perguntas seguidas ou blocos de perguntas.\\n• Depois de responder, aguarde a interação do cliente.\\n• Não finalize mensagens com \\"posso ajudar em algo mais?\\" ou variações.\\n• Não tente forçar o cliente a continuar conversando.\\n• Mantenha naturalidade, como um humano digitando no WhatsApp.\\n• Evite frases decoradas, robóticas ou formais demais.\\n• Responda apenas o que foi perguntado, uma coisa por vez.\\n• Seja direto, claro e educado, sem exageros ou floreios.\\n• Evite textos longos; mantenha mensagens simples e naturais.\\n• Sempre pare após cada resposta e aguarde o cliente avançar.\\n• Só ofereça algo adicional se estiver diretamente relacionado ao que o contato perguntou.\\n\\nIMPORTANTE - Solicitação de Atendimento Humano:\\n• Se o cliente pedir para falar com um humano, atendente, responsável ou similar, responda EXATAMENTE: \\"[SOLICITAR_HUMANO] Vou acionar um atendente humano para você. Aguarde um momento.\\"\\n• Não tente resolver o problema sozinho quando pedirem atendimento humano.\\n• Use a palavra-chave [SOLICITAR_HUMANO] no início da resposta para acionar a notificação.\\n\\nConsidere sempre estas informações ao responder:\\n\\nNome: Salão Nota 100\\nDescrição do negócio: Trabalhamos com manicure, corte de cabela, barba \\nEndereço: Quadra 16 conjunto H Paranoá, Brasilia DF\\nContato principal: 61981115043\\nHorário de funcionamento: Segunda a sexta das 8h00 as 18hoo\\nObservações gerais: Aceitamos pix e cartão\\n\\nProdutos:\\nCorte de cabelo R$50,00\\nBarba R$30,00\\nManicure R$30,00\\n\\nServiços:\\nAgende seu serviço por aqui\\n\\nTom de comunicação: Formal\\nNível de objetividade: Detalhado\\n","temperature":0.7,"maxTokens":1000,"toolsEnabled":["atualizar_agendamento","enviar_arquivo_contato","enviar_emoji","ver_info_contato","ver_horario_empresa","atualizar_info_contato","listar_agendamentos","listar_grupos","executar_ferramenta","enviar_produto","transferir_usuario","adicionar_tag","transferir_fila","call_flow_builder","curtir_mensagem","criar_agendamento","enviar_mensagem_grupo"],"knowledgeBase":[],"title":"Bloco"},"width":280,"height":157,"selected":false,"positionAbsolute":{"x":577.9788033615918,"y":25.31581197475134},"dragging":false}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1036","source":"1","sourceHandle":"a","target":"SmPeJh0VbzboWiUBg83v7WnD6TtsNw","targetHandle":null,"id":"reactflow__edge-1a-SmPeJh0VbzboWiUBg83v7WnD6TtsNw","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1430","source":"KXJm5K0lZ1Pugat6VjV2BORMRfsv4k","sourceHandle":"a","target":"mCL55UZvkDJTy4zrInrbxQ62oZyzrK","targetHandle":null,"id":"reactflow__edge-KXJm5K0lZ1Pugat6VjV2BORMRfsv4ka-mCL55UZvkDJTy4zrInrbxQ62oZyzrK","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1430","source":"SmPeJh0VbzboWiUBg83v7WnD6TtsNw","sourceHandle":"a1","target":"NBn3GVx3qa4xvGtP41iRDbXzSMRMHB","targetHandle":null,"id":"reactflow__edge-SmPeJh0VbzboWiUBg83v7WnD6TtsNwa1-NBn3GVx3qa4xvGtP41iRDbXzSMRMHB","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1430","source":"SmPeJh0VbzboWiUBg83v7WnD6TtsNw","sourceHandle":"a2","target":"KXJm5K0lZ1Pugat6VjV2BORMRfsv4k","targetHandle":null,"id":"reactflow__edge-SmPeJh0VbzboWiUBg83v7WnD6TtsNwa2-KXJm5K0lZ1Pugat6VjV2BORMRfsv4k","selected":false},{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1924","source":"NBn3GVx3qa4xvGtP41iRDbXzSMRMHB","sourceHandle":"a","target":"directOpenai-1770173601904","targetHandle":null,"id":"reactflow__edge-NBn3GVx3qa4xvGtP41iRDbXzSMRMHBa-directOpenai-1770173601904"}]}  2026-02-04 01:56:32.825+00  2026-02-04 02:53:35.32+00   139 \N
59  128 teste   t   {"nodes":[{"id":"1","position":{"x":250,"y":100},"data":{"label":"Inicio do fluxo","title":"Início do Fluxo"},"type":"start","width":280,"height":229,"selected":true,"style":{"backgroundColor":"#3b82f6","padding":1,"borderRadius":8,"pointerEvents":"auto"}},{"id":"3tPfXjFcCOpIZdc8chdpcklIfrqBS4","position":{"x":570,"y":100},"data":{"seq":[],"elements":[],"title":"Conteúdo"},"type":"singleBlock","width":300,"height":156,"selected":false,"style":{"backgroundColor":"#ffffff","padding":0,"borderRadius":8,"pointerEvents":"auto"}}],"connections":[{"style":{"stroke":"#6366f1","strokeWidth":"3px"},"animated":true,"className":"jss1065","source":"1","sourceHandle":"a","target":"3tPfXjFcCOpIZdc8chdpcklIfrqBS4","targetHandle":null,"id":"reactflow__edge-1a-3tPfXjFcCOpIZdc8chdpcklIfrqBS4","selected":false}]}    2026-02-04 03:12:03.254+00  2026-02-04 03:13:01.084+00  130 \N
\.


--
-- Data for Name: FlowCampaigns; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."FlowCampaigns" (id, "companyId", "userId", name, "flowId", phrase, status, "createdAt", "updatedAt", "whatsappId", phrases, "matchType") FROM stdin;
1   3   3   ra  5   limpo   t   2025-10-28 21:42:00.351+00  2025-10-28 21:42:00.351+00  \N  \N  \N
4   129 127 teste   53  teste2  t   2026-01-30 17:11:34.66+00   2026-01-30 17:11:34.66+00   \N  ["teste2"]  exact
\.


--
-- Data for Name: FlowDefaults; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."FlowDefaults" (id, "companyId", "userId", "flowIdWelcome", "flowIdNotPhrase", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FlowImgs; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."FlowImgs" (id, "companyId", "userId", name, "createdAt", "updatedAt") FROM stdin;
1   1   1   documentacao_api_focus_cidadao_1767334301947.pdf    2026-01-02 06:11:41.959+00  2026-01-02 06:11:41.959+00
2   1   1   funcionalidades_1767731278440.pdf   2026-01-06 20:27:58.448+00  2026-01-06 20:27:58.448+00
3   1   1   atualiza_o_1_1767759820124.png  2026-01-07 04:23:40.163+00  2026-01-07 04:23:40.163+00
4   1   1   promocao_1767762204674.png  2026-01-07 05:03:24.707+00  2026-01-07 05:03:24.707+00
5   1   1   valornovo_1767762967229.pdf 2026-01-07 05:16:07.232+00  2026-01-07 05:16:07.232+00
6   1   1   valornovo_1767762970374.png 2026-01-07 05:16:10.414+00  2026-01-07 05:16:10.414+00
7   1   1   valornovo_1_1767763869245.png   2026-01-07 05:31:09.283+00  2026-01-07 05:31:09.283+00
8   1   1   funcionalidades_1767764123491.pdf   2026-01-07 05:35:23.496+00  2026-01-07 05:35:23.496+00
9   1   1   valornovo_1767764129413.png 2026-01-07 05:35:29.417+00  2026-01-07 05:35:29.417+00
10  109 110 PDF_Portfolio_Curso_Comunica_1769273820613.pdf  2026-01-24 16:57:00.619+00  2026-01-24 16:57:00.619+00
11  109 110 Portfolio_Treinamento_Imersivo_1769273825424.pdf    2026-01-24 16:57:05.428+00  2026-01-24 16:57:05.428+00
12  112 113 Base_de_Conhecimento_Grupo_5_E_1769311830891.pdf    2026-01-25 03:30:30.896+00  2026-01-25 03:30:30.896+00
13  112 113 Base_de_Conhecimento_Grupo_5_E_1769311945044.pdf    2026-01-25 03:32:25.046+00  2026-01-25 03:32:25.046+00
14  112 113 Base_de_Conhecimento_Grupo_5_E_1769353181218.pdf    2026-01-25 14:59:41.224+00  2026-01-25 14:59:41.224+00
15  112 113 Base_de_Conhecimento_Grupo_5_E_1769354142265.pdf    2026-01-25 15:15:42.268+00  2026-01-25 15:15:42.268+00
16  1   1   valornovo_1769361353103.png 2026-01-25 17:15:53.112+00  2026-01-25 17:15:53.112+00
17  1   1   Ativar_agente_de_IA_1769632520717.mp4   2026-01-28 20:35:20.776+00  2026-01-28 20:35:20.776+00
18  1   1   overviw_1769801512863.mp4   2026-01-30 19:31:53.118+00  2026-01-30 19:31:53.118+00
\.


--
-- Data for Name: GoogleCalendarIntegrations; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."GoogleCalendarIntegrations" (id, "companyId", "googleUserId", email, "accessToken", "refreshToken", "expiryDate", "calendarId", "createdAt", "updatedAt", "userId") FROM stdin;
12  1           ya29.a0AUMWg_IR3MHn7VK8JxioPvxgvZGa5tSeBK6y6J2b_WSlPI2aj_bTSSdtSjae7SwhoVmgMJT4tWo8JRb5biEhzSgfk1HEBWyMRaEvpLV0tk9oekSmEkiYxEwqM44dUC6agAj-QZEsKPeTNBVfqjlNhIeeSpj9YWqcJ-ep-Cc2AdKvxo7Rb73EgvUgMYqejOldmOM6EJwaCgYKAc8SARYSFQHGX2MiBvd7qik5fJKwTL22f_Up9A0206   1//05x-QOXLehTcUCgYIARAAGAUSNwF-L9IreC_iZbxfk0p_XPWfr9eZhn33N06zOisYMRvGPkw5tOtPFyerpfd55pPp7lz3vrbGtKM 2026-01-24 02:15:33.154+00  primary 2026-01-16 21:23:30.582+00  2026-01-24 01:15:34.16+00   1
11  1   115725447706774210001   rafaeloficialpaixao@gmail.com   ya29.a0AUMWg_KwWw45tlJGClGw-tPqGz61kHYKGUzuOx-6N9w6NTIXI31poRDe0ryYot7LbfCra_v8zCI3w2jIfgxYYC3MDO0b2JhNZM6PrR2N_XCmbd2-bUdPeEyOIK_1ICCGPnDRVSm0OhX_3Tjx5Maqd-CXE7itHmWNGtSYh_ltvdA_9IiDHoUCDYEadF0TbJOGVCYGSckaCgYKAfsSARQSFQHGX2MipZUs0b38FfGa-ze1oOKF4A0206   1//05Avcvg99fKp9CgYIARAAGAUSNwF-L9IrOgf9DafYfysPnp3zcGoqQiOsppRCIx3LSgqPe12yCvn8ER9x65RCHyFQx45EZM2Tk0s 2026-01-16 22:21:19.952+00  primary 2026-01-16 21:21:20.956+00  2026-01-16 21:21:20.956+00  \N
\.


--
-- Data for Name: GoogleSheetsTokens; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."GoogleSheetsTokens" (id, "companyId", "googleUserId", email, "accessToken", "refreshToken", "expiryDate", "rawTokens", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Helps; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Helps" (id, title, description, video, link, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: IaWorkflows; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."IaWorkflows" (id, "companyId", "orchestratorPromptId", "agentPromptId", alias, "createdAt", "updatedAt") FROM stdin;
32  112 13  15  Agente Qualificacao de Leads    2026-02-04 23:33:00.748 2026-02-04 23:33:00.748
\.


--
-- Data for Name: Integrations; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Integrations" (id, "companyId", name, "isActive", token, "foneContact", "userLogin", "passLogin", "finalCurrentMonth", "initialCurrentMonth", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Invoices; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Invoices" (id, "companyId", "dueDate", detail, status, value, users, connections, queues, "useWhatsapp", "useFacebook", "useInstagram", "useCampaigns", "useSchedules", "useInternalChat", "useExternalApi", "createdAt", "updatedAt", "linkInvoice") FROM stdin;
1   1   2099-12-31T00:00:00-03:00   Plano 1 open    100 10  10  10  t   t   t   t   t   t   t   2025-10-10 02:50:30+00  2025-10-10 02:50:30+00  
\.


--
-- Data for Name: LogTickets; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."LogTickets" (id, "userId", "ticketId", "queueId", type, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: MediaFiles; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."MediaFiles" (id, folder_id, company_id, original_name, custom_name, mime_type, size, storage_path, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: MediaFolders; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."MediaFolders" (id, name, description, company_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Messages; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Messages" (body, ack, read, "mediaType", "mediaUrl", "ticketId", "createdAt", "updatedAt", "fromMe", "isDeleted", "contactId", "companyId", "remoteJid", "dataJson", participant, "queueId", "ticketTrakingId", "quotedMsgId", wid, id, "isPrivate", "isEdited", "isForwarded", "fromAgent", "userId") FROM stdin;
\.


--
-- Data for Name: MobileWebhooks; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."MobileWebhooks" (id, "userId", "companyId", "webhookUrl", "deviceToken", platform, "isActive", "failureCount", "lastUsed", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Negocios; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Negocios" (id, "companyId", name, description, "kanbanBoards", users, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Partners; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Partners" (id, name, phone, email, document, commission, "typeCommission", "walletId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Plans; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Plans" (id, name, users, connections, queues, "createdAt", "updatedAt", amount, "useFacebook", "useInstagram", "useWhatsapp", "useCampaigns", "useExternalApi", "useInternalChat", "useSchedules", "useKanban", "isPublic", recurrence, trial, "trialDays", "useIntegrations", "useOpenAi") FROM stdin;
1   Plano Advance   10  5   15  2025-10-10 02:50:00.261+00  2026-01-10 04:53:45.563+00  289.90  t   t   t   t   t   t   t   t   t   MENSAL  f   0   t   t
\.


--
-- Data for Name: Produtos; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Produtos" (id, "companyId", tipo, nome, descricao, valor, status, imagem_principal, galeria, dados_especificos, "createdAt", "updatedAt") FROM stdin;
15  \N  servico Teste de PRODUTO        90.00   disponivel  \N  \N  \N  2025-12-08 21:15:27.61  2025-12-08 21:15:27.61
16  \N  imovel  APTO 270MIL - CANCUN    VENDA | R$ 270 MIL | Apartamento 03 quartos, com 78,00 m² no Bairro Água Verde em Blumenau-SC\n\n- 3 dormitórios\n- Sala de estar\n- Sala de jantar\n- Cozinha\n- Banheiro\n- Área de serviço\n- Sacada com churrasqueira\n- 1 vaga de garagem coberta\n\n🎯 Johann Ohf, 1445\n📸 FOTOS: jpeixer.com.br/imovel/7247   270000.00   disponivel  company59/produtos/POST_-_APTO_270MIL_-_4.png   \N  \N  2025-12-09 08:18:58.824 2025-12-09 08:18:58.824
8   \N  fisico  Monitor     150.00  disponivel  company44/produtos/Captura_de_tela_13-11-2025_145921_www.mercadolivre.com.br.jpeg   ["company44/produtos/51vJqQDLzWL.jpg", "company44/produtos/garnet2.jpg"]    \N  2025-11-26 13:42:04.88  2025-11-26 13:42:04.88
4   \N  fisico  teste       325.00  disponivel  \N  \N  \N  2025-11-16 13:16:01.361 2025-11-16 13:16:01.361
12  \N  veiculo Gol G7  📍 2019 / 1.6 MSI\n⛽ Flex\n📌 Completo    56000.00    disponivel  company46/produtos/sddefault.jpg    ["company46/produtos/gol-g7-e-g8-painel.jpg", "company46/produtos/hqdefault.jpg"]   \N  2025-11-27 00:22:49.902 2025-11-27 01:01:59.533
13  \N  veiculo Honda HR-V  📍 2017 / EXL\n⛽ Flex\n🛠 Automático  98000.00    disponivel  company46/produtos/honda-hr-v-touring-vs.-vw-t-cross-highline-vs.-jeep-renegade-s.jpg   ["company46/produtos/Honda-HR-V-test-drive_(7).jpg", "company46/produtos/HRV23-038_EXLNavi_USB-A_Version-cropped.jpg"]  \N  2025-11-27 00:23:28.549 2025-11-27 01:02:08.776
14  \N  veiculo Volkswagen Jetta    📍 2015 / Highline 2.0 TSI\n🛠 Automático\n⚡ Turbo    79900.00    disponivel  company46/produtos/a1m9_1VI9i424Wi.jpg  ["company46/produtos/Jetta-2019-R-line-frente34l.jpg", "company46/produtos/Jetta-GLI-19.png"]   \N  2025-11-27 00:24:08.33  2025-11-27 01:02:29.991
18  \N  servico Limpeza     200.00  disponivel  company108/produtos/valornovo.png   ["company108/produtos/print-fluxo.png", "company108/produtos/print-fluxo_(1).webp", "company108/produtos/print-fluxo.webp"] \N  2026-01-25 00:57:48.317 2026-01-25 00:57:48.317
20  \N  fisico  123 123 123.00  disponivel  company132/produtos/image-1-1500x999-1.jpeg ["company132/produtos/image-1-1500x999-1.jpeg", "company132/produtos/MicrosoftTeams-image-45-1-150x150.png"]    \N  2026-02-03 02:23:51.857 2026-02-03 02:23:51.857
19  \N  servico Mentoria Renan      2000.00 disponivel  company112/produtos/example.jpg ["company112/produtos/Captura_de_Tela_2025-12-02_às_10.35.09.png", "company112/produtos/Captura_de_Tela_2025-12-02_às_10.38.22.png"]  \N  2026-01-25 15:00:34.491 2026-01-25 15:00:34.491
21  \N  fisico  producto1   descripcion 1000.00 disponivel  company133/produtos/image-1-1500x999-1.jpeg ["company133/produtos/image-1-1500x999-1.jpeg", "company133/produtos/MicrosoftTeams-image-45-1-150x150.png"]    \N  2026-02-04 00:23:05.273 2026-02-04 00:23:05.273
\.


--
-- Data for Name: PromptToolSettings; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."PromptToolSettings" (id, "companyId", "promptId", "toolName", enabled, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Prompts; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Prompts" (id, name, "apiKey", prompt, "maxTokens", "maxMessages", temperature, "promptTokens", "completionTokens", "totalTokens", voice, "voiceKey", "voiceRegion", "queueId", "companyId", "createdAt", "updatedAt", model, provider, "knowledgeBase") FROM stdin;
\.


--
-- Data for Name: QueueIntegrations; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."QueueIntegrations" (id, type, name, "projectName", "jsonContent", language, "createdAt", "updatedAt", "urlN8N", "companyId", "typebotExpires", "typebotKeywordFinish", "typebotUnknownMessage", "typebotSlug", "typebotDelayMessage", "typebotKeywordRestart", "typebotRestartMessage") FROM stdin;
2   webhook Douglas7702 Douglas7702         2025-10-28 21:36:28.51+00   2025-10-28 21:36:28.51+00   https://run-time.botbusiness.net/gupshup/bf9cca9c-df8a-41f9-8570-82ced4f79dd4   \N  0               1000        
4   webhook tgd tgd         2025-12-12 18:53:28.013+00  2025-12-12 18:53:28.013+00  fsgsdfgsdf  \N  0               1000        
6   flowbuilder teste   teste           2026-01-07 19:54:15.318+00  2026-01-07 19:54:53.157+00      \N  0               1000        
13  flowbuilder flowbuilder flowbuilder         2026-02-06 21:35:40.663+00  2026-02-06 21:35:40.663+00      1   0               1000        
8   flowbuilder Integracao1 Integracao1         2026-01-25 23:29:55.579+00  2026-01-25 23:29:55.579+00      \N  0               1000        
9   webhook Webhook-InstaLider  Webhook-InstaLider          2026-01-27 02:15:37.861+00  2026-01-27 02:15:37.861+00  https://app.faedeveloper.com.br/    \N  0               1000        
7   flowbuilder flow    flow            2026-01-16 06:22:17.209+00  2026-01-16 06:22:17.209+00      \N  0               1000        
12  flowbuilder teste1  teste1          2026-02-04 02:34:55.883+00  2026-02-04 02:34:55.883+00      \N  0               1000        
10  flowbuilder Menu Principal  Menu Principal          2026-02-03 22:56:16.009+00  2026-02-03 22:56:16.009+00      \N  0               1000        
\.


--
-- Data for Name: QueueOptions; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."QueueOptions" (id, title, message, option, "queueId", "parentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Queues; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Queues" (id, name, color, "greetingMessage", "createdAt", "updatedAt", "companyId", schedules, "outOfHoursMessage", "orderQueue", "tempoRoteador", "ativarRoteador", "integrationId", "fileListId", "closeTicket") FROM stdin;
\.


--
-- Data for Name: QuickMessages; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."QuickMessages" (id, shortcode, message, "companyId", "createdAt", "updatedAt", "userId", "mediaPath", "mediaName", geral, visao) FROM stdin;
3   Pix Pix CNPJ:\n62.346.848/0001-24   1   2025-11-24 23:36:52.958+00  2026-01-21 12:09:10.268+00  1   \N  \N  f   t
4   SaaS Whitelabel Valores 💸 Valores atualizados:\n\n💚 Para quem já tem o sistema: De R$ 450,00 por 197,00\n\n⚙️ Se você quiser que eu atualize para você: De R$ 600,00 por 397,00\n\n🚀 Ferramenta completa para quem ainda não tem: De R$ 900,00 por 650,00\n\n👑 Versão completa + 1 ano de atualizações grátis: De R$ 1.997,00 950,00    1   2025-11-25 04:07:29.343+00  2026-01-24 02:00:56.89+00   1   \N  \N  t   t
8   Teste Sistema whatelabel    👉 Acesse e teste agora:\nhttps://app.faedeveloper.com.br/cadastro \n\nCrie sua conta e teste por 24h sem compromisso 😉\n    1   2025-12-15 22:54:30.132+00  2026-01-31 08:08:29.395+00  1   \N  \N  f   t
6   SaaS Whitelabel 🔒 Funcionalidade White Label – Seu SaaS com a Sua Marca\n\nCom a funcionalidade White Label, você transforma a plataforma em um sistema 100% seu, operando com a sua marca, seu domínio e suas regras de negócio.\n\nNa prática, isso significa que todo o código do sistema roda no servidor vinculado ao seu domínio, garantindo mais controle, segurança e profissionalismo. Seus clientes acessam a plataforma diretamente pelo endereço da sua empresa, sem qualquer referência a terceiros.\n\n🚀 O que você pode fazer com o White Label?\n\nUtilizar o sistema internamente na sua empresa\n\nOu revender como um SaaS de Chatbot e Atendimento, com total autonomia\n\nDentro da plataforma, você pode:\n\nCriar planos e assinaturas personalizadas\n\nDefinir valores, limites e recursos por plano\n\nGerenciar cobranças recorrentes\n\nAtivar ou desativar funcionalidades conforme o plano contratado\n\nOferecer o sistema como produto próprio no modelo SaaS\n\n🤖 Plataforma de Chatbot SaaS Completa\n\nSeu sistema White Label inclui:\n\nChatbots inteligentes\n\nAutomações de WhatsApp\n\nAtendimento multiagente\n\nIntegrações\n\nPainel administrativo completo para gestão de clientes, planos e assinaturas\n\nTudo isso com a sua identidade visual, sua comunicação e seu posicionamento no mercado.\n\n💼 Ideal para quem quer escalar\n\nA solução White Label é perfeita para:\n\nAgências\n\nInfoprodutores\n\nEmpresas de tecnologia\n\nProfissionais que querem criar seu próprio SaaS de automação e atendimento\n\n👉 Você não vende uma ferramenta.\n👉 Você vende uma plataforma com a sua marca.   1   2025-12-14 21:48:23.74+00   2026-01-30 00:06:02.844+00  1   \N  \N  t   t
\.


--
-- Data for Name: ScheduledMessages; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."ScheduledMessages" (id, data_mensagem_programada, id_conexao, intervalo, valor_intervalo, mensagem, tipo_dias_envio, mostrar_usuario_mensagem, criar_ticket, contatos, tags, "companyId", nome, "createdAt", "updatedAt", "mediaPath", "mediaName", tipo_arquivo, usuario_envio, enviar_quantas_vezes) FROM stdin;
\.


--
-- Data for Name: ScheduledMessagesEnvios; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."ScheduledMessagesEnvios" (id, "createdAt", "updatedAt", "mediaPath", "mediaName", mensagem, "companyId", data_envio, scheduledmessages, key) FROM stdin;
\.


--
-- Data for Name: Schedules; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Schedules" (id, body, "sendAt", "sentAt", "contactId", "ticketId", "userId", "companyId", "createdAt", "updatedAt", status, "ticketUserId", "whatsappId", "statusTicket", "queueId", "openTicket", "mediaName", "mediaPath", intervalo, "valorIntervalo", "enviarQuantasVezes", "tipoDias", "contadorEnvio", assinar, "googleEventId") FROM stdin;
\.


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."SequelizeMeta" (name) FROM stdin;
20200717133438-create-users.js
20200717144403-create-contacts.js
20200717145643-create-tickets.js
20200717151645-create-messages.js
20200717170223-create-whatsapps.js
20200723200315-create-contacts-custom-fields.js
20200723202116-add-email-field-to-contacts.js
20200730153237-remove-user-association-from-messages.js
20200730153545-add-fromMe-to-messages.js
20200813114236-change-ticket-lastMessage-column-type.js
20200901235509-add-profile-column-to-users.js
20200903215941-create-settings.js
20200904220257-add-name-to-whatsapp.js
20200906122228-add-name-default-field-to-whatsapp.js
20200906155658-add-whatsapp-field-to-tickets.js
20200919124112-update-default-column-name-on-whatsappp.js
20200927220708-add-isDeleted-column-to-messages.js
20200929145451-add-user-tokenVersion-column.js
20200930162323-add-isGroup-column-to-tickets.js
20200930194808-add-isGroup-column-to-contacts.js
20201004150008-add-contactId-column-to-messages.js
20201004155719-add-vcardContactId-column-to-messages.js
20201004955719-remove-vcardContactId-column-to-messages.js
20201026215410-add-retries-to-whatsapps.js
20201028124427-add-quoted-msg-to-messages.js
20210108001431-add-unreadMessages-to-tickets.js
20210108164404-create-queues.js
20210108164504-add-queueId-to-tickets.js
20210108174594-associate-whatsapp-queue.js
20210108204708-associate-users-queue.js
20210109192513-add-greetingMessage-to-whatsapp.js
20210109192514-create-companies-table.js
20210109192515-add-column-companyId-to-Settings-table.js
20210109192516-add-column-companyId-to-Users-table.js
20210109192517-add-column-companyId-to-Contacts-table.js
20210109192518-add-column-companyId-to-Messages-table.js
20210109192519-add-column-companyId-to-Queues-table.js
20210109192520-add-column-companyId-to-Whatsapps-table.js
20210109192521-add-column-companyId-to-Tickets-table.js
20210109192522-create-plans-table.js
20210109192523-add-column-amount-to-Plan.js
20210109192523-add-column-planId-to-Companies.js
20210109192523-add-column-status-and-schedules-to-Companies.js
20210109192523-create-ticket-notes.js
20210109192524-create-quick-messages.js
20210109192525-add-column-complationMessage-to-whatsapp.js
20210109192526-add-column-outOfHoursMessage-to-whatsapp .js
20210109192527-add-column-super-to-Users-table.js
20210109192528-change-column-message-to-quick-messages-table.js
20210109192529-create-helps.js
20210109192531-create-TicketTracking-table.js
20210109192532-add-column-online-to-Users-table.js
20210109192533-create-UserRatings-table.js
20210109192534-add-rated-to-TicketTraking.js
20210109192536-add-unique-constraint-to-Tickets-table.js
20210818102606-add-uuid-to-tickets.js
20210818102607-remove-unique-indexes-to-Queues-table.js
20210818102608-add-unique-indexes-to-Queues-table.js
20210818102609-add-token-to-Whatsapps.js
20211017014719-create-chatbots.js
20211017014721-create-dialog-chatbot.js
20211205164404-create-queue-options.js
20211212125704-add-chatbot-to-tickets.js
20211227010200-create-schedules.js
20212016014719-add-bot-ticket.js
20212016014719-add-queueId-dialog.js
20220115114088-add-column-userId-to-QuickMessages-table.js
20220117130000-create-tags.js
20220117134400-associate-tickets-tags.js
20220122160900-add-status-to-schedules.js
20220220014719-add-farewellMessage-to-whatsapp.js
20220221014717-add-provider-whatsapp.js
20220221014718-add-remoteJid-messages.js
20220221014719-add-jsonMessage-messages.js
20220221014720-add-participant-messages.js
20220221014721-create-baileys.js
20220315110000-create-ContactLists-table.js
20220315110001-create-ContactListItems-table.js
20220315110002-create-Campaigns-table.js
20220315110004-create-CampaignSettings-table.js
20220315110005-remove-constraint-to-Settings.js
20220321130000-create-CampaignShipping.js
20220404000000-add-column-queueId-to-Messages-table.js
20220406000000-add-column-dueDate-to-Companies.js
20220406000001-add-column-recurrence-to-Companies.js
20220411000000-add-column-startTime-and-endTime-to-Queues.js
20220411000001-remove-column-startTime-and-endTime-to-Queues.js
20220411000002-add-column-schedules-and-outOfHoursMessage-to-Queues.js
20220411000003-create-table-Announcements.js
20220425000000-create-table-Chats.js
20220425000001-create-table-ChatUsers.js
20220425000002-create-table-ChatMessages.js
20220512000001-create-Indexes.js
20220723000001-add-mediaPath-to-quickmessages.js
20220723000002-add-mediaName-to-quickemessages.js
20220723000003-add-geral-to-quickmessages.js
20221123155118-add-acceptAudioMessages-to-contact.js
20221227164300-add-colunms-document-and-paymentMethod-to-companies-table.js
20221229000000-add-column-number-to-Whatsapps.js
20222016014719-add-channel-session.js
20222016014719-add-channel-to-contacts.js
20222016014719-add-channel-to-ticket.js
20222016014719-add-channel-token.js
20222016014719-add-channel-tokenUser.js
20222016014719-add-facebookPageUserId-whatsapp.js
20222016014719-add-facebookUserId-whatsapp.js
20222016014719-add-isAgent-chatbot.js
20230105164900-add-useFacebook-Plans.js
20230105164900-add-useInstagram-Plans.js
20230105164900-add-useWhatsapp-Plans.js
20230106164900-add-useCampaigns-Plans.js
20230106164900-add-useExternalApi-Plans.js
20230106164900-add-useInternalChat-Plans.js
20230106164900-add-useSchedules-Plans.js
20230110072000-create-integrations.js
20230119000002-create-subscriptions.js
20230119000003-create-invoices.js
20230120000000-create-ApiUsage.js
20230123155600-add-colunms-lastLogin-to-companies-table.js
20230124110200-add-endWork-Users.js
20230124110200-add-startWork-Users.js
20230127091500-add-column-active-to-Contacts.js
20230216173900-add-uuid-extension.js
20230301110200-add-color-Users.js
20230301110201-add-farewellMessage-Users.js
20230303223000-add-maxUseBotQueues-to-whatsapp copy.js
20230303223001-add-amountUsedBotQueues-to-tickets.js
20230403193000-add-disable-bot-column-to-contacts.js
20230403193000-add-expiresTicket-fields-to-whatsapp.js
20230411131007-add-allowGroup-whatsapp.js
20230505221007-add-closedAt-TicketTraking.js
20230517221007-add-optQueueId-Chatbots.js
20230517221007-add-optUserId-chatbots.js
20230517221007-add-queueType-Chatbots.js
20230603212335-create-QueueIntegrations.js
20230603212337-add-QueueIntegrations-integrationId-Chatbots.js
20230603212337-add-urlN8N-QueueIntegrations.js
20230612221007-add-remoteJid-Contact.js
20230623095932-add-whatsapp-to-user.js
20230623113000-add-timeUseBotQueues-to-whatsapp.js
20230623133903-add-chatbotAt-ticket-tracking.js
20230626141100-add-column-ticketTrakingId-to-Messages-table.js
20230628134807-add-orderQueue-Queue.js
20230630150600-create-associate-contacttags.js
20230703221100-add-column-queueId-to-TicketTraking-table.js
20230704124428-update-messages.js
20230707221100-add-column-isPrivate-to-Message-table.js
20230708192530-add-unique-constraint-to-Contacts-table.js
20230711080001-create-Index-Message-wid.js
20230711094417-add-column-companyId-to-QueueIntegrations-table.js
20230711111700-add-timeSendQueue-to-whatsapp.js
20230711111701-add-sendIdQueue-to-whatsapp.js
20230713131510-add-tempoRoteador-Queue.js
20230714113901-create-Files.js
20230714113902-create-fileOptions.js
20230716229907-add-ativaRoteador-Queue.js
20230717113705-add-isEdited-to-messages.js
20230717221007-add-optFileId-chatbots.js
20230723301001-add-kanban-to-Tags.js
20230724111007-add-collumns-whatsapp.js
20230724192535-add-column-ratingMessage-to-whatsapp.js
20230726203900-add-allTickets-user.js
20230731214345-create-table-webhooks.js
20230731224345-add-active-table-webhooks.js
20230731331007-add-lgpdAccept-Contact.js
20230808141907-add-collumns-Users.js
20230809081007-add-import-old-messages-to-whatsapp.js
20230809081007-add-import-recent-messages-to-whatsapp.js
20230809081008-add-status-import-to-whatsapp.js
20230809081009-add-closed-tickets-post-imported-to-whatsapp.js
20230809081010-add-import-old-messages-groups-to-whatsapp.js
20230809081011-add-imported-to-tickets.js
20230809081012-change-name-unique-false-to-whatsapp.js
20230810224345-add-company-table-webhooks.js
20230810234345-add-company-table-flowbuilder.js
20230813114236-change-ticket-lastMessage-column-type.js
20230816212401-add-timeCreateNewTicket-to-whatsapp.js
20230823082607-add-urlPicture-Contact.js
20230823114236-add-column-flow-and-location.js
20230823124236-add-column-data.js
20230823134236-add-column-hashflow.js
20230824082607-add-mediaType-FilesOptions.js
20230824134719-add-greetingMediaAtachmentToWhatsapp.js
20230825080921-add-profile-image-to-user.js
20230922212337-add-integrationId-Queues.js
20230922214345-create-table-flow-default.js
20231019113637-add-columns-Campaign.js
20231220080937-add-columns-Whatsapps.js
20231220223517-add-column-whatsappId-to-Contacts.js
20231221080937-change-collectiveVacationMessage-Whatsapps.js
20231229214537-add-defaultTicketsManagerWidth-Users.js
20232010133900-create-Partners-table.js
20240102230240-create-ScheduledMessages.js
20240102230240-create-ScheduledMessagesEnvio.js
20240102230241-create-ContactGroup.js
20240111080937-change-profilePicUrl-contacts.js
20240125080937-change-urlPicture-contacts.js
20240212113637-add-recorrencia-Schedules.js
20240311125600-add-colunms-folderSize-to-companies-table.js
20240322143411-add-queueIdImportMessage-to-whatsapps.js
20240323220001-create-companyId-Index-Message.js
20230801081907-add-collumns-Ticket.js
20230802214345-create-table-flowbuilder.js
20230828143411-add-Integrations-to-tickets.js
20230828143411-add-isOutOfHour-to-tickets.js
20230828144000-create-prompts.js
20230828144100-add-column-promptid-into-whatsapps.js
20230829214345-create-table-imgs-flow.js
20230831093000-add-useKanban-Plans.js
20230901101300-create-CompaniesSettings.js
20230901214345-create-table-audios-flow.js
20230902082607-add-pictureUpdate-Contact.js
20230904214345-create-table-campaign-flow.js
20230905114236-add-column-flow-now.js
20230911113900-add-unaccent-extension.js
20230911143705-add-isForwarded-to-messages.js
20230912112028-insert-CompanieSettings.js
20230913210007-create-table-LogTickets.js
20230915212800-add-public-to-plans.js
20230923000001-create-Indexes-new.js
20230923124428-update-tickets.js
20230924212337-add-fileListId-Queues.js
20230925112401-create-Indexes Tickets.js
20231128123537-add-typebot-QueueIntegrations.js
20231201123411-add-closeTicketOnTransfer-to-CompaniesSettings.js
20231202143411-add-typebotSessionId-to-tickets.js
20231207080337-add-typebotDelayMessage-QueueIntegrations.js
20231207085011-add-typebotStatus-to-tickets.js
20231218160937-add-columns-QueueIntegrations.js
20230807081007-add-lgpdAccept-Ticket.js
20230808135401-add-groupAsTicket-to-whatsapp.js
20230925212337-add-closeTicket-Queues-Chatbots.js
20230926143705-add-isGroup-to-ContactListItems.js
20231008145702-add-column-schedules-to-Whatsapps.js
20231016214537-add-allHistoric-users.js
20240202110037-add-collumns-custommessages-settings.js
20240206110037-add-linkInvoice-to-Invoices.js
20231019113637-add-columns-Schedules.js
20231020125000-add-columns-Plans.js
20231103230445-change-collumn-expiresInactiveMessage.js
20231105221305-add-visao-to-quickMessages.js
20231110214537-add-allUserChat-users.js
20231111185822-add_reset_password_column.js
20231114113637-add-openTicket-Campaign.js
20231114113637-add-openTicket-Schedules.js
20231117000001-add-mediaName-to-schedules.js
20231117000001-add-mediaPath-to-schedules.js
20231121143411-add-isActiveDemand-to-tickets.js
20231122193355-create-table-wallets-contact.js
20231122223411-add-DirectTicketsToWallets-to-CompaniesSettings.js
20231127113000-add-columns-Plans.js
20231213214537-add-permissions-users.js
20240308133648-add-columns-to-Tags.js
20240308133648-add-rollbackLaneId-to-Tags.js
20240422214537-add-permissions-users.js
20240425223411-add-showNotificationPending-to-CompaniesSettings.js
20240425225011-add-typebotSsessionTime-to-tickets.js
20240515221400-create-Versions.js
20240516112028-insert-version.js
20240523083535-create-index.js
20240610083535-create-index.js
20240718030548-add-column-flowIdNotPhrase-to-whatsapp.js
20240718084127-recriate-constraint-integracoes.js
20240719130841-add-column-flowIdWelcome-to-whatsapp.js
20240719174849-add-column-whatsappId-to-flowCampaigns.js
20240924171945-add-variables-column-to-flowbuilders.js
20250124140438-add-wavoip-to-whatsapp.js
20250127132448-add-column-notificameHub-to-CompaniesSettings-table.js
20250127171400-change_message_id_type_from_Messages.js
20250128161327-add-column-notificameHub-to-Whatsapps-table.js
20250914174400-add-provider-model-to-prompts.js.js
20251114003000-create-Negocios-table.js
20251215031800-add-productsSent-to-tickets.js
20241201000000-create-mobile-webhooks.js
20251119083000-create-Produtos-table.js
20251119083500-create-Ferramentas-table.js
20251123190000-create-table-google-calendar-integrations.js
20251123190500-add-column-googleEventId-to-schedules.js
20251125003000-add-extra-fields-to-contacts.js
20251125030500-create-slider-banners.js
20251126010000-create-faturas.js
20251126155000-add-lid-column-to-contacts.js
20251129000000-create-ia-workflows.js
20251203020000-add-video-url-to-tutorial-videos.js
20251204150000-create-slider-home.js
20251205160000-create-profissionais-servicos.js
20251205163000-create-prompt-tool-settings.js
20251214012800-create-automations.js
20251216090000-create-crm-leads.js
20251216090500-create-crm-clients.js
20251216092000-create-financeiro-faturas.js
20251216092500-create-financeiro-pagamentos.js
20251216093000-add-valor-pago-to-financeiro-faturas.js
20251218133500-link-leads-clients-contacts.js
20251219050000-create-media-folders.js
20251219051000-create-media-files.js
20251222170500-create-company-payment-settings.js
20251222171000-add-payment-fields-financeiro-faturas.js
20251222171500-add-asaas-customer-id-to-crm-clients.js
20251222172000-add-checkout-token-to-financeiro-faturas.js
20251223100000-create-company-integration-settings.js
20251223100500-create-company-integration-field-maps.js
20251223103000-create-company-api-keys.js
20251224130000-fix-company-payment-settings-columns.js
20251224170000-create-scheduled-dispatchers.js
20251224170500-create-scheduled-dispatch-logs.js
20251229210000-add-lead-value-to-tickets.js
20251231230000-create-projects-table.js
20251231230100-create-project-services-table.js
20251231230200-create-project-products-table.js
20251231230300-create-project-users-table.js
20251231230400-create-project-tasks-table.js
20251231230500-create-project-task-users-table.js
20260101150000-add-project-id-to-financeiro-faturas.js
20260101160000-create-schedules.js
20260101160100-create-appointments.js
20260101173000-add-professional-fields-to-users.js
20260101173100-create-user-services.js
20260106193000-add-knowledgeBase-to-prompts.js
20260108195000-add-column-phrases-to-flowcampaigns.js
20260108195500-add-column-matchType-to-flowcampaigns.js
20260109215800-add-fromAgent-to-messages.js
20260109223800-add-userId-to-messages.js
20260110223300-add-lid-to-tickets.js
\.


--
-- Data for Name: Settings; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Settings" (key, value, "createdAt", "updatedAt", "companyId", id) FROM stdin;
userCreation    enabled 2025-10-10 02:50:00.272+00  2025-10-10 02:50:00.272+00  \N  1
hoursCloseTicketsAuto   9999999999  2025-10-10 02:50:00.274+00  2025-10-10 02:50:00.274+00  1   2
chatBotType text    2025-10-10 02:50:00.276+00  2025-10-10 02:50:00.276+00  1   3
acceptCallWhatsapp  enabled 2025-10-10 02:50:00.278+00  2025-10-10 02:50:00.278+00  1   4
userRandom  enabled 2025-10-10 02:50:00.28+00   2025-10-10 02:50:00.28+00   1   5
sendGreetingMessageOneQueues    enabled 2025-10-10 02:50:00.282+00  2025-10-10 02:50:00.282+00  1   6
sendSignMessage enabled 2025-10-10 02:50:00.284+00  2025-10-10 02:50:00.284+00  1   7
sendFarewellWaitingTicket   disabled    2025-10-10 02:50:00.288+00  2025-10-10 02:50:00.288+00  1   8
userRating  disabled    2025-10-10 02:50:00.29+00   2025-10-10 02:50:00.29+00   1   9
sendGreetingAccepted    enabled 2025-10-10 02:50:00.291+00  2025-10-10 02:50:00.291+00  1   10
CheckMsgIsGroup enabled 2025-10-10 02:50:00.293+00  2025-10-10 02:50:00.293+00  1   11
sendQueuePosition   enabled 2025-10-10 02:50:00.294+00  2025-10-10 02:50:00.294+00  1   12
scheduleType    disabled    2025-10-10 02:50:00.296+00  2025-10-10 02:50:00.296+00  1   13
acceptAudioMessageContact   enabled 2025-10-10 02:50:00.297+00  2025-10-10 02:50:00.297+00  1   14
enableLGPD  disabled    2025-10-10 02:50:00.299+00  2025-10-10 02:50:00.299+00  1   15
requiredTag disabled    2025-10-10 02:50:00.3+00    2025-10-10 02:50:00.3+00    1   16
wtV disabled    2025-10-10 02:50:00.303+00  2025-10-10 02:50:00.303+00  \N  18
asaas       2025-10-10 02:50:00.342+00  2025-10-10 02:50:00.342+00  1   19
efichavepix     2025-10-10 02:50:00.342+00  2025-10-10 02:50:00.342+00  1   20
eficlientid     2025-10-10 02:50:00.342+00  2025-10-10 02:50:00.342+00  1   21
eficlientsecret     2025-10-10 02:50:00.342+00  2025-10-10 02:50:00.342+00  1   22
mpaccesstoken       2025-10-10 02:50:00.342+00  2025-10-10 02:50:00.342+00  1   23
stripeprivatekey        2025-10-10 02:50:00.342+00  2025-10-10 02:50:00.342+00  1   24
asaastoken      2025-10-10 02:50:00.342+00  2025-10-10 02:50:00.342+00  1   25
downloadLimit   2048    2025-10-10 02:50:00.302+00  2025-10-11 05:07:50.687+00  1   17
userCreation    enabled 2025-10-11 05:07:54.188+00  2025-10-11 05:07:54.188+00  1   31
backendUrl  https://api.faedeveloper.com.br 2026-01-13 05:52:38.638+00  2026-01-13 05:52:38.638+00  1   57
frontendUrl https://app.faedeveloper.com.br 2026-01-13 05:52:49.348+00  2026-01-13 05:52:49.348+00  1   58
smtpPort    465 2026-01-09 22:13:39.735+00  2026-01-09 22:13:39.735+00  1   48
appLogoLight    cropped-logoAtendzappy.webp 2025-10-10 03:39:23.927+00  2025-12-03 23:24:24.597+00  1   29
openaikeyaudio      2025-10-10 02:50:00.342+00  2025-12-27 19:05:44.374+00  1   26
appName Atend Zappy 2025-10-10 03:39:16.401+00  2026-01-09 19:56:45.928+00  1   28
termsImage      2026-01-09 20:37:29.673+00  2026-01-09 20:55:54.917+00  1   39
appLogoFavicon  iconhygeia.png  2025-10-10 03:39:27.943+00  2026-01-26 06:39:26.114+00  1   30
welcomeEmailText    🎉 Seja muito bem-vindo(a), Atend Zappy!\n\nÉ um prazer ter você com a gente! 🚀\nA empresa {empresa} acabou de ser cadastrada com sucesso em nossa plataforma, e agora você já pode aproveitar todos os recursos disponíveis para facilitar sua gestão e crescimento.\n\n📌 Seus dados de acesso:\n\nE-mail: {email}\n\nTelefone: {telefone}\n\nPlano: {plano}\n\nSenha: {senha}\n\nLink de acesso: https://app.faedeveloper.com.br\n\n⏳ Você possui {diasTeste} dias de teste para explorar a plataforma sem compromisso e descobrir tudo o que ela pode fazer pelo seu negócio.\n\nSe precisar de ajuda, tiver dúvidas ou quiser evoluir para um plano definitivo, nosso suporte está sempre pronto para te atender. 💬\n\nDesejamos muito sucesso nessa nova etapa e conte conosco! 💙\nEquipe Atend Zappy   2026-01-09 21:49:20.849+00  2026-02-02 01:43:43.66+00   1   41
welcomeWhatsappText 🎉 Seja muito bem-vindo(a), Atend Zappy!\n\nÉ um prazer ter você com a gente! 🚀\nA empresa {empresa} acabou de ser cadastrada com sucesso em nossa plataforma, e agora você já pode aproveitar todos os recursos disponíveis para facilitar sua gestão e crescimento.\n\n📌 Seus dados de acesso:\n\nE-mail: {email}\n\nTelefone: {telefone}\n\nPlano: {plano}\n\nSenha: {senha}\n\n⏳ Você possui {diasTeste} dias de teste para explorar a plataforma sem compromisso e descobrir tudo o que ela pode fazer pelo seu negócio.\n\nSe precisar de ajuda, tiver dúvidas ou quiser evoluir para um plano definitivo, nosso suporte está sempre pronto para te atender. 💬\n\nDesejamos muito sucesso nessa nova etapa e conte conosco! 💙\nEquipe Atend Zappy  2026-01-09 21:49:31.841+00  2026-01-20 19:04:56.644+00  1   42
termsText   1. ACEITAÇÃO DOS TERMOS\n\n1.1. Estes Termos de Uso ("Termos") regem o uso do sistema web, disponibilizado pela Empresa Atend Zappy.\n1.2. Ao acessar ou utilizar o Sistema, o usuário concorda em cumprir estes Termos. Caso não concorde, deve cessar o uso do Sistema imediatamente.\n\n2. LICENÇA DE USO\n\n2.1. O Licenciante concede ao Usuário uma licença limitada, não exclusiva, intransferível e revogável para uso do Sistema de acordo com estes Termos.\n2.2. O Usuário não poderá modificar, distribuir, vender, alugar, sublicenciar ou realizar engenharia reversa sobre o Sistema, salvo quando expressamente permitido por lei.\n\n3. DIREITOS AUTORAIS E PROPRIEDADE INTELECTUAL\n\n3.1. O Sistema, incluindo código-fonte, design, logotipos e demais conteúdos, é protegido por leis de direitos autorais e outras leis de propriedade intelectual.\n3.2. Nenhuma parte do Sistema poderá ser copiada, reproduzida ou utilizada sem a autorização expressa do Licenciante.\n3.3. O Licenciante detém todos os direitos, títulos e interesses relacionados ao Sistema.\n\n4. ACESSO E DISPONIBILIDADE\n\n4.1. O Licenciante se esforçará para manter o Sistema disponível de forma contínua, mas não garante que o acesso será ininterrupto ou livre de erros.\n4.2. O Usuário reconhece que o acesso ao Sistema pode ser temporariamente interrompido para manutenção, atualizações ou fatores externos.\n\n5. ATUALIZAÇÕES E MODIFICAÇÕES\n\n5.1. O Licenciante poderá, a seu critério, fornecer atualizações e melhorias no Sistema, sendo que algumas funcionalidades podem ser alteradas ou descontinuadas sem aviso prévio.\n5.2. O Usuário deve manter-se informado sobre as atualizações para garantir sua funcionalidade adequada.\n\n6. RESPONSABILIDADES DO USUÁRIO\n\n6.1. O Usuário se compromete a utilizar o Sistema de forma lícita e em conformidade com estes Termos.\n6.2. O Licenciante não se responsabiliza por qualquer dano decorrente do uso indevido do Sistema pelo Usuário.\n6.3. O Usuário é responsável por manter a segurança de suas credenciais de acesso e por todas as atividades realizadas em sua conta.\n\n7. LIMITAÇÃO DE RESPONSABILIDADE\n\n7.1. O Sistema é fornecido, com garantias de uso e funcionalidades, expressas ou implícitas.\n7.2. O Licenciante não será responsável por quaisquer danos diretos, indiretos, incidentais ou consequentes resultantes do uso ou impossibilidade de uso do Sistema.\n\n8. CONTATO\n\nPara dúvidas ou esclarecimentos, o Usuário pode entrar em contato com o Licenciante pelo e-mail sac@atendzappy.com.br\n ou pelo WhatsApp +55 24 3354-0335.\n\nÚltima atualização: 07-01-2026  2026-01-09 20:24:45.712+00  2026-01-26 07:10:50.072+00  1   38
dashboardImage3     2026-01-26 07:01:13.025+00  2026-01-26 07:27:40.244+00  1   81
dashboardImage2     2026-01-26 07:01:07.247+00  2026-01-26 07:27:41.618+00  1   80
smtpHost        2026-01-09 21:49:34.816+00  2026-02-06 21:38:35.714+00  1   44
smtpFrom        2026-01-09 21:49:33.404+00  2026-02-06 21:38:36.811+00  1   43
smtpPass        2026-01-09 21:49:38.364+00  2026-02-06 21:38:38.679+00  1   46
smtpUser        2026-01-09 21:49:36.109+00  2026-02-06 21:38:41.435+00  1   45
geminiApiKey        2026-01-13 05:45:29.982+00  2026-02-06 21:38:42.914+00  1   53
openaiApiKey        2026-01-13 05:45:27.749+00  2026-02-06 21:38:45.145+00  1   52
verifyToken     2026-01-13 05:52:13.47+00   2026-02-06 21:38:46.943+00  1   56
facebookAppId       2026-01-13 05:51:50.179+00  2026-02-06 21:38:48.416+00  1   54
facebookAppSecret       2026-01-13 05:52:01.032+00  2026-02-06 21:38:51.266+00  1   55
googleRedirectUri       2026-01-13 05:53:29.911+00  2026-02-06 21:38:52.922+00  1   61
googleClientSecret      2026-01-13 05:53:20.664+00  2026-02-06 21:38:54.188+00  1   60
googleClientId      2026-01-13 05:53:06.729+00  2026-02-06 21:38:58.372+00  1   59
trialDays   3   2026-01-09 21:49:19.965+00  2026-02-06 21:39:04.943+00  1   40
dashboardImage1     2026-01-26 07:01:02.159+00  2026-01-26 07:31:03.886+00  1   79
appLogoLoading  iconhygeia.png  2026-01-30 13:37:23.913+00  2026-01-30 13:37:23.913+00  1   85
primaryColorLight   #1E1F20 2025-10-10 03:39:07.034+00  2026-02-06 08:42:44.909+00  1   27
\.


--
-- Data for Name: SliderBanners; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."SliderBanners" (id, image, url, "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Subscriptions; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Subscriptions" (id, "isActive", "expiresAt", "userPriceCents", "whatsPriceCents", "lastInvoiceUrl", "lastPlanChange", "companyId", "providerSubscriptionId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Tags; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Tags" (id, name, color, "companyId", "createdAt", "updatedAt", kanban, "timeLane", "nextLaneId", "greetingMessageLane", "rollbackLaneId") FROM stdin;
\.


--
-- Data for Name: TicketNotes; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."TicketNotes" (id, note, "userId", "contactId", "ticketId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TicketTags; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."TicketTags" ("ticketId", "tagId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TicketTraking; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."TicketTraking" (id, "ticketId", "companyId", "whatsappId", "userId", "createdAt", "updatedAt", "queuedAt", "startedAt", "finishedAt", "ratingAt", rated, "closedAt", "chatbotAt", "queueId") FROM stdin;
1050    \N  1   \N  1   2025-12-17 03:44:26.849+00  2025-12-17 04:44:04.986+00  2025-12-17 03:44:50.33+00   2025-12-17 03:44:36.428+00  2025-12-17 04:44:04.976+00  \N  f   2025-12-17 04:44:04.976+00  \N  \N
235 \N  1   \N  \N  2025-11-13 10:56:11.552+00  2025-11-13 14:45:15.018+00  2025-11-13 14:45:15.007+00  \N  \N  \N  f   \N  \N  \N
180 \N  1   \N  \N  2025-11-13 02:03:53.355+00  2025-11-13 02:20:14.575+00  2025-11-13 02:05:27.329+00  \N  2025-11-13 02:20:14.571+00  \N  f   2025-11-13 02:20:14.571+00  \N  \N
228 \N  1   \N  1   2025-11-13 05:45:24.012+00  2025-11-13 05:52:17.388+00  2025-11-13 05:47:43.886+00  2025-11-13 05:47:43.895+00  2025-11-13 05:52:17.384+00  \N  f   2025-11-13 05:52:17.384+00  \N  \N
219 \N  1   \N  1   2025-11-13 05:18:24.394+00  2025-11-13 05:19:23.533+00  2025-11-13 05:18:44.165+00  2025-11-13 05:18:44.176+00  2025-11-13 05:19:23.531+00  \N  f   2025-11-13 05:19:23.531+00  \N  \N
239 \N  1   \N  1   2025-11-13 13:06:13.128+00  2025-11-13 16:54:48.299+00  2025-11-13 16:51:10.225+00  2025-11-13 16:51:10.233+00  2025-11-13 16:54:48.296+00  \N  f   2025-11-13 16:54:48.296+00  \N  \N
1149    \N  1   \N  1   2026-01-02 23:41:47.16+00   2026-01-03 04:17:41.23+00   2026-01-02 23:43:17.876+00  2026-01-02 23:43:17.883+00  2026-01-03 04:17:41.225+00  \N  f   2026-01-03 04:17:41.225+00  \N  \N
1175    \N  1   \N  1   2026-01-03 19:06:02.511+00  2026-01-08 23:52:49.306+00  2026-01-08 18:09:55.938+00  2026-01-03 19:15:50.968+00  2026-01-08 23:52:49.274+00  \N  f   2026-01-08 23:52:49.274+00  \N  \N
1059    \N  1   \N  1   2025-12-20 00:47:36.678+00  2025-12-22 17:17:41.623+00  2025-12-21 03:43:12.322+00  2025-12-20 00:49:02.848+00  2025-12-22 17:17:41.62+00   \N  f   2025-12-22 17:17:41.62+00   \N  \N
2049    \N  1   \N  1   2026-01-26 20:09:05.257+00  2026-02-06 08:33:54.371+00  2026-02-06 08:33:54.361+00  2026-01-26 20:19:32.894+00  \N  \N  f   \N  \N  \N
74  \N  1   \N  \N  2025-10-21 14:54:24.858+00  2025-10-21 15:17:13.191+00  \N  \N  2025-10-21 15:17:13.185+00  \N  f   2025-10-21 15:17:13.185+00  \N  \N
182 \N  1   \N  \N  2025-11-13 02:08:16.128+00  2025-11-13 02:19:49.149+00  2025-11-13 02:08:39.839+00  \N  2025-11-13 02:19:49.146+00  \N  f   2025-11-13 02:19:49.146+00  \N  \N
271 \N  1   \N  1   2025-11-13 18:09:35.127+00  2025-11-13 18:09:44.319+00  2025-11-13 18:09:44.302+00  2025-11-13 18:09:44.314+00  \N  \N  f   \N  \N  \N
555 \N  1   \N  \N  2025-11-18 05:24:50.579+00  2025-11-18 05:40:09.248+00  2025-11-18 05:28:23.161+00  \N  2025-11-18 05:40:09.243+00  \N  f   2025-11-18 05:40:09.243+00  \N  \N
198 \N  1   \N  \N  2025-11-13 03:28:16.059+00  2025-11-13 03:30:25.621+00  2025-11-13 03:28:54.192+00  \N  2025-11-13 03:30:25.618+00  \N  f   2025-11-13 03:30:25.618+00  \N  \N
192 \N  1   \N  \N  2025-11-13 02:55:25.571+00  2025-11-13 02:55:48.036+00  2025-11-13 02:55:35.409+00  \N  2025-11-13 02:55:48.033+00  \N  f   2025-11-13 02:55:48.033+00  \N  \N
1040    \N  1   \N  1   2025-12-16 11:40:11.959+00  2025-12-16 12:15:47.521+00  2025-12-16 12:15:47.502+00  2025-12-16 12:15:47.512+00  \N  \N  f   \N  \N  \N
605 \N  1   \N  1   2025-11-19 23:08:45.57+00   2025-11-19 23:51:46.583+00  2025-11-19 23:18:21.466+00  2025-11-19 23:18:21.473+00  2025-11-19 23:51:46.571+00  \N  f   2025-11-19 23:51:46.571+00  \N  \N
1025    \N  1   \N  1   2025-12-15 22:34:32.045+00  2025-12-15 22:45:30.976+00  2025-12-15 22:45:30.958+00  2025-12-15 22:45:30.967+00  \N  \N  f   \N  \N  \N
203 \N  1   \N  \N  2025-11-13 04:04:57.467+00  2025-11-13 17:06:57.804+00  \N  \N  2025-11-13 17:06:57.778+00  \N  f   2025-11-13 17:06:57.778+00  \N  \N
400 \N  1   \N  1   2025-11-17 04:19:04.605+00  2025-11-17 04:19:04.613+00  \N  \N  2025-11-17 04:19:04.612+00  \N  f   2025-11-17 04:19:04.612+00  \N  \N
1423    \N  1   \N  1   2026-01-09 01:23:33.99+00   2026-01-09 02:20:20.116+00  2026-01-09 02:20:20.094+00  2026-01-09 02:20:20.104+00  \N  \N  f   \N  \N  \N
171 \N  1   \N  \N  2025-11-12 23:00:52.25+00   2025-11-13 08:14:41.85+00   2025-11-13 08:14:41.837+00  \N  \N  \N  f   \N  \N  \N
830 \N  1   \N  1   2025-11-27 06:29:05.258+00  2025-11-27 19:22:30.547+00  2025-11-27 06:46:08.856+00  2025-11-27 06:46:08.866+00  2025-11-27 19:22:30.545+00  \N  f   2025-11-27 19:22:30.545+00  \N  \N
1027    \N  1   \N  1   2025-12-15 23:02:56.427+00  2025-12-20 00:46:58.998+00  2025-12-15 23:11:05.222+00  2025-12-15 23:11:05.23+00   2025-12-20 00:46:58.988+00  \N  f   2025-12-20 00:46:58.988+00  \N  \N
2156    \N  1   \N  1   2026-01-30 23:04:30.927+00  2026-02-03 23:39:53.271+00  2026-02-03 23:39:53.26+00   2026-01-30 23:04:37.073+00  \N  \N  f   \N  \N  \N
2133    \N  1   \N  1   2026-01-30 18:00:26.88+00   2026-01-30 18:20:43.955+00  2026-01-30 18:20:43.944+00  2026-01-30 18:17:00.816+00  \N  \N  f   \N  \N  \N
2145    \N  1   \N  1   2026-01-30 20:17:29.351+00  2026-02-03 21:47:48.12+00   2026-02-03 21:47:48.109+00  2026-01-30 20:18:20.5+00    \N  \N  f   \N  \N  \N
2272    \N  1   \N  1   2026-02-05 09:45:41.112+00  2026-02-06 09:15:15.045+00  2026-02-06 09:15:15.033+00  2026-02-05 09:54:50.809+00  \N  \N  f   \N  \N  \N
2166    \N  1   \N  1   2026-01-31 07:52:23.024+00  2026-01-31 07:53:29.717+00  2026-01-31 07:53:29.696+00  2026-01-31 07:53:29.705+00  \N  \N  f   \N  \N  \N
2211    \N  1   \N  1   2026-02-01 08:50:00.662+00  2026-02-02 01:30:17.883+00  2026-02-02 00:26:30.697+00  2026-02-01 08:50:33.963+00  2026-02-02 01:30:17.879+00  \N  f   2026-02-02 01:30:17.879+00  \N  \N
399 \N  1   \N  \N  2025-11-17 04:18:40.876+00  2025-11-17 04:20:05.138+00  \N  \N  2025-11-17 04:20:05.136+00  \N  f   2025-11-17 04:20:05.136+00  \N  \N
124 \N  1   \N  \N  2025-10-28 19:30:16.562+00  2025-10-28 19:30:16.562+00  \N  \N  \N  \N  f   \N  \N  \N
253 \N  1   \N  \N  2025-11-13 16:56:40.294+00  2025-11-13 17:04:12.77+00   \N  \N  2025-11-13 17:04:12.767+00  \N  f   2025-11-13 17:04:12.767+00  \N  \N
115 \N  1   \N  \N  2025-10-27 18:24:29.997+00  2025-10-28 04:33:00.089+00  \N  \N  2025-10-28 04:33:00.081+00  \N  f   2025-10-28 04:33:00.081+00  \N  \N
545 \N  1   \N  \N  2025-11-18 04:30:38.208+00  2025-11-18 04:34:44.216+00  \N  \N  2025-11-18 04:34:44.214+00  \N  f   2025-11-18 04:34:44.214+00  \N  \N
280 \N  1   \N  \N  2025-11-13 18:29:44.57+00   2025-11-13 18:31:14.662+00  \N  \N  2025-11-13 18:31:14.66+00   \N  f   2025-11-13 18:31:14.66+00   \N  \N
217 \N  1   \N  \N  2025-11-13 04:35:21.948+00  2025-11-13 04:36:32.636+00  \N  \N  2025-11-13 04:36:32.633+00  \N  f   2025-11-13 04:36:32.633+00  \N  \N
185 \N  1   \N  \N  2025-11-13 02:26:29.48+00   2025-11-13 02:30:15.803+00  \N  \N  2025-11-13 02:30:15.8+00    \N  f   2025-11-13 02:30:15.8+00    \N  \N
195 \N  1   \N  \N  2025-11-13 03:10:08.407+00  2025-11-13 03:14:33.799+00  \N  \N  2025-11-13 03:14:33.79+00   \N  f   2025-11-13 03:14:33.791+00  \N  \N
566 \N  1   \N  \N  2025-11-19 01:38:20.028+00  2025-11-19 01:38:20.028+00  \N  \N  \N  \N  f   \N  \N  \N
188 \N  1   \N  1   2025-11-13 02:42:14.61+00   2025-11-13 02:42:52.33+00   \N  \N  2025-11-13 02:42:52.327+00  \N  f   2025-11-13 02:42:52.327+00  \N  \N
196 \N  1   \N  \N  2025-11-13 03:14:58.051+00  2025-11-13 03:18:44.874+00  \N  \N  2025-11-13 03:18:44.863+00  \N  f   2025-11-13 03:18:44.863+00  \N  \N
189 \N  1   \N  \N  2025-11-13 02:43:07.587+00  2025-11-13 02:43:10.376+00  \N  \N  2025-11-13 02:43:10.374+00  \N  f   2025-11-13 02:43:10.374+00  \N  \N
197 \N  1   \N  \N  2025-11-13 03:18:53.848+00  2025-11-13 03:28:03.462+00  \N  \N  2025-11-13 03:28:03.458+00  \N  f   2025-11-13 03:28:03.459+00  \N  \N
223 \N  1   \N  1   2025-11-13 05:32:15.158+00  2025-11-13 05:32:15.167+00  \N  \N  2025-11-13 05:32:15.165+00  \N  f   2025-11-13 05:32:15.165+00  \N  \N
225 \N  1   \N  1   2025-11-13 05:34:06.668+00  2025-11-13 05:34:06.681+00  \N  \N  2025-11-13 05:34:06.679+00  \N  f   2025-11-13 05:34:06.679+00  \N  \N
190 \N  1   \N  1   2025-11-13 02:43:40.402+00  2025-11-13 02:49:44.686+00  \N  \N  2025-11-13 02:49:44.684+00  \N  f   2025-11-13 02:49:44.684+00  \N  \N
295 \N  1   \N  1   2025-11-13 20:47:05.33+00   2025-11-13 20:50:56.701+00  2025-11-13 20:47:17.2+00    2025-11-13 20:47:17.206+00  2025-11-13 20:50:56.697+00  \N  f   2025-11-13 20:50:56.697+00  \N  \N
187 \N  1   \N  \N  2025-11-13 02:41:22.677+00  2025-11-13 02:42:04.615+00  2025-11-13 02:41:47.833+00  \N  2025-11-13 02:42:04.613+00  \N  f   2025-11-13 02:42:04.613+00  \N  \N
186 \N  1   \N  \N  2025-11-13 02:39:52.905+00  2025-11-13 02:41:18.025+00  2025-11-13 02:40:08.638+00  \N  2025-11-13 02:41:18.023+00  \N  f   2025-11-13 02:41:18.023+00  \N  \N
218 \N  1   \N  \N  2025-11-13 04:36:42.282+00  2025-11-13 05:18:12.999+00  2025-11-13 04:37:24.241+00  \N  2025-11-13 05:18:12.996+00  \N  f   2025-11-13 05:18:12.996+00  \N  \N
157 \N  1   \N  1   2025-11-05 13:20:56.947+00  2025-11-05 13:20:56.955+00  \N  \N  2025-11-05 13:20:56.953+00  \N  f   2025-11-05 13:20:56.953+00  \N  \N
290 \N  1   \N  \N  2025-11-13 20:40:53.592+00  2025-11-13 20:42:32.861+00  \N  \N  2025-11-13 20:42:32.859+00  \N  f   2025-11-13 20:42:32.859+00  \N  \N
193 \N  1   \N  \N  2025-11-13 03:07:46.939+00  2025-11-13 03:09:12.609+00  2025-11-13 03:09:04.299+00  \N  2025-11-13 03:09:12.607+00  \N  f   2025-11-13 03:09:12.607+00  \N  \N
200 \N  1   \N  \N  2025-11-13 03:41:37.225+00  2025-11-13 03:42:29.312+00  2025-11-13 03:42:09.31+00   \N  2025-11-13 03:42:29.309+00  \N  f   2025-11-13 03:42:29.309+00  \N  \N
201 \N  1   \N  \N  2025-11-13 03:42:46.719+00  2025-11-13 03:43:47.662+00  2025-11-13 03:42:57.316+00  \N  2025-11-13 03:43:47.659+00  \N  f   2025-11-13 03:43:47.66+00   \N  \N
221 \N  1   \N  1   2025-11-13 05:20:25.608+00  2025-11-13 05:31:55.936+00  2025-11-13 05:23:14.469+00  2025-11-13 05:23:14.479+00  2025-11-13 05:31:55.933+00  \N  f   2025-11-13 05:31:55.933+00  \N  \N
226 \N  1   \N  1   2025-11-13 05:34:25.505+00  2025-11-13 05:39:58.97+00   2025-11-13 05:39:29.843+00  2025-11-13 05:39:29.863+00  2025-11-13 05:39:58.967+00  \N  f   2025-11-13 05:39:58.967+00  \N  \N
183 \N  1   \N  \N  2025-11-13 02:20:25.807+00  2025-11-13 02:22:26.25+00   2025-11-13 02:21:41.776+00  \N  2025-11-13 02:22:26.248+00  \N  f   2025-11-13 02:22:26.248+00  \N  \N
184 \N  1   \N  \N  2025-11-13 02:22:30.937+00  2025-11-13 02:23:10.211+00  2025-11-13 02:22:52.428+00  \N  2025-11-13 02:23:10.208+00  \N  f   2025-11-13 02:23:10.208+00  \N  \N
191 \N  1   \N  \N  2025-11-13 02:50:37.276+00  2025-11-13 02:54:11.725+00  2025-11-13 02:51:40.909+00  \N  2025-11-13 02:54:11.721+00  \N  f   2025-11-13 02:54:11.721+00  \N  \N
194 \N  1   \N  \N  2025-11-13 03:09:19.126+00  2025-11-13 03:09:58.674+00  2025-11-13 03:09:29.365+00  \N  2025-11-13 03:09:58.672+00  \N  f   2025-11-13 03:09:58.672+00  \N  \N
238 \N  1   \N  1   2025-11-13 12:25:47.668+00  2025-11-13 17:20:39.793+00  2025-11-13 17:05:00.836+00  2025-11-13 17:05:00.845+00  2025-11-13 17:20:39.782+00  \N  f   2025-11-13 17:20:39.783+00  \N  \N
258 \N  1   \N  1   2025-11-13 17:21:24.179+00  2025-11-13 17:29:06.049+00  2025-11-13 17:21:55.335+00  2025-11-13 17:21:55.361+00  2025-11-13 17:29:06.044+00  \N  f   2025-11-13 17:29:06.045+00  \N  \N
254 \N  1   \N  \N  2025-11-13 16:57:36.329+00  2025-11-13 17:04:14.997+00  \N  \N  2025-11-13 17:04:14.994+00  \N  f   2025-11-13 17:04:14.994+00  \N  \N
1122    \N  1   \N  \N  2026-01-02 13:21:15.744+00  2026-01-02 13:21:15.744+00  \N  \N  \N  \N  f   \N  \N  \N
85  \N  1   \N  1   2025-10-22 04:00:03.484+00  2025-10-23 02:46:59.282+00  2025-10-22 19:09:28.86+00   2025-10-22 19:09:28.924+00  2025-10-23 02:46:59.274+00  \N  f   2025-10-23 02:46:59.274+00  \N  \N
250 \N  1   \N  1   2025-11-13 16:40:50.369+00  2025-11-13 17:04:38.066+00  2025-11-13 16:56:19.979+00  2025-11-13 16:56:19.987+00  2025-11-13 17:04:38.064+00  \N  f   2025-11-13 17:04:38.064+00  \N  \N
248 \N  1   \N  1   2025-11-13 15:30:32.374+00  2025-11-13 16:51:04.942+00  \N  \N  2025-11-13 16:51:04.939+00  \N  f   2025-11-13 16:51:04.939+00  \N  \N
1052    \N  1   \N  1   2025-12-17 04:47:28.109+00  2025-12-20 00:46:58.989+00  2025-12-17 05:24:28.123+00  2025-12-17 04:47:35.516+00  2025-12-20 00:46:58.98+00   \N  f   2025-12-20 00:46:58.98+00   \N  \N
296 \N  1   \N  1   2025-11-13 20:49:45.101+00  2025-11-13 20:50:56.702+00  \N  \N  2025-11-13 20:50:56.699+00  \N  f   2025-11-13 20:50:56.699+00  \N  \N
247 \N  1   \N  \N  2025-11-13 15:29:53.15+00   2025-11-13 17:06:57.795+00  \N  \N  2025-11-13 17:06:57.718+00  \N  f   2025-11-13 17:06:57.718+00  \N  \N
94  \N  1   \N  \N  2025-10-24 00:01:07.376+00  2025-10-24 00:10:58.87+00   2025-10-24 00:10:58.859+00  \N  \N  \N  f   \N  \N  \N
269 \N  1   \N  \N  2025-11-13 18:03:17.213+00  2025-11-13 18:03:17.213+00  \N  \N  \N  \N  f   \N  \N  \N
172 \N  1   \N  \N  2025-11-12 23:02:40.582+00  2025-11-12 23:02:40.582+00  \N  \N  \N  \N  f   \N  \N  \N
265 \N  1   \N  \N  2025-11-13 17:46:40.318+00  2025-11-13 17:46:40.332+00  \N  \N  2025-11-13 17:46:40.328+00  \N  f   2025-11-13 17:46:40.329+00  \N  \N
277 \N  1   \N  \N  2025-11-13 18:26:57.316+00  2025-11-13 18:29:34.964+00  \N  \N  2025-11-13 18:29:34.961+00  \N  f   2025-11-13 18:29:34.962+00  \N  \N
174 \N  1   \N  \N  2025-11-12 23:51:12.242+00  2025-11-13 17:06:57.782+00  \N  \N  2025-11-13 17:06:57.723+00  \N  f   2025-11-13 17:06:57.723+00  \N  \N
335 \N  1   \N  \N  2025-11-14 01:02:55.867+00  2025-11-14 01:02:55.927+00  \N  \N  2025-11-14 01:02:55.916+00  \N  f   2025-11-14 01:02:55.916+00  \N  \N
268 \N  1   \N  \N  2025-11-13 17:57:03.219+00  2025-11-13 17:57:03.228+00  \N  \N  2025-11-13 17:57:03.226+00  \N  f   2025-11-13 17:57:03.226+00  \N  \N
181 \N  1   \N  1   2025-11-13 02:07:18.062+00  2025-11-13 05:32:03.48+00   2025-11-13 02:09:42.644+00  2025-11-13 02:09:42.655+00  2025-11-13 05:32:03.477+00  \N  f   2025-11-13 05:32:03.477+00  \N  \N
262 \N  1   \N  1   2025-11-13 17:28:53.181+00  2025-11-13 17:30:52.286+00  2025-11-13 17:29:24.494+00  2025-11-13 17:29:24.502+00  2025-11-13 17:30:52.284+00  \N  f   2025-11-13 17:30:52.284+00  \N  \N
266 \N  1   \N  1   2025-11-13 17:49:13.118+00  2025-11-14 01:02:55.927+00  2025-11-13 17:53:51.974+00  2025-11-13 17:53:51.986+00  2025-11-14 01:02:55.915+00  \N  f   2025-11-14 01:02:55.915+00  \N  \N
263 \N  1   \N  1   2025-11-13 17:31:20.268+00  2025-11-13 17:57:28.186+00  2025-11-13 17:31:35.587+00  2025-11-13 17:31:35.597+00  2025-11-13 17:57:28.184+00  \N  f   2025-11-13 17:57:28.184+00  \N  \N
131 \N  1   \N  1   2025-10-31 22:30:50.029+00  2025-11-05 13:44:21.052+00  2025-10-31 22:31:01.79+00   2025-10-31 22:31:01.827+00  2025-11-05 13:44:21.049+00  \N  f   2025-11-05 13:44:21.049+00  \N  \N
202 \N  1   \N  \N  2025-11-13 03:46:09.304+00  2025-11-13 04:02:56.111+00  2025-11-13 03:47:21.598+00  \N  2025-11-13 04:02:56.109+00  \N  f   2025-11-13 04:02:56.109+00  \N  \N
220 \N  1   \N  1   2025-11-13 05:19:39.237+00  2025-11-13 05:20:17.747+00  2025-11-13 05:20:09.776+00  2025-11-13 05:20:09.787+00  2025-11-13 05:20:17.742+00  \N  f   2025-11-13 05:20:17.743+00  \N  \N
227 \N  1   \N  1   2025-11-13 05:42:30.643+00  2025-11-13 05:45:14.13+00   2025-11-13 05:43:21.871+00  2025-11-13 05:43:21.883+00  2025-11-13 05:45:14.128+00  \N  f   2025-11-13 05:45:14.128+00  \N  \N
264 \N  1   \N  1   2025-11-13 17:32:31.56+00   2025-11-13 17:32:44.749+00  2025-11-13 17:32:44.735+00  2025-11-13 17:32:44.745+00  \N  \N  f   \N  \N  \N
153 \N  1   \N  \N  2025-11-05 06:49:04.797+00  2025-11-05 12:34:18.045+00  \N  \N  2025-11-05 12:34:18.043+00  \N  f   2025-11-05 12:34:18.043+00  \N  \N
128 \N  1   \N  \N  2025-10-31 02:08:15.363+00  2025-10-31 22:30:32.943+00  \N  \N  2025-10-31 22:30:32.938+00  \N  f   2025-10-31 22:30:32.938+00  \N  \N
93  \N  1   \N  \N  2025-10-23 23:30:59.794+00  2025-10-25 05:23:38.048+00  \N  \N  2025-10-25 05:23:38.045+00  \N  f   2025-10-25 05:23:38.045+00  \N  \N
283 \N  1   \N  \N  2025-11-13 18:29:44.604+00  2025-11-13 18:31:16.953+00  \N  \N  2025-11-13 18:31:16.951+00  \N  f   2025-11-13 18:31:16.951+00  \N  \N
279 \N  1   \N  \N  2025-11-13 18:29:44.415+00  2025-11-13 18:31:20.311+00  \N  \N  2025-11-13 18:31:20.307+00  \N  f   2025-11-13 18:31:20.307+00  \N  \N
278 \N  1   \N  \N  2025-11-13 18:29:44.411+00  2025-11-13 18:31:12.909+00  \N  \N  2025-11-13 18:31:12.906+00  \N  f   2025-11-13 18:31:12.906+00  \N  \N
199 \N  1   \N  \N  2025-11-13 03:30:36.01+00   2025-11-13 03:32:24.601+00  \N  \N  2025-11-13 03:32:24.599+00  \N  f   2025-11-13 03:32:24.599+00  \N  \N
242 \N  1   \N  \N  2025-11-13 13:28:00.589+00  2025-11-13 17:06:57.801+00  \N  \N  2025-11-13 17:06:57.738+00  \N  f   2025-11-13 17:06:57.738+00  \N  \N
236 \N  1   \N  \N  2025-11-13 11:02:28.448+00  2025-11-13 17:06:57.801+00  \N  \N  2025-11-13 17:06:57.739+00  \N  f   2025-11-13 17:06:57.739+00  \N  \N
176 \N  1   \N  \N  2025-11-13 00:52:37.385+00  2025-11-13 00:52:37.385+00  \N  \N  \N  \N  f   \N  \N  \N
95  \N  1   \N  \N  2025-10-24 00:37:26.869+00  2025-11-02 06:28:57.617+00  2025-11-02 06:28:57.55+00   \N  \N  \N  f   \N  \N  \N
178 \N  1   \N  \N  2025-11-13 01:18:44.073+00  2025-11-13 01:18:44.073+00  \N  \N  \N  \N  f   \N  \N  \N
112 \N  1   \N  \N  2025-10-27 13:40:37.419+00  2025-10-27 13:40:37.419+00  \N  \N  \N  \N  f   \N  \N  \N
109 \N  1   \N  \N  2025-10-27 11:03:18.566+00  2025-10-27 11:03:18.566+00  \N  \N  \N  \N  f   \N  \N  \N
177 \N  1   \N  \N  2025-11-13 01:05:03.092+00  2025-11-13 01:05:03.092+00  \N  \N  \N  \N  f   \N  \N  \N
376 \N  1   \N  \N  2025-11-15 19:54:54.954+00  2025-11-17 04:19:03.771+00  \N  \N  2025-11-17 04:19:03.768+00  \N  f   2025-11-17 04:19:03.768+00  \N  \N
380 \N  1   \N  \N  2025-11-15 21:39:55.193+00  2025-11-17 04:19:05.371+00  \N  \N  2025-11-17 04:19:05.369+00  \N  f   2025-11-17 04:19:05.369+00  \N  \N
252 \N  1   \N  \N  2025-11-13 16:52:30.024+00  2025-11-13 16:54:56.662+00  \N  \N  2025-11-13 16:54:56.659+00  \N  f   2025-11-13 16:54:56.66+00   \N  \N
1166    \N  1   \N  1   2026-01-03 16:12:22.362+00  2026-01-03 16:12:30.298+00  2026-01-03 16:12:30.274+00  2026-01-03 16:12:30.285+00  \N  \N  f   \N  \N  \N
285 \N  1   \N  \N  2025-11-13 18:32:00.883+00  2025-11-13 18:33:31.254+00  \N  \N  2025-11-13 18:33:31.25+00   \N  f   2025-11-13 18:33:31.25+00   \N  \N
282 \N  1   \N  \N  2025-11-13 18:29:44.603+00  2025-11-13 18:31:17.889+00  \N  \N  2025-11-13 18:31:17.883+00  \N  f   2025-11-13 18:31:17.883+00  \N  \N
281 \N  1   \N  \N  2025-11-13 18:29:44.576+00  2025-11-13 18:31:15.906+00  \N  \N  2025-11-13 18:31:15.901+00  \N  f   2025-11-13 18:31:15.901+00  \N  \N
284 \N  1   \N  \N  2025-11-13 18:31:07.344+00  2025-11-13 18:31:07.344+00  \N  \N  \N  \N  f   \N  \N  \N
222 \N  1   \N  1   2025-11-13 05:31:59.652+00  2025-11-13 05:31:59.662+00  \N  \N  2025-11-13 05:31:59.66+00   \N  f   2025-11-13 05:31:59.66+00   \N  \N
224 \N  1   \N  1   2025-11-13 05:33:45.588+00  2025-11-13 05:33:45.596+00  \N  \N  2025-11-13 05:33:45.594+00  \N  f   2025-11-13 05:33:45.594+00  \N  \N
527 \N  1   \N  1   2025-11-18 02:40:08.443+00  2025-11-18 02:41:49.16+00   2025-11-18 02:40:34.731+00  2025-11-18 02:40:34.737+00  2025-11-18 02:41:49.157+00  \N  f   2025-11-18 02:41:49.157+00  \N  \N
270 \N  1   \N  1   2025-11-13 18:06:13.821+00  2025-11-17 04:19:07.678+00  2025-11-13 18:07:00.092+00  2025-11-13 18:07:00.102+00  2025-11-17 04:19:07.677+00  \N  f   2025-11-17 04:19:07.677+00  \N  \N
415 \N  1   \N  1   2025-11-17 05:03:56.022+00  2025-11-17 05:26:33.166+00  2025-11-17 05:05:27.573+00  2025-11-17 05:05:27.582+00  2025-11-17 05:26:33.163+00  \N  f   2025-11-17 05:26:33.163+00  \N  \N
529 \N  1   \N  \N  2025-11-18 02:42:03.9+00    2025-11-18 02:42:03.9+00    \N  \N  \N  \N  f   \N  \N  \N
162 \N  1   \N  \N  2025-11-05 16:12:12.952+00  2025-11-05 17:53:00.346+00  \N  \N  2025-11-05 17:53:00.339+00  \N  f   2025-11-05 17:53:00.339+00  \N  \N
501 \N  1   \N  \N  2025-11-17 19:09:09.712+00  2025-11-17 22:44:23.168+00  \N  \N  2025-11-17 22:44:23.166+00  \N  f   2025-11-17 22:44:23.166+00  \N  \N
519 \N  1   \N  \N  2025-11-17 23:26:43.037+00  2025-11-18 01:08:55.827+00  \N  \N  2025-11-18 01:08:55.824+00  \N  f   2025-11-18 01:08:55.824+00  \N  \N
546 \N  1   \N  \N  2025-11-18 04:34:48.378+00  2025-11-18 04:37:15.831+00  \N  \N  2025-11-18 04:37:15.83+00   \N  f   2025-11-18 04:37:15.83+00   \N  \N
547 \N  1   \N  \N  2025-11-18 04:37:22.194+00  2025-11-18 04:39:00.477+00  \N  \N  2025-11-18 04:39:00.475+00  \N  f   2025-11-18 04:39:00.475+00  \N  \N
327 \N  1   \N  1   2025-11-14 00:27:35.333+00  2025-11-14 00:30:44.588+00  2025-11-14 00:30:40.627+00  2025-11-14 00:30:40.638+00  2025-11-14 00:30:44.586+00  \N  f   2025-11-14 00:30:44.586+00  \N  \N
346 \N  1   \N  \N  2025-11-14 14:36:15.949+00  2025-11-15 00:13:14.823+00  \N  \N  2025-11-15 00:13:14.784+00  \N  f   2025-11-15 00:13:14.784+00  \N  \N
313 \N  1   \N  1   2025-11-13 22:52:22.238+00  2025-11-13 23:47:26.631+00  2025-11-13 23:47:02.071+00  2025-11-13 23:47:02.08+00   2025-11-13 23:47:26.628+00  \N  f   2025-11-13 23:47:26.628+00  \N  \N
366 \N  1   \N  1   2025-11-15 02:53:39.224+00  2025-11-17 13:34:40.362+00  2025-11-15 03:35:24.044+00  2025-11-15 03:35:24.051+00  2025-11-17 13:34:40.36+00   \N  f   2025-11-17 13:34:40.36+00   \N  \N
457 \N  1   \N  1   2025-11-17 13:13:56.803+00  2025-11-17 13:40:44.712+00  2025-11-17 13:35:58.019+00  2025-11-17 13:35:58.035+00  2025-11-17 13:40:44.71+00   \N  f   2025-11-17 13:40:44.71+00   \N  \N
393 \N  1   \N  \N  2025-11-16 22:42:56.207+00  2025-11-17 04:18:56.613+00  \N  \N  2025-11-17 04:18:56.611+00  \N  f   2025-11-17 04:18:56.611+00  \N  \N
548 \N  1   \N  \N  2025-11-18 04:39:05.162+00  2025-11-18 04:44:35.587+00  \N  \N  2025-11-18 04:44:35.582+00  \N  f   2025-11-18 04:44:35.582+00  \N  \N
304 \N  1   \N  1   2025-11-13 21:08:45.179+00  2025-11-13 21:16:03.696+00  2025-11-13 21:12:15.178+00  2025-11-13 21:12:15.186+00  2025-11-13 21:16:03.692+00  \N  f   2025-11-13 21:16:03.692+00  \N  \N
549 \N  1   \N  \N  2025-11-18 04:44:41.983+00  2025-11-18 04:47:52.503+00  \N  \N  2025-11-18 04:47:52.5+00    \N  f   2025-11-18 04:47:52.5+00    \N  \N
550 \N  1   \N  \N  2025-11-18 04:49:32.096+00  2025-11-18 04:52:47.614+00  \N  \N  2025-11-18 04:52:47.612+00  \N  f   2025-11-18 04:52:47.612+00  \N  \N
551 \N  1   \N  \N  2025-11-18 04:52:53.491+00  2025-11-18 05:09:19.562+00  \N  \N  2025-11-18 05:09:19.555+00  \N  f   2025-11-18 05:09:19.555+00  \N  \N
332 \N  1   \N  1   2025-11-14 00:57:14.446+00  2025-11-14 01:02:46.633+00  2025-11-14 00:57:28.087+00  2025-11-14 00:57:28.096+00  2025-11-14 01:02:46.628+00  \N  f   2025-11-14 01:02:46.628+00  \N  \N
552 \N  1   \N  \N  2025-11-18 05:09:35.662+00  2025-11-18 05:11:30.943+00  \N  \N  2025-11-18 05:11:30.94+00   \N  f   2025-11-18 05:11:30.94+00   \N  \N
553 \N  1   \N  \N  2025-11-18 05:14:03.383+00  2025-11-18 05:14:51.61+00   \N  \N  2025-11-18 05:14:51.607+00  \N  f   2025-11-18 05:14:51.607+00  \N  \N
554 \N  1   \N  \N  2025-11-18 05:21:27.945+00  2025-11-18 05:24:44.315+00  \N  \N  2025-11-18 05:24:44.311+00  \N  f   2025-11-18 05:24:44.311+00  \N  \N
297 \N  1   \N  1   2025-11-13 20:50:08.134+00  2025-11-13 20:50:56.702+00  2025-11-13 20:50:25.411+00  2025-11-13 20:50:25.424+00  2025-11-13 20:50:56.698+00  \N  f   2025-11-13 20:50:56.698+00  \N  \N
303 \N  1   \N  1   2025-11-13 21:02:34.896+00  2025-11-13 21:16:16.915+00  2025-11-13 21:03:00.312+00  2025-11-13 21:03:00.321+00  2025-11-13 21:16:16.913+00  \N  f   2025-11-13 21:16:16.913+00  \N  \N
469 \N  1   \N  \N  2025-11-17 14:18:22.935+00  2025-11-17 15:17:24.305+00  \N  \N  2025-11-17 15:17:24.303+00  \N  f   2025-11-17 15:17:24.303+00  \N  \N
452 \N  1   \N  \N  2025-11-17 12:09:59.994+00  2025-11-17 15:17:33.668+00  \N  \N  2025-11-17 15:17:33.666+00  \N  f   2025-11-17 15:17:33.666+00  \N  \N
323 \N  1   \N  1   2025-11-14 00:21:05.1+00    2025-11-14 00:21:23.358+00  \N  \N  2025-11-14 00:21:23.355+00  \N  f   2025-11-14 00:21:23.355+00  \N  \N
324 \N  1   \N  1   2025-11-14 00:21:30.509+00  2025-11-14 00:22:39.955+00  2025-11-14 00:22:21.264+00  \N  2025-11-14 00:22:39.952+00  \N  f   2025-11-14 00:22:39.952+00  \N  \N
326 \N  1   \N  1   2025-11-14 00:24:31.113+00  2025-11-14 00:27:08.84+00   2025-11-14 00:26:36.31+00   \N  2025-11-14 00:27:08.837+00  \N  f   2025-11-14 00:27:08.837+00  \N  \N
342 \N  1   \N  \N  2025-11-14 14:15:12.179+00  2025-11-14 14:35:19.736+00  \N  \N  2025-11-14 14:35:19.733+00  \N  f   2025-11-14 14:35:19.733+00  \N  \N
437 \N  1   \N  1   2025-11-17 05:35:49.234+00  2025-11-17 15:45:28.713+00  2025-11-17 13:34:22.808+00  2025-11-17 13:34:22.816+00  2025-11-17 15:45:28.71+00   \N  f   2025-11-17 15:45:28.71+00   \N  \N
343 \N  1   \N  1   2025-11-14 14:29:10.039+00  2025-11-14 14:35:31.929+00  \N  \N  2025-11-14 14:35:31.927+00  \N  f   2025-11-14 14:35:31.927+00  \N  \N
328 \N  1   \N  1   2025-11-14 00:34:23.911+00  2025-11-14 00:34:29.352+00  2025-11-14 00:34:23.921+00  2025-11-14 00:34:23.929+00  2025-11-14 00:34:29.349+00  \N  f   2025-11-14 00:34:29.349+00  \N  \N
325 \N  1   \N  \N  2025-11-14 00:23:21.232+00  2025-11-14 00:23:21.232+00  \N  \N  \N  \N  f   \N  \N  \N
350 \N  1   \N  1   2025-11-14 15:00:29.529+00  2025-11-15 00:13:14.846+00  2025-11-14 15:01:52.777+00  2025-11-14 15:01:52.784+00  2025-11-15 00:13:14.807+00  \N  f   2025-11-15 00:13:14.807+00  \N  \N
301 \N  1   \N  1   2025-11-13 21:00:01.127+00  2025-11-13 21:16:05.688+00  2025-11-13 21:00:27.21+00   2025-11-13 21:00:27.221+00  2025-11-13 21:16:05.683+00  \N  f   2025-11-13 21:16:05.683+00  \N  \N
463 \N  1   \N  \N  2025-11-17 13:48:20.743+00  2025-11-17 15:17:27.329+00  \N  \N  2025-11-17 15:17:27.327+00  \N  f   2025-11-17 15:17:27.327+00  \N  \N
405 \N  1   \N  \N  2025-11-17 04:29:26.688+00  2025-11-17 04:33:37.676+00  \N  \N  2025-11-17 04:33:37.672+00  \N  f   2025-11-17 04:33:37.672+00  \N  \N
409 \N  1   \N  \N  2025-11-17 04:42:44.446+00  2025-11-17 04:52:04.223+00  \N  \N  2025-11-17 04:52:04.217+00  \N  f   2025-11-17 04:52:04.217+00  \N  \N
414 \N  1   \N  \N  2025-11-17 05:02:37.069+00  2025-11-17 05:03:00.569+00  \N  \N  2025-11-17 05:03:00.566+00  \N  f   2025-11-17 05:03:00.566+00  \N  \N
435 \N  1   \N  \N  2025-11-17 05:32:42.713+00  2025-11-17 05:33:37.103+00  \N  \N  2025-11-17 05:33:37.101+00  \N  f   2025-11-17 05:33:37.101+00  \N  \N
474 \N  1   \N  \N  2025-11-17 15:52:05.793+00  2025-11-17 15:53:24.897+00  \N  \N  2025-11-17 15:53:24.894+00  \N  f   2025-11-17 15:53:24.894+00  \N  \N
337 \N  1   \N  \N  2025-11-14 01:14:44.575+00  2025-11-14 01:15:55.171+00  \N  \N  2025-11-14 01:15:55.169+00  \N  f   2025-11-14 01:15:55.169+00  \N  \N
309 \N  1   \N  \N  2025-11-13 21:37:28.34+00   2025-11-14 01:02:55.916+00  \N  \N  2025-11-14 01:02:55.901+00  \N  f   2025-11-14 01:02:55.901+00  \N  \N
349 \N  1   \N  \N  2025-11-14 14:50:15.004+00  2025-11-14 14:50:15.012+00  \N  \N  2025-11-14 14:50:15.011+00  \N  f   2025-11-14 14:50:15.011+00  \N  \N
441 \N  1   \N  \N  2025-11-17 10:58:54.525+00  2025-11-17 15:18:44.626+00  \N  \N  2025-11-17 15:18:44.623+00  \N  f   2025-11-17 15:18:44.623+00  \N  \N
397 \N  1   \N  \N  2025-11-17 04:15:50.501+00  2025-11-17 04:15:50.501+00  \N  \N  \N  \N  f   \N  \N  \N
320 \N  1   \N  1   2025-11-13 23:47:30.317+00  2025-11-13 23:47:30.325+00  \N  \N  2025-11-13 23:47:30.323+00  \N  f   2025-11-13 23:47:30.323+00  \N  \N
338 \N  1   \N  1   2025-11-14 01:18:22.171+00  2025-11-14 01:19:06.383+00  2025-11-14 01:18:44.382+00  2025-11-14 01:18:44.389+00  2025-11-14 01:19:06.381+00  \N  f   2025-11-14 01:19:06.381+00  \N  \N
402 \N  1   \N  \N  2025-11-17 04:20:49.989+00  2025-11-17 04:24:21.936+00  \N  \N  2025-11-17 04:24:21.928+00  \N  f   2025-11-17 04:24:21.928+00  \N  \N
333 \N  1   \N  \N  2025-11-14 01:00:10.436+00  2025-11-14 01:02:43.776+00  \N  \N  2025-11-14 01:02:43.771+00  \N  f   2025-11-14 01:02:43.771+00  \N  \N
351 \N  1   \N  \N  2025-11-14 15:16:11.808+00  2025-11-15 00:13:09.971+00  \N  \N  2025-11-15 00:13:09.967+00  \N  f   2025-11-15 00:13:09.967+00  \N  \N
329 \N  1   \N  1   2025-11-14 00:35:00.569+00  2025-11-14 00:36:48.873+00  2025-11-14 00:36:38.655+00  2025-11-14 00:36:38.687+00  2025-11-14 00:36:48.871+00  \N  f   2025-11-14 00:36:48.871+00  \N  \N
365 \N  1   \N  1   2025-11-15 02:17:49.496+00  2025-11-15 05:03:01.256+00  2025-11-15 02:18:03.185+00  2025-11-15 02:18:03.196+00  2025-11-15 05:03:01.253+00  \N  f   2025-11-15 05:03:01.253+00  \N  \N
348 \N  1   \N  1   2025-11-14 14:50:09.474+00  2025-11-15 00:13:14.848+00  2025-11-14 14:50:09.484+00  2025-11-14 14:50:09.491+00  2025-11-15 00:13:14.81+00   \N  f   2025-11-15 00:13:14.81+00   \N  \N
305 \N  1   \N  1   2025-11-13 21:16:42.606+00  2025-11-13 21:17:24.1+00    2025-11-13 21:16:50.129+00  2025-11-13 21:16:50.142+00  2025-11-13 21:17:24.096+00  \N  f   2025-11-13 21:17:24.096+00  \N  \N
364 \N  1   \N  1   2025-11-15 02:07:36.068+00  2025-11-15 02:08:09.347+00  2025-11-15 02:08:09.332+00  2025-11-15 02:08:09.341+00  \N  \N  f   \N  \N  \N
306 \N  1   \N  1   2025-11-13 21:17:39.73+00   2025-11-14 00:03:02.974+00  2025-11-13 21:17:46.491+00  2025-11-13 21:17:46.503+00  2025-11-14 00:03:02.969+00  \N  f   2025-11-14 00:03:02.969+00  \N  \N
475 \N  1   \N  1   2025-11-17 15:53:43.412+00  2025-11-17 16:01:55.04+00   2025-11-17 16:01:00.323+00  2025-11-17 16:01:00.332+00  2025-11-17 16:01:55.037+00  \N  f   2025-11-17 16:01:55.037+00  \N  \N
322 \N  1   \N  1   2025-11-14 00:03:45.961+00  2025-11-14 00:06:54.456+00  2025-11-14 00:05:34.94+00   2025-11-14 00:05:34.947+00  2025-11-14 00:06:54.438+00  \N  f   2025-11-14 00:06:54.438+00  \N  \N
478 \N  1   \N  1   2025-11-17 16:02:18.196+00  2025-11-17 16:09:33.446+00  2025-11-17 16:05:49.933+00  2025-11-17 16:05:49.949+00  2025-11-17 16:09:33.444+00  \N  f   2025-11-17 16:09:33.444+00  \N  \N
340 \N  1   \N  1   2025-11-14 03:05:32.228+00  2025-11-14 03:05:32.239+00  \N  \N  2025-11-14 03:05:32.237+00  \N  f   2025-11-14 03:05:32.237+00  \N  \N
369 \N  1   \N  \N  2025-11-15 05:03:15.251+00  2025-11-15 05:03:31.769+00  \N  \N  2025-11-15 05:03:31.767+00  \N  f   2025-11-15 05:03:31.767+00  \N  \N
370 \N  1   \N  \N  2025-11-15 05:04:30.984+00  2025-11-17 04:15:44.94+00   \N  \N  2025-11-17 04:15:44.937+00  \N  f   2025-11-17 04:15:44.938+00  \N  \N
298 \N  1   \N  1   2025-11-13 20:52:39.861+00  2025-11-13 20:55:34.348+00  2025-11-13 20:52:53.316+00  2025-11-13 20:52:53.323+00  2025-11-13 20:55:34.346+00  \N  f   2025-11-13 20:55:34.346+00  \N  \N
482 \N  1   \N  1   2025-11-17 16:10:04.875+00  2025-11-17 16:18:09.221+00  2025-11-17 16:13:06.415+00  2025-11-17 16:13:06.424+00  2025-11-17 16:18:09.216+00  \N  f   2025-11-17 16:18:09.216+00  \N  \N
401 \N  1   \N  \N  2025-11-17 04:20:12.77+00   2025-11-17 04:20:12.77+00   \N  \N  \N  \N  f   \N  \N  \N
403 \N  1   \N  \N  2025-11-17 04:24:57.898+00  2025-11-17 04:24:57.898+00  \N  \N  \N  \N  f   \N  \N  \N
352 \N  1   \N  1   2025-11-14 15:20:31.376+00  2025-11-15 00:13:14.846+00  2025-11-14 18:33:37.299+00  2025-11-14 18:33:37.309+00  2025-11-15 00:13:14.808+00  \N  f   2025-11-15 00:13:14.808+00  \N  \N
293 \N  1   \N  1   2025-11-13 20:42:45.69+00   2025-11-13 20:45:56.621+00  2025-11-13 20:43:02.578+00  2025-11-13 20:43:02.586+00  2025-11-13 20:45:56.618+00  \N  f   2025-11-13 20:45:56.618+00  \N  \N
330 \N  1   \N  \N  2025-11-14 00:50:37.368+00  2025-11-14 00:52:41.561+00  \N  \N  2025-11-14 00:52:41.559+00  \N  f   2025-11-14 00:52:41.559+00  \N  \N
398 \N  1   \N  \N  2025-11-17 04:16:19.568+00  2025-11-17 04:18:26.56+00   \N  \N  2025-11-17 04:18:26.557+00  \N  f   2025-11-17 04:18:26.557+00  \N  \N
361 \N  1   \N  1   2025-11-15 00:36:41.483+00  2025-11-15 01:57:16.123+00  2025-11-15 00:36:41.498+00  2025-11-15 00:36:41.508+00  2025-11-15 01:57:16.121+00  \N  f   2025-11-15 01:57:16.121+00  \N  \N
406 \N  1   \N  \N  2025-11-17 04:33:53.038+00  2025-11-17 04:39:29.878+00  \N  \N  2025-11-17 04:39:29.874+00  \N  f   2025-11-17 04:39:29.874+00  \N  \N
410 \N  1   \N  \N  2025-11-17 04:52:46.057+00  2025-11-17 04:55:22.093+00  \N  \N  2025-11-17 04:55:22.09+00   \N  f   2025-11-17 04:55:22.09+00   \N  \N
411 \N  1   \N  \N  2025-11-17 04:55:44.261+00  2025-11-17 04:57:33.359+00  \N  \N  2025-11-17 04:57:33.357+00  \N  f   2025-11-17 04:57:33.357+00  \N  \N
407 \N  1   \N  \N  2025-11-17 04:39:34.393+00  2025-11-17 04:39:34.402+00  \N  \N  2025-11-17 04:39:34.4+00    \N  f   2025-11-17 04:39:34.4+00    \N  \N
412 \N  1   \N  \N  2025-11-17 04:59:07.961+00  2025-11-17 04:59:58.491+00  \N  \N  2025-11-17 04:59:58.489+00  \N  f   2025-11-17 04:59:58.489+00  \N  \N
404 \N  1   \N  \N  2025-11-17 04:25:50.408+00  2025-11-17 04:29:16.982+00  \N  \N  2025-11-17 04:29:16.977+00  \N  f   2025-11-17 04:29:16.977+00  \N  \N
408 \N  1   \N  \N  2025-11-17 04:40:00.936+00  2025-11-17 04:41:37.436+00  \N  \N  2025-11-17 04:41:37.431+00  \N  f   2025-11-17 04:41:37.431+00  \N  \N
334 \N  1   \N  1   2025-11-14 01:02:55.857+00  2025-11-14 01:02:55.933+00  \N  \N  2025-11-14 01:02:55.924+00  \N  f   2025-11-14 01:02:55.924+00  \N  \N
310 \N  1   \N  \N  2025-11-13 22:06:18.603+00  2025-11-14 01:02:55.913+00  \N  \N  2025-11-14 01:02:55.891+00  \N  f   2025-11-14 01:02:55.891+00  \N  \N
383 \N  1   \N  \N  2025-11-16 15:21:14.82+00   2025-11-17 04:18:55.81+00   \N  \N  2025-11-17 04:18:55.808+00  \N  f   2025-11-17 04:18:55.808+00  \N  \N
416 \N  1   \N  \N  2025-11-17 05:08:00.524+00  2025-11-17 15:17:31.232+00  \N  \N  2025-11-17 15:17:31.23+00   \N  f   2025-11-17 15:17:31.23+00   \N  \N
358 \N  1   \N  \N  2025-11-14 18:17:24.066+00  2025-11-14 18:17:24.075+00  \N  \N  2025-11-14 18:17:24.073+00  \N  f   2025-11-14 18:17:24.073+00  \N  \N
359 \N  1   \N  \N  2025-11-14 18:17:26.732+00  2025-11-14 18:17:26.739+00  \N  \N  2025-11-14 18:17:26.737+00  \N  f   2025-11-14 18:17:26.738+00  \N  \N
382 \N  1   \N  \N  2025-11-16 14:21:19.606+00  2025-11-17 04:19:02.188+00  \N  \N  2025-11-17 04:19:02.186+00  \N  f   2025-11-17 04:19:02.186+00  \N  \N
392 \N  1   \N  \N  2025-11-16 22:30:20.971+00  2025-11-17 04:18:58.22+00   \N  \N  2025-11-17 04:18:58.218+00  \N  f   2025-11-17 04:18:58.218+00  \N  \N
440 \N  1   \N  \N  2025-11-17 10:45:39.179+00  2025-11-17 15:17:32.225+00  \N  \N  2025-11-17 15:17:32.224+00  \N  f   2025-11-17 15:17:32.224+00  \N  \N
353 \N  1   \N  \N  2025-11-14 15:23:45.778+00  2025-11-14 18:17:46.81+00   \N  \N  2025-11-14 18:17:46.808+00  \N  f   2025-11-14 18:17:46.808+00  \N  \N
394 \N  1   \N  \N  2025-11-17 02:08:33.476+00  2025-11-17 04:18:52.823+00  \N  \N  2025-11-17 04:18:52.82+00   \N  f   2025-11-17 04:18:52.82+00   \N  \N
460 \N  1   \N  \N  2025-11-17 13:16:00.649+00  2025-11-17 22:44:23.972+00  2025-11-17 13:16:01.33+00   \N  2025-11-17 22:44:23.97+00   \N  f   2025-11-17 22:44:23.97+00   \N  \N
413 \N  1   \N  \N  2025-11-17 05:00:26.875+00  2025-11-17 05:02:07.218+00  \N  \N  2025-11-17 05:02:07.215+00  \N  f   2025-11-17 05:02:07.215+00  \N  \N
446 \N  1   \N  \N  2025-11-17 11:46:56.328+00  2025-11-17 15:17:37.056+00  \N  \N  2025-11-17 15:17:37.054+00  \N  f   2025-11-17 15:17:37.054+00  \N  \N
448 \N  1   \N  \N  2025-11-17 12:04:10.625+00  2025-11-17 15:17:35.173+00  \N  \N  2025-11-17 15:17:35.172+00  \N  f   2025-11-17 15:17:35.172+00  \N  \N
436 \N  1   \N  \N  2025-11-17 05:34:10.652+00  2025-11-17 05:34:39.867+00  \N  \N  2025-11-17 05:34:39.865+00  \N  f   2025-11-17 05:34:39.865+00  \N  \N
483 \N  1   \N  \N  2025-11-17 16:19:25.458+00  2025-11-17 16:19:25.458+00  \N  \N  \N  \N  f   \N  \N  \N
484 \N  1   \N  \N  2025-11-17 16:26:03.192+00  2025-11-17 16:26:03.192+00  \N  \N  \N  \N  f   \N  \N  \N
485 \N  1   \N  \N  2025-11-17 16:32:57.972+00  2025-11-17 16:35:43.955+00  \N  \N  2025-11-17 16:35:43.951+00  \N  f   2025-11-17 16:35:43.952+00  \N  \N
486 \N  1   \N  \N  2025-11-17 16:36:16.991+00  2025-11-17 16:39:49.406+00  \N  \N  2025-11-17 16:39:49.4+00    \N  f   2025-11-17 16:39:49.4+00    \N  \N
490 \N  1   \N  \N  2025-11-17 16:40:12.01+00   2025-11-17 16:40:21.431+00  \N  \N  2025-11-17 16:40:21.426+00  \N  f   2025-11-17 16:40:21.427+00  \N  \N
336 \N  1   \N  1   2025-11-14 01:04:02.453+00  2025-11-14 01:17:05.287+00  2025-11-14 01:04:09.327+00  2025-11-14 01:04:09.335+00  2025-11-14 01:17:05.284+00  \N  f   2025-11-14 01:17:05.284+00  \N  \N
339 \N  1   \N  1   2025-11-14 01:18:45.515+00  2025-11-15 00:13:14.848+00  2025-11-14 01:19:03.103+00  2025-11-14 01:19:03.11+00   2025-11-15 00:13:14.811+00  \N  f   2025-11-15 00:13:14.811+00  \N  \N
542 \N  1   \N  \N  2025-11-18 04:17:28.344+00  2025-11-18 04:22:50.141+00  2025-11-18 04:19:47.812+00  \N  2025-11-18 04:22:50.139+00  \N  f   2025-11-18 04:22:50.139+00  \N  \N
480 \N  1   \N  1   2025-11-17 16:08:28.423+00  2025-11-18 06:15:46.903+00  2025-11-17 16:09:01.72+00   2025-11-17 16:09:01.735+00  2025-11-18 06:15:46.884+00  \N  f   2025-11-18 06:15:46.884+00  \N  \N
288 \N  1   \N  1   2025-11-13 18:34:11.886+00  2025-11-17 04:19:08.349+00  2025-11-13 18:37:32.717+00  2025-11-13 18:37:32.732+00  2025-11-17 04:19:08.347+00  \N  f   2025-11-17 04:19:08.347+00  \N  \N
496 \N  1   \N  1   2025-11-17 17:03:29.532+00  2025-11-17 17:07:28.391+00  2025-11-17 17:07:24.953+00  2025-11-17 17:07:24.961+00  2025-11-17 17:07:28.39+00   \N  f   2025-11-17 17:07:28.39+00   \N  \N
331 \N  1   \N  1   2025-11-14 00:51:36.651+00  2025-11-14 00:57:33.571+00  2025-11-14 00:52:45.791+00  2025-11-14 00:52:45.799+00  2025-11-14 00:57:33.569+00  \N  f   2025-11-14 00:57:33.569+00  \N  \N
528 \N  1   \N  1   2025-11-18 02:40:56.128+00  2025-11-18 02:41:33.922+00  2025-11-18 02:41:33.911+00  2025-11-18 02:41:33.919+00  \N  \N  f   \N  \N  \N
367 \N  1   \N  \N  2025-11-15 02:53:51.763+00  2025-11-15 03:35:19.189+00  \N  \N  2025-11-15 03:35:19.186+00  \N  f   2025-11-15 03:35:19.186+00  \N  \N
389 \N  1   \N  \N  2025-11-16 18:23:10.693+00  2025-11-17 04:19:01.422+00  \N  \N  2025-11-17 04:19:01.419+00  \N  f   2025-11-17 04:19:01.419+00  \N  \N
465 \N  1   \N  \N  2025-11-17 13:58:20.514+00  2025-11-17 15:17:25.77+00   \N  \N  2025-11-17 15:17:25.767+00  \N  f   2025-11-17 15:17:25.767+00  \N  \N
461 \N  1   \N  \N  2025-11-17 13:24:59.782+00  2025-11-17 13:35:49.981+00  \N  \N  2025-11-17 13:35:49.978+00  \N  f   2025-11-17 13:35:49.978+00  \N  \N
538 \N  1   \N  \N  2025-11-18 03:44:55.827+00  2025-11-18 03:54:32.684+00  \N  \N  2025-11-18 03:54:32.682+00  \N  f   2025-11-18 03:54:32.682+00  \N  \N
535 \N  1   \N  \N  2025-11-18 03:43:04.125+00  2025-11-18 03:43:04.125+00  \N  \N  \N  \N  f   \N  \N  \N
534 \N  1   \N  \N  2025-11-18 03:38:16.133+00  2025-11-18 03:42:43.077+00  \N  \N  2025-11-18 03:42:43.073+00  \N  f   2025-11-18 03:42:43.073+00  \N  \N
533 \N  1   \N  \N  2025-11-18 03:37:57.471+00  2025-11-18 03:42:44.372+00  \N  \N  2025-11-18 03:42:44.369+00  \N  f   2025-11-18 03:42:44.37+00   \N  \N
536 \N  1   \N  \N  2025-11-18 03:43:13.584+00  2025-11-18 03:43:13.584+00  \N  \N  \N  \N  f   \N  \N  \N
537 \N  1   \N  \N  2025-11-18 03:44:45.896+00  2025-11-18 03:54:31.277+00  \N  \N  2025-11-18 03:54:31.275+00  \N  f   2025-11-18 03:54:31.275+00  \N  \N
471 \N  1   \N  1   2025-11-17 15:20:34.909+00  2025-11-18 01:12:29.798+00  2025-11-17 16:02:21.295+00  2025-11-17 16:02:21.304+00  2025-11-18 01:12:29.795+00  \N  f   2025-11-18 01:12:29.795+00  \N  \N
455 \N  1   \N  1   2025-11-17 13:12:34.153+00  2025-11-17 13:37:49.625+00  2025-11-17 13:37:34.711+00  2025-11-17 13:37:34.721+00  2025-11-17 13:37:49.622+00  \N  f   2025-11-17 13:37:49.622+00  \N  \N
540 \N  1   \N  \N  2025-11-18 04:03:48.267+00  2025-11-18 04:03:54.847+00  \N  \N  2025-11-18 04:03:54.841+00  \N  f   2025-11-18 04:03:54.841+00  \N  \N
541 \N  1   \N  \N  2025-11-18 04:10:21.395+00  2025-11-18 04:11:25.414+00  \N  \N  2025-11-18 04:11:25.411+00  \N  f   2025-11-18 04:11:25.412+00  \N  \N
523 \N  1   \N  1   2025-11-18 01:46:35.492+00  2025-11-18 06:15:46.891+00  2025-11-18 01:53:57.787+00  2025-11-18 01:53:57.797+00  2025-11-18 06:15:46.863+00  \N  f   2025-11-18 06:15:46.863+00  \N  \N
525 \N  1   \N  1   2025-11-18 02:04:33.559+00  2025-11-18 06:15:46.886+00  2025-11-18 02:39:56.591+00  2025-11-18 02:39:56.599+00  2025-11-18 06:15:46.858+00  \N  f   2025-11-18 06:15:46.858+00  \N  \N
495 \N  1   \N  \N  2025-11-17 17:03:06.842+00  2025-11-17 17:08:09.033+00  \N  \N  2025-11-17 17:08:09.031+00  \N  f   2025-11-17 17:08:09.031+00  \N  \N
543 \N  1   \N  \N  2025-11-18 04:22:54.732+00  2025-11-18 04:25:35.595+00  \N  \N  2025-11-18 04:25:35.592+00  \N  f   2025-11-18 04:25:35.592+00  \N  \N
544 \N  1   \N  \N  2025-11-18 04:25:39.54+00   2025-11-18 04:28:50.738+00  \N  \N  2025-11-18 04:28:50.735+00  \N  f   2025-11-18 04:28:50.736+00  \N  \N
513 \N  1   \N  \N  2025-11-17 20:31:35.093+00  2025-11-17 22:44:15.866+00  \N  \N  2025-11-17 22:44:15.864+00  \N  f   2025-11-17 22:44:15.864+00  \N  \N
488 \N  1   \N  \N  2025-11-17 16:40:06.144+00  2025-11-17 22:44:24.774+00  \N  \N  2025-11-17 22:44:24.773+00  \N  f   2025-11-17 22:44:24.773+00  \N  \N
487 \N  1   \N  \N  2025-11-17 16:40:06.14+00   2025-11-17 22:44:25.603+00  \N  \N  2025-11-17 22:44:25.601+00  \N  f   2025-11-17 22:44:25.601+00  \N  \N
489 \N  1   \N  \N  2025-11-17 16:40:06.144+00  2025-11-17 22:44:25.189+00  \N  \N  2025-11-17 22:44:25.188+00  \N  f   2025-11-17 22:44:25.188+00  \N  \N
516 \N  1   \N  \N  2025-11-17 22:44:21.276+00  2025-11-17 22:44:21.283+00  \N  \N  2025-11-17 22:44:21.282+00  \N  f   2025-11-17 22:44:21.282+00  \N  \N
438 \N  1   \N  \N  2025-11-17 09:57:56.239+00  2025-11-17 15:17:33.189+00  \N  \N  2025-11-17 15:17:33.187+00  \N  f   2025-11-17 15:17:33.187+00  \N  \N
530 \N  1   \N  \N  2025-11-18 02:51:06.803+00  2025-11-18 03:55:57.375+00  \N  \N  2025-11-18 03:55:57.373+00  \N  f   2025-11-18 03:55:57.373+00  \N  \N
470 \N  1   \N  \N  2025-11-17 14:28:42.533+00  2025-11-17 15:17:22.738+00  \N  \N  2025-11-17 15:17:22.736+00  \N  f   2025-11-17 15:17:22.736+00  \N  \N
515 \N  1   \N  \N  2025-11-17 22:44:11.913+00  2025-11-17 22:44:11.922+00  \N  \N  2025-11-17 22:44:11.92+00   \N  f   2025-11-17 22:44:11.92+00   \N  \N
506 \N  1   \N  \N  2025-11-17 20:05:21.64+00   2025-11-17 22:44:19.895+00  \N  \N  2025-11-17 22:44:19.893+00  \N  f   2025-11-17 22:44:19.893+00  \N  \N
500 \N  1   \N  \N  2025-11-17 19:08:03.306+00  2025-11-17 22:44:17.627+00  \N  \N  2025-11-17 22:44:17.626+00  \N  f   2025-11-17 22:44:17.626+00  \N  \N
520 \N  1   \N  \N  2025-11-17 23:27:28.426+00  2025-11-18 01:08:56.564+00  \N  \N  2025-11-18 01:08:56.562+00  \N  f   2025-11-18 01:08:56.562+00  \N  \N
556 \N  1   \N  \N  2025-11-18 18:57:26.991+00  2025-11-18 18:57:26.991+00  \N  \N  \N  \N  f   \N  \N  \N
619 \N  1   \N  1   2025-11-20 10:51:20.278+00  2025-11-20 17:18:02.803+00  2025-11-20 17:18:02.787+00  2025-11-20 17:18:02.797+00  \N  \N  f   \N  \N  \N
1462    \N  1   \N  1   2026-01-10 02:13:31.435+00  2026-01-10 17:18:37.299+00  2026-01-10 03:15:17.015+00  2026-01-10 02:42:50.524+00  2026-01-10 17:18:37.296+00  \N  f   2026-01-10 17:18:37.296+00  \N  \N
1029    \N  1   \N  1   2025-12-15 23:16:22.429+00  2025-12-16 15:27:42.563+00  2025-12-16 15:27:42.542+00  2025-12-16 15:27:42.553+00  \N  \N  f   \N  \N  \N
574 \N  1   \N  1   2025-11-19 03:33:09.803+00  2025-11-19 03:35:56.166+00  2025-11-19 03:34:37.498+00  \N  2025-11-19 03:35:56.163+00  \N  f   2025-11-19 03:35:56.163+00  \N  \N
1011    \N  1   \N  1   2025-12-15 14:23:14.178+00  2025-12-17 01:12:11.232+00  2025-12-17 00:42:12.591+00  2025-12-15 15:24:22.365+00  2025-12-17 01:12:11.229+00  \N  f   2025-12-17 01:12:11.229+00  \N  \N
600 \N  1   \N  1   2025-11-19 21:11:27.263+00  2025-11-19 23:50:08.399+00  2025-11-19 22:40:55.166+00  2025-11-19 22:40:55.175+00  2025-11-19 23:50:08.396+00  \N  f   2025-11-19 23:50:08.396+00  \N  \N
584 \N  1   \N  1   2025-11-19 17:32:26.612+00  2025-11-19 18:48:31.279+00  2025-11-19 17:43:12.49+00   2025-11-19 17:43:12.504+00  2025-11-19 18:48:31.276+00  \N  f   2025-11-19 18:48:31.276+00  \N  \N
1030    \N  1   \N  1   2025-12-16 02:40:45.535+00  2025-12-20 00:46:58.995+00  2025-12-16 14:04:23.559+00  2025-12-16 14:04:23.569+00  2025-12-20 00:46:58.991+00  \N  f   2025-12-20 00:46:58.991+00  \N  \N
610 \N  1   \N  1   2025-11-20 04:28:44.806+00  2025-11-20 04:41:12.129+00  2025-11-20 04:29:03.105+00  2025-11-20 04:29:03.114+00  2025-11-20 04:41:12.126+00  \N  f   2025-11-20 04:41:12.126+00  \N  \N
567 \N  1   \N  \N  2025-11-19 01:40:41.758+00  2025-11-19 02:01:07.836+00  2025-11-19 01:48:54.047+00  \N  2025-11-19 02:01:07.834+00  \N  f   2025-11-19 02:01:07.834+00  \N  \N
597 \N  1   \N  1   2025-11-19 19:40:46.81+00   2025-11-19 19:40:55.292+00  2025-11-19 19:40:55.28+00   2025-11-19 19:40:55.288+00  \N  \N  f   \N  \N  \N
575 \N  1   \N  \N  2025-11-19 03:36:37.756+00  2025-11-19 03:52:37.702+00  2025-11-19 03:46:04.387+00  \N  2025-11-19 03:52:37.7+00    \N  f   2025-11-19 03:52:37.7+00    \N  \N
1031    \N  1   \N  1   2025-12-16 02:46:14.805+00  2025-12-20 00:46:58.996+00  2025-12-16 15:27:25.364+00  2025-12-16 15:27:25.371+00  2025-12-20 00:46:58.988+00  \N  f   2025-12-20 00:46:58.988+00  \N  \N
837 \N  1   \N  1   2025-11-27 17:35:32.213+00  2025-11-27 17:38:28.265+00  2025-11-27 17:38:28.244+00  2025-11-27 17:38:28.254+00  \N  \N  f   \N  \N  \N
1032    \N  1   \N  1   2025-12-16 03:32:26.069+00  2025-12-20 00:46:58.998+00  2025-12-16 15:27:08.581+00  2025-12-16 15:27:08.591+00  2025-12-20 00:46:58.992+00  \N  f   2025-12-20 00:46:58.992+00  \N  \N
1123    \N  1   \N  1   2026-01-02 18:44:56.344+00  2026-01-02 21:55:15.948+00  2026-01-02 21:55:15.941+00  2026-01-02 19:36:41.98+00   \N  \N  f   \N  \N  \N
557 \N  1   \N  1   2025-11-18 22:10:13.069+00  2025-11-18 22:16:29.091+00  \N  \N  2025-11-18 22:16:29.088+00  \N  f   2025-11-18 22:16:29.088+00  \N  \N
1473    \N  1   \N  \N  2026-01-11 21:36:42.36+00   2026-01-11 21:36:42.36+00   \N  \N  \N  \N  f   \N  \N  \N
1061    \N  1   \N  1   2025-12-20 16:19:01.525+00  2025-12-22 17:17:45.027+00  2025-12-20 17:06:07.457+00  2025-12-20 17:06:07.471+00  2025-12-22 17:17:45.025+00  \N  f   2025-12-22 17:17:45.025+00  \N  \N
1385    \N  1   \N  1   2026-01-08 15:53:48.343+00  2026-01-08 23:52:49.268+00  2026-01-08 17:36:57.284+00  2026-01-08 15:54:00.661+00  2026-01-08 23:52:49.201+00  \N  f   2026-01-08 23:52:49.202+00  \N  \N
583 \N  1   \N  \N  2025-11-19 17:19:10.385+00  2025-11-19 17:40:33.788+00  \N  \N  2025-11-19 17:40:33.786+00  \N  f   2025-11-19 17:40:33.786+00  \N  \N
1349    \N  1   \N  1   2026-01-07 18:55:41.492+00  2026-01-08 19:59:00.042+00  2026-01-07 22:50:47.634+00  2026-01-07 22:50:47.642+00  2026-01-08 19:59:00.042+00  \N  f   2026-01-08 19:59:00.042+00  \N  \N
1435    \N  1   \N  \N  2026-01-09 17:29:55.442+00  2026-01-09 17:29:55.442+00  \N  \N  \N  \N  f   \N  \N  \N
595 \N  1   \N  \N  2025-11-19 19:39:11.266+00  2025-11-19 19:40:38.392+00  \N  \N  2025-11-19 19:40:38.389+00  \N  f   2025-11-19 19:40:38.389+00  \N  \N
608 \N  1   \N  \N  2025-11-20 02:33:01.15+00   2025-11-20 02:33:39.384+00  \N  \N  2025-11-20 02:33:39.379+00  \N  f   2025-11-20 02:33:39.379+00  \N  \N
612 \N  1   \N  1   2025-11-20 04:41:36.504+00  2025-11-20 04:42:30.832+00  2025-11-20 04:41:52.821+00  2025-11-20 04:41:52.829+00  2025-11-20 04:42:30.83+00   \N  f   2025-11-20 04:42:30.83+00   \N  \N
1924    \N  1   \N  1   2026-01-23 15:25:20.261+00  2026-01-30 22:24:22.631+00  2026-01-30 22:24:22.616+00  2026-01-23 15:26:10.21+00   \N  \N  f   \N  \N  \N
2168    \N  1   \N  1   2026-01-31 12:09:37.88+00   2026-01-31 14:56:47.132+00  2026-01-31 14:56:47.105+00  2026-01-31 14:56:47.117+00  \N  \N  f   \N  \N  \N
1305    \N  1   \N  1   2026-01-07 00:11:18.53+00   2026-01-08 23:52:49.31+00   2026-01-07 15:20:46.333+00  2026-01-07 15:20:46.341+00  2026-01-08 23:52:49.282+00  \N  f   2026-01-08 23:52:49.282+00  \N  \N
1457    \N  1   \N  1   2026-01-10 00:55:54.062+00  2026-01-10 01:13:49.989+00  2026-01-10 01:13:49.976+00  2026-01-10 00:56:07.751+00  \N  \N  f   \N  \N  \N
2014    \N  1   \N  1   2026-01-25 22:56:07.668+00  2026-02-06 09:14:32.551+00  2026-02-06 09:14:32.536+00  2026-01-25 23:03:52.146+00  \N  \N  f   \N  \N  \N
1315    \N  1   \N  \N  2026-01-07 05:16:54.546+00  2026-01-07 05:16:54.546+00  \N  \N  \N  \N  f   \N  \N  \N
558 \N  1   \N  \N  2025-11-19 00:57:17.669+00  2025-11-19 00:57:24.04+00   \N  \N  2025-11-19 00:57:24.038+00  \N  f   2025-11-19 00:57:24.038+00  \N  \N
1401    \N  1   \N  1   2026-01-08 19:09:03.335+00  2026-01-08 23:52:49.091+00  2026-01-08 23:37:04.165+00  2026-01-08 23:37:04.176+00  2026-01-08 23:52:49.036+00  \N  f   2026-01-08 23:52:49.044+00  \N  \N
1350    \N  1   \N  \N  2026-01-07 19:09:16.974+00  2026-01-07 19:09:16.974+00  \N  \N  \N  \N  f   \N  \N  \N
596 \N  1   \N  \N  2025-11-19 19:39:27.512+00  2025-11-19 19:40:40.058+00  \N  \N  2025-11-19 19:40:40.056+00  \N  f   2025-11-19 19:40:40.056+00  \N  \N
1436    \N  1   \N  \N  2026-01-09 17:30:00.896+00  2026-01-09 17:30:00.896+00  \N  \N  \N  \N  f   \N  \N  \N
1182    \N  1   \N  \N  2026-01-03 21:24:03.478+00  2026-01-03 21:24:03.478+00  \N  \N  \N  \N  f   \N  \N  \N
559 \N  1   \N  \N  2025-11-19 01:06:01.535+00  2025-11-19 01:18:11.105+00  \N  \N  2025-11-19 01:18:11.102+00  \N  f   2025-11-19 01:18:11.102+00  \N  \N
1402    \N  1   \N  1   2026-01-08 19:12:15.355+00  2026-01-08 23:52:49.253+00  2026-01-08 23:37:00.779+00  2026-01-08 23:37:00.791+00  2026-01-08 23:52:49.176+00  \N  f   2026-01-08 23:52:49.176+00  \N  \N
576 \N  1   \N  \N  2025-11-19 04:47:41.875+00  2025-11-19 04:57:14.273+00  \N  \N  2025-11-19 04:57:14.268+00  \N  f   2025-11-19 04:57:14.268+00  \N  \N
586 \N  1   \N  \N  2025-11-19 18:49:12.818+00  2025-11-19 18:50:18.439+00  \N  \N  2025-11-19 18:50:18.436+00  \N  f   2025-11-19 18:50:18.437+00  \N  \N
611 \N  1   \N  \N  2025-11-20 04:40:49.188+00  2025-11-20 04:41:14.352+00  \N  \N  2025-11-20 04:41:14.35+00   \N  f   2025-11-20 04:41:14.35+00   \N  \N
585 \N  1   \N  \N  2025-11-19 18:49:12.746+00  2025-11-19 18:49:24.019+00  \N  \N  2025-11-19 18:49:24.017+00  \N  f   2025-11-19 18:49:24.017+00  \N  \N
1237    \N  1   \N  \N  2026-01-05 14:55:52.042+00  2026-01-05 14:55:52.042+00  \N  \N  \N  \N  f   \N  \N  \N
1389    \N  1   \N  \N  2026-01-08 17:32:09.667+00  2026-01-08 17:32:09.667+00  \N  \N  \N  \N  f   \N  \N  \N
560 \N  1   \N  \N  2025-11-19 01:17:58.438+00  2025-11-19 01:22:07.486+00  \N  \N  2025-11-19 01:22:07.483+00  \N  f   2025-11-19 01:22:07.483+00  \N  \N
1080    \N  1   \N  \N  2025-12-30 17:05:51.928+00  2025-12-30 17:05:51.928+00  \N  \N  \N  \N  f   \N  \N  \N
1307    \N  1   \N  1   2026-01-07 01:16:05.332+00  2026-01-07 01:16:05.345+00  \N  \N  2026-01-07 01:16:05.343+00  \N  f   2026-01-07 01:16:05.343+00  \N  \N
577 \N  1   \N  1   2025-11-19 04:59:40.816+00  2025-11-19 13:49:03.801+00  2025-11-19 04:59:40.826+00  2025-11-19 04:59:40.835+00  2025-11-19 13:49:03.795+00  \N  f   2025-11-19 13:49:03.795+00  \N  \N
587 \N  1   \N  \N  2025-11-19 18:49:58.903+00  2025-11-19 18:50:19.861+00  \N  \N  2025-11-19 18:50:19.859+00  \N  f   2025-11-19 18:50:19.859+00  \N  \N
1964    \N  1   \N  1   2026-01-24 12:06:19.165+00  2026-01-24 16:48:33.052+00  2026-01-24 16:48:33.044+00  2026-01-24 16:08:57.575+00  \N  \N  f   \N  \N  \N
1950    \N  1   \N  1   2026-01-24 01:42:14.551+00  2026-01-31 15:16:27.48+00   2026-01-31 15:16:27.464+00  2026-01-24 01:42:23.67+00   \N  \N  f   \N  \N  \N
2139    \N  1   \N  1   2026-01-30 19:37:40.904+00  2026-01-30 19:42:23.555+00  2026-01-30 19:42:23.536+00  2026-01-30 19:42:23.544+00  \N  \N  f   \N  \N  \N
2209    \N  1   \N  1   2026-02-01 08:48:58.481+00  2026-02-01 08:49:40.196+00  2026-02-01 08:49:40.176+00  2026-02-01 08:49:40.185+00  \N  \N  f   \N  \N  \N
2046    \N  1   \N  1   2026-01-26 17:51:59.872+00  2026-01-26 20:19:37.019+00  2026-01-26 20:19:36.997+00  2026-01-26 20:19:37.007+00  \N  \N  f   \N  \N  \N
1989    \N  1   \N  1   2026-01-25 02:24:38.798+00  2026-01-25 06:05:41.441+00  2026-01-25 06:05:41.388+00  2026-01-25 06:05:41.422+00  \N  \N  f   \N  \N  \N
1962    \N  1   \N  1   2026-01-24 08:07:38.701+00  2026-01-24 16:09:34.353+00  2026-01-24 16:09:34.334+00  2026-01-24 16:09:34.343+00  \N  \N  f   \N  \N  \N
1952    \N  1   \N  1   2026-01-24 01:46:01.731+00  2026-01-24 16:50:27.201+00  2026-01-24 16:50:27.193+00  2026-01-24 01:46:11.103+00  \N  \N  f   \N  \N  \N
2170    \N  1   \N  1   2026-01-31 13:54:46.793+00  2026-01-31 15:27:28.394+00  2026-01-31 15:27:28.375+00  2026-01-31 15:27:28.384+00  \N  \N  f   \N  \N  \N
2110    \N  1   \N  1   2026-01-29 01:37:59.293+00  2026-01-29 01:38:56.856+00  2026-01-29 01:38:56.835+00  2026-01-29 01:38:56.844+00  \N  \N  f   \N  \N  \N
2037    \N  1   \N  1   2026-01-26 13:12:20.589+00  2026-01-26 14:02:44.117+00  2026-01-26 14:02:44.087+00  2026-01-26 14:02:44.099+00  \N  \N  f   \N  \N  \N
1960    \N  1   \N  1   2026-01-24 04:17:34.349+00  2026-01-24 16:49:09.539+00  2026-01-24 16:49:09.524+00  2026-01-24 04:21:37.184+00  \N  \N  f   \N  \N  \N
1951    \N  1   \N  1   2026-01-24 01:43:10.963+00  2026-01-24 16:48:58.428+00  2026-01-24 16:48:58.42+00   2026-01-24 01:43:34.871+00  \N  \N  f   \N  \N  \N
1975    \N  1   \N  1   2026-01-24 18:41:15.428+00  2026-01-25 22:55:40.608+00  2026-01-25 22:42:59.074+00  2026-01-24 18:47:20.917+00  2026-01-25 22:55:40.605+00  \N  f   2026-01-25 22:55:40.605+00  \N  \N
1965    \N  1   \N  1   2026-01-24 12:36:32.207+00  2026-01-25 17:52:45.581+00  2026-01-25 17:52:45.571+00  2026-01-24 16:08:54.23+00   \N  \N  f   \N  \N  \N
1963    \N  1   \N  1   2026-01-24 09:20:48.84+00   2026-01-24 16:48:11.378+00  2026-01-24 16:48:11.368+00  2026-01-24 16:09:18.411+00  \N  \N  f   \N  \N  \N
2129    \N  1   \N  1   2026-01-30 16:44:47.528+00  2026-01-30 17:54:05.365+00  2026-01-30 17:54:05.332+00  2026-01-30 17:54:05.351+00  \N  \N  f   \N  \N  \N
2128    \N  1   \N  1   2026-01-30 16:33:21.788+00  2026-01-30 17:54:08.409+00  2026-01-30 17:54:08.378+00  2026-01-30 17:54:08.393+00  \N  \N  f   \N  \N  \N
1054    \N  1   \N  1   2025-12-17 13:25:36.593+00  2025-12-19 18:06:04.028+00  2025-12-19 18:06:03.943+00  2025-12-17 15:55:31.289+00  \N  \N  f   \N  \N  \N
613 \N  1   \N  1   2025-11-20 04:43:26.463+00  2025-11-20 04:51:50.367+00  2025-11-20 04:51:50.343+00  2025-11-20 04:51:50.361+00  \N  \N  f   \N  \N  \N
561 \N  1   \N  1   2025-11-19 01:18:19.421+00  2025-11-19 01:20:05.53+00   2025-11-19 01:18:57.975+00  \N  2025-11-19 01:20:05.527+00  \N  f   2025-11-19 01:20:05.527+00  \N  \N
1428    \N  1   \N  1   2026-01-09 11:36:34.751+00  2026-01-09 16:10:35.251+00  2026-01-09 16:10:35.195+00  2026-01-09 16:10:35.236+00  \N  \N  f   \N  \N  \N
704 \N  1   \N  1   2025-11-24 19:43:19.005+00  2025-11-24 20:47:40.618+00  2025-11-24 20:47:40.606+00  2025-11-24 20:47:40.614+00  \N  \N  f   \N  \N  \N
579 \N  1   \N  1   2025-11-19 07:52:58.59+00   2025-11-19 12:43:12.695+00  2025-11-19 12:42:42.954+00  2025-11-19 12:42:42.965+00  2025-11-19 12:43:12.693+00  \N  f   2025-11-19 12:43:12.693+00  \N  \N
1024    \N  1   \N  1   2025-12-15 22:20:57.555+00  2025-12-15 23:12:59.892+00  2025-12-15 23:12:59.875+00  2025-12-15 23:12:59.883+00  \N  \N  f   \N  \N  \N
1081    \N  1   \N  \N  2025-12-31 10:19:04.544+00  2025-12-31 10:19:04.544+00  \N  \N  \N  \N  f   \N  \N  \N
852 \N  1   \N  \N  2025-11-29 01:41:38.535+00  2025-11-29 01:41:38.535+00  \N  \N  \N  \N  f   \N  \N  \N
1070    \N  1   \N  1   2025-12-24 21:18:21.406+00  2025-12-29 17:07:40.613+00  2025-12-24 23:13:43.38+00   2025-12-24 23:13:43.432+00  2025-12-29 17:07:40.611+00  \N  f   2025-12-29 17:07:40.611+00  \N  \N
588 \N  1   \N  \N  2025-11-19 18:51:06.285+00  2025-11-19 19:05:43.16+00   \N  \N  2025-11-19 19:05:43.157+00  \N  f   2025-11-19 19:05:43.157+00  \N  \N
1390    \N  1   \N  1   2026-01-08 17:35:01.933+00  2026-01-08 23:52:49.222+00  2026-01-08 23:37:32.475+00  2026-01-08 23:37:32.483+00  2026-01-08 23:52:49.123+00  \N  f   2026-01-08 23:52:49.123+00  \N  \N
562 \N  1   \N  \N  2025-11-19 01:20:13.578+00  2025-11-19 01:36:47.21+00   \N  \N  2025-11-19 01:36:47.207+00  \N  f   2025-11-19 01:36:47.207+00  \N  \N
1167    \N  1   \N  \N  2026-01-03 16:35:11.077+00  2026-01-03 16:35:11.077+00  \N  \N  \N  \N  f   \N  \N  \N
589 \N  1   \N  \N  2025-11-19 18:51:44.482+00  2025-11-19 19:05:36.621+00  \N  \N  2025-11-19 19:05:36.619+00  \N  f   2025-11-19 19:05:36.619+00  \N  \N
614 \N  1   \N  \N  2025-11-20 05:11:16.802+00  2025-11-20 05:11:16.802+00  \N  \N  \N  \N  f   \N  \N  \N
1397    \N  1   \N  1   2026-01-08 17:35:23.321+00  2026-01-08 23:52:49.31+00   2026-01-08 23:37:14.249+00  2026-01-08 23:37:14.257+00  2026-01-08 23:52:49.282+00  \N  f   2026-01-08 23:52:49.282+00  \N  \N
591 \N  1   \N  \N  2025-11-19 19:07:01.846+00  2025-11-19 19:07:01.846+00  \N  \N  \N  \N  f   \N  \N  \N
1154    \N  1   \N  \N  2026-01-03 00:18:29.482+00  2026-01-03 00:18:29.482+00  \N  \N  \N  \N  f   \N  \N  \N
571 \N  1   \N  \N  2025-11-19 01:59:36.19+00   2025-11-19 02:57:35.399+00  \N  \N  2025-11-19 02:57:35.396+00  \N  f   2025-11-19 02:57:35.397+00  \N  \N
616 \N  1   \N  \N  2025-11-20 05:18:51.743+00  2025-11-20 05:31:11.114+00  \N  \N  2025-11-20 05:31:11.111+00  \N  f   2025-11-20 05:31:11.111+00  \N  \N
1394    \N  1   \N  1   2026-01-08 17:35:22.778+00  2026-01-08 23:52:49.282+00  2026-01-08 23:37:21.531+00  2026-01-08 23:37:21.539+00  2026-01-08 23:52:49.247+00  \N  f   2026-01-08 23:52:49.247+00  \N  \N
1393    \N  1   \N  1   2026-01-08 17:35:22.252+00  2026-01-08 23:52:49.282+00  2026-01-08 23:37:24.147+00  2026-01-08 23:37:24.158+00  2026-01-08 23:52:49.247+00  \N  f   2026-01-08 23:52:49.247+00  \N  \N
1301    \N  1   \N  \N  2026-01-06 23:14:27.329+00  2026-01-06 23:14:27.329+00  \N  \N  \N  \N  f   \N  \N  \N
771 \N  1   \N  \N  2025-11-26 18:39:58.838+00  2025-11-26 18:39:58.838+00  \N  \N  \N  \N  f   \N  \N  \N
606 \N  1   \N  \N  2025-11-19 23:09:39.683+00  2025-11-19 23:18:14.026+00  \N  \N  2025-11-19 23:18:14.023+00  \N  f   2025-11-19 23:18:14.023+00  \N  \N
1048    \N  1   \N  \N  2025-12-16 23:33:49.18+00   2025-12-16 23:37:51.063+00  2025-12-16 23:37:51.053+00  \N  \N  \N  f   \N  \N  \N
1380    \N  1   \N  \N  2026-01-08 13:57:41.483+00  2026-01-08 13:57:41.483+00  \N  \N  \N  \N  f   \N  \N  \N
1395    \N  1   \N  1   2026-01-08 17:35:23.03+00   2026-01-08 23:52:49.306+00  2026-01-08 23:37:19.354+00  2026-01-08 23:37:19.364+00  2026-01-08 23:52:49.274+00  \N  f   2026-01-08 23:52:49.274+00  \N  \N
1365    \N  1   \N  1   2026-01-07 22:20:48.337+00  2026-01-08 18:56:19.584+00  2026-01-07 22:50:25.141+00  2026-01-07 22:50:25.15+00   2026-01-08 18:56:19.581+00  \N  f   2026-01-08 18:56:19.581+00  \N  \N
592 \N  1   \N  \N  2025-11-19 19:17:49.441+00  2025-11-19 19:17:49.441+00  \N  \N  \N  \N  f   \N  \N  \N
563 \N  1   \N  \N  2025-11-19 01:26:44.103+00  2025-11-19 02:57:40.352+00  \N  \N  2025-11-19 02:57:40.35+00   \N  f   2025-11-19 02:57:40.35+00   \N  \N
2253    \N  1   \N  1   2026-02-04 14:52:07.093+00  2026-02-04 14:53:10.384+00  2026-02-04 14:52:36.442+00  2026-02-04 14:52:36.452+00  2026-02-04 14:53:10.382+00  \N  f   2026-02-04 14:53:10.382+00  \N  \N
1058    \N  1   \N  1   2025-12-19 18:38:14.062+00  2025-12-20 00:46:58.992+00  2025-12-20 00:42:34.436+00  2025-12-19 18:41:40.531+00  2025-12-20 00:46:58.983+00  \N  f   2025-12-20 00:46:58.983+00  \N  \N
1432    \N  1   \N  1   2026-01-09 15:16:30.321+00  2026-01-09 16:10:56.181+00  2026-01-09 16:10:56.154+00  2026-01-09 16:10:56.164+00  \N  \N  f   \N  \N  \N
1396    \N  1   \N  1   2026-01-08 17:35:23.315+00  2026-01-08 23:52:49.31+00   2026-01-08 23:37:16.935+00  2026-01-08 23:37:16.945+00  2026-01-08 23:52:49.281+00  \N  f   2026-01-08 23:52:49.282+00  \N  \N
1086    \N  1   \N  \N  2025-12-31 18:13:34.903+00  2025-12-31 18:13:34.903+00  \N  \N  \N  \N  f   \N  \N  \N
1398    \N  1   \N  1   2026-01-08 17:36:02.939+00  2026-01-08 23:52:49.31+00   2026-01-08 23:37:11.305+00  2026-01-08 23:37:11.315+00  2026-01-08 23:52:49.282+00  \N  f   2026-01-08 23:52:49.282+00  \N  \N
1335    \N  1   \N  1   2026-01-07 15:28:44.85+00   2026-01-08 23:52:49.31+00   2026-01-08 15:53:06.169+00  2026-01-07 15:47:51.543+00  2026-01-08 23:52:49.281+00  \N  f   2026-01-08 23:52:49.281+00  \N  \N
1953    \N  1   \N  1   2026-01-24 02:47:57.511+00  2026-01-24 16:49:57.681+00  2026-01-24 16:49:57.673+00  2026-01-24 02:55:26.303+00  \N  \N  f   \N  \N  \N
2172    \N  1   \N  1   2026-01-31 19:16:16.202+00  2026-02-02 10:20:11.777+00  2026-02-02 10:20:11.766+00  2026-01-31 19:22:06.389+00  \N  \N  f   \N  \N  \N
1944    \N  1   \N  1   2026-01-24 01:00:20.197+00  2026-01-24 01:02:43.497+00  2026-01-24 01:02:43.477+00  2026-01-24 01:02:43.486+00  \N  \N  f   \N  \N  \N
2232    \N  1   \N  1   2026-02-03 18:52:38.612+00  2026-02-03 18:54:30.554+00  2026-02-03 18:54:30.528+00  2026-02-03 18:54:30.541+00  \N  \N  f   \N  \N  \N
2161    \N  1   \N  1   2026-01-31 02:03:53.513+00  2026-01-31 02:37:01.214+00  2026-01-31 02:37:01.186+00  2026-01-31 02:37:01.198+00  \N  \N  f   \N  \N  \N
2130    \N  1   \N  1   2026-01-30 16:56:23.948+00  2026-01-30 17:54:01.021+00  2026-01-30 17:54:00.945+00  2026-01-30 17:54:00.998+00  \N  \N  f   \N  \N  \N
2212    \N  1   \N  1   2026-02-01 08:50:17.482+00  2026-02-01 08:50:30.153+00  2026-02-01 08:50:30.131+00  2026-02-01 08:50:30.141+00  \N  \N  f   \N  \N  \N
2276    \N  1   \N  1   2026-02-05 15:27:45.828+00  2026-02-05 15:52:55.186+00  2026-02-05 15:52:55.149+00  2026-02-05 15:52:55.168+00  \N  \N  f   \N  \N  \N
2241    \N  1   \N  1   2026-02-04 01:49:03.077+00  2026-02-04 02:40:16.676+00  2026-02-04 02:40:16.654+00  2026-02-04 02:40:16.663+00  \N  \N  f   \N  \N  \N
2260    \N  1   \N  1   2026-02-04 17:28:31.327+00  2026-02-04 20:23:40.697+00  2026-02-04 20:23:40.676+00  2026-02-04 20:23:40.684+00  \N  \N  f   \N  \N  \N
2111    \N  1   \N  1   2026-01-29 07:49:48.208+00  2026-01-29 07:58:31.852+00  2026-01-29 07:58:31.82+00   2026-01-29 07:58:31.837+00  \N  \N  f   \N  \N  \N
1981    \N  1   \N  1   2026-01-24 22:09:32.065+00  2026-01-24 23:21:05.001+00  2026-01-24 23:21:04.982+00  2026-01-24 23:21:04.991+00  \N  \N  f   \N  \N  \N
1977    \N  1   \N  1   2026-01-24 21:04:59.366+00  2026-01-24 21:46:18.475+00  2026-01-24 21:46:18.466+00  2026-01-24 21:33:06.264+00  \N  \N  f   \N  \N  \N
1945    \N  1   \N  1   2026-01-24 01:02:07.121+00  2026-01-24 16:50:06.952+00  2026-01-24 16:50:06.942+00  2026-01-24 01:02:36.971+00  \N  \N  f   \N  \N  \N
1956    \N  1   \N  1   2026-01-24 03:28:01.214+00  2026-01-24 16:49:41.095+00  2026-01-24 16:49:41.086+00  2026-01-24 03:31:26.7+00    \N  \N  f   \N  \N  \N
1934    \N  1   \N  1   2026-01-23 20:55:16.23+00   2026-01-23 21:02:49.345+00  2026-01-23 21:02:49.338+00  2026-01-23 20:59:27.211+00  \N  \N  f   \N  \N  \N
1968    \N  1   \N  1   2026-01-24 14:45:51.86+00   2026-01-24 16:48:20.803+00  2026-01-24 16:48:20.795+00  2026-01-24 15:57:47.065+00  \N  \N  f   \N  \N  \N
1955    \N  1   \N  1   2026-01-24 03:13:57.706+00  2026-01-24 16:49:49.135+00  2026-01-24 16:49:49.123+00  2026-01-24 03:14:10.502+00  \N  \N  f   \N  \N  \N
1978    \N  1   \N  1   2026-01-24 21:53:19.689+00  2026-01-28 15:28:05.966+00  2026-01-28 15:28:05.937+00  2026-01-24 21:55:06.065+00  \N  \N  f   \N  \N  \N
2163    \N  1   \N  1   2026-01-31 03:18:12.757+00  2026-01-31 08:14:27.681+00  2026-01-31 08:14:27.658+00  2026-01-31 08:14:27.668+00  \N  \N  f   \N  \N  \N
1970    \N  1   \N  1   2026-01-24 16:35:17.461+00  2026-01-24 16:48:02.47+00   2026-01-24 16:48:02.452+00  2026-01-24 16:36:47.556+00  \N  \N  f   \N  \N  \N
1954    \N  1   \N  1   2026-01-24 03:08:04.742+00  2026-01-24 03:08:15.533+00  2026-01-24 03:08:15.51+00   2026-01-24 03:08:15.522+00  \N  \N  f   \N  \N  \N
1966    \N  1   \N  1   2026-01-24 13:07:18.044+00  2026-01-24 16:48:49.584+00  2026-01-24 16:48:49.573+00  2026-01-24 16:05:01.539+00  \N  \N  f   \N  \N  \N
1932    \N  1   \N  1   2026-01-23 20:54:45.733+00  2026-01-23 22:23:23.215+00  2026-01-23 22:23:23.195+00  2026-01-23 22:23:23.204+00  \N  \N  f   \N  \N  \N
2162    \N  1   \N  1   2026-01-31 03:02:56.105+00  2026-01-31 08:13:34.823+00  2026-01-31 08:13:34.805+00  2026-01-31 08:13:34.814+00  \N  \N  f   \N  \N  \N
2154    \N  1   \N  1   2026-01-30 21:42:41.528+00  2026-01-30 22:09:51.487+00  2026-01-30 22:09:51.468+00  2026-01-30 22:09:51.477+00  \N  \N  f   \N  \N  \N
1930    \N  1   \N  1   2026-01-23 20:54:45.477+00  2026-01-23 21:41:36.957+00  2026-01-23 21:41:36.935+00  2026-01-23 21:41:36.945+00  \N  \N  f   \N  \N  \N
2171    \N  1   \N  1   2026-01-31 15:16:52.61+00   2026-02-01 09:31:25.447+00  2026-02-01 09:31:25.43+00   2026-01-31 15:27:19.138+00  \N  \N  f   \N  \N  \N
2164    \N  1   \N  1   2026-01-31 05:00:30.508+00  2026-01-31 08:13:11.616+00  2026-01-31 08:13:11.594+00  2026-01-31 08:13:11.604+00  \N  \N  f   \N  \N  \N
2269    \N  1   \N  1   2026-02-05 00:14:45.3+00    2026-02-05 09:55:01.474+00  2026-02-05 09:55:01.427+00  2026-02-05 09:55:01.448+00  \N  \N  f   \N  \N  \N
1957    \N  1   \N  1   2026-01-24 03:39:56.154+00  2026-01-24 16:49:23.623+00  2026-01-24 16:49:23.615+00  2026-01-24 03:40:01.275+00  \N  \N  f   \N  \N  \N
2216    \N  1   \N  1   2026-02-02 01:30:33.383+00  2026-02-03 18:49:28.116+00  2026-02-03 18:49:28.102+00  2026-02-02 02:17:37.283+00  \N  \N  f   \N  \N  \N
1028    \N  1   \N  1   2025-12-15 23:15:10.341+00  2025-12-17 02:26:34.693+00  2025-12-17 02:14:58.98+00   2025-12-17 01:50:38.417+00  2025-12-17 02:26:34.689+00  \N  f   2025-12-17 02:26:34.69+00   \N  \N
1421    \N  1   \N  \N  2026-01-09 00:04:06.63+00   2026-01-09 02:27:00.036+00  2026-01-09 00:36:14.954+00  2026-01-09 00:36:14.963+00  2026-01-09 02:27:00.036+00  \N  f   2026-01-09 02:27:00.036+00  \N  \N
2255    \N  1   \N  \N  2026-02-04 14:53:22.709+00  2026-02-04 14:53:32.032+00  2026-02-04 14:53:32.015+00  \N  \N  \N  f   \N  \N  \N
1594    \N  1   \N  \N  2026-01-14 11:42:41.93+00   2026-01-14 11:42:41.93+00   \N  \N  \N  \N  f   \N  \N  \N
1434    \N  1   \N  \N  2026-01-09 17:29:44.435+00  2026-01-09 17:29:44.435+00  \N  \N  \N  \N  f   \N  \N  \N
1060    \N  1   \N  1   2025-12-20 14:01:32.376+00  2025-12-22 17:17:48.747+00  2025-12-20 15:44:06.619+00  2025-12-20 15:44:06.626+00  2025-12-22 17:17:48.745+00  \N  f   2025-12-22 17:17:48.745+00  \N  \N
593 \N  1   \N  \N  2025-11-19 19:30:05.205+00  2025-11-19 19:38:27.65+00   \N  \N  2025-11-19 19:38:27.647+00  \N  f   2025-11-19 19:38:27.647+00  \N  \N
594 \N  1   \N  \N  2025-11-19 19:30:20.489+00  2025-11-19 19:38:26.062+00  \N  \N  2025-11-19 19:38:26.056+00  \N  f   2025-11-19 19:38:26.056+00  \N  \N
1384    \N  1   \N  1   2026-01-08 15:14:08.236+00  2026-01-08 16:57:36.124+00  2026-01-08 16:52:14.657+00  2026-01-08 16:52:14.667+00  2026-01-08 16:57:36.121+00  \N  f   2026-01-08 16:57:36.121+00  \N  \N
607 \N  1   \N  \N  2025-11-20 02:32:03.938+00  2025-11-20 03:42:58.493+00  \N  \N  2025-11-20 03:42:58.491+00  \N  f   2025-11-20 03:42:58.491+00  \N  \N
1399    \N  1   \N  1   2026-01-08 17:36:03.182+00  2026-01-08 23:52:49.31+00   2026-01-08 23:37:06.92+00   2026-01-08 23:37:06.93+00   2026-01-08 23:52:49.282+00  \N  f   2026-01-08 23:52:49.282+00  \N  \N
1946    \N  1   \N  1   2026-01-24 01:25:00.594+00  2026-01-24 16:51:16.478+00  2026-01-24 16:51:16.464+00  2026-01-24 01:28:16.054+00  \N  \N  f   \N  \N  \N
2148    \N  1   \N  \N  2026-01-30 20:25:59.479+00  2026-01-30 23:04:26.066+00  2026-01-30 20:28:35.139+00  2026-01-30 20:27:50.777+00  2026-01-30 23:04:26.046+00  \N  f   2026-01-30 23:04:26.046+00  \N  \N
1947    \N  1   \N  1   2026-01-24 01:28:10.838+00  2026-02-04 20:20:17.777+00  2026-02-04 20:20:17.76+00   2026-01-24 01:28:21.577+00  \N  \N  f   \N  \N  \N
1959    \N  1   \N  1   2026-01-24 03:45:13.346+00  2026-01-25 23:44:11.3+00    2026-01-25 23:44:11.289+00  2026-01-24 03:45:19.43+00   \N  \N  f   \N  \N  \N
2235    \N  1   \N  1   2026-02-03 21:03:00.119+00  2026-02-03 21:48:04.595+00  2026-02-03 21:48:04.553+00  2026-02-03 21:48:04.581+00  \N  \N  f   \N  \N  \N
2210    \N  1   \N  1   2026-02-01 08:48:58.923+00  2026-02-01 08:49:36.146+00  2026-02-01 08:49:36.122+00  2026-02-01 08:49:36.131+00  \N  \N  f   \N  \N  \N
1937    \N  1   \N  1   2026-01-23 20:55:16.533+00  2026-01-24 05:50:40.442+00  2026-01-24 05:50:40.308+00  2026-01-24 05:50:40.43+00   \N  \N  f   \N  \N  \N
2273    \N  1   \N  1   2026-02-05 13:38:10.166+00  2026-02-05 15:53:02.74+00   2026-02-05 15:53:02.639+00  2026-02-05 15:53:02.715+00  \N  \N  f   \N  \N  \N
2054    \N  1   \N  1   2026-01-26 23:57:23.587+00  2026-01-31 06:18:23.758+00  2026-01-31 06:18:23.746+00  2026-01-27 03:09:30.097+00  \N  \N  f   \N  \N  \N
2160    \N  1   \N  1   2026-01-31 01:36:34.717+00  2026-01-31 08:13:07.493+00  2026-01-31 08:13:07.469+00  2026-01-31 08:13:07.48+00   \N  \N  f   \N  \N  \N
2167    \N  1   \N  1   2026-01-31 11:16:18.352+00  2026-01-31 15:27:13.577+00  2026-01-31 15:27:13.55+00   2026-01-31 15:27:13.562+00  \N  \N  f   \N  \N  \N
1897    \N  1   \N  1   2026-01-20 19:04:32.266+00  2026-01-23 15:24:06.712+00  2026-01-23 06:03:32.282+00  2026-01-20 19:06:11.218+00  2026-01-23 15:24:06.708+00  \N  f   2026-01-23 15:24:06.708+00  \N  \N
2126    \N  1   \N  1   2026-01-30 14:23:45.343+00  2026-02-04 00:27:53.309+00  2026-02-04 00:27:53.285+00  2026-01-30 17:54:11.332+00  \N  \N  f   \N  \N  \N
1948    \N  1   \N  1   2026-01-24 01:30:05.375+00  2026-01-24 16:50:48.553+00  2026-01-24 16:50:48.545+00  2026-01-24 01:30:18.89+00   \N  \N  f   \N  \N  \N
\.


--
-- Data for Name: Tickets; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Tickets" (id, status, "lastMessage", "contactId", "userId", "createdAt", "updatedAt", "whatsappId", "isGroup", "unreadMessages", "queueId", "companyId", uuid, chatbot, "queueOptionId", "isBot", channel, "amountUsedBotQueues", "fromMe", "amountUsedBotQueuesNPS", "sendInactiveMessage", "lgpdSendMessageAt", "lgpdAcceptedAt", imported, "flowWebhook", "lastFlowId", "dataWebhook", "hashFlowId", "useIntegration", "integrationId", "isOutOfHour", "flowStopped", "isActiveDemand", "typebotSessionId", "typebotStatus", "typebotSessionTime", "productsSent", crm_lead_id, crm_client_id, "leadValue", lid) FROM stdin;
\.


--
-- Data for Name: UserDevices; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."UserDevices" (id, "userId", "deviceToken", platform, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: UserGoogleCalendarIntegrations; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."UserGoogleCalendarIntegrations" (id, user_id, company_id, "googleUserId", email, "accessToken", "refreshToken", "expiryDate", "calendarId", active, "syncToken", "lastSyncAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: UserQueues; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."UserQueues" ("userId", "queueId", "createdAt", "updatedAt") FROM stdin;
2   1   2025-10-10 05:07:43.344+00  2025-10-10 05:07:43.344+00
6   2   2025-10-10 17:58:32.624+00  2025-10-10 17:58:32.624+00
6   3   2025-10-10 17:58:32.624+00  2025-10-10 17:58:32.624+00
5   2   2025-10-10 18:06:56.333+00  2025-10-10 18:06:56.333+00
5   3   2025-10-10 18:06:56.333+00  2025-10-10 18:06:56.333+00
7   2   2025-10-10 18:08:21.554+00  2025-10-10 18:08:21.554+00
7   3   2025-10-10 18:08:21.554+00  2025-10-10 18:08:21.554+00
8   2   2025-10-10 18:09:27.582+00  2025-10-10 18:09:27.582+00
8   3   2025-10-10 18:09:27.582+00  2025-10-10 18:09:27.582+00
3   4   2025-10-21 18:22:13.825+00  2025-10-21 18:22:13.825+00
20  4   2025-10-21 18:31:35.011+00  2025-10-21 18:31:35.011+00
25  7   2025-11-16 16:21:54.208+00  2025-11-16 16:21:54.208+00
27  8   2025-11-19 22:35:26.759+00  2025-11-19 22:35:26.759+00
40  10  2025-11-23 22:51:07.696+00  2025-11-23 22:51:07.696+00
44  5   2025-11-25 16:52:03.347+00  2025-11-25 16:52:03.347+00
44  6   2025-11-25 16:52:03.347+00  2025-11-25 16:52:03.347+00
43  12  2025-11-25 16:54:02.626+00  2025-11-25 16:54:02.626+00
46  13  2025-11-26 20:04:45.429+00  2025-11-26 20:04:45.429+00
46  14  2025-11-26 20:04:45.429+00  2025-11-26 20:04:45.429+00
46  15  2025-11-26 20:04:45.429+00  2025-11-26 20:04:45.429+00
46  16  2025-11-26 20:04:45.429+00  2025-11-26 20:04:45.429+00
65  17  2025-12-08 23:25:58.771+00  2025-12-08 23:25:58.771+00
59  18  2025-12-09 11:16:50.666+00  2025-12-09 11:16:50.666+00
86  5   2026-01-07 01:17:28.199+00  2026-01-07 01:17:28.199+00
96  26  2026-01-10 01:15:24.657+00  2026-01-10 01:15:24.657+00
103 30  2026-01-11 22:27:44.089+00  2026-01-11 22:27:44.089+00
103 31  2026-01-11 22:27:44.089+00  2026-01-11 22:27:44.089+00
103 32  2026-01-11 22:27:44.089+00  2026-01-11 22:27:44.089+00
104 33  2026-01-14 17:07:03.815+00  2026-01-14 17:07:03.815+00
104 34  2026-01-14 17:07:03.815+00  2026-01-14 17:07:03.815+00
53  35  2026-01-22 20:13:25.449+00  2026-01-22 20:13:25.449+00
110 37  2026-01-24 17:03:55.539+00  2026-01-24 17:03:55.539+00
112 39  2026-01-25 01:51:44.194+00  2026-01-25 01:51:44.194+00
112 40  2026-01-25 01:51:44.194+00  2026-01-25 01:51:44.194+00
109 42  2026-01-25 02:28:25.788+00  2026-01-25 02:28:25.788+00
114 42  2026-01-25 03:28:46.554+00  2026-01-25 03:28:46.554+00
115 43  2026-01-25 14:16:44.381+00  2026-01-25 14:16:44.381+00
113 43  2026-01-25 14:37:05.593+00  2026-01-25 14:37:05.593+00
129 47  2026-02-02 11:16:49.834+00  2026-02-02 11:16:49.834+00
130 46  2026-02-02 11:18:31.661+00  2026-02-02 11:18:31.661+00
136 51  2026-02-04 02:16:36.721+00  2026-02-04 02:16:36.721+00
136 52  2026-02-04 02:16:36.721+00  2026-02-04 02:16:36.721+00
\.


--
-- Data for Name: UserRatings; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."UserRatings" (id, "ticketId", "companyId", "userId", rate, "createdAt", "updatedAt") FROM stdin;
6   \N  1   1   10  2026-01-08 19:14:41.652+00  2026-01-08 19:14:41.652+00
7   \N  1   1   10  2026-01-09 17:46:42.462+00  2026-01-09 17:46:42.462+00
8   \N  1   1   9   2026-01-09 17:48:24.391+00  2026-01-09 17:48:24.391+00
9   \N  1   1   10  2026-01-09 17:55:56.967+00  2026-01-09 17:55:56.967+00
\.


--
-- Data for Name: UserServices; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."UserServices" (id, "userId", "serviceId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Users" (id, name, email, "passwordHash", "createdAt", "updatedAt", profile, "tokenVersion", "companyId", super, online, "endWork", "startWork", color, "farewellMessage", "whatsappId", "allTicket", "allowGroup", "defaultMenu", "defaultTheme", "profileImage", "allHistoric", "allUserChat", "resetPassword", "userClosePendingTicket", "showDashboard", "defaultTicketsManagerWidth", "allowRealTime", "allowConnections", "userType", "workDays", "lunchStart", "lunchEnd") FROM stdin;
1   Administrador   superadmin@demo.com $2a$08$uVykGrgkZOLqQzM/7eWtbuhpR6qIE7R.MnlX0uFRw.1V9r6vRZkQe    2025-10-10 02:50:00.335+00  2026-02-06 21:46:02.667+00  admin   0   1   t   t   23:59   00:00   \N  \N  \N  enable  t   closed  light   \N  enabled enabled     enabled disabled    698 enabled enabled attendant   1,2,3,4,5,6,0   \N  \N
\.


--
-- Data for Name: Versions; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Versions" (id, "versionFrontend", "versionBackend", "createdAt", "updatedAt") FROM stdin;
1   1.1.7d  1.1.7d  2024-05-16 15:13:48.163+00  2024-05-16 16:02:46.03+00
\.


--
-- Data for Name: Webhooks; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Webhooks" (id, user_id, name, hash_id, config, "createdAt", "updatedAt", active, "requestMonth", "requestAll", company_id) FROM stdin;
1   104 flowbuilder WOz3RGmE5MTd6RRyPzXTv0YO9SAjuqbzHAeNaY7f26  \N  2026-01-14 16:11:53.265+00  2026-01-14 16:11:53.265+00  t   0   0   104
2   108 flowbuilder wgrqh5PVGD0SKgNKRyS0tG3HEqXZ4tjJhflIbUQXJH  \N  2026-01-20 19:07:26.937+00  2026-01-20 19:07:26.937+00  t   0   0   107
3   109 flowbuilder ResJaWFq9TxVPBJFRCcZi8biM7lerVGiIJCBScZKmy  \N  2026-01-23 23:01:00.34+00   2026-01-23 23:01:00.34+00   t   0   0   108
4   110 flowbuilder fO7c3SAHSwck0tGF4fhcM1Pf7ljITFG5T8PU9xkEDC  \N  2026-01-24 14:04:34.917+00  2026-01-24 14:04:34.917+00  t   0   0   109
5   113 flowbuilder bbQdemyyYTFp1eqSfGyS2OAsu2dbs9IzX3WuTogJKo  \N  2026-01-25 03:01:11.169+00  2026-01-25 03:01:11.169+00  t   0   0   112
6   125 flowbuilder p1rfhnSiZKQGu4Qe2vECzWOfy1k8bauExiUbxLiFNj  \N  2026-01-29 23:29:39.535+00  2026-01-29 23:29:39.535+00  t   0   0   122
7   127 flowbuilder VfS6vV4yDCF41wEehufxI4ubXaPmxoyBNujVrtI6P3  \N  2026-01-30 16:58:27.421+00  2026-01-30 16:58:27.421+00  t   0   0   129
8   129 flowbuilder zRoMRbdEC4zIgh9WLppQXTV7s6Du8PPgvzzC9BuJhb  \N  2026-02-02 03:38:13.735+00  2026-02-02 03:38:13.735+00  t   0   0   131
9   131 flowbuilder P5Z9isyF1k3z3haFSoCocjiCCfFCx7WiS7Amj9R6qS  \N  2026-02-03 04:37:54.022+00  2026-02-03 04:37:54.022+00  t   0   0   132
10  132 flowbuilder b9KPE5v6d7iwtzP75m9yYyfjagYlNG8pGcLMdusQAc  \N  2026-02-03 18:28:08.928+00  2026-02-03 18:28:08.928+00  t   0   0   133
11  136 flowbuilder 2HTUEA9zAxJHCxfn6hG9iilnVkK704PH1OznnHnDGU  \N  2026-02-04 01:56:32.835+00  2026-02-04 01:56:32.835+00  t   0   0   139
12  128 flowbuilder m1UMP7ckjKC0BKNLfvAzh8nIlq0ZPOqq9CVAGXT3ef  \N  2026-02-04 03:12:03.261+00  2026-02-04 03:12:03.261+00  t   0   0   130
\.


--
-- Data for Name: WhatsappQueues; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."WhatsappQueues" ("whatsappId", "queueId", "createdAt", "updatedAt") FROM stdin;
21  4   2025-10-21 18:29:05.566+00  2025-10-21 18:29:05.566+00
61  18  2025-12-09 12:36:28.624+00  2025-12-09 12:36:28.624+00
62  18  2025-12-09 16:49:50.097+00  2025-12-09 16:49:50.097+00
72  21  2026-01-02 20:28:41.906+00  2026-01-02 20:28:41.906+00
72  22  2026-01-02 20:28:41.906+00  2026-01-02 20:28:41.906+00
72  23  2026-01-02 20:28:41.906+00  2026-01-02 20:28:41.906+00
77  24  2026-01-08 02:04:58.038+00  2026-01-08 02:04:58.038+00
77  25  2026-01-08 02:04:58.038+00  2026-01-08 02:04:58.038+00
80  27  2026-01-10 14:25:40.252+00  2026-01-10 14:25:40.252+00
81  30  2026-01-11 22:25:55.474+00  2026-01-11 22:25:55.474+00
81  31  2026-01-11 22:25:55.474+00  2026-01-11 22:25:55.474+00
81  32  2026-01-11 22:25:55.474+00  2026-01-11 22:25:55.474+00
83  33  2026-01-13 21:21:52.588+00  2026-01-13 21:21:52.588+00
\.


--
-- Data for Name: Whatsapps; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public."Whatsapps" (id, session, qrcode, status, battery, plugged, "createdAt", "updatedAt", name, "isDefault", retries, "greetingMessage", "companyId", "complationMessage", "outOfHoursMessage", token, "farewellMessage", provider, number, channel, "facebookUserToken", "tokenMeta", "facebookPageUserId", "facebookUserId", "maxUseBotQueues", "expiresTicket", "allowGroup", "timeUseBotQueues", "timeSendQueue", "sendIdQueue", "expiresInactiveMessage", "maxUseBotQueuesNPS", "inactiveMessage", "whenExpiresTicket", "expiresTicketNPS", "timeInactiveMessage", "ratingMessage", "groupAsTicket", "importOldMessages", "importRecentMessages", "statusImportMessages", "closedTicketsPostImported", "importOldMessagesGroups", "timeCreateNewTicket", "greetingMediaAttachment", "promptId", "integrationId", schedules, "collectiveVacationEnd", "collectiveVacationStart", "collectiveVacationMessage", "queueIdImportMessages", "flowIdNotPhrase", "flowIdWelcome", wavoip, "notificameHub", "coexistencePhoneNumberId", "coexistenceWabaId", "coexistencePermanentToken", "coexistenceEnabled", "businessAppConnected", "messageRoutingMode", "routingRules", "lastCoexistenceSync") FROM stdin;
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.appointments (id, title, description, start_datetime, duration_minutes, status, schedule_id, service_id, client_id, contact_id, company_id, created_at, updated_at, google_event_id) FROM stdin;
\.


--
-- Data for Name: company_api_keys; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.company_api_keys (id, company_id, label, token, webhook_url, webhook_secret, active, last_used_at, "createdAt", "updatedAt") FROM stdin;
1   1   Integração  073ea129db057eb3ac51fb9f26e0d30a488820b8ee8f14841c006f4c3874020624a708954b61f7a0ea44c8df580f4d30    \N  \N  t   2026-01-23 17:32:34.858 2025-12-23 03:45:52.56  2026-01-23 17:32:34.858
\.


--
-- Data for Name: company_integration_field_maps; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.company_integration_field_maps (id, integration_id, external_field, crm_field, transform_expression, options, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: company_integration_settings; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.company_integration_settings (id, company_id, name, provider, base_url, api_key, api_secret, webhook_secret, metadata, active, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: company_payment_settings; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.company_payment_settings (id, company_id, provider, token, additional_data, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: crm_client_contacts; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.crm_client_contacts (id, client_id, contact_id, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: crm_clients; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.crm_clients (id, company_id, type, name, company_name, document, birth_date, email, phone, zip_code, address, number, complement, neighborhood, city, state, status, client_since, owner_user_id, notes, created_at, updated_at, contact_id, primary_ticket_id, asaas_customer_id, lid) FROM stdin;
23  133 pf  cliente1    empresa de cliente  012012012   2026-02-12  cliente@empresa.com 504899999999    123 spos    123 spsp    sps sps sp  active  2026-02-19  137 123132  2026-02-04 03:21:28.447+00  2026-02-04 03:21:28.447+00  \N  \N  \N  \N
16  109 pf  Anderson    Farms       \N  andersonluizhaack@gmail.com     85601-275   Avenida Luiz Antônio Faêdo  112         Francisco Beltrão   PR  active  2026-01-24  110     2026-01-24 14:19:29.45+00   2026-01-24 14:19:29.45+00   \N  \N  \N  \N
13  104 pf  Estúdio de Dança Daiene Weiss       \N  \N  \N  555184605806    \N  \N  \N  \N  \N  \N  \N  active  2026-01-14  \N      2026-01-14 22:04:38.886+00  2026-01-19 17:50:16.18+00   \N  \N  \N  \N
12  104 pf  Paola Oliveira      \N  \N  \N  554891591427    \N  \N  \N  \N  \N  \N  \N  active  2026-01-14  \N      2026-01-14 16:03:40.336+00  2026-01-14 16:03:40.336+00  \N  \N  \N  \N
11  104 pf  Gracinha!       \N  \N  \N  554896020435    \N  \N  \N  \N  \N  \N  \N  active  2026-01-14  \N      2026-01-14 16:00:05.297+00  2026-01-14 16:00:05.297+00  \N  \N  \N  \N
22  112 pf  Rafael Paixão       \N  \N  \N  5524993959492   \N  \N  \N  \N  \N  \N  \N  active  2026-01-25  \N      2026-01-25 23:35:37.738+00  2026-01-29 15:14:17.306+00  \N  \N  \N  \N
\.


--
-- Data for Name: crm_leads; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.crm_leads (id, company_id, name, email, phone, birth_date, document, company_name, "position", source, campaign, medium, status, score, temperature, owner_user_id, notes, last_activity_at, created_at, updated_at, contact_id, primary_ticket_id, converted_client_id, converted_at, lead_status, lid) FROM stdin;
1272    131 Murilo  \N  5511993612214   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 13:19:34.573+00  2026-02-04 13:17:07.502+00  2026-02-04 13:19:34.573+00  \N  \N  \N  \N  novo    \N
1238    131 Neto        5511959590402   \N                      \N  contacted   0   \N  \N      2026-02-04 13:16:58.714+00  2026-02-02 03:23:18.827+00  2026-02-04 13:16:58.714+00  \N  \N  \N  \N  novo    \N
86  74  Food Plus   \N  21969412092104  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:04:00.145+00  2026-01-02 21:04:00.145+00  2026-01-02 21:04:00.145+00  \N  \N  \N  \N  novo    \N
87  74  Rafael  \N  5524993959492   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:05:41.302+00  2026-01-02 21:05:41.302+00  2026-01-02 21:11:47.531+00  \N  \N  \N  \N  novo    \N
88  74  Food Plus   \N  21969412092104  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:12:24.777+00  2026-01-02 21:12:24.777+00  2026-01-02 21:12:24.777+00  \N  \N  \N  \N  novo    \N
1239    131 Priscila😜   \N  5511969090402   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-02 12:17:42.499+00  2026-02-02 12:16:27.474+00  2026-02-02 12:17:42.499+00  \N  \N  \N  \N  novo    \N
83  70  178490603257889 \N  178490603257889 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 11:12:24.596+00  2026-01-02 11:12:24.596+00  2026-01-02 11:12:24.596+00  \N  \N  \N  \N  novo    \N
91  74  Lucas Rodrigues \N  185925007110197 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:14:06.91+00   2026-01-02 21:14:06.91+00   2026-01-02 21:14:06.91+00   \N  \N  \N  \N  novo    \N
90  74  120044822507706 \N  120044822507706 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:13:14.125+00  2026-01-02 21:13:14.125+00  2026-01-02 21:14:49.171+00  \N  \N  \N  \N  novo    \N
89  74  Food Plus   \N  21969412092104  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:12:56.566+00  2026-01-02 21:12:56.566+00  2026-01-02 21:12:56.566+00  \N  \N  \N  \N  novo    \N
901 103 Ailton Lopes    \N  5511983012483   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 00:58:51.656+00  2026-01-16 00:58:51.656+00  2026-01-16 00:58:51.656+00  \N  \N  \N  \N  novo    \N
950 103 Rafa Canovas    \N  5511983324287   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 23:51:14.264+00  2026-01-16 23:51:14.264+00  2026-01-16 23:51:14.264+00  \N  \N  \N  \N  novo    \N
840 103 Mirela Batista  \N  5511983250004   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 15:48:39.786+00  2026-01-14 15:48:39.786+00  2026-01-14 15:48:39.786+00  \N  \N  \N  \N  novo    \N
1006    103 Eliane Arbex    \N  5511985015745   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 16:28:50.239+00  2026-01-18 16:28:50.239+00  2026-01-18 16:28:50.239+00  \N  \N  \N  \N  novo    \N
1008    103 Silvia Parise   \N  5519987028272   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 19:14:07.42+00   2026-01-18 19:14:07.42+00   2026-01-18 19:14:07.42+00   \N  \N  \N  \N  novo    \N
1125    111 Contato sem nome    \N  5524992754226   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 05:36:48.43+00   2026-01-25 05:36:48.43+00   2026-01-25 05:36:48.43+00   \N  \N  \N  \N  novo    \N
80  70  120044822507706 \N  5524993959492   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 10:59:18.85+00   2026-01-02 10:59:18.85+00   2026-01-02 11:15:44.071+00  \N  \N  \N  \N  novo    \N
82  70  APsolutions Technology Services \N  249817410310204 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 11:12:18.422+00  2026-01-02 11:12:18.422+00  2026-01-02 11:12:18.422+00  \N  \N  \N  \N  novo    \N
81  70  APsolutions Technology Services \N  249817410310204 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 10:59:46.916+00  2026-01-02 10:59:46.916+00  2026-01-02 11:02:16.115+00  \N  \N  \N  \N  novo    \N
129 74  Cida 🌹🌺🌹    \N  244190449553443 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 14:49:11.288+00  2026-01-03 14:49:11.288+00  2026-01-03 14:49:11.288+00  \N  \N  \N  \N  novo    \N
124 74  5511998515914   \N  5511998515914   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 09:25:34.061+00  2026-01-03 09:25:34.061+00  2026-01-03 09:25:34.061+00  \N  \N  \N  \N  novo    \N
130 74  Wal - Waldemir Ferrarez \N  556181548707    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 15:42:03.239+00  2026-01-03 15:42:03.239+00  2026-01-03 15:42:03.239+00  \N  \N  \N  \N  novo    \N
144 74  Lívia Viana \N  5511972529008   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 19:05:13.27+00   2026-01-03 19:05:13.271+00  2026-01-03 19:05:13.271+00  \N  \N  \N  \N  novo    \N
151 74  .   \N  5511957370281   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 21:07:00.328+00  2026-01-03 21:07:00.341+00  2026-01-03 21:07:00.341+00  \N  \N  \N  \N  novo    \N
156 74  Associação Cruz de Malta    \N  556132747950    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 21:45:37.701+00  2026-01-03 21:45:37.701+00  2026-01-03 21:45:37.701+00  \N  \N  \N  \N  novo    \N
1007    103 luancyrillo \N  5511986868718   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 17:33:24.963+00  2026-01-18 17:33:24.964+00  2026-01-18 17:33:24.964+00  \N  \N  \N  \N  novo    \N
774 103 Mirian Khéde    \N  5528999442536   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 14:37:55.216+00  2026-01-13 14:37:55.217+00  2026-01-13 14:37:55.217+00  \N  \N  \N  \N  novo    \N
846 103 Gessica Marques \N  556299592235    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 20:08:57.152+00  2026-01-14 20:08:57.152+00  2026-01-14 20:08:57.152+00  \N  \N  \N  \N  novo    \N
747 103 Food Plus   \N  553172378117    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-11 22:35:36.714+00  2026-01-11 22:35:36.714+00  2026-01-11 22:35:36.714+00  \N  \N  \N  \N  novo    \N
902 103 Vanessa Foppa   \N  555199159870    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 01:03:22.097+00  2026-01-16 01:03:22.097+00  2026-01-16 01:03:22.097+00  \N  \N  \N  \N  novo    \N
951 103 Ricardo \N  5511992327598   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 23:57:50.034+00  2026-01-16 23:57:50.034+00  2026-01-16 23:57:50.034+00  \N  \N  \N  \N  novo    \N
955 103 🌸🌸🌸Jo🍀🍀🍀🍀🍀  \N  553584261206    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 00:16:20.905+00  2026-01-17 00:16:20.905+00  2026-01-17 00:16:20.905+00  \N  \N  \N  \N  novo    \N
748 5   Rafael  \N  5524993959492   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 17:22:16.981+00  2026-01-12 17:22:16.981+00  2026-01-12 17:22:16.981+00  \N  \N  \N  \N  novo    \N
1009    103 Mariana \N  5511982253097   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 19:16:43.904+00  2026-01-18 19:16:43.905+00  2026-01-18 19:16:43.905+00  \N  \N  \N  \N  novo    \N
853 103 T.  \N  5511987818153   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 23:28:36.52+00   2026-01-14 23:28:36.52+00   2026-01-14 23:28:36.52+00   \N  \N  \N  \N  novo    \N
952 103 Paula Baroni Santi  \N  5533761691218   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 00:04:12.335+00  2026-01-17 00:04:12.335+00  2026-01-17 00:04:12.335+00  \N  \N  \N  \N  novo    \N
842 103 Stela Canoa \N  5518997177090   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 17:35:40.285+00  2026-01-14 17:35:40.285+00  2026-01-14 17:35:40.285+00  \N  \N  \N  \N  novo    \N
164 74  Guilherme   \N  5518981333757   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 23:27:00.933+00  2026-01-03 23:27:00.933+00  2026-01-03 23:27:00.933+00  \N  \N  \N  \N  novo    \N
168 74  Carlos Pusch    \N  5511999373038   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 00:11:28.514+00  2026-01-04 00:11:28.514+00  2026-01-04 00:11:28.514+00  \N  \N  \N  \N  novo    \N
161 74  Henrique Crawford   \N  5511981609400   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 23:20:08.109+00  2026-01-03 23:20:08.109+00  2026-01-03 23:20:08.109+00  \N  \N  \N  \N  novo    \N
1137    112 Vitória Lopes   \N  555197332988    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-05 02:10:48.856+00  2026-01-26 11:44:23.108+00  2026-02-05 02:10:48.856+00  \N  \N  \N  \N  novo    \N
1138    112 Hitec Informática   \N  558006066054    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 11:44:23.453+00  2026-01-26 11:44:23.453+00  2026-01-26 11:44:23.453+00  \N  \N  \N  \N  novo    \N
1139    112 Atendimento \N  5527996716613   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 12:07:13.243+00  2026-01-26 12:07:13.244+00  2026-01-26 12:07:20.148+00  \N  \N  \N  \N  novo    \N
1140    112 Vintor  \N  5512988415918   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 12:08:27.817+00  2026-01-26 12:08:27.818+00  2026-01-26 12:08:27.818+00  \N  \N  \N  \N  novo    \N
1273    5   Amélia  \N  5524999521878   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 14:53:13.973+00  2026-02-04 14:53:01.244+00  2026-02-04 14:53:13.973+00  \N  \N  \N  \N  novo    \N
1044    5   Gabriel Fernandes   \N  5524999095827   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-19 14:30:08.462+00  2026-01-19 14:30:08.463+00  2026-01-19 14:32:13.586+00  \N  \N  \N  \N  novo    \N
1045    5   Ronney Vianna   \N  5524981214444   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-19 17:17:01.484+00  2026-01-19 17:17:01.484+00  2026-01-19 17:17:01.484+00  \N  \N  \N  \N  novo    \N
1237    5   Rafael Cavallotti   \N  5524999995852   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-02 13:43:37.664+00  2026-02-01 21:37:06.154+00  2026-02-02 13:43:37.664+00  \N  \N  \N  \N  novo    \N
1178    5   Daniel  \N  5524992938427   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-28 11:30:29.472+00  2026-01-28 11:30:29.472+00  2026-01-28 11:30:29.472+00  \N  \N  \N  \N  novo    \N
1179    5   Contato sem nome    \N  5524999870237   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-28 11:42:47.553+00  2026-01-28 11:42:47.553+00  2026-01-28 11:42:47.553+00  \N  \N  \N  \N  novo    \N
1180    5   Shirlene    \N  5524992464962   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-28 11:44:28.03+00   2026-01-28 11:44:28.03+00   2026-01-28 12:19:00.848+00  \N  \N  \N  \N  novo    \N
841 5   Marlene \N  5524999978618   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 16:52:44.292+00  2026-01-14 16:52:44.293+00  2026-01-14 16:52:44.293+00  \N  \N  \N  \N  novo    \N
773 5   JOSÉ DE MAGALHÁES PERES \N  5521997635960   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 13:24:58.841+00  2026-01-13 13:24:58.841+00  2026-01-13 13:24:58.841+00  \N  \N  \N  \N  novo    \N
200 74  Isadora Hoffmann    \N  554799261903    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 21:18:18.802+00  2026-01-04 21:18:18.802+00  2026-01-04 21:18:18.802+00  \N  \N  \N  \N  novo    \N
1276    130 Flavio Guirado  Vectax  \N  558496770061    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 17:41:37.908+00  2026-02-04 17:04:30.069+00  2026-02-04 17:41:37.908+00  \N  \N  \N  \N  novo    \N
220 74  Anna Costa  \N  556996012073    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 23:20:17.686+00  2026-01-04 23:20:17.686+00  2026-01-04 23:20:17.686+00  \N  \N  \N  \N  novo    \N
1278    130 Rafael Fonseca  \N  5521982027149   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 17:40:08.143+00  2026-02-04 17:40:08.128+00  2026-02-04 17:40:08.143+00  \N  \N  \N  \N  novo    \N
749 5   Rafael  \N  5524993959492   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 17:27:23.495+00  2026-01-12 17:27:23.495+00  2026-01-12 17:27:23.495+00  \N  \N  \N  \N  novo    \N
776 103 Lucas Aragão    \N  557599036857    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 15:34:30.562+00  2026-01-13 15:34:30.562+00  2026-01-13 15:34:30.562+00  \N  \N  \N  \N  novo    \N
1010    103 Me  \N  5511913099365   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 19:22:39.67+00   2026-01-18 19:22:39.67+00   2026-01-18 19:22:39.67+00   \N  \N  \N  \N  novo    \N
904 103 Ádelin  \N  5511960505577   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 02:11:56.723+00  2026-01-16 02:11:56.724+00  2026-01-16 02:11:56.724+00  \N  \N  \N  \N  novo    \N
762 103 Michael \N  5511992276364   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 23:38:01.024+00  2026-01-12 23:38:01.025+00  2026-01-17 21:39:50.397+00  \N  \N  \N  \N  novo    \N
953 103 Carlos A Matos  \N  5511951269940   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 00:04:55.232+00  2026-01-17 00:04:55.232+00  2026-01-17 00:04:55.232+00  \N  \N  \N  \N  novo    \N
221 74  Guilherme Scardini  \N  5521996820511   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 23:28:18.829+00  2026-01-04 23:28:18.829+00  2026-01-04 23:28:18.829+00  \N  \N  \N  \N  novo    \N
222 74  Analu   \N  5511999993363   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 23:33:25.849+00  2026-01-04 23:33:25.849+00  2026-01-04 23:33:25.849+00  \N  \N  \N  \N  novo    \N
231 74  Y   \N  554598508859    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 01:05:39.613+00  2026-01-05 01:05:39.613+00  2026-01-05 01:05:39.613+00  \N  \N  \N  \N  novo    \N
1241    132 Empresa 1   empresa3@demo.com   89520312    2026-02-11  123465  empresa3    15132   123132  2313212 paid_social new 10  frio    131 23123132    2026-02-03 05:17:49.894+00  2026-02-03 05:17:49.894+00  2026-02-03 05:17:49.894+00  \N  \N  \N  \N  novo    \N
777 103 Bruna L \N  5541764603841   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 16:40:52.583+00  2026-01-13 16:40:52.583+00  2026-01-13 16:40:52.583+00  \N  \N  \N  \N  novo    \N
1011    103 💥   \N  5511974344200   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 20:18:36+00  2026-01-18 20:18:36+00  2026-01-18 20:18:36+00  \N  \N  \N  \N  novo    \N
848 103 Kelly Gama  \N  5533762641515   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 21:05:32.939+00  2026-01-14 21:05:32.939+00  2026-01-14 21:05:32.939+00  \N  \N  \N  \N  novo    \N
905 103 Carlos Emerson  \N  558681297171    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 02:38:21.92+00   2026-01-16 02:38:21.92+00   2026-01-16 02:38:21.92+00   \N  \N  \N  \N  novo    \N
954 103 Susana  \N  5511967554242   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 00:11:39.888+00  2026-01-17 00:11:39.888+00  2026-01-17 00:11:39.888+00  \N  \N  \N  \N  novo    \N
232 74  122728740864089 \N  122728740864089 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 01:06:17.044+00  2026-01-05 01:06:17.044+00  2026-01-05 01:06:17.044+00  \N  \N  \N  \N  novo    \N
223 74  alexandre martins junior    \N  5511999865957   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 23:37:42.591+00  2026-01-04 23:37:42.591+00  2026-01-04 23:37:42.591+00  \N  \N  \N  \N  novo    \N
1242    132 Rafael Paixão   \N  5524993959492   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 05:21:51.982+00  2026-02-03 05:21:51.97+00   2026-02-03 05:21:51.982+00  \N  \N  \N  \N  novo    \N
778 103 André Canuto    \N  556185959686    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 16:47:50.978+00  2026-01-13 16:47:50.978+00  2026-01-13 16:47:50.978+00  \N  \N  \N  \N  novo    \N
1012    103 .   \N  5511952430068   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 20:43:31.544+00  2026-01-18 20:43:31.544+00  2026-01-18 20:43:31.544+00  \N  \N  \N  \N  novo    \N
849 103 Matheus Alves Aquino    \N  554497634999    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 21:40:17.131+00  2026-01-14 21:40:17.131+00  2026-01-14 21:40:17.131+00  \N  \N  \N  \N  novo    \N
906 103 Mônica Fernandes    \N  5511930162454   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 02:56:29.257+00  2026-01-16 02:56:29.257+00  2026-01-16 02:56:29.257+00  \N  \N  \N  \N  novo    \N
957 103 Renata Diniz    \N  5511934073007   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 00:25:35.518+00  2026-01-17 00:25:35.518+00  2026-01-17 00:25:35.518+00  \N  \N  \N  \N  novo    \N
224 74  231404449353816 \N  231404449353816 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 23:44:58.826+00  2026-01-04 23:44:58.826+00  2026-01-04 23:44:58.826+00  \N  \N  \N  \N  novo    \N
1049    104 Maria Eduarda   \N  554899993273    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-20 18:05:43.527+00  2026-01-20 18:05:43.527+00  2026-01-20 18:30:54.883+00  \N  \N  \N  \N  novo    \N
1013    103 Rafael Serraneto ®️ \N  5519997443352   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 20:47:45.724+00  2026-01-18 20:47:45.725+00  2026-01-18 20:47:45.725+00  \N  \N  \N  \N  novo    \N
851 103 Guilherme Marcondes \N  554788034370    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 23:13:52.691+00  2026-01-14 23:13:52.691+00  2026-01-14 23:13:52.691+00  \N  \N  \N  \N  novo    \N
752 103 P R I S C I L L A🤍  \N  558399151020    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 21:56:36.971+00  2026-01-12 21:56:36.971+00  2026-01-12 21:56:36.971+00  \N  \N  \N  \N  novo    \N
753 103 5511956058354   \N  5511956058354   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 21:56:59.115+00  2026-01-12 21:56:59.116+00  2026-01-12 21:56:59.116+00  \N  \N  \N  \N  novo    \N
907 103 Caroline    \N  5511983896351   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 02:57:00.74+00   2026-01-16 02:57:00.74+00   2026-01-16 13:21:22.558+00  \N  \N  \N  \N  novo    \N
958 103 Cristiane   \N  555481135203    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 00:30:04.29+00   2026-01-17 00:30:04.291+00  2026-01-17 00:30:04.291+00  \N  \N  \N  \N  novo    \N
1050    104 Contato sem nome 2372   \N  246810513772736 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-20 18:49:23.307+00  2026-01-20 18:49:23.307+00  2026-01-20 22:00:00.075+00  \N  \N  \N  \N  novo    \N
1141    112 Consultor Teiachat CRM  \N  554130872537    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 13:08:11.916+00  2026-01-26 13:08:11.917+00  2026-01-26 13:08:11.917+00  \N  \N  \N  \N  novo    \N
1143    112 Site Connect    \N  554192098329    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 13:21:48.409+00  2026-01-26 13:21:48.41+00   2026-01-26 13:21:48.41+00   \N  \N  \N  \N  novo    \N
1130    112 Grupo 5 Elementos   \N  555192934318    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 20:48:50.503+00  2026-01-25 17:27:43.886+00  2026-02-04 20:48:50.504+00  \N  \N  \N  \N  novo    \N
1145    112 Synapse Labs - Tecnologia   \N  556381032759    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 14:00:22.856+00  2026-01-26 14:00:22.858+00  2026-01-26 14:00:22.858+00  \N  \N  \N  \N  novo    \N
1275    112 Eliz Pires\nTreinadora comportamental   \N  555181919970    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 15:16:43.425+00  2026-02-04 15:16:43.412+00  2026-02-04 15:16:43.425+00  \N  \N  \N  \N  novo    \N
1277    112 Amanda Passos   \N  555191877792    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 20:49:34.42+00   2026-02-04 17:31:46.197+00  2026-02-04 20:49:34.42+00   \N  \N  \N  \N  novo    \N
1182    112 Cristian Alves | CGG Assessoria \N  553584089707    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-28 14:56:58.427+00  2026-01-28 14:56:58.428+00  2026-01-30 00:03:06.396+00  \N  \N  \N  \N  novo    \N
1183    112 Bruno Simões | Synlua   \N  5511945592596   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 22:49:46.83+00   2026-01-28 16:58:36.248+00  2026-02-03 22:49:46.83+00   \N  \N  \N  \N  novo    \N
1054    107 Contato sem nome    \N  5546935052107   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-20 23:03:37.583+00  2026-01-20 23:03:37.583+00  2026-01-20 23:03:37.583+00  \N  \N  \N  \N  novo    \N
1184    5   Isadora Chaves  \N  5524993306963   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-28 17:20:58.769+00  2026-01-28 17:20:58.769+00  2026-01-28 17:30:41.192+00  \N  \N  \N  \N  novo    \N
1144    5   Camila Moraes   \N  5524974015554   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 13:40:28.546+00  2026-01-26 13:40:28.546+00  2026-01-26 13:40:28.546+00  \N  \N  \N  \N  novo    \N
750 5   Contato sem nome 2071   \N  120044822507706 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 17:29:37.19+00   2026-01-12 17:29:37.19+00   2026-01-13 16:13:42.188+00  \N  \N  \N  \N  novo    \N
1181    5   Livia Diniz \N  5524999879215   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-28 11:50:17.818+00  2026-01-28 11:50:17.818+00  2026-01-28 11:51:36.815+00  \N  \N  \N  \N  novo    \N
843 5   Cláudia Toti Tintas \N  5524999487471   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 17:48:04.004+00  2026-01-14 17:48:04.004+00  2026-01-14 17:48:04.004+00  \N  \N  \N  \N  novo    \N
751 5   Rafael  \N  5524993959492   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 17:36:02.095+00  2026-01-12 17:36:02.095+00  2026-01-12 17:36:02.095+00  \N  \N  \N  \N  novo    \N
1047    5   Manu Ravaneli   \N  5524992876776   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-20 12:21:39.699+00  2026-01-20 12:21:39.699+00  2026-01-20 12:21:39.699+00  \N  \N  \N  \N  novo    \N
225 74  Wair De Paula   \N  5511950599935   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 23:56:19.313+00  2026-01-04 23:56:19.313+00  2026-01-04 23:56:19.313+00  \N  \N  \N  \N  novo    \N
226 74  Bruna A.    \N  5511999399309   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 00:00:54.657+00  2026-01-05 00:00:54.657+00  2026-01-05 00:00:54.657+00  \N  \N  \N  \N  novo    \N
780 103 Cmc vendas  \N  5511918779887   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 17:44:11.482+00  2026-01-13 17:44:11.482+00  2026-01-13 17:44:11.482+00  \N  \N  \N  \N  novo    \N
1014    103 Fe Gentil   \N  5511976086555   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 21:11:08.836+00  2026-01-18 21:11:08.836+00  2026-01-18 21:11:08.836+00  \N  \N  \N  \N  novo    \N
1020    103 Carolina Saraiva    \N  5511940721127   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 21:57:30.805+00  2026-01-18 21:57:30.805+00  2026-01-18 21:57:30.805+00  \N  \N  \N  \N  novo    \N
852 103 Carmen  \N  5511991089101   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 23:15:32.167+00  2026-01-14 23:15:32.167+00  2026-01-14 23:15:32.167+00  \N  \N  \N  \N  novo    \N
754 103 Sinesia \N  5511985574801   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 22:01:55.153+00  2026-01-12 22:01:55.153+00  2026-01-12 22:01:55.153+00  \N  \N  \N  \N  novo    \N
959 103 Ana Mageste \N  5511986617337   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 00:34:21.959+00  2026-01-17 00:34:21.959+00  2026-01-17 00:34:21.959+00  \N  \N  \N  \N  novo    \N
227 74  Luane Esparza   \N  5517997747888   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 00:29:26.026+00  2026-01-05 00:29:26.026+00  2026-01-05 00:29:26.026+00  \N  \N  \N  \N  novo    \N
228 74  226018409377890 \N  226018409377890 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 00:39:45.039+00  2026-01-05 00:39:45.039+00  2026-01-05 00:39:45.039+00  \N  \N  \N  \N  novo    \N
229 74  Henrique    \N  5511956599127   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 00:48:01.061+00  2026-01-05 00:48:01.061+00  2026-01-05 00:48:01.061+00  \N  \N  \N  \N  novo    \N
234 74  83421820883149  \N  83421820883149  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 02:19:19.124+00  2026-01-05 02:19:19.125+00  2026-01-05 02:19:19.125+00  \N  \N  \N  \N  novo    \N
782 103 Larissa Feitoza \N  5511993625876   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 18:30:05.926+00  2026-01-13 18:30:05.926+00  2026-01-13 18:30:05.926+00  \N  \N  \N  \N  novo    \N
1015    103 Juliana \N  5514981115540   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 21:14:59.3+00    2026-01-18 21:14:59.301+00  2026-01-18 21:14:59.301+00  \N  \N  \N  \N  novo    \N
755 103 Marco   \N  556598119921    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 22:20:49.34+00   2026-01-12 22:20:49.34+00   2026-01-12 22:20:49.34+00   \N  \N  \N  \N  novo    \N
855 103 Fabiana Lira    \N  5511948691996   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 23:49:49.303+00  2026-01-14 23:49:49.303+00  2026-01-14 23:49:49.303+00  \N  \N  \N  \N  novo    \N
961 103 Fabricio    \N  5511982728721   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 01:23:14.288+00  2026-01-17 01:23:14.288+00  2026-01-17 01:23:14.288+00  \N  \N  \N  \N  novo    \N
266 5   Rafael  \N  120044822507706 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 20:23:54.838+00  2026-01-05 20:23:54.838+00  2026-01-05 20:23:54.838+00  \N  \N  \N  \N  novo    \N
265 5   Rafael  \N  5524993959492   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 20:23:44.534+00  2026-01-05 20:23:44.534+00  2026-01-05 20:23:44.534+00  \N  \N  \N  \N  novo    \N
783 103 Daniele Mitie   \N  5511946750859   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 18:38:16.357+00  2026-01-13 18:38:16.357+00  2026-01-13 18:38:16.357+00  \N  \N  \N  \N  novo    \N
1016    103 BCB \N  5511988549934   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 21:21:54.664+00  2026-01-18 21:21:54.664+00  2026-01-18 21:21:54.664+00  \N  \N  \N  \N  novo    \N
1022    103 Eduardo Queiroz \N  5511991271478   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 22:31:44.594+00  2026-01-18 22:31:44.595+00  2026-01-18 22:31:44.595+00  \N  \N  \N  \N  novo    \N
756 103 Daniela Ferreira    \N  5516996101419   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 22:28:25.967+00  2026-01-12 22:28:25.967+00  2026-01-12 22:28:25.967+00  \N  \N  \N  \N  novo    \N
856 103 Lays Frazão \N  556799111602    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 00:13:46.118+00  2026-01-15 00:13:46.118+00  2026-01-15 00:13:46.118+00  \N  \N  \N  \N  novo    \N
962 103 Wania   \N  5511991665747   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 02:08:11.521+00  2026-01-17 02:08:11.522+00  2026-01-17 02:08:11.522+00  \N  \N  \N  \N  novo    \N
290 74  150560229584909 \N  150560229584909 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 01:41:46.587+00  2026-01-06 01:41:46.587+00  2026-01-06 01:41:46.587+00  \N  \N  \N  \N  novo    \N
239 74  46183967883426  \N  46183967883426  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 10:04:27.494+00  2026-01-05 10:04:27.494+00  2026-01-05 10:04:27.494+00  \N  \N  \N  \N  novo    \N
275 74  Maria Ester \N  5521991851702   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 22:34:18.358+00  2026-01-05 22:34:18.358+00  2026-01-05 22:34:18.358+00  \N  \N  \N  \N  novo    \N
276 74  M   \N  5511915161600   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 22:37:42.432+00  2026-01-05 22:37:42.432+00  2026-01-05 22:37:42.432+00  \N  \N  \N  \N  novo    \N
296 74  119438946893911 \N  119438946893911 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 12:33:43.078+00  2026-01-06 12:33:43.078+00  2026-01-06 12:33:43.078+00  \N  \N  \N  \N  novo    \N
784 103 Artur Oliveira  \N  5511955588384   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 18:47:06.469+00  2026-01-13 18:47:06.469+00  2026-01-13 18:47:06.469+00  \N  \N  \N  \N  novo    \N
1017    103 Betina Rezende  \N  554888345375    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 21:27:11.843+00  2026-01-18 21:27:11.843+00  2026-01-18 21:27:11.843+00  \N  \N  \N  \N  novo    \N
757 103 Moraes Lucas    \N  99102192848934  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 23:07:18.56+00   2026-01-12 23:07:18.56+00   2026-01-12 23:07:18.56+00   \N  \N  \N  \N  novo    \N
1132    112 Bete    \N  555196220428    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 19:08:14.31+00   2026-01-25 19:08:14.31+00   2026-01-25 19:08:14.31+00   \N  \N  \N  \N  novo    \N
1146    112 Alisson \N  554888380737    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 14:19:56.457+00  2026-01-26 14:19:56.458+00  2026-01-26 14:19:56.458+00  \N  \N  \N  \N  novo    \N
1147    112 Auto Unique \N  555192288591    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 16:14:25.016+00  2026-01-26 16:14:25.016+00  2026-01-26 16:30:02.047+00  \N  \N  \N  \N  novo    \N
1133    112 Contato sem nome 2452   \N  172546133618899 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 19:08:25.75+00   2026-01-25 19:08:25.75+00   2026-01-25 22:00:00.13+00   \N  \N  \N  \N  novo    \N
1135    112 Rafael Paixão   \N  5524993959492   \N  \N                  \N  converted   0   \N  \N      2026-01-31 00:31:44.34+00   2026-01-25 22:51:51.51+00   2026-01-31 00:31:44.34+00   \N  \N  22  2026-01-25 23:35:37.751+00  convertido  \N
1149    112 Mtech Systems   \N  temp-1769449567110910   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 17:46:07.227+00  2026-01-26 17:46:07.228+00  2026-01-26 17:50:16.81+00   \N  \N  \N  \N  novo    \N
1254    112 Ana…    \N  555181306511    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 20:02:14.701+00  2026-02-03 17:01:44.502+00  2026-02-03 20:02:14.701+00  \N  \N  \N  \N  novo    \N
1148    107 Luiz Gustavo    \N  5511932573888   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 16:46:39.849+00  2026-01-26 16:46:39.85+00   2026-01-26 16:46:39.85+00   \N  \N  \N  \N  novo    \N
1053    107 Laudir Bispo - H5 Company Marketing \N  554688074970    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-20 19:27:08.392+00  2026-01-20 19:27:08.392+00  2026-01-20 19:27:08.392+00  \N  \N  \N  \N  novo    \N
289 5   Contato sem nome 7  \N  5524992153735   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 01:30:32.548+00  2026-01-06 01:30:32.548+00  2026-01-16 01:53:08.743+00  \N  \N  \N  \N  novo    \N
295 5   87836460097630  \N  87836460097630  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 11:58:37.953+00  2026-01-06 11:58:37.953+00  2026-01-06 11:58:37.953+00  \N  \N  \N  \N  novo    \N
280 5   183649127403549 \N  183649127403549 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 23:07:41.611+00  2026-01-05 23:07:41.611+00  2026-01-05 23:07:41.611+00  \N  \N  \N  \N  novo    \N
1279    5   Sthefany    \N  5524998217832   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 20:15:32.892+00  2026-02-04 20:12:23.332+00  2026-02-04 20:15:32.892+00  \N  \N  \N  \N  novo    \N
1280    5   Dani    \N  5524998700554   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 20:35:28.765+00  2026-02-04 20:12:23.337+00  2026-02-04 20:35:28.765+00  \N  \N  \N  \N  novo    \N
267 5   Jeane Nascimento    \N  5524993178237   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 20:40:24.843+00  2026-01-05 20:40:24.843+00  2026-01-20 19:32:19.713+00  \N  \N  \N  \N  novo    \N
288 5   210105521967137 \N  210105521967137 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 00:55:16.28+00   2026-01-06 00:55:16.28+00   2026-01-06 00:55:16.28+00   \N  \N  \N  \N  novo    \N
274 5   Jéssica 😁   \N  5524998607865   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 22:07:31.952+00  2026-01-05 22:07:31.952+00  2026-01-05 22:07:31.952+00  \N  \N  \N  \N  novo    \N
911 5   Katellin Paixão \N  5524998580623   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 07:25:34.223+00  2026-01-16 07:25:34.223+00  2026-01-16 07:25:34.223+00  \N  \N  \N  \N  novo    \N
1187    5   Luciana Dias    \N  553284322076    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-28 19:55:02.149+00  2026-01-28 19:55:02.149+00  2026-01-28 19:55:59.3+00    \N  \N  \N  \N  novo    \N
857 103 Guilherme Mello \N  5511971722416   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 00:26:52.289+00  2026-01-15 00:26:52.289+00  2026-01-15 00:26:52.289+00  \N  \N  \N  \N  novo    \N
964 103 Giulia Suleimann    \N  5511995048467   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 18:06:17.594+00  2026-01-17 18:06:17.594+00  2026-01-17 18:06:17.594+00  \N  \N  \N  \N  novo    \N
1055    104 Contato sem nome 2377   \N  555180464545    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-21 13:15:19.139+00  2026-01-21 13:15:19.14+00   2026-01-21 13:23:07.204+00  \N  \N  \N  \N  novo    \N
800 104 Breno   \N  559881746197    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:25.368+00  2026-01-13 21:24:25.368+00  2026-01-21 14:23:50.869+00  \N  \N  \N  \N  novo    \N
785 103 Sergio Krivt    \N  5511999742363   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 19:10:48.155+00  2026-01-13 19:10:48.155+00  2026-01-13 19:10:48.155+00  \N  \N  \N  \N  novo    \N
1018    103 Valdeir \N  554792633306    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 21:33:30.428+00  2026-01-18 21:33:30.428+00  2026-01-18 21:33:30.428+00  \N  \N  \N  \N  novo    \N
758 103 Desirrê \N  554198772317    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 23:11:33.377+00  2026-01-12 23:11:33.377+00  2026-01-12 23:11:33.377+00  \N  \N  \N  \N  novo    \N
858 103 Lú_Brait    \N  5511998223632   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 00:32:39.996+00  2026-01-15 00:32:39.997+00  2026-01-15 00:32:39.997+00  \N  \N  \N  \N  novo    \N
912 103 Felipe Dantas   \N  5511972336509   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 09:42:14.291+00  2026-01-16 09:42:14.292+00  2026-01-16 09:42:14.292+00  \N  \N  \N  \N  novo    \N
965 103 Ana Lúcia Camboim Pitta \N  558188829904    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 18:48:47.854+00  2026-01-17 18:48:47.855+00  2026-01-17 18:48:47.855+00  \N  \N  \N  \N  novo    \N
304 74  20401111433395  \N  20401111433395  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 14:49:36.839+00  2026-01-06 14:49:36.839+00  2026-01-06 14:49:36.839+00  \N  \N  \N  \N  novo    \N
305 74  161508134785251 \N  161508134785251 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 15:03:53.907+00  2026-01-06 15:03:53.907+00  2026-01-06 15:03:53.907+00  \N  \N  \N  \N  novo    \N
350 74  Eduardo Gonzales    \N  5518981769093   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:43:19.295+00  2026-01-06 23:43:19.295+00  2026-01-06 23:43:19.295+00  \N  \N  \N  \N  novo    \N
317 74  🌹Glete 🎀🌷   \N  5511996317604   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 19:06:07.512+00  2026-01-06 19:06:07.512+00  2026-01-06 19:06:07.512+00  \N  \N  \N  \N  novo    \N
357 86  74002336878654  \N  74002336878654  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 02:36:15.468+00  2026-01-07 02:36:15.468+00  2026-01-07 02:36:15.468+00  \N  \N  \N  \N  novo    \N
322 86  E R I C K   \N  5550256927383   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 20:57:02.014+00  2026-01-06 20:57:02.014+00  2026-01-06 20:57:02.014+00  \N  \N  \N  \N  novo    \N
324 86  183103683338452 \N  183103683338452 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 22:02:00.437+00  2026-01-06 22:02:00.438+00  2026-01-06 22:02:00.438+00  \N  \N  \N  \N  novo    \N
325 86  257376032673915 \N  257376032673915 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 22:12:45.77+00   2026-01-06 22:12:45.77+00   2026-01-06 22:12:45.77+00   \N  \N  \N  \N  novo    \N
356 86  Connecta    \N  5550254534295   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 00:52:28.455+00  2026-01-07 00:52:28.455+00  2026-01-07 00:52:28.455+00  \N  \N  \N  \N  novo    \N
323 86  50231353891 \N  5550231353891   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 21:15:50.398+00  2026-01-06 21:15:50.398+00  2026-01-06 21:15:50.398+00  \N  \N  \N  \N  novo    \N
326 86  Celeste Vásquez     \N  5550257232704   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:09:40.876+00  2026-01-06 23:09:40.876+00  2026-01-06 23:09:40.876+00  \N  \N  \N  \N  novo    \N
1056    104 Aninha  \N  555192383755    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-21 13:23:41.793+00  2026-01-21 13:23:41.793+00  2026-01-21 14:29:59.215+00  \N  \N  \N  \N  novo    \N
966 103 Angie 😈 \N  5511965487756   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 19:48:42.683+00  2026-01-17 19:48:42.683+00  2026-01-17 19:48:42.683+00  \N  \N  \N  \N  novo    \N
786 103 Bruno Araújo    \N  559884980793    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 20:18:19.828+00  2026-01-13 20:18:19.828+00  2026-01-13 20:18:19.828+00  \N  \N  \N  \N  novo    \N
1019    103 Marcia Maria    \N  5511973951047   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 21:41:15.95+00   2026-01-18 21:41:15.95+00   2026-01-18 21:41:15.95+00   \N  \N  \N  \N  novo    \N
759 103 5511996220121   \N  5511996220121   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 23:12:28.346+00  2026-01-12 23:12:28.346+00  2026-01-12 23:12:28.346+00  \N  \N  \N  \N  novo    \N
859 103 Francine    \N  5511984569491   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 00:36:00.278+00  2026-01-15 00:36:00.278+00  2026-01-15 00:36:00.278+00  \N  \N  \N  \N  novo    \N
921 103 Andreia Leite   \N  5511998705596   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 16:57:28.172+00  2026-01-16 16:57:28.172+00  2026-01-16 16:57:28.172+00  \N  \N  \N  \N  novo    \N
374 74  190752466403580 \N  190752466403580 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:26:03.194+00  2026-01-07 05:26:03.195+00  2026-01-07 05:26:03.195+00  \N  \N  \N  \N  novo    \N
400 74  279293384986825 \N  279293384986825 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:05:36.563+00  2026-01-07 06:05:36.564+00  2026-01-07 06:05:36.564+00  \N  \N  \N  \N  novo    \N
422 74  6352273416206   \N  6352273416206   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:36:49.568+00  2026-01-07 06:36:49.568+00  2026-01-07 06:36:49.568+00  \N  \N  \N  \N  novo    \N
1136    112 Contato sem nome 2455   \N  120044822507706 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 22:52:00.119+00  2026-01-25 22:52:00.119+00  2026-01-26 10:00:00.108+00  \N  \N  \N  \N  novo    \N
1252    112 Ana…    \N  555181306511    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.482+00  2026-02-03 17:01:44.482+00  2026-02-03 17:01:44.482+00  \N  \N  \N  \N  novo    \N
1151    112 Hubbie  \N  553173173548    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:45.148+00  2026-01-26 19:50:01.143+00  2026-02-03 17:01:45.148+00  \N  \N  \N  \N  novo    \N
1282    112 Nova Digital    \N  553196510686    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 22:56:55.456+00  2026-02-04 22:54:33.534+00  2026-02-04 22:56:55.456+00  \N  \N  \N  \N  novo    \N
1190    112 Bela Homes Aluguel de Temporada \N  554888783196    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:49.488+00  2026-01-29 00:22:34.546+00  2026-02-03 17:01:49.488+00  \N  \N  \N  \N  novo    \N
1247    112 Matheus Palmarante  \N  555194593333    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.373+00  2026-02-03 17:01:44.373+00  2026-02-03 17:01:44.373+00  \N  \N  \N  \N  novo    \N
375 5   150693306433631 \N  150693306433631 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:26:08.212+00  2026-01-07 05:26:08.212+00  2026-01-07 05:26:08.212+00  \N  \N  \N  \N  novo    \N
360 5   110054409822237 \N  110054409822237 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 03:42:23.752+00  2026-01-07 03:42:23.752+00  2026-01-07 03:42:23.752+00  \N  \N  \N  \N  novo    \N
309 5   87596009001176  \N  87596009001176  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 15:46:55.41+00   2026-01-06 15:46:55.41+00   2026-01-06 15:46:55.41+00   \N  \N  \N  \N  novo    \N
352 5   244233332080782 \N  244233332080782 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 00:06:09.064+00  2026-01-07 00:06:09.064+00  2026-01-07 00:06:09.064+00  \N  \N  \N  \N  novo    \N
320 5   🌞   \N  5524999929451   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 19:18:48.249+00  2026-01-06 19:18:48.249+00  2026-01-06 19:18:48.249+00  \N  \N  \N  \N  novo    \N
312 5   5524992035959   \N  5524992035959   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 17:47:41.924+00  2026-01-06 17:47:41.924+00  2026-01-06 17:47:41.924+00  \N  \N  \N  \N  novo    \N
383 5   84769937350881  \N  84769937350881  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:38:48.771+00  2026-01-07 05:38:48.771+00  2026-01-07 05:38:48.771+00  \N  \N  \N  \N  novo    \N
347 5   10544295739642  \N  10544295739642  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:26.943+00  2026-01-06 23:14:26.943+00  2026-01-06 23:14:26.943+00  \N  \N  \N  \N  novo    \N
369 74  189949441777787 \N  189949441777787 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:20:09.701+00  2026-01-07 05:20:09.701+00  2026-01-07 05:20:09.701+00  \N  \N  \N  \N  novo    \N
396 74  179735925637275 \N  179735925637275 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:59:32.043+00  2026-01-07 05:59:32.043+00  2026-01-07 05:59:32.043+00  \N  \N  \N  \N  novo    \N
397 74  173276647141619 \N  173276647141619 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:00:00.558+00  2026-01-07 06:00:00.558+00  2026-01-07 06:00:00.558+00  \N  \N  \N  \N  novo    \N
398 74  202026688463100 \N  202026688463100 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:00:57.848+00  2026-01-07 06:00:57.848+00  2026-01-07 06:00:57.848+00  \N  \N  \N  \N  novo    \N
384 74  22677595107559  \N  22677595107559  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:40:13.122+00  2026-01-07 05:40:13.122+00  2026-01-07 05:40:13.122+00  \N  \N  \N  \N  novo    \N
387 74  31693268324515  \N  31693268324515  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:49:53.104+00  2026-01-07 05:49:53.104+00  2026-01-07 05:49:53.104+00  \N  \N  \N  \N  novo    \N
390 74  62397318479953  \N  62397318479953  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:52:40.025+00  2026-01-07 05:52:40.025+00  2026-01-07 05:52:40.025+00  \N  \N  \N  \N  novo    \N
399 74  179426637664259 \N  179426637664259 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:04:26.09+00   2026-01-07 06:04:26.09+00   2026-01-07 06:04:26.09+00   \N  \N  \N  \N  novo    \N
376 86  191139231576078 \N  191139231576078 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:26:48.57+00   2026-01-07 05:26:48.571+00  2026-01-07 05:26:48.571+00  \N  \N  \N  \N  novo    \N
388 86  188497692508332 \N  188497692508332 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:50:42.654+00  2026-01-07 05:50:42.654+00  2026-01-07 05:50:42.654+00  \N  \N  \N  \N  novo    \N
381 86  77253643890722  \N  77253643890722  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:32:30.594+00  2026-01-07 05:32:30.594+00  2026-01-07 05:32:30.594+00  \N  \N  \N  \N  novo    \N
385 86  49907670994966  \N  49907670994966  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:46:11.85+00   2026-01-07 05:46:11.85+00   2026-01-07 05:46:11.85+00   \N  \N  \N  \N  novo    \N
391 86  90988882219106  \N  90988882219106  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:53:19.524+00  2026-01-07 05:53:19.524+00  2026-01-07 05:53:19.524+00  \N  \N  \N  \N  novo    \N
377 86  261336210645110 \N  261336210645110 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:28:53.053+00  2026-01-07 05:28:53.053+00  2026-01-07 05:28:53.053+00  \N  \N  \N  \N  novo    \N
361 86  214851527905302 \N  214851527905302 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 03:55:35.94+00   2026-01-07 03:55:35.94+00   2026-01-07 03:55:35.94+00   \N  \N  \N  \N  novo    \N
358 86  219610385252418 \N  219610385252418 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 02:44:23.01+00   2026-01-07 02:44:23.01+00   2026-01-07 02:44:23.01+00   \N  \N  \N  \N  novo    \N
371 86  192178429133013 \N  192178429133013 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:23:22.755+00  2026-01-07 05:23:22.755+00  2026-01-07 05:23:22.755+00  \N  \N  \N  \N  novo    \N
389 86  213850850910444 \N  213850850910444 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:51:12.967+00  2026-01-07 05:51:12.968+00  2026-01-07 05:51:12.968+00  \N  \N  \N  \N  novo    \N
372 86  169187469197432 \N  169187469197432 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:23:48.226+00  2026-01-07 05:23:48.226+00  2026-01-07 05:23:48.226+00  \N  \N  \N  \N  novo    \N
393 86  50942791684316  \N  50942791684316  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:58:20.927+00  2026-01-07 05:58:20.927+00  2026-01-07 05:58:20.927+00  \N  \N  \N  \N  novo    \N
392 86  201331071533120 \N  201331071533120 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:58:12.509+00  2026-01-07 05:58:12.509+00  2026-01-07 05:58:12.509+00  \N  \N  \N  \N  novo    \N
414 74  215646063337564 \N  215646063337564 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:20:47.162+00  2026-01-07 06:20:47.163+00  2026-01-07 06:20:47.163+00  \N  \N  \N  \N  novo    \N
967 103 Di  \N  5511981272352   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 20:05:30.37+00   2026-01-17 20:05:30.37+00   2026-01-17 20:05:30.37+00   \N  \N  \N  \N  novo    \N
1021    103 Beth Barros \N  5511976368757   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 22:26:45.096+00  2026-01-18 22:26:45.096+00  2026-01-18 22:26:45.096+00  \N  \N  \N  \N  novo    \N
1026    103 Pedro   \N  5511967996767   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:05:04.364+00  2026-01-18 23:05:04.364+00  2026-01-18 23:05:04.364+00  \N  \N  \N  \N  novo    \N
1031    103 Oswaldo Juliani Jr  \N  5511993963115   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:28:51.093+00  2026-01-18 23:28:51.093+00  2026-01-18 23:28:51.093+00  \N  \N  \N  \N  novo    \N
760 103 erica luz   \N  5521983133715   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 23:21:41.702+00  2026-01-12 23:21:41.702+00  2026-01-12 23:21:41.702+00  \N  \N  \N  \N  novo    \N
860 103 Dr. Victor Chaves   \N  5511970903155   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 00:39:05.464+00  2026-01-15 00:39:05.465+00  2026-01-15 00:39:05.465+00  \N  \N  \N  \N  novo    \N
914 103 Jonatas \N  5511980339925   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 14:36:11.602+00  2026-01-16 14:36:11.602+00  2026-01-16 14:36:11.602+00  \N  \N  \N  \N  novo    \N
415 86  133311640924172 \N  133311640924172 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:22:10.772+00  2026-01-07 06:22:10.772+00  2026-01-07 06:22:10.772+00  \N  \N  \N  \N  novo    \N
793 104 Contato sem nome 2114   \N  56964251947162  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:12.737+00  2026-01-13 21:24:12.737+00  2026-01-23 20:11:32.854+00  \N  \N  \N  \N  novo    \N
968 103 Agnes   \N  5511996260983   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 20:55:58.618+00  2026-01-17 20:55:58.618+00  2026-01-17 20:55:58.618+00  \N  \N  \N  \N  novo    \N
788 103 Terezinha   \N  5521999820571   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 20:51:16.859+00  2026-01-13 20:51:16.859+00  2026-01-13 20:51:16.859+00  \N  \N  \N  \N  novo    \N
1023    103 Bruna   \N  553193156804    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 22:45:06.671+00  2026-01-18 22:45:06.671+00  2026-01-18 22:45:06.671+00  \N  \N  \N  \N  novo    \N
761 103 Valter Porto    \N  5511947119191   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 23:25:56.211+00  2026-01-12 23:25:56.211+00  2026-01-12 23:25:56.211+00  \N  \N  \N  \N  novo    \N
863 103 Lilian Gusmão   \N  556193093966    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 01:10:23.036+00  2026-01-15 01:10:23.036+00  2026-01-15 01:10:23.036+00  \N  \N  \N  \N  novo    \N
915 103 Taíne Vidaletti \N  5521975800101   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 14:48:49.118+00  2026-01-16 14:48:49.118+00  2026-01-16 14:48:49.118+00  \N  \N  \N  \N  novo    \N
416 74  51986418397384  \N  51986418397384  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:24:07.587+00  2026-01-07 06:24:07.587+00  2026-01-07 06:24:07.587+00  \N  \N  \N  \N  novo    \N
969 103 Marcia  \N  5511958088650   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 21:14:33.697+00  2026-01-17 21:14:33.697+00  2026-01-17 21:14:33.697+00  \N  \N  \N  \N  novo    \N
1025    103 Wylma Mouradian \N  5511992213758   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 22:52:50.22+00   2026-01-18 22:52:50.22+00   2026-01-18 22:52:50.22+00   \N  \N  \N  \N  novo    \N
1024    103 Andreia Mendonça    \N  5511981218869   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 22:48:02.978+00  2026-01-18 22:48:02.978+00  2026-01-18 22:48:02.978+00  \N  \N  \N  \N  novo    \N
763 103 Cida    \N  240819017670887 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 23:42:40.387+00  2026-01-12 23:42:40.387+00  2026-01-12 23:42:40.387+00  \N  \N  \N  \N  novo    \N
770 103 Luis.🇧🇷🧏🏽‍♂️    \N  5511987391913   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 03:01:07.448+00  2026-01-13 03:01:07.449+00  2026-01-13 03:01:07.449+00  \N  \N  \N  \N  novo    \N
865 103 Cozzi   \N  5511986772519   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 11:23:07.961+00  2026-01-15 11:23:07.962+00  2026-01-15 11:23:07.962+00  \N  \N  \N  \N  novo    \N
916 103 Larissa Santana \N  5511994539004   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 15:36:34.063+00  2026-01-16 15:36:34.063+00  2026-01-16 15:36:34.063+00  \N  \N  \N  \N  novo    \N
920 103 Glauce  \N  5511967666172   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 16:47:49.281+00  2026-01-16 16:47:49.281+00  2026-01-16 16:47:49.281+00  \N  \N  \N  \N  novo    \N
1253    112 Ana…    \N  555181306511    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.502+00  2026-02-03 17:01:44.502+00  2026-02-03 17:01:44.502+00  \N  \N  \N  \N  novo    \N
1153    112 Lu  \N  555182018500    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 21:36:33.878+00  2026-01-26 21:36:33.878+00  2026-01-26 21:36:33.878+00  \N  \N  \N  \N  novo    \N
1154    112 R&D Reboques    \N  555192754429    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 22:50:49.601+00  2026-01-26 22:50:49.601+00  2026-01-26 22:51:38.766+00  \N  \N  \N  \N  novo    \N
1286    112 Renan   \N  555198082879    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-05 14:53:48.056+00  2026-02-05 14:48:07.775+00  2026-02-05 14:53:48.056+00  \N  \N  \N  \N  novo    \N
1191    112 Rosangela   \N  555196536018    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 12:01:40.292+00  2026-01-29 00:46:02.81+00   2026-02-04 12:01:40.292+00  \N  \N  \N  \N  novo    \N
1250    112 Matheus Palmarante  \N  555194593333    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.389+00  2026-02-03 17:01:44.389+00  2026-02-03 17:01:44.389+00  \N  \N  \N  \N  novo    \N
1251    112 Matheus Palmarante  \N  555194593333    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.389+00  2026-02-03 17:01:44.389+00  2026-02-03 17:01:44.389+00  \N  \N  \N  \N  novo    \N
787 5   Leandro Villas Boas \N  5524988083163   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 20:33:30.955+00  2026-01-13 20:33:30.955+00  2026-01-13 21:01:01.95+00   \N  \N  \N  \N  novo    \N
1057    5   Fernanda Machado    \N  5524981701704   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-21 15:09:24.28+00   2026-01-21 15:09:24.28+00   2026-01-21 15:09:24.28+00   \N  \N  \N  \N  novo    \N
713 5   Pamella Vieira✨💄🪞   \N  5524993355406   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-05 19:08:52.226+00  2026-01-09 14:19:09.153+00  2026-02-05 19:08:52.226+00  \N  \N  \N  \N  novo    \N
717 5   162195245662360 \N  162195245662360 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-09 15:20:19.951+00  2026-01-09 15:20:19.951+00  2026-01-09 15:20:19.951+00  \N  \N  \N  \N  novo    \N
715 5   ✨   \N  5524992448989   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 20:08:10.924+00  2026-01-09 14:34:39.433+00  2026-02-04 20:08:10.924+00  \N  \N  \N  \N  novo    \N
417 86  52673546076191  \N  52673546076191  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:26:17.565+00  2026-01-07 06:26:17.565+00  2026-01-07 06:26:17.565+00  \N  \N  \N  \N  novo    \N
794 104 Contato sem nome 2115   \N  65025905545378  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:12.954+00  2026-01-13 21:24:12.954+00  2026-01-23 20:39:54.936+00  \N  \N  \N  \N  novo    \N
790 104 Paola Oliveira  \N  554891591427    \N  \N                  \N  converted   0   \N  \N      2026-01-13 21:12:56.888+00  2026-01-13 21:12:56.888+00  2026-01-14 16:03:40.345+00  \N  \N  12  2026-01-14 16:03:40.344+00  convertido  \N
970 103 Bianca Guimaraes    \N  5511992090772   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 21:17:52.16+00   2026-01-17 21:17:52.16+00   2026-01-17 21:17:52.16+00   \N  \N  \N  \N  novo    \N
1027    103 Ana Lúcia Camargo   \N  5511983350992   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:05:24.327+00  2026-01-18 23:05:24.327+00  2026-01-18 23:05:24.327+00  \N  \N  \N  \N  novo    \N
1029    103 Beatriz Panhan Stabile  \N  5519996017308   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:09:03.886+00  2026-01-18 23:09:03.886+00  2026-01-18 23:09:03.886+00  \N  \N  \N  \N  novo    \N
1032    103 Marcos Furtado  \N  5511995298025   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:32:44.446+00  2026-01-18 23:32:44.446+00  2026-01-18 23:32:44.446+00  \N  \N  \N  \N  novo    \N
764 103 Vera Casali \N  5511993843245   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-12 23:46:30.015+00  2026-01-12 23:46:30.015+00  2026-01-12 23:46:30.015+00  \N  \N  \N  \N  novo    \N
866 103 Nayara Diniz Foods Vendas Direta    \N  5511998590069   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 11:35:40.911+00  2026-01-15 11:35:40.911+00  2026-01-15 11:35:40.911+00  \N  \N  \N  \N  novo    \N
917 103 Vitória 🤍   \N  5511984406480   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 15:44:39.212+00  2026-01-16 15:44:39.212+00  2026-01-16 15:44:39.212+00  \N  \N  \N  \N  novo    \N
418 74  160125071401114 \N  160125071401114 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:28:40.713+00  2026-01-07 06:28:40.713+00  2026-01-07 06:28:40.713+00  \N  \N  \N  \N  novo    \N
791 104 Contato sem nome 2112   \N  206661109215353 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:11.765+00  2026-01-13 21:24:11.765+00  2026-01-16 16:02:42.7+00    \N  \N  \N  \N  novo    \N
1058    104 Corpo em Ação academia  \N  554888781837    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-21 23:57:02.894+00  2026-01-21 23:57:02.894+00  2026-01-23 19:08:02.792+00  \N  \N  \N  \N  novo    \N
971 103 Jamile  \N  5511974498385   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 21:18:27.806+00  2026-01-17 21:18:27.806+00  2026-01-17 21:18:27.806+00  \N  \N  \N  \N  novo    \N
972 103 Monica Maluf Semijoias  \N  5511999025653   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 21:21:27.72+00   2026-01-17 21:21:27.72+00   2026-01-17 21:21:27.72+00   \N  \N  \N  \N  novo    \N
1028    103 Caio Rocha  \N  5511998614968   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:06:01.511+00  2026-01-18 23:06:01.512+00  2026-01-18 23:06:01.512+00  \N  \N  \N  \N  novo    \N
765 103 😴   \N  5511961120320   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 00:31:48.145+00  2026-01-13 00:31:48.145+00  2026-01-13 00:31:48.145+00  \N  \N  \N  \N  novo    \N
867 103 Renan Lovison   \N  555484333841    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 12:31:46.817+00  2026-01-15 12:31:46.817+00  2026-01-15 12:31:46.817+00  \N  \N  \N  \N  novo    \N
918 103 Raphael Mendonça    \N  5521988850106   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 15:48:38.599+00  2026-01-16 15:48:38.599+00  2026-01-16 15:48:38.599+00  \N  \N  \N  \N  novo    \N
797 104 Contato sem nome 2118   \N  225301200154850 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:18.724+00  2026-01-13 21:24:18.725+00  2026-01-13 22:00:00.131+00  \N  \N  \N  \N  novo    \N
798 104 Arbues Representações   \N  559888114610    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:19.461+00  2026-01-13 21:24:19.461+00  2026-01-14 13:18:49.267+00  \N  \N  \N  \N  novo    \N
796 104 Contato sem nome 2117   \N  85981168459835  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:18.491+00  2026-01-13 21:24:18.492+00  2026-01-15 12:37:47.574+00  \N  \N  \N  \N  novo    \N
799 104 Contato sem nome    \N  558699665555    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:22.507+00  2026-01-13 21:24:22.507+00  2026-01-13 21:24:22.507+00  \N  \N  \N  \N  novo    \N
792 104 Estúdio de Dança Daiene Weiss   \N  555184605806    \N  \N                  \N  converted   0   \N  \N      2026-01-13 21:24:12.472+00  2026-01-13 21:24:12.472+00  2026-01-19 17:50:16.177+00  \N  \N  13  2026-01-14 22:04:38.903+00  convertido  \N
795 104 Viviane Vargas  \N  555196181448    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:15.564+00  2026-01-13 21:24:15.565+00  2026-01-13 21:26:42.416+00  \N  \N  \N  \N  novo    \N
766 103 Ítalo   \N  5511912667575   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 00:58:22.919+00  2026-01-13 00:58:22.919+00  2026-01-13 00:58:22.919+00  \N  \N  \N  \N  novo    \N
1030    103 AC  \N  5511932616405   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:25:03.948+00  2026-01-18 23:25:03.948+00  2026-01-18 23:25:03.948+00  \N  \N  \N  \N  novo    \N
880 103 Lari Bonfim \N  5516993790991   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 21:05:36.493+00  2026-01-15 21:05:36.493+00  2026-01-15 21:05:36.493+00  \N  \N  \N  \N  novo    \N
973 103 Fernando    \N  5511999319566   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 21:37:09.921+00  2026-01-17 21:37:09.921+00  2026-01-17 21:37:09.921+00  \N  \N  \N  \N  novo    \N
1039    103 Fernando Romero \N  5511911326024   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-19 00:49:55.637+00  2026-01-19 00:49:55.637+00  2026-01-19 00:49:55.637+00  \N  \N  \N  \N  novo    \N
868 103 Arthur Alves    \N  5511945053153   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 12:37:26.869+00  2026-01-15 12:37:26.869+00  2026-01-15 12:37:26.869+00  \N  \N  \N  \N  novo    \N
432 74  262061875536087 \N  262061875536087 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:52:40.752+00  2026-01-07 06:52:40.752+00  2026-01-07 06:52:40.752+00  \N  \N  \N  \N  novo    \N
426 86  33097437450317  \N  33097437450317  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:45:26.226+00  2026-01-07 06:45:26.226+00  2026-01-07 06:45:26.226+00  \N  \N  \N  \N  novo    \N
1255    112 Atendimento webot3  \N  558399880429    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.888+00  2026-02-03 17:01:44.582+00  2026-02-03 17:01:44.888+00  \N  \N  \N  \N  novo    \N
1194    112 Linkoo  \N  557131905187    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:45.097+00  2026-01-29 08:58:19.426+00  2026-02-03 17:01:45.097+00  \N  \N  \N  \N  novo    \N
463 5   171334919274600 \N  171334919274600 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:51:26.417+00  2026-01-07 07:51:26.417+00  2026-01-07 07:51:26.417+00  \N  \N  \N  \N  novo    \N
434 5   234221897523248 \N  234221897523248 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:59:09.61+00   2026-01-07 06:59:09.611+00  2026-01-07 06:59:09.611+00  \N  \N  \N  \N  novo    \N
718 5   Sabrina \N  5524999290807   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-09 16:20:57.228+00  2026-01-09 16:20:57.228+00  2026-01-09 16:20:57.228+00  \N  \N  \N  \N  novo    \N
1289    5   Dr Bruno Chaves \N  556781631600    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-05 20:04:00.486+00  2026-02-05 20:03:46.541+00  2026-02-05 20:04:00.486+00  \N  \N  \N  \N  novo    \N
437 5   48297058259018  \N  48297058259018  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:05:59.648+00  2026-01-07 07:05:59.648+00  2026-01-07 07:05:59.648+00  \N  \N  \N  \N  novo    \N
438 5   25903182696669  \N  25903182696669  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:06:34.281+00  2026-01-07 07:06:34.281+00  2026-01-07 07:06:34.281+00  \N  \N  \N  \N  novo    \N
446 5   79186479837305  \N  79186479837305  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:27:36.546+00  2026-01-07 07:27:36.546+00  2026-01-07 07:27:36.546+00  \N  \N  \N  \N  novo    \N
454 5   224575401017438 \N  224575401017438 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:42:24.503+00  2026-01-07 07:42:24.503+00  2026-01-07 07:42:24.503+00  \N  \N  \N  \N  novo    \N
448 5   73491202236657  \N  73491202236657  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:28:51.244+00  2026-01-07 07:28:51.244+00  2026-01-07 07:28:51.244+00  \N  \N  \N  \N  novo    \N
447 86  216565186347034 \N  216565186347034 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:28:48.968+00  2026-01-07 07:28:48.969+00  2026-01-07 07:28:48.969+00  \N  \N  \N  \N  novo    \N
419 86  158630406058210 \N  158630406058210 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:29:06.085+00  2026-01-07 06:29:06.085+00  2026-01-07 06:29:06.085+00  \N  \N  \N  \N  novo    \N
421 86  83752013287659  \N  83752013287659  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:32:06.025+00  2026-01-07 06:32:06.026+00  2026-01-07 06:32:06.026+00  \N  \N  \N  \N  novo    \N
427 86  192668189622295 \N  192668189622295 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:46:10.425+00  2026-01-07 06:46:10.425+00  2026-01-07 06:46:10.425+00  \N  \N  \N  \N  novo    \N
429 86  36726449955056  \N  36726449955056  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:49:43.827+00  2026-01-07 06:49:43.827+00  2026-01-07 06:49:43.827+00  \N  \N  \N  \N  novo    \N
433 86  33715493286108  \N  33715493286108  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:56:47.111+00  2026-01-07 06:56:47.111+00  2026-01-07 06:56:47.111+00  \N  \N  \N  \N  novo    \N
435 86  171253566583003 \N  171253566583003 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:00:04.243+00  2026-01-07 07:00:04.243+00  2026-01-07 07:00:04.243+00  \N  \N  \N  \N  novo    \N
436 86  2203351797788   \N  2203351797788   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:04:27.555+00  2026-01-07 07:04:27.555+00  2026-01-07 07:04:27.555+00  \N  \N  \N  \N  novo    \N
439 86  239027898859594 \N  239027898859594 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:06:41.912+00  2026-01-07 07:06:41.912+00  2026-01-07 07:06:41.912+00  \N  \N  \N  \N  novo    \N
440 86  203585895854320 \N  203585895854320 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:09:23.096+00  2026-01-07 07:09:23.096+00  2026-01-07 07:09:23.096+00  \N  \N  \N  \N  novo    \N
442 86  237640691507441 \N  237640691507441 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:17:44.043+00  2026-01-07 07:17:44.043+00  2026-01-07 07:17:44.043+00  \N  \N  \N  \N  novo    \N
443 86  160739318882421 \N  160739318882421 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:19:48.267+00  2026-01-07 07:19:48.267+00  2026-01-07 07:19:48.267+00  \N  \N  \N  \N  novo    \N
453 86  29283405852685  \N  29283405852685  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:39:06.28+00   2026-01-07 07:39:06.28+00   2026-01-07 07:39:06.28+00   \N  \N  \N  \N  novo    \N
456 86  174500394070135 \N  174500394070135 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:44:19.082+00  2026-01-07 07:44:19.082+00  2026-01-07 07:44:19.082+00  \N  \N  \N  \N  novo    \N
457 86  219245329776857 \N  219245329776857 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:44:27.784+00  2026-01-07 07:44:27.784+00  2026-01-07 07:44:27.784+00  \N  \N  \N  \N  novo    \N
458 86  235042219552850 \N  235042219552850 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:44:36.714+00  2026-01-07 07:44:36.715+00  2026-01-07 07:44:36.715+00  \N  \N  \N  \N  novo    \N
460 86  189086035906734 \N  189086035906734 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:45:47.104+00  2026-01-07 07:45:47.104+00  2026-01-07 07:45:47.104+00  \N  \N  \N  \N  novo    \N
801 104 Contato sem nome    \N  554830397860    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:31.873+00  2026-01-13 21:24:31.873+00  2026-01-13 21:24:31.873+00  \N  \N  \N  \N  novo    \N
483 86  234110161301526 \N  234110161301526 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:44:04.099+00  2026-01-07 08:44:04.099+00  2026-01-07 08:44:04.099+00  \N  \N  \N  \N  novo    \N
1258    130 Anderson Ferro Negócios Digitai desde 2005  \N  5516992091604   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-05 12:32:00.208+00  2026-02-03 18:29:43.258+00  2026-02-05 12:32:00.208+00  \N  \N  \N  \N  novo    \N
804 104 Contato sem nome 2125   \N  185280829116669 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:32.82+00   2026-01-13 21:24:32.82+00   2026-01-13 22:00:00.137+00  \N  \N  \N  \N  novo    \N
802 104 Contato sem nome    \N  554891642323    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:32.182+00  2026-01-13 21:24:32.183+00  2026-01-13 21:24:32.183+00  \N  \N  \N  \N  novo    \N
805 104 Alice Tito  \N  555599947736    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:32.981+00  2026-01-13 21:24:32.981+00  2026-01-20 17:48:24.204+00  \N  \N  \N  \N  novo    \N
806 104 Contato sem nome    \N  554896536958    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:37.795+00  2026-01-13 21:24:37.795+00  2026-01-13 21:24:37.795+00  \N  \N  \N  \N  novo    \N
807 104 Contato sem nome    \N  555191335128    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:39.718+00  2026-01-13 21:24:39.718+00  2026-01-13 21:24:39.718+00  \N  \N  \N  \N  novo    \N
809 104 Contato sem nome    \N  556796899919    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:41.125+00  2026-01-13 21:24:41.125+00  2026-01-13 21:24:41.125+00  \N  \N  \N  \N  novo    \N
808 104 Daniel Xavier - Co.Experience   \N  558791779560    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:24:40.609+00  2026-01-13 21:24:40.609+00  2026-01-21 14:50:21.946+00  \N  \N  \N  \N  novo    \N
803 104 Gracinha!   \N  554896020435    \N  \N                  \N  converted   0   \N  \N      2026-01-13 21:24:32.65+00   2026-01-13 21:24:32.651+00  2026-01-14 16:00:05.313+00  \N  \N  11  2026-01-14 16:00:05.312+00  convertido  \N
974 103 Alencar \N  554884392820    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 21:45:21.854+00  2026-01-17 21:45:21.854+00  2026-01-17 21:45:21.854+00  \N  \N  \N  \N  novo    \N
1033    103 Sofia   \N  556299530151    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:40:30.369+00  2026-01-18 23:40:30.369+00  2026-01-18 23:40:30.369+00  \N  \N  \N  \N  novo    \N
767 103 Alexandre Macedo    \N  5514045566045   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 01:00:12.096+00  2026-01-13 01:00:12.096+00  2026-01-13 01:00:12.096+00  \N  \N  \N  \N  novo    \N
821 104 Contato sem nome    \N  554891279959    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 23:12:37.203+00  2026-01-13 23:12:37.203+00  2026-01-13 23:12:37.203+00  \N  \N  \N  \N  novo    \N
501 74  5162752028918   \N  5162752028918   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:23:36.188+00  2026-01-07 09:23:36.188+00  2026-01-07 09:23:36.188+00  \N  \N  \N  \N  novo    \N
485 74  9543534833731   \N  9543534833731   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:46:40.761+00  2026-01-07 08:46:40.761+00  2026-01-07 08:46:40.761+00  \N  \N  \N  \N  novo    \N
502 86  175346452291661 \N  175346452291661 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:23:43.237+00  2026-01-07 09:23:43.237+00  2026-01-07 09:23:43.237+00  \N  \N  \N  \N  novo    \N
810 103 Nicolas Rios    \N  5513991265606   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:25:31.463+00  2026-01-13 21:25:31.464+00  2026-01-13 21:25:31.464+00  \N  \N  \N  \N  novo    \N
847 103 …   \N  556596062210    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 20:33:08.325+00  2026-01-14 20:33:08.325+00  2026-01-14 20:33:08.325+00  \N  \N  \N  \N  novo    \N
881 103 Cauã | Prime Visual Studio  \N  5511988147604   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 21:55:36.386+00  2026-01-15 21:55:36.386+00  2026-01-15 21:55:36.386+00  \N  \N  \N  \N  novo    \N
975 103 Henrique Ariolli    \N  5511985580617   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 21:47:05.179+00  2026-01-17 21:47:05.179+00  2026-01-17 21:47:05.179+00  \N  \N  \N  \N  novo    \N
862 103 David Meira \N  5512267007810   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 00:59:11.023+00  2026-01-15 00:59:11.023+00  2026-01-15 00:59:11.023+00  \N  \N  \N  \N  novo    \N
1034    103 Rodrigo Macedo  \N  5511999226852   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:41:25.516+00  2026-01-18 23:41:25.516+00  2026-01-18 23:41:25.516+00  \N  \N  \N  \N  novo    \N
768 103 93497361195197  \N  93497361195197  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 01:05:07.661+00  2026-01-13 01:05:07.661+00  2026-01-13 01:05:07.661+00  \N  \N  \N  \N  novo    \N
870 103 Contato sem nome    \N  5516982285428   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 13:28:21.583+00  2026-01-15 13:28:21.583+00  2026-01-15 13:28:21.583+00  \N  \N  \N  \N  novo    \N
923 103 Caroline Lemke  \N  554791160843    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 18:38:02.708+00  2026-01-16 18:38:02.708+00  2026-01-16 18:38:02.708+00  \N  \N  \N  \N  novo    \N
488 74  5789649485870   \N  5789649485870   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:00:23.223+00  2026-01-07 09:00:23.223+00  2026-01-07 09:00:23.223+00  \N  \N  \N  \N  novo    \N
490 74  280989846781953 \N  280989846781953 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:09:50.269+00  2026-01-07 09:09:50.269+00  2026-01-07 09:09:50.269+00  \N  \N  \N  \N  novo    \N
492 74  52952802828378  \N  52952802828378  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:13:19.452+00  2026-01-07 09:13:19.452+00  2026-01-07 09:13:19.452+00  \N  \N  \N  \N  novo    \N
1158    112 Atendechat White Label      555198917243    \N                      \N  new 0   quente  115     2026-02-03 17:01:44.911+00  2026-01-27 00:31:22.703+00  2026-02-03 17:01:44.911+00  \N  \N  \N  \N  novo    \N
1159    112 Maicon Cardoso  \N  555193938903    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 01:43:00.415+00  2026-01-27 01:43:00.415+00  2026-01-27 01:43:24.397+00  \N  \N  \N  \N  novo    \N
1160    112 Make Acelerador de Vendas   \N  5511986540334   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 10:36:34.003+00  2026-01-27 10:36:34.003+00  2026-01-27 10:36:34.003+00  \N  \N  \N  \N  novo    \N
1059    107 Contato sem nome    \N  5513997438073   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-22 03:20:37.232+00  2026-01-22 03:20:37.232+00  2026-01-22 03:20:37.232+00  \N  \N  \N  \N  novo    \N
1061    107 Logyca Tecnologia   \N  5511918389540   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-22 17:51:04.859+00  2026-01-22 17:51:04.859+00  2026-01-22 17:51:04.859+00  \N  \N  \N  \N  novo    \N
1199    5   Paulo cesar Oliveira    \N  5512997766275   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-29 19:21:04.918+00  2026-01-29 19:21:04.918+00  2026-01-29 19:21:43.627+00  \N  \N  \N  \N  novo    \N
1174    5   Contato sem nome    \N  5524999494768   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 18:45:26.379+00  2026-01-27 18:45:26.379+00  2026-01-27 18:45:26.379+00  \N  \N  \N  \N  novo    \N
1197    5   Flavia  \N  5524981065544   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-29 13:48:17.732+00  2026-01-29 13:48:17.732+00  2026-01-29 13:48:17.732+00  \N  \N  \N  \N  novo    \N
484 5   107846645592066 \N  107846645592066 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:46:30.113+00  2026-01-07 08:46:30.113+00  2026-01-07 08:46:30.113+00  \N  \N  \N  \N  novo    \N
486 86  94528153346263  \N  94528153346263  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:48:55.576+00  2026-01-07 08:48:55.576+00  2026-01-07 08:48:55.576+00  \N  \N  \N  \N  novo    \N
487 86  70364617019614  \N  70364617019614  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:57:51.638+00  2026-01-07 08:57:51.638+00  2026-01-07 08:57:51.638+00  \N  \N  \N  \N  novo    \N
500 86  39539519320110  \N  39539519320110  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:22:55.13+00   2026-01-07 09:22:55.13+00   2026-01-07 09:22:55.13+00   \N  \N  \N  \N  novo    \N
811 103 Karen Ko    \N  5511999328888   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:36:19.153+00  2026-01-13 21:36:19.153+00  2026-01-13 21:36:19.153+00  \N  \N  \N  \N  novo    \N
812 103 Bárbara✨    \N  5511952365090   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 21:55:41.106+00  2026-01-13 21:55:41.107+00  2026-01-13 21:55:41.107+00  \N  \N  \N  \N  novo    \N
878 103 Carolina Rebouças   \N  5511958767140   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 18:44:07.598+00  2026-01-15 18:44:07.598+00  2026-01-15 18:44:07.598+00  \N  \N  \N  \N  novo    \N
976 103 Filipe  \N  554896025484    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 21:48:00.084+00  2026-01-17 21:48:00.084+00  2026-01-17 21:48:00.084+00  \N  \N  \N  \N  novo    \N
1035    103 Daniel Castelo Rocha    \N  558596738800    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:49:06.35+00   2026-01-18 23:49:06.35+00   2026-01-18 23:49:06.35+00   \N  \N  \N  \N  novo    \N
771 103 5521970198435   \N  5521970198435   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 03:06:39.838+00  2026-01-13 03:06:39.838+00  2026-01-13 03:06:39.838+00  \N  \N  \N  \N  novo    \N
769 103 Contato sem nome 2090   \N  5511998515914   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 01:44:51.864+00  2026-01-13 01:44:51.864+00  2026-01-13 07:38:52.287+00  \N  \N  \N  \N  novo    \N
871 103 Contato sem nome    \N  5511987492855   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 14:12:27.016+00  2026-01-15 14:12:27.016+00  2026-01-15 14:12:27.016+00  \N  \N  \N  \N  novo    \N
491 74  108938120949776 \N  108938120949776 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:11:44.409+00  2026-01-07 09:11:44.409+00  2026-01-07 09:11:44.409+00  \N  \N  \N  \N  novo    \N
813 103 Jorge Henrique - HELP MACHINE   \N  5511947316431   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 22:21:22.898+00  2026-01-13 22:21:22.898+00  2026-01-13 22:21:22.898+00  \N  \N  \N  \N  novo    \N
977 103 Valmir 😃    \N  5511963475656   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 21:54:22.671+00  2026-01-17 21:54:22.671+00  2026-01-17 21:54:22.671+00  \N  \N  \N  \N  novo    \N
997 103 LB  \N  5517996287761   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 23:19:33.417+00  2026-01-17 23:19:33.418+00  2026-01-17 23:19:33.418+00  \N  \N  \N  \N  novo    \N
1036    103 Vera Penteado   \N  5511991223793   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:53:25.055+00  2026-01-18 23:53:25.055+00  2026-01-18 23:53:25.055+00  \N  \N  \N  \N  novo    \N
772 103 rafaelfujioka83 \N  5511912342442   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 06:51:10.159+00  2026-01-13 06:51:10.159+00  2026-01-13 06:51:10.159+00  \N  \N  \N  \N  novo    \N
872 103 Maria Clara🎀🥰❤️ \N  5511999967080   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 15:14:36.14+00   2026-01-15 15:14:36.141+00  2026-01-15 15:14:36.141+00  \N  \N  \N  \N  novo    \N
925 103 Renata Rancan   \N  5516997855579   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 19:44:14.106+00  2026-01-16 19:44:14.106+00  2026-01-16 19:44:14.106+00  \N  \N  \N  \N  novo    \N
493 86  239740896972826 \N  239740896972826 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:14:35.364+00  2026-01-07 09:14:35.364+00  2026-01-07 09:14:35.364+00  \N  \N  \N  \N  novo    \N
495 86  252647340794054 \N  252647340794054 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:15:45.195+00  2026-01-07 09:15:45.195+00  2026-01-07 09:15:45.195+00  \N  \N  \N  \N  novo    \N
814 103 ✨Alice Biancalana✨  \N  5511995330060   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 22:28:40.643+00  2026-01-13 22:28:40.643+00  2026-01-13 22:28:40.643+00  \N  \N  \N  \N  novo    \N
978 103 Rafael  \N  5511981944227   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:01:05.671+00  2026-01-17 22:01:05.671+00  2026-01-17 22:01:05.671+00  \N  \N  \N  \N  novo    \N
1037    103 Gustavo Acurcio Cruz    \N  554298330286    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:58:21.346+00  2026-01-18 23:58:21.346+00  2026-01-18 23:58:21.346+00  \N  \N  \N  \N  novo    \N
873 103 Kelly Ximenes   \N  5511932951430   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 15:16:50.223+00  2026-01-15 15:16:50.223+00  2026-01-15 15:16:50.223+00  \N  \N  \N  \N  novo    \N
926 103 Peter Gabriel Schweikert    \N  5511992477731   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 20:25:05.002+00  2026-01-16 20:25:05.002+00  2026-01-16 20:25:05.002+00  \N  \N  \N  \N  novo    \N
496 74  147407706833037 \N  147407706833037 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:18:51.243+00  2026-01-07 09:18:51.243+00  2026-01-07 09:18:51.243+00  \N  \N  \N  \N  novo    \N
1263    138 Teste       21992422287 \N              Facebook/Instagram Ads  Anúncio Patrocinado paid_social new 9   morno   135     2026-02-04 00:21:58.05+00   2026-02-04 00:21:58.05+00   2026-02-04 00:21:58.05+00   \N  \N  \N  \N  novo    \N
815 103 Isadora \N  553299724545    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 22:31:39.805+00  2026-01-13 22:31:39.805+00  2026-01-13 22:31:39.805+00  \N  \N  \N  \N  novo    \N
979 103 Enzo Watanabe   \N  5511988110955   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:15:09.14+00   2026-01-17 22:15:09.141+00  2026-01-17 22:15:09.141+00  \N  \N  \N  \N  novo    \N
1038    103 Heloisa \N  5511993086100   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 23:59:27.276+00  2026-01-18 23:59:27.276+00  2026-01-18 23:59:27.276+00  \N  \N  \N  \N  novo    \N
927 103 Anny    \N  5511999194131   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 20:52:50.702+00  2026-01-16 20:52:50.702+00  2026-01-16 20:52:50.702+00  \N  \N  \N  \N  novo    \N
508 74  28514472431799  \N  28514472431799  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:27:59.095+00  2026-01-07 09:27:59.095+00  2026-01-07 09:27:59.095+00  \N  \N  \N  \N  novo    \N
497 86  219773493329949 \N  219773493329949 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:20:48.698+00  2026-01-07 09:20:48.698+00  2026-01-07 09:20:48.698+00  \N  \N  \N  \N  novo    \N
844 103 Ana \N  5511994278996   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 18:45:21.881+00  2026-01-14 18:45:21.881+00  2026-01-14 18:45:21.881+00  \N  \N  \N  \N  novo    \N
928 103 Michelle Sales Producao Maxima  \N  5511910457676   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 21:04:02.499+00  2026-01-16 21:04:02.499+00  2026-01-16 21:04:02.499+00  \N  \N  \N  \N  novo    \N
1062    53  Guilherme Milward   \N  5521988813393   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-22 20:28:15.313+00  2026-01-22 20:28:15.313+00  2026-01-22 20:28:15.313+00  \N  \N  \N  \N  novo    \N
1063    53  Contato sem nome 2384   \N  108563938680966 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-22 20:28:25.605+00  2026-01-22 20:28:25.605+00  2026-01-22 22:00:00.104+00  \N  \N  \N  \N  novo    \N
1200    112 Contato sem nome    \N  5511935030999   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-31 00:25:05.902+00  2026-01-29 19:53:08.369+00  2026-01-31 00:25:05.902+00  \N  \N  \N  \N  novo    \N
1172    112 Ideal Publicidade e Marketing   \N  5511980752100   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 18:38:06.377+00  2026-01-27 18:38:06.377+00  2026-01-27 18:38:06.377+00  \N  \N  \N  \N  novo    \N
1260    112 Nanda   \N  555198645354    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 23:33:33.471+00  2026-02-03 20:42:47.399+00  2026-02-03 23:33:33.471+00  \N  \N  \N  \N  novo    \N
1262    112 Mario Kids Festas   \N  555192631843    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 21:55:54.903+00  2026-02-03 21:52:28.506+00  2026-02-03 21:55:54.903+00  \N  \N  \N  \N  novo    \N
1161    112 Ronaldo \N  555181171424    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 12:34:23.126+00  2026-01-27 12:34:23.126+00  2026-01-27 12:42:17.388+00  \N  \N  \N  \N  novo    \N
1162    112 Daniela Forgiarini Pereir   \N  555199188600    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 12:38:23.161+00  2026-01-27 12:38:23.161+00  2026-01-28 23:46:14.213+00  \N  \N  \N  \N  novo    \N
1065    5   Ariadne \N  5524999788979   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-23 15:16:57.26+00   2026-01-23 15:16:57.26+00   2026-01-23 15:16:58.749+00  \N  \N  \N  \N  novo    \N
1066    5   Fernando    \N  5524998271718   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-23 15:16:57.307+00  2026-01-23 15:16:57.307+00  2026-01-23 15:16:59.244+00  \N  \N  \N  \N  novo    \N
1064    5   Contato sem nome    \N  5524992770357   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-23 15:16:57.252+00  2026-01-23 15:16:57.252+00  2026-01-23 15:16:58.849+00  \N  \N  \N  \N  novo    \N
1067    5   Milena  \N  5524998507076   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-23 15:16:57.505+00  2026-01-23 15:16:57.505+00  2026-01-23 15:16:57.613+00  \N  \N  \N  \N  novo    \N
1201    5   Alice Vilela    \N  5524998335329   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-30 11:26:59.332+00  2026-01-30 11:26:59.332+00  2026-01-30 11:26:59.332+00  \N  \N  \N  \N  novo    \N
723 5   Ligia Anjos \N  5524998264313   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-09 17:55:02.745+00  2026-01-09 17:55:02.745+00  2026-01-09 17:55:02.745+00  \N  \N  \N  \N  novo    \N
724 5   212265974370351 \N  212265974370351 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-09 17:55:04.128+00  2026-01-09 17:55:04.128+00  2026-01-09 17:55:04.128+00  \N  \N  \N  \N  novo    \N
489 5   187393818767561 \N  187393818767561 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:01:17.311+00  2026-01-07 09:01:17.311+00  2026-01-07 09:01:17.311+00  \N  \N  \N  \N  novo    \N
816 103 Anadiso França  \N  temp-1768344058670228   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 22:40:58.682+00  2026-01-13 22:40:58.682+00  2026-01-13 22:40:58.682+00  \N  \N  \N  \N  novo    \N
980 103 Marcelo Santos  \N  5511974005012   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:25:37.962+00  2026-01-17 22:25:37.962+00  2026-01-17 22:25:37.962+00  \N  \N  \N  \N  novo    \N
875 103 Mirian  \N  5519993215005   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 15:51:44.107+00  2026-01-15 15:51:44.107+00  2026-01-15 15:51:44.107+00  \N  \N  \N  \N  novo    \N
503 74  225829464338503 \N  225829464338503 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:25:13.599+00  2026-01-07 09:25:13.599+00  2026-01-07 09:25:13.599+00  \N  \N  \N  \N  novo    \N
498 86  70467696242826  \N  70467696242826  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:21:10.103+00  2026-01-07 09:21:10.103+00  2026-01-07 09:21:10.103+00  \N  \N  \N  \N  novo    \N
504 86  20856864530584  \N  20856864530584  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:25:58.983+00  2026-01-07 09:25:58.983+00  2026-01-07 09:25:58.983+00  \N  \N  \N  \N  novo    \N
929 103 Alexandre Jerussalmy    \N  5511998772808   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 21:17:38.656+00  2026-01-16 21:17:38.656+00  2026-01-16 21:17:38.656+00  \N  \N  \N  \N  novo    \N
817 103 Lívia Reis  \N  553891869334    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 22:41:51.335+00  2026-01-13 22:41:51.335+00  2026-01-13 22:41:51.335+00  \N  \N  \N  \N  novo    \N
981 103 Icaro   \N  554792335656    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:30:37.852+00  2026-01-17 22:30:37.852+00  2026-01-17 22:30:37.852+00  \N  \N  \N  \N  novo    \N
877 103 Lucas Martins   \N  5511967322929   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 18:40:45.689+00  2026-01-15 18:40:45.689+00  2026-01-15 18:40:45.689+00  \N  \N  \N  \N  novo    \N
930 103 Isabela \N  5521996976563   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 21:29:12.775+00  2026-01-16 21:29:12.775+00  2026-01-16 21:29:12.775+00  \N  \N  \N  \N  novo    \N
818 103 Regina  \N  5517991814647   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 22:46:55.936+00  2026-01-13 22:46:55.936+00  2026-01-13 22:46:55.936+00  \N  \N  \N  \N  novo    \N
820 103 Mariza Lemos    \N  5511994308046   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 22:58:50.784+00  2026-01-13 22:58:50.784+00  2026-01-13 22:58:50.784+00  \N  \N  \N  \N  novo    \N
982 103 Ana Paula   \N  5517997060108   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:31:12.505+00  2026-01-17 22:31:12.505+00  2026-01-17 22:31:12.505+00  \N  \N  \N  \N  novo    \N
509 86  136704665092205 \N  136704665092205 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:29:05.185+00  2026-01-07 09:29:05.185+00  2026-01-07 09:29:05.185+00  \N  \N  \N  \N  novo    \N
513 86  97968824836192  \N  97968824836192  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:31:42.377+00  2026-01-07 09:31:42.377+00  2026-01-07 09:31:42.377+00  \N  \N  \N  \N  novo    \N
515 86  116638594670780 \N  116638594670780 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:32:53.32+00   2026-01-07 09:32:53.321+00  2026-01-07 09:32:53.321+00  \N  \N  \N  \N  novo    \N
517 86  168711013007431 \N  168711013007431 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:33:27.283+00  2026-01-07 09:33:27.284+00  2026-01-07 09:33:27.284+00  \N  \N  \N  \N  novo    \N
523 86  150659013808219 \N  150659013808219 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:41:20.485+00  2026-01-07 09:41:20.485+00  2026-01-07 09:41:20.485+00  \N  \N  \N  \N  novo    \N
524 86  227319750914152 \N  227319750914152 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:41:37.522+00  2026-01-07 09:41:37.522+00  2026-01-07 09:41:37.522+00  \N  \N  \N  \N  novo    \N
525 86  40218409361441  \N  40218409361441  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:44:44.246+00  2026-01-07 09:44:44.246+00  2026-01-07 09:44:44.246+00  \N  \N  \N  \N  novo    \N
530 86  97143637442563  \N  97143637442563  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:07:19.489+00  2026-01-07 10:07:19.489+00  2026-01-07 10:07:19.489+00  \N  \N  \N  \N  novo    \N
543 86  171253281382528 \N  171253281382528 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:27:56.957+00  2026-01-07 10:27:56.957+00  2026-01-07 10:27:56.957+00  \N  \N  \N  \N  novo    \N
552 86  138444009373915 \N  138444009373915 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:54:42.23+00   2026-01-07 10:54:42.23+00   2026-01-07 10:54:42.23+00   \N  \N  \N  \N  novo    \N
556 86  163659946967270 \N  163659946967270 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:01:50.054+00  2026-01-07 11:01:50.054+00  2026-01-07 11:01:50.054+00  \N  \N  \N  \N  novo    \N
558 86  221787849761023 \N  221787849761023 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:04:06.846+00  2026-01-07 11:04:06.846+00  2026-01-07 11:04:06.846+00  \N  \N  \N  \N  novo    \N
559 86  31014176960611  \N  31014176960611  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:04:50.222+00  2026-01-07 11:04:50.222+00  2026-01-07 11:04:50.222+00  \N  \N  \N  \N  novo    \N
560 86  242094841065673 \N  242094841065673 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:05:45.97+00   2026-01-07 11:05:45.97+00   2026-01-07 11:05:45.97+00   \N  \N  \N  \N  novo    \N
562 86  273628138569945 \N  273628138569945 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:07:10.212+00  2026-01-07 11:07:10.212+00  2026-01-07 11:07:10.212+00  \N  \N  \N  \N  novo    \N
563 86  89666065821748  \N  89666065821748  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:07:16.239+00  2026-01-07 11:07:16.239+00  2026-01-07 11:07:16.239+00  \N  \N  \N  \N  novo    \N
567 86  4737483145225   \N  4737483145225   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:19:49.59+00   2026-01-07 11:19:49.59+00   2026-01-07 11:19:49.59+00   \N  \N  \N  \N  novo    \N
1267    133 Empresa 1   empresa3@demo.com   89520312    \N  123 empresa3    15132   123132  2313212 paid_social new 7   frio    137 123 2026-02-04 03:21:57.801+00  2026-02-04 03:21:57.801+00  2026-02-04 03:21:57.801+00  \N  \N  \N  \N  novo    \N
568 86  193363772964964 \N  193363772964964 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:22:23.788+00  2026-01-07 11:22:23.788+00  2026-01-07 11:22:23.788+00  \N  \N  \N  \N  novo    \N
584 86  139461983784984 \N  139461983784984 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:58:51.234+00  2026-01-07 11:58:51.234+00  2026-01-07 11:58:51.234+00  \N  \N  \N  \N  novo    \N
590 86  151672844230763 \N  151672844230763 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:11:56.107+00  2026-01-07 12:11:56.107+00  2026-01-07 12:11:56.107+00  \N  \N  \N  \N  novo    \N
1165    112 Domingues   \N  558585542384    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 16:30:29.734+00  2026-01-27 16:30:29.734+00  2026-01-27 16:30:29.734+00  \N  \N  \N  \N  novo    \N
1166    112 Leandro \N  555197806555    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 16:32:44.95+00   2026-01-27 16:32:44.95+00   2026-01-27 17:31:44.39+00   \N  \N  \N  \N  novo    \N
1168    112 Lucas Klein \N  555182607040    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 16:56:45.391+00  2026-01-27 16:56:45.391+00  2026-01-27 18:14:44.529+00  \N  \N  \N  \N  novo    \N
1069    107 João Victor \N  554699332657    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-23 17:33:42.534+00  2026-01-23 17:33:42.534+00  2026-01-23 17:33:42.534+00  \N  \N  \N  \N  novo    \N
1068    5   Fabianne Barbosa    \N  5524993140474   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-23 15:16:57.819+00  2026-01-23 15:16:57.819+00  2026-01-23 15:31:54.236+00  \N  \N  \N  \N  novo    \N
1203    5   Areane Aguiar   \N  5524998274790   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 16:32:14.976+00  2026-01-30 15:52:00.78+00   2026-02-04 16:32:14.976+00  \N  \N  \N  \N  novo    \N
539 5   Vera Eunice \N  5524999669732   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:20:07.229+00  2026-01-07 10:20:07.229+00  2026-01-07 10:20:07.229+00  \N  \N  \N  \N  novo    \N
554 5   67796360761579  \N  67796360761579  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:59:26.441+00  2026-01-07 10:59:26.441+00  2026-01-07 10:59:26.441+00  \N  \N  \N  \N  novo    \N
499 5   28080563351601  \N  28080563351601  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:21:50.618+00  2026-01-07 09:21:50.618+00  2026-01-07 09:21:50.618+00  \N  \N  \N  \N  novo    \N
511 5   165648365789249 \N  165648365789249 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:31:11.965+00  2026-01-07 09:31:11.965+00  2026-01-07 09:31:11.965+00  \N  \N  \N  \N  novo    \N
879 103 Paulo   \N  5511983891170   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 21:02:09.749+00  2026-01-15 21:02:09.749+00  2026-01-15 21:02:09.749+00  \N  \N  \N  \N  novo    \N
931 103 Kelly   \N  5511999350512   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 21:30:20.703+00  2026-01-16 21:30:20.703+00  2026-01-16 21:30:20.703+00  \N  \N  \N  \N  novo    \N
819 103 Mellissa Rosa   \N  555191241824    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 22:54:30.064+00  2026-01-13 22:54:30.064+00  2026-01-13 22:54:30.064+00  \N  \N  \N  \N  novo    \N
983 103 Bispa Rúbia \N  556281119592    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:32:00.51+00   2026-01-17 22:32:00.511+00  2026-01-17 22:32:00.511+00  \N  \N  \N  \N  novo    \N
1208    129 Willington Oliveira \N  556199686824    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-30 17:16:27.77+00   2026-01-30 17:10:26.273+00  2026-01-30 17:16:27.77+00   \N  \N  \N  \N  novo    \N
1207    129 Contato sem nome    \N  5527997098439   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-30 17:10:10.846+00  2026-01-30 17:10:00.812+00  2026-01-30 17:10:10.846+00  \N  \N  \N  \N  novo    \N
1271    133 Rafael Paixão   \N  5524993959492   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 04:49:26.316+00  2026-02-04 04:26:12.418+00  2026-02-04 04:49:26.316+00  \N  \N  \N  \N  novo    \N
569 74  278880984285210 \N  278880984285210 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:27:21.778+00  2026-01-07 11:27:21.778+00  2026-01-07 11:27:21.778+00  \N  \N  \N  \N  novo    \N
932 103 Vanessa \N  5521988562291   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 21:33:04.676+00  2026-01-16 21:33:04.676+00  2026-01-16 21:33:04.676+00  \N  \N  \N  \N  novo    \N
933 103 Daniel Palomo   \N  5511975837566   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 21:33:26.528+00  2026-01-16 21:33:26.528+00  2026-01-16 21:33:26.528+00  \N  \N  \N  \N  novo    \N
882 103 Luciano Camargo \N  5511996227227   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 22:12:28.218+00  2026-01-15 22:12:28.218+00  2026-01-15 22:12:28.218+00  \N  \N  \N  \N  novo    \N
822 103 Aisha Labib \N  5517991571735   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 23:39:48.965+00  2026-01-13 23:39:48.965+00  2026-01-13 23:39:48.965+00  \N  \N  \N  \N  novo    \N
984 103 Ricardo \N  5511967792565   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:34:19.64+00   2026-01-17 22:34:19.64+00   2026-01-17 22:34:19.64+00   \N  \N  \N  \N  novo    \N
582 86  127848492867632 \N  127848492867632 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:52:22.046+00  2026-01-07 11:52:22.046+00  2026-01-07 11:52:22.046+00  \N  \N  \N  \N  novo    \N
934 103 Mara Veiga  \N  5511998248637   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 21:38:16.542+00  2026-01-16 21:38:16.543+00  2026-01-16 21:38:16.543+00  \N  \N  \N  \N  novo    \N
883 103 Henrique Spencer    \N  558192937283    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 22:13:44.995+00  2026-01-15 22:13:44.995+00  2026-01-15 22:55:34.906+00  \N  \N  \N  \N  novo    \N
823 103 Luana Sinhori   \N  554599876852    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 23:52:48.937+00  2026-01-13 23:52:48.937+00  2026-01-13 23:52:48.937+00  \N  \N  \N  \N  novo    \N
985 103 Tatiana Plaza   \N  5511984573780   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:40:21.099+00  2026-01-17 22:40:21.099+00  2026-01-17 22:40:21.099+00  \N  \N  \N  \N  novo    \N
994 103 Andressa    \N  5511988183332   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 23:14:10.382+00  2026-01-17 23:14:10.382+00  2026-01-17 23:14:10.382+00  \N  \N  \N  \N  novo    \N
995 103 Vandro  \N  555199611388    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 23:14:10.547+00  2026-01-17 23:14:10.547+00  2026-01-17 23:14:10.547+00  \N  \N  \N  \N  novo    \N
571 86  93724793122994  \N  93724793122994  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:31:59.254+00  2026-01-07 11:31:59.254+00  2026-01-07 11:31:59.254+00  \N  \N  \N  \N  novo    \N
850 103 Giovana \N  5511978432944   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 22:43:37.513+00  2026-01-14 22:43:37.513+00  2026-01-14 22:43:37.513+00  \N  \N  \N  \N  novo    \N
935 103 Lucas Santos    \N  temp-1768599881738752   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 21:44:41.902+00  2026-01-16 21:44:41.903+00  2026-01-16 21:44:41.903+00  \N  \N  \N  \N  novo    \N
884 103 Cida    \N  5511981013062   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 22:16:26.011+00  2026-01-15 22:16:26.011+00  2026-01-15 22:16:26.011+00  \N  \N  \N  \N  novo    \N
824 103 Fga Eduarda Cunha   \N  555182824415    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-13 23:58:48.083+00  2026-01-13 23:58:48.083+00  2026-01-13 23:58:48.083+00  \N  \N  \N  \N  novo    \N
827 103 Dior    \N  5511955801418   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 02:37:48.432+00  2026-01-14 02:37:48.432+00  2026-01-14 02:37:48.432+00  \N  \N  \N  \N  novo    \N
986 103 Leonardo    \N  5511985554894   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:41:20.851+00  2026-01-17 22:41:20.851+00  2026-01-17 22:41:20.851+00  \N  \N  \N  \N  novo    \N
572 74  Cat \N  5511975340333   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:33:26.869+00  2026-01-07 11:33:26.869+00  2026-01-07 11:33:26.869+00  \N  \N  \N  \N  novo    \N
573 74  76785492459574  \N  76785492459574  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:36:46.204+00  2026-01-07 11:36:46.204+00  2026-01-07 11:36:46.204+00  \N  \N  \N  \N  novo    \N
583 74  Caroline F. Azevedo \N  5524999475692   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:53:47.141+00  2026-01-07 11:53:47.142+00  2026-01-07 11:53:47.142+00  \N  \N  \N  \N  novo    \N
733 94  Josias ADutra   \N  553198862377    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-10 00:28:10.98+00   2026-01-10 00:28:10.98+00   2026-01-10 00:28:10.98+00   \N  \N  \N  \N  novo    \N
936 103 Isadora 💕   \N  5511914967489   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 21:59:04.008+00  2026-01-16 21:59:04.008+00  2026-01-16 21:59:04.008+00  \N  \N  \N  \N  novo    \N
885 103 Maria Ligia Chacon  \N  5512981978353   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 22:26:24.68+00   2026-01-15 22:26:24.68+00   2026-01-15 22:26:24.68+00   \N  \N  \N  \N  novo    \N
825 103 Paulo Ferreira  \N  5511988686075   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 00:06:08.907+00  2026-01-14 00:06:08.907+00  2026-01-14 00:06:08.907+00  \N  \N  \N  \N  novo    \N
987 103 Cintia Matos    \N  5511985876106   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:44:41.184+00  2026-01-17 22:44:41.184+00  2026-01-17 22:44:41.184+00  \N  \N  \N  \N  novo    \N
581 74  245083769176217 \N  245083769176217 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:51:21.138+00  2026-01-07 11:51:21.138+00  2026-01-07 11:51:21.138+00  \N  \N  \N  \N  novo    \N
574 86  166438723678240 \N  166438723678240 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:38:38.951+00  2026-01-07 11:38:38.951+00  2026-01-07 11:38:38.951+00  \N  \N  \N  \N  novo    \N
1175    112 Gabriel Robalo | Zapi Pro   \N  555196446840    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-30 19:51:40.149+00  2026-01-27 20:05:33.147+00  2026-01-30 19:51:40.149+00  \N  \N  \N  \N  novo    \N
1176    112 Wayne Mendes    \N  5511954101621   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 20:56:58.968+00  2026-01-27 20:56:58.968+00  2026-01-27 20:56:58.968+00  \N  \N  \N  \N  novo    \N
1211    112 Vitor Nunes \N  555197199032    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:46.292+00  2026-01-30 19:13:01.781+00  2026-02-03 17:01:46.292+00  \N  \N  \N  \N  novo    \N
1169    112 Rudimar Cabreira    \N  555184254240    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 17:04:22.073+00  2026-01-27 17:04:22.073+00  2026-01-27 17:04:22.073+00  \N  \N  \N  \N  novo    \N
1170    112 Pedro Henrique  \N  5511978420487   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 17:24:16.777+00  2026-01-27 17:24:16.777+00  2026-01-27 17:24:16.777+00  \N  \N  \N  \N  novo    \N
1171    5   Luzia   \N  5524999596796   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 18:37:44.559+00  2026-01-27 18:37:44.56+00   2026-01-27 19:32:28.946+00  \N  \N  \N  \N  novo    \N
845 5   Eunice Almada   \N  5524981440072   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 17:51:48.254+00  2026-01-14 19:49:22.318+00  2026-02-04 17:51:48.254+00  \N  \N  \N  \N  novo    \N
1173    5   Ana Maria   \N  5524999596641   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-30 22:34:38.067+00  2026-01-27 18:41:35.728+00  2026-01-30 22:34:38.067+00  \N  \N  \N  \N  novo    \N
1210    5   CCN Distribuidora   \N  5522992286759   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-30 20:22:20.26+00   2026-01-30 18:25:10.487+00  2026-01-30 20:22:20.26+00   \N  \N  \N  \N  novo    \N
731 5   5524999125443   \N  5524999125443   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-09 20:37:54.023+00  2026-01-09 20:37:54.023+00  2026-01-09 20:37:54.023+00  \N  \N  \N  \N  novo    \N
570 5   242932007342260 \N  242932007342260 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:29:49.185+00  2026-01-07 11:29:49.186+00  2026-01-07 11:29:49.186+00  \N  \N  \N  \N  novo    \N
734 94  256397182783591 \N  256397182783591 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-10 00:42:38.155+00  2026-01-10 00:42:38.155+00  2026-01-10 00:42:38.155+00  \N  \N  \N  \N  novo    \N
900 103 Danilo Candelaria   \N  5511944992711   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 00:46:03.286+00  2026-01-16 00:46:03.287+00  2026-01-16 00:46:03.287+00  \N  \N  \N  \N  novo    \N
937 103 Pedro Barreto   \N  5521979986493   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 22:02:37.906+00  2026-01-16 22:02:37.906+00  2026-01-16 22:02:37.906+00  \N  \N  \N  \N  novo    \N
886 103 Carolina Freitas    \N  553499604043    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 22:31:48.9+00    2026-01-15 22:31:48.9+00    2026-01-15 22:31:48.9+00    \N  \N  \N  \N  novo    \N
826 103 Celso Zilbovicius   \N  5511982299794   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 00:25:18.285+00  2026-01-14 00:25:18.285+00  2026-01-14 00:25:18.285+00  \N  \N  \N  \N  novo    \N
988 103 Caio Cesar  \N  5511932650595   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:46:35.172+00  2026-01-17 22:46:35.172+00  2026-01-17 22:46:35.172+00  \N  \N  \N  \N  novo    \N
991 103 Gabriel Gaiotto \N  5515997080409   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:49:28.634+00  2026-01-17 22:49:28.634+00  2026-01-17 22:49:28.634+00  \N  \N  \N  \N  novo    \N
575 86  137817044832471 \N  137817044832471 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:39:36.865+00  2026-01-07 11:39:36.865+00  2026-01-07 11:39:36.865+00  \N  \N  \N  \N  novo    \N
578 86  94931863498878  \N  94931863498878  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:47:27.325+00  2026-01-07 11:47:27.325+00  2026-01-07 11:47:27.325+00  \N  \N  \N  \N  novo    \N
735 94  553195226351    \N  553195226351    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-10 00:54:11.476+00  2026-01-10 00:54:11.476+00  2026-01-10 00:54:11.476+00  \N  \N  \N  \N  novo    \N
938 103 Roberta Kwasnicki Tonon \N  554191681760    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 22:12:26.028+00  2026-01-16 22:12:26.028+00  2026-01-16 22:12:26.028+00  \N  \N  \N  \N  novo    \N
887 103 Alexandre Vallejo   \N  5511980154296   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 22:40:43.244+00  2026-01-15 22:40:43.245+00  2026-01-15 22:40:43.245+00  \N  \N  \N  \N  novo    \N
828 103 David Infiesto  \N  5511959825866   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 03:16:49.984+00  2026-01-14 03:16:49.984+00  2026-01-14 03:16:49.984+00  \N  \N  \N  \N  novo    \N
990 103 Nina Lozzda \N  558896115257    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:47:27.46+00   2026-01-17 22:47:27.46+00   2026-01-17 22:47:27.46+00   \N  \N  \N  \N  novo    \N
989 103 Marcos Oliveira \N  5511915081712   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:47:13.381+00  2026-01-17 22:47:13.381+00  2026-01-17 22:47:13.381+00  \N  \N  \N  \N  novo    \N
1114    111 Josias Dutra    \N  553198862377    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 01:31:31.499+00  2026-01-25 01:31:31.499+00  2026-01-25 01:31:31.499+00  \N  \N  \N  \N  novo    \N
939 103 ⚽💢😎 \N  5521998168534   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 22:28:18.645+00  2026-01-16 22:28:18.646+00  2026-01-16 22:28:18.646+00  \N  \N  \N  \N  novo    \N
888 103 Helio   \N  5511996675280   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 22:44:00.583+00  2026-01-15 22:44:00.583+00  2026-01-15 22:44:00.583+00  \N  \N  \N  \N  novo    \N
889 103 José Renê   \N  5511975906089   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 22:44:08.98+00   2026-01-15 22:44:08.98+00   2026-01-15 22:44:32.608+00  \N  \N  \N  \N  novo    \N
943 103 João    \N  5518991486420   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 22:53:23.41+00   2026-01-16 22:53:23.41+00   2026-01-16 22:53:23.41+00   \N  \N  \N  \N  novo    \N
992 103 Vinicius Gobbi  \N  5512996662380   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 22:51:46.373+00  2026-01-17 22:51:46.373+00  2026-01-17 22:51:46.373+00  \N  \N  \N  \N  novo    \N
580 74  122316558225437 \N  122316558225437 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:50:37.351+00  2026-01-07 11:50:37.351+00  2026-01-07 11:50:37.351+00  \N  \N  \N  \N  novo    \N
579 86  98900329418912  \N  98900329418912  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:50:09.792+00  2026-01-07 11:50:09.792+00  2026-01-07 11:50:09.792+00  \N  \N  \N  \N  novo    \N
940 103 Vitor de Angeli \N  558698050508    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 22:38:40.65+00   2026-01-16 22:38:40.65+00   2026-01-16 22:38:40.65+00   \N  \N  \N  \N  novo    \N
890 103 Teresa Daltro   \N  5511996319744   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 23:04:07.346+00  2026-01-15 23:04:07.346+00  2026-01-15 23:04:07.346+00  \N  \N  \N  \N  novo    \N
993 103 Tomislav    \N  5511996888968   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 23:07:10.323+00  2026-01-17 23:07:10.323+00  2026-01-17 23:07:10.323+00  \N  \N  \N  \N  novo    \N
1000    103 Paola Villaça   \N  5511988199002   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 00:10:32.115+00  2026-01-18 00:10:32.115+00  2026-01-18 00:10:32.115+00  \N  \N  \N  \N  novo    \N
1115    111 Fae Developer   \N  552433540335    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 02:07:52.97+00   2026-01-25 02:07:52.97+00   2026-01-25 02:08:07.551+00  \N  \N  \N  \N  novo    \N
585 74  28033352257685  \N  28033352257685  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:59:45.131+00  2026-01-07 11:59:45.131+00  2026-01-07 11:59:45.131+00  \N  \N  \N  \N  novo    \N
941 103 Raphael Pereira Arantes \N  5511984829066   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 22:41:38.557+00  2026-01-16 22:41:38.557+00  2026-01-16 22:41:38.557+00  \N  \N  \N  \N  novo    \N
831 103 veronica franco \N  553199912497    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 12:00:06.173+00  2026-01-14 12:00:06.173+00  2026-01-14 12:00:06.173+00  \N  \N  \N  \N  novo    \N
996 103 Natália Spinola \N  5511985782733   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 23:16:56.357+00  2026-01-17 23:16:56.357+00  2026-01-17 23:16:56.357+00  \N  \N  \N  \N  novo    \N
586 86  200772675469414 \N  200772675469414 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:02:08.032+00  2026-01-07 12:02:08.032+00  2026-01-07 12:02:08.032+00  \N  \N  \N  \N  novo    \N
892 103 Raphael Monteiro    \N  556181170102    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 23:18:36.947+00  2026-01-15 23:18:36.947+00  2026-01-15 23:18:36.947+00  \N  \N  \N  \N  novo    \N
942 103 Juliane Teixeira    \N  559182153206    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 22:44:14.26+00   2026-01-16 22:44:14.26+00   2026-01-16 22:44:14.26+00   \N  \N  \N  \N  novo    \N
832 103 Vini    \N  5511965284391   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 12:00:29.463+00  2026-01-14 12:00:29.463+00  2026-01-14 12:00:29.463+00  \N  \N  \N  \N  novo    \N
838 103 Mori    \N  5511985842229   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 14:40:38.692+00  2026-01-14 14:40:38.692+00  2026-01-14 14:40:38.692+00  \N  \N  \N  \N  novo    \N
998 103 Beto    \N  5511983053169   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 23:30:26.561+00  2026-01-17 23:30:26.561+00  2026-01-17 23:30:26.561+00  \N  \N  \N  \N  novo    \N
588 74  124158948171784 \N  124158948171784 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:04:41.09+00   2026-01-07 12:04:41.09+00   2026-01-07 12:04:41.09+00   \N  \N  \N  \N  novo    \N
596 86  144585879736425 \N  144585879736425 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:22:50.873+00  2026-01-07 12:22:50.873+00  2026-01-07 12:22:50.873+00  \N  \N  \N  \N  novo    \N
1118    111 Luiz Henrique Moreira   \N  553191095971    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 03:07:27.372+00  2026-01-25 03:07:27.372+00  2026-01-25 03:14:35.845+00  \N  \N  \N  \N  novo    \N
740 88  556182215427    \N  556182215427    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-10 13:03:46.212+00  2026-01-10 13:03:46.212+00  2026-01-10 13:03:46.212+00  \N  \N  \N  \N  novo    \N
893 103 Dete    \N  554191937435    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 23:23:21.769+00  2026-01-15 23:23:21.769+00  2026-01-15 23:23:21.769+00  \N  \N  \N  \N  novo    \N
898 103 Bárbara Cagnatto    \N  5511981963659   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 23:43:24.295+00  2026-01-15 23:43:24.295+00  2026-01-15 23:43:24.295+00  \N  \N  \N  \N  novo    \N
944 103 Kátia   \N  5511973993309   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 23:08:08.753+00  2026-01-16 23:08:08.753+00  2026-01-16 23:08:08.753+00  \N  \N  \N  \N  novo    \N
1113    109 Anderson Haack  \N  554691364141    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 00:25:17.626+00  2026-01-25 00:25:17.626+00  2026-01-25 00:25:17.626+00  \N  \N  \N  \N  novo    \N
1177    112 Vinicius Martins - DKW  \N  555197472574    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-31 01:21:30.608+00  2026-01-28 01:21:19.028+00  2026-01-31 01:21:30.609+00  \N  \N  \N  \N  novo    \N
1212    112 Mari Abbott \N  555191563637    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-30 19:27:40.653+00  2026-01-30 19:27:12.89+00   2026-01-30 19:27:40.653+00  \N  \N  \N  \N  novo    \N
1217    112 zabot   \N  554884641312    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-30 20:27:22.126+00  2026-01-30 20:26:59.807+00  2026-01-30 20:27:22.126+00  \N  \N  \N  \N  novo    \N
829 5   Luciana \N  5524992465555   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 11:29:31.582+00  2026-01-14 11:29:31.582+00  2026-01-14 11:29:31.582+00  \N  \N  \N  \N  novo    \N
833 5   Juliana \N  5521970055187   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 12:35:50.288+00  2026-01-14 12:35:50.288+00  2026-01-14 12:35:50.288+00  \N  \N  \N  \N  novo    \N
577 5   162251063480416 \N  162251063480416 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:42:09.448+00  2026-01-07 11:42:09.449+00  2026-01-07 11:42:09.449+00  \N  \N  \N  \N  novo    \N
576 5   Aguinaldo Almeida   \N  5524999422834   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:41:40.94+00   2026-01-07 11:41:40.941+00  2026-01-07 11:41:40.941+00  \N  \N  \N  \N  novo    \N
587 5   Personalizadoss da Nat  \N  5524999099641   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:03:06.931+00  2026-01-07 12:03:06.931+00  2026-01-07 12:03:06.931+00  \N  \N  \N  \N  novo    \N
999 103 Rica Castilho   \N  5511942483659   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 00:03:19.285+00  2026-01-18 00:03:19.285+00  2026-01-18 00:03:19.285+00  \N  \N  \N  \N  novo    \N
960 103 Mariana \N  5511996140878   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 01:08:16.433+00  2026-01-17 01:08:16.433+00  2026-01-17 01:08:16.433+00  \N  \N  \N  \N  novo    \N
963 103 Piseti  \N  5511951799366   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 02:41:06.166+00  2026-01-17 02:41:06.166+00  2026-01-17 02:41:06.166+00  \N  \N  \N  \N  novo    \N
589 86  281329065267386 \N  281329065267386 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:08:03.73+00   2026-01-07 12:08:03.73+00   2026-01-07 12:08:03.73+00   \N  \N  \N  \N  novo    \N
591 86  56784383393870  \N  56784383393870  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:14:03.946+00  2026-01-07 12:14:03.946+00  2026-01-07 12:14:03.946+00  \N  \N  \N  \N  novo    \N
592 86  189386633289894 \N  189386633289894 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:17:11.235+00  2026-01-07 12:17:11.236+00  2026-01-07 12:17:11.236+00  \N  \N  \N  \N  novo    \N
1119    111 Contato sem nome    \N  554999214230    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 03:07:27.467+00  2026-01-25 03:07:27.467+00  2026-01-25 03:07:27.467+00  \N  \N  \N  \N  novo    \N
894 103 🇩🇪🇨🇭🇧🇷  \N  5522981775977   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 23:32:24.878+00  2026-01-15 23:32:24.878+00  2026-01-15 23:32:24.878+00  \N  \N  \N  \N  novo    \N
945 103 Christiane  \N  5511993433669   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 23:12:27.098+00  2026-01-16 23:12:27.098+00  2026-01-16 23:12:27.098+00  \N  \N  \N  \N  novo    \N
1001    103 Márcia  \N  554188520428    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 01:47:15.824+00  2026-01-18 01:47:15.824+00  2026-01-18 01:47:15.824+00  \N  \N  \N  \N  novo    \N
835 104 Contato sem nome 2157   \N  133526892601576 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 13:23:00.372+00  2026-01-14 13:23:00.372+00  2026-01-21 14:22:55.339+00  \N  \N  \N  \N  novo    \N
593 74  252643029086237 \N  252643029086237 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:17:39.53+00   2026-01-07 12:17:39.53+00   2026-01-07 12:17:39.53+00   \N  \N  \N  \N  novo    \N
1121    111 Contato sem nome    \N  5516997288204   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 03:07:27.768+00  2026-01-25 03:07:27.768+00  2026-01-25 03:07:27.768+00  \N  \N  \N  \N  novo    \N
1120    111 Wando   \N  5519982021097   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 03:07:27.537+00  2026-01-25 03:07:27.537+00  2026-01-25 03:08:38.423+00  \N  \N  \N  \N  novo    \N
895 103 Marcos Lenci    \N  5511996515131   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 23:32:39.941+00  2026-01-15 23:32:39.941+00  2026-01-15 23:34:10.374+00  \N  \N  \N  \N  novo    \N
946 103 Camila Cavalcante   \N  5511987627087   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 23:14:16.566+00  2026-01-16 23:14:16.566+00  2026-01-16 23:14:16.566+00  \N  \N  \N  \N  novo    \N
1002    103 Osmani Jr   \N  553599973028    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 02:41:12.28+00   2026-01-18 02:41:12.28+00   2026-01-18 02:41:12.28+00   \N  \N  \N  \N  novo    \N
1122    111 Contato sem nome    \N  5516997288204   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 03:07:27.805+00  2026-01-25 03:07:27.805+00  2026-01-25 03:07:27.805+00  \N  \N  \N  \N  novo    \N
947 103 Iolanda Barreto \N  5511915068448   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 23:25:54.545+00  2026-01-16 23:25:54.545+00  2026-01-16 23:25:54.545+00  \N  \N  \N  \N  novo    \N
956 103 Luis Gustavo    \N  5511932034273   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-17 00:21:11.677+00  2026-01-17 00:21:11.677+00  2026-01-17 00:21:11.677+00  \N  \N  \N  \N  novo    \N
836 103 Paula   \N  556182300765    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 13:59:18.072+00  2026-01-14 13:59:18.072+00  2026-01-14 13:59:18.072+00  \N  \N  \N  \N  novo    \N
1003    103 Isabella Valle  \N  556292867903    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 14:04:47.887+00  2026-01-18 14:04:47.888+00  2026-01-18 14:04:47.888+00  \N  \N  \N  \N  novo    \N
652 86  Francisco Javier    \N  5550232433869   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 18:22:08.962+00  2026-01-07 18:22:08.962+00  2026-01-07 18:22:08.962+00  \N  \N  \N  \N  novo    \N
654 86  83593049178146  \N  83593049178146  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 18:29:24.05+00   2026-01-07 18:29:24.05+00   2026-01-07 18:29:24.05+00   \N  \N  \N  \N  novo    \N
655 86  Ayron   \N  5550242116505   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 18:32:11.196+00  2026-01-07 18:32:11.196+00  2026-01-07 18:32:11.196+00  \N  \N  \N  \N  novo    \N
603 86  30305356382337  \N  30305356382337  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:44:00.898+00  2026-01-07 12:44:00.898+00  2026-01-07 12:44:00.898+00  \N  \N  \N  \N  novo    \N
610 86  64661185679551  \N  64661185679551  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 13:02:19.274+00  2026-01-07 13:02:19.274+00  2026-01-07 13:02:19.274+00  \N  \N  \N  \N  novo    \N
619 86  23029664977052  \N  23029664977052  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 13:44:37.286+00  2026-01-07 13:44:37.286+00  2026-01-07 13:44:37.286+00  \N  \N  \N  \N  novo    \N
623 86  261829897011316 \N  261829897011316 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 14:06:16.324+00  2026-01-07 14:06:16.324+00  2026-01-07 14:06:16.324+00  \N  \N  \N  \N  novo    \N
617 86  Estuardo B  \N  5550257072813   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 13:33:43.233+00  2026-01-07 13:33:43.233+00  2026-01-07 13:33:43.233+00  \N  \N  \N  \N  novo    \N
626 86  Nacional Code   \N  573504931577    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 14:46:31.312+00  2026-01-07 14:46:31.312+00  2026-01-07 14:46:31.312+00  \N  \N  \N  \N  novo    \N
634 86  Melissa ♥️💙 \N  5550235176939   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 16:00:10.875+00  2026-01-07 16:00:10.875+00  2026-01-07 16:00:10.875+00  \N  \N  \N  \N  novo    \N
635 86  169380692418792 \N  169380692418792 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 16:05:57.238+00  2026-01-07 16:05:57.238+00  2026-01-07 16:05:57.238+00  \N  \N  \N  \N  novo    \N
636 86  15178464792759  \N  15178464792759  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 16:09:12.895+00  2026-01-07 16:09:12.896+00  2026-01-07 16:09:12.896+00  \N  \N  \N  \N  novo    \N
638 86  256766046683298 \N  256766046683298 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 16:38:19.851+00  2026-01-07 16:38:19.852+00  2026-01-07 16:38:19.852+00  \N  \N  \N  \N  novo    \N
644 86  TiTo Samayoa    \N  5550241491841   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 17:24:09.664+00  2026-01-07 17:24:09.664+00  2026-01-07 17:24:09.664+00  \N  \N  \N  \N  novo    \N
642 86  Rapixchange \N  5550259515570   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 17:14:22.011+00  2026-01-07 17:14:22.011+00  2026-01-07 17:14:22.011+00  \N  \N  \N  \N  novo    \N
640 86  Gustavo Sierra  \N  5550231203418   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 17:03:05.601+00  2026-01-07 17:03:05.601+00  2026-01-07 17:03:05.601+00  \N  \N  \N  \N  novo    \N
646 86  97139292123361  \N  97139292123361  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 17:27:47.502+00  2026-01-07 17:27:47.502+00  2026-01-07 17:27:47.502+00  \N  \N  \N  \N  novo    \N
647 86  51987482104 \N  5551987482104   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 17:29:18.842+00  2026-01-07 17:29:18.842+00  2026-01-07 17:29:18.842+00  \N  \N  \N  \N  novo    \N
637 86  Marlon  \N  5550259791927   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 16:15:37.891+00  2026-01-07 16:15:37.891+00  2026-01-07 16:15:37.891+00  \N  \N  \N  \N  novo    \N
1123    111 Fantasma    \N  557598310736    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-25 03:22:58.149+00  2026-01-25 03:22:58.15+00   2026-01-25 03:22:58.15+00   \N  \N  \N  \N  novo    \N
662 88  556185395999    \N  556185395999    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 19:36:22.144+00  2026-01-07 19:36:22.144+00  2026-01-07 19:36:22.144+00  \N  \N  \N  \N  novo    \N
663 88  556181115943    \N  556181115943    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 19:36:41.476+00  2026-01-07 19:36:41.476+00  2026-01-07 19:36:41.476+00  \N  \N  \N  \N  novo    \N
897 103 Pedro   \N  5511971331313   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 23:41:52.689+00  2026-01-15 23:41:52.689+00  2026-01-15 23:41:52.689+00  \N  \N  \N  \N  novo    \N
948 103 Leticia \N  5518997733283   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 23:28:05.7+00    2026-01-16 23:28:05.7+00    2026-01-16 23:28:05.7+00    \N  \N  \N  \N  novo    \N
837 103 Elizabeti Gomes \N  5511992504427   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 14:33:26.767+00  2026-01-14 14:33:26.767+00  2026-01-14 14:33:26.767+00  \N  \N  \N  \N  novo    \N
1004    103 Borgexzz❤️  \N  553173055858    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 15:58:45.9+00    2026-01-18 15:58:45.9+00    2026-01-18 15:58:45.9+00    \N  \N  \N  \N  novo    \N
650 5   20663121256641  \N  20663121256641  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 18:10:02.053+00  2026-01-07 18:10:02.053+00  2026-01-07 18:10:02.053+00  \N  \N  \N  \N  novo    \N
598 5   96203157045412  \N  96203157045412  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:34:10.158+00  2026-01-07 12:34:10.158+00  2026-01-07 12:34:10.158+00  \N  \N  \N  \N  novo    \N
595 5   40270267732206  \N  40270267732206  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:20:40.043+00  2026-01-07 12:20:40.043+00  2026-01-07 12:20:40.043+00  \N  \N  \N  \N  novo    \N
834 5   Bem Frio ar condicionado    \N  5524998554648   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-30 13:40:02.694+00  2026-01-14 12:47:13.316+00  2026-01-30 13:40:02.694+00  \N  \N  \N  \N  novo    \N
613 5   🌻Joana Darc🌻    \N  5524999988428   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 13:16:04.668+00  2026-01-07 13:16:04.669+00  2026-01-07 13:16:04.669+00  \N  \N  \N  \N  novo    \N
219 74  Philippe Nelson \N  5511972817999   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 23:15:29.996+00  2026-01-04 23:15:29.996+00  2026-01-04 23:15:29.996+00  \N  \N  \N  \N  novo    \N
184 74  243194151329813 \N  243194151329813 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 13:39:01.678+00  2026-01-04 13:39:01.679+00  2026-01-04 13:39:01.679+00  \N  \N  \N  \N  novo    \N
256 74  165833082978455 \N  165833082978455 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 17:51:40.167+00  2026-01-05 17:51:40.168+00  2026-01-05 17:51:40.168+00  \N  \N  \N  \N  novo    \N
277 74  Patrícia    \N  5511959550074   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 22:39:57.122+00  2026-01-05 22:39:57.123+00  2026-01-05 22:39:57.123+00  \N  \N  \N  \N  novo    \N
165 74  Luiz Gustavo Anoni  \N  5517991418181   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 23:30:38.456+00  2026-01-03 23:30:38.456+00  2026-01-03 23:30:38.456+00  \N  \N  \N  \N  novo    \N
185 74  189270887284868 \N  189270887284868 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 13:58:10.847+00  2026-01-04 13:58:10.847+00  2026-01-04 13:58:10.847+00  \N  \N  \N  \N  novo    \N
258 74  Bruno Oliveira  \N  5511991939615   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 18:27:27.622+00  2026-01-05 18:27:27.622+00  2026-01-05 18:27:27.622+00  \N  \N  \N  \N  novo    \N
327 74  Julie Anne Braun    \N  5511974164326   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.633+00  2026-01-06 23:14:10.633+00  2026-01-06 23:14:10.633+00  \N  \N  \N  \N  novo    \N
328 74  Julie Anne Braun    \N  5511974164326   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.711+00  2026-01-06 23:14:10.711+00  2026-01-06 23:14:10.711+00  \N  \N  \N  \N  novo    \N
330 74  Julie Anne Braun    \N  5511974164326   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.738+00  2026-01-06 23:14:10.738+00  2026-01-06 23:14:10.738+00  \N  \N  \N  \N  novo    \N
331 74  Julie Anne Braun    \N  5511974164326   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.727+00  2026-01-06 23:14:10.727+00  2026-01-06 23:14:10.727+00  \N  \N  \N  \N  novo    \N
332 74  Julie Anne Braun    \N  5511974164326   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.776+00  2026-01-06 23:14:10.776+00  2026-01-06 23:14:10.776+00  \N  \N  \N  \N  novo    \N
333 74  Julie Anne Braun    \N  5511974164326   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.776+00  2026-01-06 23:14:10.776+00  2026-01-06 23:14:10.776+00  \N  \N  \N  \N  novo    \N
334 74  Julie Anne Braun    \N  5511974164326   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.781+00  2026-01-06 23:14:10.781+00  2026-01-06 23:14:10.781+00  \N  \N  \N  \N  novo    \N
335 74  Julie Anne Braun    \N  5511974164326   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.781+00  2026-01-06 23:14:10.781+00  2026-01-06 23:14:10.781+00  \N  \N  \N  \N  novo    \N
336 74  Julie Anne Braun    \N  5511974164326   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.791+00  2026-01-06 23:14:10.791+00  2026-01-06 23:14:10.791+00  \N  \N  \N  \N  novo    \N
162 74  Jefferson Marques   \N  5511955702875   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 23:20:36.095+00  2026-01-03 23:20:36.095+00  2026-01-03 23:20:36.095+00  \N  \N  \N  \N  novo    \N
125 74  248755983007845 \N  248755983007845 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 10:07:44.595+00  2026-01-03 10:07:44.595+00  2026-01-03 10:07:44.595+00  \N  \N  \N  \N  novo    \N
291 74  165352096968846 \N  165352096968846 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 02:38:03.59+00   2026-01-06 02:38:03.59+00   2026-01-06 02:38:03.59+00   \N  \N  \N  \N  novo    \N
201 74  5511952953024   \N  5511952953024   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 21:20:20.541+00  2026-01-04 21:20:20.541+00  2026-01-04 21:20:20.541+00  \N  \N  \N  \N  novo    \N
452 74  278176576098317 \N  278176576098317 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:35:33.472+00  2026-01-07 07:35:33.472+00  2026-01-07 07:35:33.472+00  \N  \N  \N  \N  novo    \N
510 74  34140812517484  \N  34140812517484  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:30:05.109+00  2026-01-07 09:30:05.109+00  2026-01-07 09:30:05.109+00  \N  \N  \N  \N  novo    \N
536 74  112584095199434 \N  112584095199434 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:19:03.948+00  2026-01-07 10:19:03.948+00  2026-01-07 10:19:03.948+00  \N  \N  \N  \N  novo    \N
110 74  5511996459184   \N  5511996459184   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 23:46:48.345+00  2026-01-02 23:46:48.345+00  2026-01-02 23:46:48.345+00  \N  \N  \N  \N  novo    \N
202 74  Pedro Queiroz   \N  556191868790    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 21:25:40.586+00  2026-01-04 21:25:40.586+00  2026-01-04 21:25:40.586+00  \N  \N  \N  \N  novo    \N
131 74  SS  \N  5511913548493   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 15:42:31.239+00  2026-01-03 15:42:31.24+00   2026-01-03 15:42:31.24+00   \N  \N  \N  \N  novo    \N
126 74  Carol Robles    \N  5527997585998   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 11:07:54.597+00  2026-01-03 11:07:54.598+00  2026-01-03 11:07:54.598+00  \N  \N  \N  \N  novo    \N
93  74  Leticia katiel  \N  120770386747430 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:51:51.193+00  2026-01-02 21:51:51.193+00  2026-01-02 21:51:51.193+00  \N  \N  \N  \N  novo    \N
687 74  .   \N  5511982489727   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-08 03:16:57.701+00  2026-01-08 03:16:57.701+00  2026-01-08 03:16:57.701+00  \N  \N  \N  \N  novo    \N
659 86  62891323584618  \N  62891323584618  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 19:17:01.809+00  2026-01-07 19:17:01.809+00  2026-01-07 19:17:01.809+00  \N  \N  \N  \N  novo    \N
476 86  50245493155 \N  5550245493155   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:29:42.706+00  2026-01-07 08:29:42.706+00  2026-01-07 19:18:02.038+00  \N  \N  \N  \N  novo    \N
660 86  50253442030 \N  5550253442030   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 19:20:38.224+00  2026-01-07 19:20:38.224+00  2026-01-07 19:20:38.224+00  \N  \N  \N  \N  novo    \N
661 86  50252000268 \N  5550252000268   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 19:23:16.424+00  2026-01-07 19:23:16.424+00  2026-01-07 19:23:16.424+00  \N  \N  \N  \N  novo    \N
666 86  Enio Walter \N  5550248595223   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 20:24:01.193+00  2026-01-07 20:24:01.193+00  2026-01-07 20:24:01.193+00  \N  \N  \N  \N  novo    \N
166 74  Deliane Petsitter   \N  5516997229289   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 23:48:01.892+00  2026-01-03 23:48:01.892+00  2026-01-03 23:48:01.892+00  \N  \N  \N  \N  novo    \N
186 74  140943781019848 \N  140943781019848 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 14:13:59.411+00  2026-01-04 14:13:59.411+00  2026-01-04 14:13:59.411+00  \N  \N  \N  \N  novo    \N
241 74  160885230284952 \N  160885230284952 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 12:40:20.021+00  2026-01-05 12:40:20.021+00  2026-01-05 12:40:20.021+00  \N  \N  \N  \N  novo    \N
306 74  Larissa Nunes   \N  5511951700763   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 15:30:36.342+00  2026-01-06 15:30:36.342+00  2026-01-06 15:30:36.342+00  \N  \N  \N  \N  novo    \N
292 74  51969322426603  \N  51969322426603  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 08:07:39.436+00  2026-01-06 08:07:39.436+00  2026-01-06 08:07:39.436+00  \N  \N  \N  \N  novo    \N
339 74  ~ Cami Novaes   \N  5511945152483   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.868+00  2026-01-06 23:14:10.868+00  2026-01-06 23:14:10.868+00  \N  \N  \N  \N  novo    \N
111 74  Dra Silvia Carvalho \N  5511995596519   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 23:47:54.733+00  2026-01-02 23:47:54.733+00  2026-01-02 23:47:54.733+00  \N  \N  \N  \N  novo    \N
127 74  272851403845875 \N  272851403845875 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 13:36:20.088+00  2026-01-03 13:36:20.088+00  2026-01-03 13:36:20.088+00  \N  \N  \N  \N  novo    \N
94  74  Sinesia \N  5511985574801   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:57:38.832+00  2026-01-02 21:57:38.832+00  2026-01-02 22:04:57.72+00   \N  \N  \N  \N  novo    \N
167 74  Karla   \N  5511983756832   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 23:52:54.223+00  2026-01-03 23:52:54.223+00  2026-01-03 23:52:54.223+00  \N  \N  \N  \N  novo    \N
203 74  Ana Cecília \N  559691120042    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 21:36:11.583+00  2026-01-04 21:36:11.583+00  2026-01-04 21:36:11.583+00  \N  \N  \N  \N  novo    \N
206 74  Carol Figueiredo    \N  556799085852    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 22:12:35.291+00  2026-01-04 22:12:35.291+00  2026-01-04 22:12:35.291+00  \N  \N  \N  \N  novo    \N
242 74  82343532445746  \N  82343532445746  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 12:50:27.455+00  2026-01-05 12:50:27.455+00  2026-01-05 12:50:27.455+00  \N  \N  \N  \N  novo    \N
260 74  76338799071354  \N  76338799071354  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 18:35:11.926+00  2026-01-05 18:35:11.926+00  2026-01-05 18:35:11.926+00  \N  \N  \N  \N  novo    \N
307 74  Eliana  \N  5511982824031   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 15:39:38.973+00  2026-01-06 15:39:38.973+00  2026-01-06 15:39:38.973+00  \N  \N  \N  \N  novo    \N
112 74  193024504115350 \N  193024504115350 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 23:52:46.978+00  2026-01-02 23:52:46.978+00  2026-01-02 23:52:46.978+00  \N  \N  \N  \N  novo    \N
169 74  157780069638236 \N  157780069638236 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 00:35:00.982+00  2026-01-04 00:35:00.982+00  2026-01-04 00:35:00.982+00  \N  \N  \N  \N  novo    \N
95  74  21969412092104  \N  21969412092104  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:58:30.061+00  2026-01-02 21:58:30.061+00  2026-01-02 22:00:54.677+00  \N  \N  \N  \N  novo    \N
188 74  Leonardo    \N  5511941097092   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 15:54:08.918+00  2026-01-04 15:54:08.918+00  2026-01-04 15:54:08.918+00  \N  \N  \N  \N  novo    \N
96  74  Adrielli Cedran \N  5516991557994   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:58:38.108+00  2026-01-02 21:58:38.108+00  2026-01-02 21:58:38.108+00  \N  \N  \N  \N  novo    \N
204 74  Isabella Souza  \N  5511983541527   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 21:43:36.254+00  2026-01-04 21:43:36.255+00  2026-01-04 21:43:36.255+00  \N  \N  \N  \N  novo    \N
149 74  2933848568022   \N  2933848568022   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 20:54:27.036+00  2026-01-03 20:54:27.036+00  2026-01-03 20:54:27.036+00  \N  \N  \N  \N  novo    \N
243 74  Izabelli Nicoli \N  5511913184714   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 14:02:22.41+00   2026-01-05 14:02:22.41+00   2026-01-05 14:02:22.41+00   \N  \N  \N  \N  novo    \N
262 74  Daniela Barahona Garces \N  573178950408    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 19:22:27.009+00  2026-01-05 19:22:27.01+00   2026-01-05 19:22:27.01+00   \N  \N  \N  \N  novo    \N
278 74  Vera    \N  5511967310451   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 22:44:57.402+00  2026-01-05 22:44:57.402+00  2026-01-05 22:44:57.402+00  \N  \N  \N  \N  novo    \N
293 74  Eventos Veridiana   \N  5511984990088   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 10:46:40.742+00  2026-01-06 10:46:40.742+00  2026-01-06 10:46:40.742+00  \N  \N  \N  \N  novo    \N
308 74  BacoIA  \N  5511981580518   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 15:40:00.41+00   2026-01-06 15:40:00.41+00   2026-01-06 15:40:00.41+00   \N  \N  \N  \N  novo    \N
113 74  Gabriel M. Maranhão \N  559888999848    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 00:03:37.072+00  2026-01-03 00:03:37.072+00  2026-01-03 00:03:37.072+00  \N  \N  \N  \N  novo    \N
462 74  95069218550010  \N  95069218550010  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:51:18.602+00  2026-01-07 07:51:18.602+00  2026-01-07 07:51:18.602+00  \N  \N  \N  \N  novo    \N
97  74  Fabiana Lira    \N  156551675400203 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:59:56.702+00  2026-01-02 21:59:56.702+00  2026-01-02 21:59:56.702+00  \N  \N  \N  \N  novo    \N
134 74  Diogo   \N  5511988833590   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 15:54:49.242+00  2026-01-03 15:54:49.242+00  2026-01-03 15:54:49.242+00  \N  \N  \N  \N  novo    \N
150 74  Renata A Nakano Mendes  \N  5511989869545   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 20:56:01.979+00  2026-01-03 20:56:01.979+00  2026-01-03 20:56:01.979+00  \N  \N  \N  \N  novo    \N
189 74  69277923147796  \N  69277923147796  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 17:48:03.636+00  2026-01-04 17:48:03.636+00  2026-01-04 17:48:03.636+00  \N  \N  \N  \N  novo    \N
244 74  250293564481604 \N  250293564481604 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 14:09:01.78+00   2026-01-05 14:09:01.78+00   2026-01-05 14:09:01.78+00   \N  \N  \N  \N  novo    \N
263 74  igormeloxp  \N  5521966826653   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 20:04:44.16+00   2026-01-05 20:04:44.16+00   2026-01-05 20:04:44.16+00   \N  \N  \N  \N  novo    \N
294 74  Leonardo Bueno  \N  5511989768103   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 11:40:11.458+00  2026-01-06 11:40:11.458+00  2026-01-06 11:40:11.458+00  \N  \N  \N  \N  novo    \N
343 74  5511980323724   \N  5511980323724   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.886+00  2026-01-06 23:14:10.886+00  2026-01-06 23:14:10.886+00  \N  \N  \N  \N  novo    \N
534 74  281273130049734 \N  281273130049734 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:12:15.281+00  2026-01-07 10:12:15.282+00  2026-01-07 10:12:15.282+00  \N  \N  \N  \N  novo    \N
538 74  94768604434621  \N  94768604434621  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:20:07.157+00  2026-01-07 10:20:07.157+00  2026-01-07 10:20:07.157+00  \N  \N  \N  \N  novo    \N
114 74  Bruno   \N  5516997914455   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 00:12:13.103+00  2026-01-03 00:12:13.104+00  2026-01-03 00:12:13.104+00  \N  \N  \N  \N  novo    \N
99  74  5511930162454   \N  5511930162454   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 22:03:32.602+00  2026-01-02 22:03:32.602+00  2026-01-02 22:03:32.602+00  \N  \N  \N  \N  novo    \N
651 74  167065772122346 \N  167065772122346 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 18:12:55.171+00  2026-01-07 18:12:55.171+00  2026-01-07 18:12:55.171+00  \N  \N  \N  \N  novo    \N
171 74  184194084921564 \N  184194084921564 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 01:15:38.19+00   2026-01-04 01:15:38.19+00   2026-01-04 01:15:38.19+00   \N  \N  \N  \N  novo    \N
172 74  Néia Vermeille  \N  5527998332708   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 01:39:18.416+00  2026-01-04 01:39:18.416+00  2026-01-04 01:39:18.416+00  \N  \N  \N  \N  novo    \N
135 74  128462622838988 \N  128462622838988 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 16:07:20.404+00  2026-01-03 16:07:20.404+00  2026-01-03 16:07:20.404+00  \N  \N  \N  \N  novo    \N
190 74  208202968871055 \N  208202968871055 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 18:16:35.158+00  2026-01-04 18:16:35.158+00  2026-01-04 18:16:35.158+00  \N  \N  \N  \N  novo    \N
207 74  maria eduarda   \N  5511961011591   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 22:24:13.556+00  2026-01-04 22:24:13.556+00  2026-01-04 22:24:13.556+00  \N  \N  \N  \N  novo    \N
264 74  Hugo Araujo \N  557799843818    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 20:05:42.39+00   2026-01-05 20:05:42.39+00   2026-01-05 20:05:42.39+00   \N  \N  \N  \N  novo    \N
279 74  Lara Guimarães  \N  5511963993256   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 23:02:07.67+00   2026-01-05 23:02:07.67+00   2026-01-05 23:02:07.67+00   \N  \N  \N  \N  novo    \N
338 74  Michael Cintra  \N  5511969337575   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.868+00  2026-01-06 23:14:10.868+00  2026-01-06 23:14:10.868+00  \N  \N  \N  \N  novo    \N
344 74  Michael Cintra  \N  5511969337575   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.886+00  2026-01-06 23:14:10.886+00  2026-01-06 23:14:10.886+00  \N  \N  \N  \N  novo    \N
351 74  Solange Bandiera    \N  5516991780992   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 00:00:45.385+00  2026-01-07 00:00:45.385+00  2026-01-07 00:00:45.385+00  \N  \N  \N  \N  novo    \N
173 74  241905594028241 \N  241905594028241 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 01:48:46.873+00  2026-01-04 01:48:46.873+00  2026-01-04 01:48:46.873+00  \N  \N  \N  \N  novo    \N
191 74  João    \N  553197064486    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 18:34:52.262+00  2026-01-04 18:34:52.263+00  2026-01-04 18:34:52.263+00  \N  \N  \N  \N  novo    \N
208 74  Luana Carvalho  \N  5511983689368   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 22:30:48.402+00  2026-01-04 22:30:48.402+00  2026-01-04 22:30:48.402+00  \N  \N  \N  \N  novo    \N
115 74  Lu Murari   \N  5514981179832   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 00:22:31.185+00  2026-01-03 00:22:31.185+00  2026-01-03 00:22:31.185+00  \N  \N  \N  \N  novo    \N
211 74  Sueli Carvalho  \N  5511959034762   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 22:41:02.271+00  2026-01-04 22:41:02.271+00  2026-01-04 22:41:02.271+00  \N  \N  \N  \N  novo    \N
152 74  Paulo Henrique  \N  5511940361071   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 21:18:29.852+00  2026-01-03 21:18:29.852+00  2026-01-03 21:18:29.852+00  \N  \N  \N  \N  novo    \N
251 74  Caio Martins    \N  553175778551    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 16:11:20.188+00  2026-01-05 16:11:20.188+00  2026-01-05 16:11:20.188+00  \N  \N  \N  \N  novo    \N
246 74  250448183357575 \N  250448183357575 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 14:59:04.024+00  2026-01-05 14:59:04.024+00  2026-01-05 14:59:04.024+00  \N  \N  \N  \N  novo    \N
100 74  TARCISIO/DEUS É FIEL    \N  147064075870296 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 22:09:30.695+00  2026-01-02 22:09:30.695+00  2026-01-02 22:09:30.695+00  \N  \N  \N  \N  novo    \N
283 74  Kathe   \N  5511959517827   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 23:31:59.129+00  2026-01-05 23:31:59.129+00  2026-01-05 23:31:59.129+00  \N  \N  \N  \N  novo    \N
319 74  122127562875022 \N  122127562875022 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 19:18:42.417+00  2026-01-06 19:18:42.417+00  2026-01-06 19:18:42.417+00  \N  \N  \N  \N  novo    \N
341 74  Daniela justen  \N  5512997997770   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.887+00  2026-01-06 23:14:10.887+00  2026-01-06 23:14:10.887+00  \N  \N  \N  \N  novo    \N
192 74  209521708392678 \N  209521708392678 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 19:30:44.268+00  2026-01-04 19:30:44.268+00  2026-01-04 19:30:44.268+00  \N  \N  \N  \N  novo    \N
116 74  244693128491259 \N  244693128491259 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 00:48:36.228+00  2026-01-03 00:48:36.228+00  2026-01-03 00:48:36.228+00  \N  \N  \N  \N  novo    \N
153 74  Luciana \N  5516992415263   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 21:19:41.888+00  2026-01-03 21:19:41.888+00  2026-01-03 21:19:41.888+00  \N  \N  \N  \N  novo    \N
209 74  Juliana Matayoshi   \N  5511958554134   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 22:35:05.598+00  2026-01-04 22:35:05.598+00  2026-01-04 22:35:05.598+00  \N  \N  \N  \N  novo    \N
197 74  21011214929993  \N  21011214929993  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 20:22:35.725+00  2026-01-04 20:22:35.725+00  2026-01-04 20:22:35.725+00  \N  \N  \N  \N  novo    \N
281 74  Maira ✨🌸    \N  4915905073783   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 23:08:44.973+00  2026-01-05 23:08:44.974+00  2026-01-05 23:08:44.974+00  \N  \N  \N  \N  novo    \N
174 74  Sergio  \N  5511991029448   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 02:07:27.404+00  2026-01-04 02:07:27.404+00  2026-01-04 02:07:27.404+00  \N  \N  \N  \N  novo    \N
101 74  Gabi ✨  \N  168319919374569 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 22:17:01.629+00  2026-01-02 22:17:01.629+00  2026-01-02 22:17:01.629+00  \N  \N  \N  \N  novo    \N
297 74  Mariana Martins \N  5511989791164   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 13:07:03.614+00  2026-01-06 13:07:03.614+00  2026-01-06 13:07:03.614+00  \N  \N  \N  \N  novo    \N
210 74  195202136412166 \N  195202136412166 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 22:40:24.05+00   2026-01-04 22:40:24.05+00   2026-01-04 22:40:24.05+00   \N  \N  \N  \N  novo    \N
117 74  258140520071286 \N  258140520071286 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 01:33:10.736+00  2026-01-03 01:33:10.736+00  2026-01-03 01:33:10.736+00  \N  \N  \N  \N  novo    \N
102 74  Karina Silvestre    \N  179964062261284 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 22:51:29.45+00   2026-01-02 22:51:29.45+00   2026-01-02 22:51:29.45+00   \N  \N  \N  \N  novo    \N
177 74  38783722496009  \N  38783722496009  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 03:29:18.342+00  2026-01-04 03:29:18.343+00  2026-01-04 03:29:18.343+00  \N  \N  \N  \N  novo    \N
193 74  Heder   \N  5511985450786   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 19:53:11.679+00  2026-01-04 19:53:11.679+00  2026-01-04 19:53:11.679+00  \N  \N  \N  \N  novo    \N
175 74  20585996402824  \N  20585996402824  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 02:20:05.579+00  2026-01-04 02:20:05.579+00  2026-01-04 02:20:05.579+00  \N  \N  \N  \N  novo    \N
248 74  179478194090104 \N  179478194090104 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 15:05:49.958+00  2026-01-05 15:05:49.958+00  2026-01-05 15:05:49.958+00  \N  \N  \N  \N  novo    \N
268 74  Marcelo \N  5511999037524   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 20:53:47.225+00  2026-01-05 20:53:47.225+00  2026-01-05 20:53:47.225+00  \N  \N  \N  \N  novo    \N
271 74  Stela Mara  \N  553388941001    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 21:51:18.088+00  2026-01-05 21:51:18.088+00  2026-01-05 21:51:18.088+00  \N  \N  \N  \N  novo    \N
282 74  Ana Cristina    \N  557199121775    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 23:27:16.42+00   2026-01-05 23:27:16.42+00   2026-01-05 23:27:16.42+00   \N  \N  \N  \N  novo    \N
310 74  Cauã    \N  5527997810933   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 16:22:44.214+00  2026-01-06 16:22:44.215+00  2026-01-06 16:22:44.215+00  \N  \N  \N  \N  novo    \N
321 74  Fernanda A. Barbosa \N  5511981475669   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 19:56:15.298+00  2026-01-06 19:56:15.298+00  2026-01-06 19:56:15.298+00  \N  \N  \N  \N  novo    \N
667 74  Fernando Berones    \N  5511948894525   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 20:34:40.215+00  2026-01-07 20:34:40.215+00  2026-01-07 20:34:40.215+00  \N  \N  \N  \N  novo    \N
118 74  269496329715891 \N  269496329715891 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 01:39:34.033+00  2026-01-03 01:39:34.033+00  2026-01-03 01:39:34.033+00  \N  \N  \N  \N  novo    \N
176 74  133260218765456 \N  133260218765456 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 02:30:51.149+00  2026-01-04 02:30:51.149+00  2026-01-04 02:30:51.149+00  \N  \N  \N  \N  novo    \N
155 74  Fábio   \N  5511966729529   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 21:27:35.104+00  2026-01-03 21:27:35.105+00  2026-01-03 21:27:35.105+00  \N  \N  \N  \N  novo    \N
103 74  Juliana Ferreira    \N  133483439603854 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 22:58:01.603+00  2026-01-02 22:58:01.603+00  2026-01-02 22:58:01.603+00  \N  \N  \N  \N  novo    \N
180 74  196297302774003 \N  196297302774003 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 11:40:52.429+00  2026-01-04 11:40:52.429+00  2026-01-04 11:40:52.429+00  \N  \N  \N  \N  novo    \N
653 74  246823298019341 \N  246823298019341 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 18:22:57.065+00  2026-01-07 18:22:57.065+00  2026-01-07 18:22:57.065+00  \N  \N  \N  \N  novo    \N
342 74  236966381658305 \N  236966381658305 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.886+00  2026-01-06 23:14:10.886+00  2026-01-06 23:14:10.886+00  \N  \N  \N  \N  novo    \N
230 74  206094039265410 \N  206094039265410 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 00:55:53.605+00  2026-01-05 00:55:53.605+00  2026-01-05 00:55:53.605+00  \N  \N  \N  \N  novo    \N
311 74  ~   \N  5511977017175   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 16:43:00.508+00  2026-01-06 16:43:00.509+00  2026-01-06 16:43:00.509+00  \N  \N  \N  \N  novo    \N
269 74  Gê da Esmalteria Belíssim   \N  558488050464    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 20:58:39.212+00  2026-01-05 20:58:39.212+00  2026-01-05 20:58:39.212+00  \N  \N  \N  \N  novo    \N
236 74  184979980054673 \N  184979980054673 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 03:30:59.327+00  2026-01-05 03:30:59.327+00  2026-01-05 03:30:59.327+00  \N  \N  \N  \N  novo    \N
194 74  Alejandra Maldonado \N  5541796600648   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 20:10:21.38+00   2026-01-04 20:10:21.38+00   2026-01-04 20:10:21.38+00   \N  \N  \N  \N  novo    \N
212 74  Alan    \N  5511989863501   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 22:41:23.105+00  2026-01-04 22:41:23.105+00  2026-01-04 22:41:23.105+00  \N  \N  \N  \N  novo    \N
249 74  69999964221517  \N  69999964221517  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 15:10:18.539+00  2026-01-05 15:10:18.539+00  2026-01-05 15:10:18.539+00  \N  \N  \N  \N  novo    \N
284 74  Raquel  \N  5511930119119   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 23:36:25.292+00  2026-01-05 23:36:25.292+00  2026-01-05 23:36:25.292+00  \N  \N  \N  \N  novo    \N
353 74  Elida Queiroz   \N  5511959996982   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 00:11:09.14+00   2026-01-07 00:11:09.14+00   2026-01-07 00:11:09.14+00   \N  \N  \N  \N  novo    \N
250 74  Caio Cesar Rodrigues Paes   \N  5511971171017   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 15:46:05.606+00  2026-01-05 15:46:05.606+00  2026-01-05 15:46:05.606+00  \N  \N  \N  \N  novo    \N
270 74  Ana Paula Moura \N  556196494392    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 21:04:54.597+00  2026-01-05 21:04:54.597+00  2026-01-05 21:04:54.597+00  \N  \N  \N  \N  novo    \N
104 74  Inês    \N  33719872159885  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 23:00:47.072+00  2026-01-02 23:00:47.072+00  2026-01-02 23:00:47.072+00  \N  \N  \N  \N  novo    \N
285 74  Leo Sarli   \N  5512024225221   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 23:55:32.566+00  2026-01-05 23:55:32.567+00  2026-01-05 23:55:32.567+00  \N  \N  \N  \N  novo    \N
195 74  Raquel  \N  5511999534200   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 20:13:14.657+00  2026-01-04 20:13:14.657+00  2026-01-04 20:13:14.657+00  \N  \N  \N  \N  novo    \N
213 74  EJR \N  5511984016395   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 22:48:52.558+00  2026-01-04 22:48:52.559+00  2026-01-04 22:48:52.559+00  \N  \N  \N  \N  novo    \N
233 74  Laercio Nascimento. \N  5511953069503   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 01:41:24.909+00  2026-01-05 01:41:24.909+00  2026-01-05 01:41:24.909+00  \N  \N  \N  \N  novo    \N
680 74  Débora Machado  \N  556296381879    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 23:47:59.602+00  2026-01-07 23:47:59.602+00  2026-01-07 23:47:59.602+00  \N  \N  \N  \N  novo    \N
337 74  Wellington Valquer  \N  5511932821588   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.868+00  2026-01-06 23:14:10.868+00  2026-01-06 23:14:10.868+00  \N  \N  \N  \N  novo    \N
355 74  235415864922358 \N  235415864922358 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 00:50:11.685+00  2026-01-07 00:50:11.686+00  2026-01-07 00:50:11.686+00  \N  \N  \N  \N  novo    \N
299 74  229316944212030 \N  229316944212030 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 13:47:13.791+00  2026-01-06 13:47:13.791+00  2026-01-06 13:47:13.791+00  \N  \N  \N  \N  novo    \N
329 74  Nataly Santos   \N  5513991484649   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.705+00  2026-01-06 23:14:10.705+00  2026-01-06 23:14:10.705+00  \N  \N  \N  \N  novo    \N
120 74  Leandra Treinamentos    \N  5511972625441   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 01:59:33.942+00  2026-01-03 01:59:33.942+00  2026-01-03 01:59:33.942+00  \N  \N  \N  \N  novo    \N
179 74  Teodora 🐯   \N  5511999315745   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 10:20:57.968+00  2026-01-04 10:20:57.968+00  2026-01-04 10:20:57.968+00  \N  \N  \N  \N  novo    \N
196 74  264982352683143 \N  264982352683143 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 20:19:19.953+00  2026-01-04 20:19:19.954+00  2026-01-04 20:19:19.954+00  \N  \N  \N  \N  novo    \N
214 74  27586692382928  \N  27586692382928  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 22:55:42.924+00  2026-01-04 22:55:42.924+00  2026-01-04 22:55:42.924+00  \N  \N  \N  \N  novo    \N
235 74  178795311034547 \N  178795311034547 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 03:04:08.83+00   2026-01-05 03:04:08.83+00   2026-01-05 03:04:08.83+00   \N  \N  \N  \N  novo    \N
252 74  180487427477564 \N  180487427477564 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 16:37:02.866+00  2026-01-05 16:37:02.866+00  2026-01-05 16:37:02.866+00  \N  \N  \N  \N  novo    \N
257 74  Lucas Borges    \N  554195535981    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 18:08:11.737+00  2026-01-05 18:08:11.737+00  2026-01-05 18:08:11.737+00  \N  \N  \N  \N  novo    \N
259 74  ROSE LEILA RODASLI CHUERE   \N  5511954665864   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 18:32:43.179+00  2026-01-05 18:32:43.179+00  2026-01-05 18:32:43.179+00  \N  \N  \N  \N  novo    \N
272 74  Beatriz Branco  \N  5511988818434   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 21:57:21.644+00  2026-01-05 21:57:21.644+00  2026-01-05 21:57:21.644+00  \N  \N  \N  \N  novo    \N
139 74  Fernanda Tirapelle  \N  5519993487123   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 16:40:05.115+00  2026-01-03 16:40:05.115+00  2026-01-03 16:40:05.115+00  \N  \N  \N  \N  novo    \N
105 74  Dani Carasco    \N  5511992476766   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 23:27:25.498+00  2026-01-02 23:27:25.499+00  2026-01-02 23:32:19.206+00  \N  \N  \N  \N  novo    \N
157 74  154331126980649 \N  154331126980649 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 21:54:38.497+00  2026-01-03 21:54:38.497+00  2026-01-03 21:54:38.497+00  \N  \N  \N  \N  novo    \N
286 74  🐈 Sonie Sarli 🐈 \N  5519997630160   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 00:00:28.55+00   2026-01-06 00:00:28.55+00   2026-01-06 00:00:28.55+00   \N  \N  \N  \N  novo    \N
300 74  175178965368955 \N  175178965368955 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 14:31:44.496+00  2026-01-06 14:31:44.496+00  2026-01-06 14:31:44.496+00  \N  \N  \N  \N  novo    \N
313 74  170660575895722 \N  170660575895722 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 18:01:09.566+00  2026-01-06 18:01:09.566+00  2026-01-06 18:01:09.566+00  \N  \N  \N  \N  novo    \N
314 74  Bruno Genestretti   \N  5511988223601   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 18:07:39.663+00  2026-01-06 18:07:39.663+00  2026-01-06 18:07:39.663+00  \N  \N  \N  \N  novo    \N
345 74  553171220121    \N  553171220121    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.919+00  2026-01-06 23:14:10.919+00  2026-01-06 23:14:10.919+00  \N  \N  \N  \N  novo    \N
346 74  5511946285544   \N  5511946285544   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.951+00  2026-01-06 23:14:10.951+00  2026-01-06 23:14:10.951+00  \N  \N  \N  \N  novo    \N
181 74  ㅤㅤ  \N  5519974119356   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 12:01:17.723+00  2026-01-04 12:01:17.723+00  2026-01-04 12:01:17.723+00  \N  \N  \N  \N  novo    \N
287 74  Giovanny    \N  556796350477    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 00:02:00.445+00  2026-01-06 00:02:00.445+00  2026-01-06 00:02:00.445+00  \N  \N  \N  \N  novo    \N
301 74  147961707290843 \N  147961707290843 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 14:34:30.198+00  2026-01-06 14:34:30.198+00  2026-01-06 14:34:30.198+00  \N  \N  \N  \N  novo    \N
215 74  Gilvan Filho    \N  5511976566673   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 23:03:27.52+00   2026-01-04 23:03:27.52+00   2026-01-04 23:03:27.52+00   \N  \N  \N  \N  novo    \N
216 74  Maria Alice \N  5511912137670   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 23:03:51.529+00  2026-01-04 23:03:51.529+00  2026-01-04 23:03:51.529+00  \N  \N  \N  \N  novo    \N
198 74  201326759788584 \N  201326759788584 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 20:54:10.979+00  2026-01-04 20:54:10.98+00   2026-01-04 20:54:10.98+00   \N  \N  \N  \N  novo    \N
253 74  245015519428726 \N  245015519428726 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 16:39:08.86+00   2026-01-05 16:39:08.86+00   2026-01-05 16:39:08.86+00   \N  \N  \N  \N  novo    \N
273 74  Fabrício David  \N  556291428669    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 22:05:05.795+00  2026-01-05 22:05:05.795+00  2026-01-05 22:05:05.795+00  \N  \N  \N  \N  novo    \N
158 74  250319317532695 \N  250319317532695 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 22:13:39.48+00   2026-01-03 22:13:39.48+00   2026-01-03 22:13:39.48+00   \N  \N  \N  \N  novo    \N
107 74  Clarice \N  8405318127690   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 23:34:31.529+00  2026-01-02 23:34:31.529+00  2026-01-02 23:34:31.529+00  \N  \N  \N  \N  novo    \N
122 74  67233434837110  \N  67233434837110  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 02:28:57.616+00  2026-01-03 02:28:57.616+00  2026-01-03 02:28:57.616+00  \N  \N  \N  \N  novo    \N
182 74  Aline   \N  554588204169    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 12:03:55.877+00  2026-01-04 12:03:55.878+00  2026-01-04 12:03:55.878+00  \N  \N  \N  \N  novo    \N
159 74  33651102376050  \N  33651102376050  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 22:20:43.937+00  2026-01-03 22:20:43.937+00  2026-01-03 22:20:43.937+00  \N  \N  \N  \N  novo    \N
199 74  Fernanda Falconi    \N  556599148563    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 21:07:29.978+00  2026-01-04 21:07:29.978+00  2026-01-04 21:07:29.978+00  \N  \N  \N  \N  novo    \N
217 74  234797288964297 \N  234797288964297 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 23:04:52.686+00  2026-01-04 23:04:52.686+00  2026-01-04 23:04:52.686+00  \N  \N  \N  \N  novo    \N
238 74  29077029318787  \N  29077029318787  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 08:20:20.812+00  2026-01-05 08:20:20.812+00  2026-01-05 08:20:20.812+00  \N  \N  \N  \N  novo    \N
254 74  Juliano \N  5511910657621   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 17:24:15.163+00  2026-01-05 17:24:15.163+00  2026-01-05 17:24:15.163+00  \N  \N  \N  \N  novo    \N
261 74  258359630545008 \N  258359630545008 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 19:01:57.757+00  2026-01-05 19:01:57.758+00  2026-01-05 19:01:57.758+00  \N  \N  \N  \N  novo    \N
303 74  273709826883725 \N  273709826883725 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 14:49:06.735+00  2026-01-06 14:49:06.735+00  2026-01-06 14:49:06.735+00  \N  \N  \N  \N  novo    \N
315 74  Ana Carla   \N  5511983551159   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 18:11:11.194+00  2026-01-06 18:11:11.194+00  2026-01-06 18:11:11.194+00  \N  \N  \N  \N  novo    \N
656 74  Talita Favero   \N  554198463373    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 18:47:29.484+00  2026-01-07 18:47:29.484+00  2026-01-07 18:47:29.484+00  \N  \N  \N  \N  novo    \N
340 74  Iris    \N  5511931439522   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:10.871+00  2026-01-06 23:14:10.871+00  2026-01-06 23:14:10.871+00  \N  \N  \N  \N  novo    \N
431 74  14366766329961  \N  14366766329961  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:51:36.037+00  2026-01-07 06:51:36.037+00  2026-01-07 06:51:36.037+00  \N  \N  \N  \N  novo    \N
123 74  Tatiana \N  5511996469090   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 05:21:11.305+00  2026-01-03 05:21:11.305+00  2026-01-03 05:21:11.305+00  \N  \N  \N  \N  novo    \N
142 74  Carol Ernesto   \N  5511976188358   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 18:22:04.244+00  2026-01-03 18:22:04.245+00  2026-01-03 18:22:04.245+00  \N  \N  \N  \N  novo    \N
160 74  Vitória Videira \N  5511910916539   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 22:27:59.582+00  2026-01-03 22:27:59.582+00  2026-01-03 22:27:59.582+00  \N  \N  \N  \N  novo    \N
183 74  Rafaela Barion  \N  5514997258040   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 13:00:01.746+00  2026-01-04 13:00:01.746+00  2026-01-04 13:00:01.746+00  \N  \N  \N  \N  novo    \N
218 74  Caroline    \N  5511940217724   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 23:11:16.856+00  2026-01-04 23:11:16.856+00  2026-01-04 23:11:16.856+00  \N  \N  \N  \N  novo    \N
255 74  Tais Helena Proença \N  5511981492695   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-05 17:32:03.058+00  2026-01-05 17:32:03.058+00  2026-01-05 17:32:03.058+00  \N  \N  \N  \N  novo    \N
682 74  Fabricio L Rocha    \N  554192820813    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-08 00:05:55.235+00  2026-01-08 00:05:55.236+00  2026-01-08 00:05:55.236+00  \N  \N  \N  \N  novo    \N
406 74  175196078129378 \N  175196078129378 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:14:06.92+00   2026-01-07 06:14:06.92+00   2026-01-07 06:14:06.92+00   \N  \N  \N  \N  novo    \N
411 74  91439954436333  \N  91439954436333  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:17:51.721+00  2026-01-07 06:17:51.721+00  2026-01-07 06:17:51.721+00  \N  \N  \N  \N  novo    \N
420 74  199372415463491 \N  199372415463491 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:29:39.152+00  2026-01-07 06:29:39.152+00  2026-01-07 06:29:39.152+00  \N  \N  \N  \N  novo    \N
424 74  192904295354383 \N  192904295354383 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:40:01.248+00  2026-01-07 06:40:01.249+00  2026-01-07 06:40:01.249+00  \N  \N  \N  \N  novo    \N
428 74  212399185461339 \N  212399185461339 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:46:29.367+00  2026-01-07 06:46:29.367+00  2026-01-07 06:46:29.367+00  \N  \N  \N  \N  novo    \N
430 74  170269800984820 \N  170269800984820 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:49:54.874+00  2026-01-07 06:49:54.874+00  2026-01-07 06:49:54.874+00  \N  \N  \N  \N  novo    \N
668 74  Pedro Matos \N  559281508489    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 20:51:01.701+00  2026-01-07 20:51:01.701+00  2026-01-07 20:51:01.701+00  \N  \N  \N  \N  novo    \N
147 74  81604546441413  \N  81604546441413  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-03 19:23:37.261+00  2026-01-03 19:23:37.261+00  2026-01-03 19:23:37.261+00  \N  \N  \N  \N  novo    \N
657 74  145887204528320 \N  145887204528320 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 18:52:55.057+00  2026-01-07 18:52:55.058+00  2026-01-07 18:52:55.058+00  \N  \N  \N  \N  novo    \N
684 74  Alessandra  \N  553192331865    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-08 00:51:50.677+00  2026-01-08 00:51:50.677+00  2026-01-08 00:51:50.677+00  \N  \N  \N  \N  novo    \N
444 74  278494453969086 \N  278494453969086 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:20:50.906+00  2026-01-07 07:20:50.906+00  2026-01-07 07:20:50.906+00  \N  \N  \N  \N  novo    \N
445 74  145530806132854 \N  145530806132854 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:26:47.726+00  2026-01-07 07:26:47.726+00  2026-01-07 07:26:47.726+00  \N  \N  \N  \N  novo    \N
441 74  210650982785094 \N  210650982785094 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:13:15.381+00  2026-01-07 07:13:15.381+00  2026-01-07 07:13:15.381+00  \N  \N  \N  \N  novo    \N
669 74  Paula Burci \N  5511993475252   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 21:24:12.06+00   2026-01-07 21:24:12.06+00   2026-01-07 21:24:12.06+00   \N  \N  \N  \N  novo    \N
683 74  78645850853405  \N  78645850853405  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-08 00:05:55.298+00  2026-01-08 00:05:55.298+00  2026-01-08 00:05:55.298+00  \N  \N  \N  \N  novo    \N
92  74  103126593970306 \N  103126593970306 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-02 21:24:17.942+00  2026-01-02 21:24:17.942+00  2026-01-02 21:24:17.942+00  \N  \N  \N  \N  novo    \N
455 74  41326242459673  \N  41326242459673  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:42:26.979+00  2026-01-07 07:42:26.979+00  2026-01-07 07:42:26.979+00  \N  \N  \N  \N  novo    \N
470 74  11295831122048  \N  11295831122048  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:10:23.983+00  2026-01-07 08:10:23.983+00  2026-01-07 08:10:23.983+00  \N  \N  \N  \N  novo    \N
685 74  leticia \N  5511989543367   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-08 01:41:52.096+00  2026-01-08 01:41:52.097+00  2026-01-08 01:41:52.097+00  \N  \N  \N  \N  novo    \N
471 74  18940906442807  \N  18940906442807  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:12:55.387+00  2026-01-07 08:12:55.387+00  2026-01-07 08:12:55.387+00  \N  \N  \N  \N  novo    \N
472 74  36846708998243  \N  36846708998243  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:14:29.097+00  2026-01-07 08:14:29.097+00  2026-01-07 08:14:29.097+00  \N  \N  \N  \N  novo    \N
478 74  213816440815813 \N  213816440815813 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:37:22.831+00  2026-01-07 08:37:22.831+00  2026-01-07 08:37:22.831+00  \N  \N  \N  \N  novo    \N
482 74  121105226453230 \N  121105226453230 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:38:42.007+00  2026-01-07 08:38:42.007+00  2026-01-07 08:38:42.007+00  \N  \N  \N  \N  novo    \N
535 74  216191624822989 \N  216191624822989 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:15:41.694+00  2026-01-07 10:15:41.694+00  2026-01-07 10:15:41.694+00  \N  \N  \N  \N  novo    \N
540 74  105561790124158 \N  105561790124158 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:22:29.541+00  2026-01-07 10:22:29.541+00  2026-01-07 10:22:29.541+00  \N  \N  \N  \N  novo    \N
670 74  160812551434359 \N  160812551434359 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 21:33:17.469+00  2026-01-07 21:33:17.469+00  2026-01-07 21:33:17.469+00  \N  \N  \N  \N  novo    \N
686 74  135020954050667 \N  135020954050667 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-08 01:50:12.385+00  2026-01-08 01:50:12.386+00  2026-01-08 01:50:12.386+00  \N  \N  \N  \N  novo    \N
671 74  Pedro Henrique Ferraz   \N  5511982629002   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 22:07:48.388+00  2026-01-07 22:07:48.389+00  2026-01-07 22:07:48.389+00  \N  \N  \N  \N  novo    \N
675 74  John Veasey \N  5511996665646   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 22:24:56.93+00   2026-01-07 22:24:56.93+00   2026-01-07 22:24:56.93+00   \N  \N  \N  \N  novo    \N
205 74  134033044434969 \N  134033044434969 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-04 21:52:23.106+00  2026-01-04 21:52:23.106+00  2026-01-04 21:52:23.106+00  \N  \N  \N  \N  novo    \N
505 74  160709136613386 \N  160709136613386 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:26:19.16+00   2026-01-07 09:26:19.16+00   2026-01-07 09:26:19.16+00   \N  \N  \N  \N  novo    \N
506 74  165386523779312 \N  165386523779312 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:26:48.039+00  2026-01-07 09:26:48.039+00  2026-01-07 09:26:48.039+00  \N  \N  \N  \N  novo    \N
512 74  45853070864516  \N  45853070864516  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:31:20.494+00  2026-01-07 09:31:20.495+00  2026-01-07 09:31:20.495+00  \N  \N  \N  \N  novo    \N
514 74  198912853995521 \N  198912853995521 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:31:51.036+00  2026-01-07 09:31:51.036+00  2026-01-07 09:31:51.036+00  \N  \N  \N  \N  novo    \N
519 74  225112271884525 \N  225112271884525 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:34:34.593+00  2026-01-07 09:34:34.593+00  2026-01-07 09:34:34.593+00  \N  \N  \N  \N  novo    \N
520 74  232095838429398 \N  232095838429398 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:35:37.337+00  2026-01-07 09:35:37.337+00  2026-01-07 09:35:37.337+00  \N  \N  \N  \N  novo    \N
672 74  13070105579644  \N  13070105579644  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 22:12:33.299+00  2026-01-07 22:12:33.299+00  2026-01-07 22:12:33.299+00  \N  \N  \N  \N  novo    \N
676 74  5511991170827   \N  5511991170827   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 22:45:08.475+00  2026-01-07 22:45:08.476+00  2026-01-07 22:45:08.476+00  \N  \N  \N  \N  novo    \N
521 74  221319731892438 \N  221319731892438 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:37:56.303+00  2026-01-07 09:37:56.303+00  2026-01-07 09:37:56.303+00  \N  \N  \N  \N  novo    \N
522 74  244897034315    \N  244897034315    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:39:35.217+00  2026-01-07 09:39:35.217+00  2026-01-07 09:39:35.217+00  \N  \N  \N  \N  novo    \N
526 74  89855161835549  \N  89855161835549  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:52:10.665+00  2026-01-07 09:52:10.665+00  2026-01-07 09:52:10.665+00  \N  \N  \N  \N  novo    \N
529 74  54971336798462  \N  54971336798462  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:06:30.636+00  2026-01-07 10:06:30.637+00  2026-01-07 10:06:30.637+00  \N  \N  \N  \N  novo    \N
531 74  188373406867601 \N  188373406867601 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:07:24.243+00  2026-01-07 10:07:24.243+00  2026-01-07 10:07:24.243+00  \N  \N  \N  \N  novo    \N
673 74  Dr Ricardo  \N  557799280480    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 22:15:26.177+00  2026-01-07 22:15:26.177+00  2026-01-07 22:15:26.177+00  \N  \N  \N  \N  novo    \N
542 74  239092273029256 \N  239092273029256 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:27:51.482+00  2026-01-07 10:27:51.482+00  2026-01-07 10:27:51.482+00  \N  \N  \N  \N  novo    \N
544 74  98715528364076  \N  98715528364076  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:28:13.683+00  2026-01-07 10:28:13.683+00  2026-01-07 10:28:13.683+00  \N  \N  \N  \N  novo    \N
546 74  46961189204080  \N  46961189204080  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:40:06.048+00  2026-01-07 10:40:06.049+00  2026-01-07 10:40:06.049+00  \N  \N  \N  \N  novo    \N
547 74  8723212836921   \N  8723212836921   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:42:16.597+00  2026-01-07 10:42:16.598+00  2026-01-07 10:42:16.598+00  \N  \N  \N  \N  novo    \N
548 74  259978799636667 \N  259978799636667 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:48:54.05+00   2026-01-07 10:48:54.051+00  2026-01-07 10:48:54.051+00  \N  \N  \N  \N  novo    \N
550 74  178365898199127 \N  178365898199127 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:52:32.253+00  2026-01-07 10:52:32.253+00  2026-01-07 10:52:32.253+00  \N  \N  \N  \N  novo    \N
551 74  3264242253903   \N  3264242253903   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:53:59.581+00  2026-01-07 10:53:59.581+00  2026-01-07 10:53:59.581+00  \N  \N  \N  \N  novo    \N
555 74  69677288018162  \N  69677288018162  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:00:01.839+00  2026-01-07 11:00:01.839+00  2026-01-07 11:00:01.839+00  \N  \N  \N  \N  novo    \N
561 74  241007878791234 \N  241007878791234 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:06:35.546+00  2026-01-07 11:06:35.546+00  2026-01-07 11:06:35.546+00  \N  \N  \N  \N  novo    \N
564 74  164252484673712 \N  164252484673712 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:09:56.368+00  2026-01-07 11:09:56.368+00  2026-01-07 11:09:56.368+00  \N  \N  \N  \N  novo    \N
677 74  84301702025326  \N  84301702025326  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 23:04:03.154+00  2026-01-07 23:04:03.154+00  2026-01-07 23:04:03.154+00  \N  \N  \N  \N  novo    \N
594 74  252763372019786 \N  252763372019786 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:19:37.794+00  2026-01-07 12:19:37.794+00  2026-01-07 12:19:37.794+00  \N  \N  \N  \N  novo    \N
597 74  205205115256967 \N  205205115256967 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:33:55.923+00  2026-01-07 12:33:55.923+00  2026-01-07 12:33:55.923+00  \N  \N  \N  \N  novo    \N
599 74  249541995528367 \N  249541995528367 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:37:31.88+00   2026-01-07 12:37:31.881+00  2026-01-07 12:37:31.881+00  \N  \N  \N  \N  novo    \N
601 74  280452925505607 \N  280452925505607 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:39:28.134+00  2026-01-07 12:39:28.134+00  2026-01-07 12:39:28.134+00  \N  \N  \N  \N  novo    \N
602 74  99651931865262  \N  99651931865262  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:40:50.967+00  2026-01-07 12:40:50.967+00  2026-01-07 12:40:50.967+00  \N  \N  \N  \N  novo    \N
604 74  193475425341678 \N  193475425341678 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:47:03+00  2026-01-07 12:47:03+00  2026-01-07 12:47:03+00  \N  \N  \N  \N  novo    \N
605 74  165635497664592 \N  165635497664592 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:47:07.73+00   2026-01-07 12:47:07.73+00   2026-01-07 12:47:07.73+00   \N  \N  \N  \N  novo    \N
606 74  156457370681348 \N  156457370681348 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:48:50.152+00  2026-01-07 12:48:50.152+00  2026-01-07 12:48:50.152+00  \N  \N  \N  \N  novo    \N
607 74  22458535022838  \N  22458535022838  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:54:45.445+00  2026-01-07 12:54:45.445+00  2026-01-07 12:54:45.445+00  \N  \N  \N  \N  novo    \N
608 74  104466606985447 \N  104466606985447 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:58:43.221+00  2026-01-07 12:58:43.221+00  2026-01-07 12:58:43.221+00  \N  \N  \N  \N  novo    \N
609 74  170304143884344 \N  170304143884344 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 13:01:31.151+00  2026-01-07 13:01:31.151+00  2026-01-07 13:01:31.151+00  \N  \N  \N  \N  novo    \N
611 74  113933117571216 \N  113933117571216 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 13:04:40.109+00  2026-01-07 13:04:40.109+00  2026-01-07 13:04:40.109+00  \N  \N  \N  \N  novo    \N
618 74  Maris   \N  5511993827644   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 13:44:25.646+00  2026-01-07 13:44:25.646+00  2026-01-07 13:44:25.646+00  \N  \N  \N  \N  novo    \N
624 74  232035641770089 \N  232035641770089 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 14:34:11.922+00  2026-01-07 14:34:11.922+00  2026-01-07 14:34:11.922+00  \N  \N  \N  \N  novo    \N
615 74  198346052509941 \N  198346052509941 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 13:20:07.96+00   2026-01-07 13:20:07.961+00  2026-01-07 13:20:07.961+00  \N  \N  \N  \N  novo    \N
622 74  241007828451509 \N  241007828451509 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 14:05:59.874+00  2026-01-07 14:05:59.874+00  2026-01-07 14:05:59.874+00  \N  \N  \N  \N  novo    \N
616 74  Carla Lamberti  \N  5511984921712   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 13:31:02.569+00  2026-01-07 13:31:02.569+00  2026-01-07 13:31:02.569+00  \N  \N  \N  \N  novo    \N
625 74  Paulo   \N  5511993564442   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 14:45:14.155+00  2026-01-07 14:45:14.155+00  2026-01-07 14:45:14.155+00  \N  \N  \N  \N  novo    \N
630 74  238031399342138 \N  238031399342138 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 15:26:52.37+00   2026-01-07 15:26:52.37+00   2026-01-07 15:26:52.37+00   \N  \N  \N  \N  novo    \N
621 74  199918060830956 \N  199918060830956 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 14:05:52.118+00  2026-01-07 14:05:52.118+00  2026-01-07 14:05:52.118+00  \N  \N  \N  \N  novo    \N
627 74  ni  \N  5511972674443   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 15:11:49.141+00  2026-01-07 15:11:49.141+00  2026-01-07 15:11:49.141+00  \N  \N  \N  \N  novo    \N
629 74  105656296190034 \N  105656296190034 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 15:26:48.114+00  2026-01-07 15:26:48.114+00  2026-01-07 15:26:48.114+00  \N  \N  \N  \N  novo    \N
664 74  Gabriel \N  5511967321811   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 19:57:29.682+00  2026-01-07 19:57:29.682+00  2026-01-07 19:57:29.682+00  \N  \N  \N  \N  novo    \N
665 74  Greiciele Mendes    \N  5515997635639   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 20:21:46.557+00  2026-01-07 20:21:46.557+00  2026-01-07 20:21:46.557+00  \N  \N  \N  \N  novo    \N
678 74  Teknologia em licenças e Parklets   \N  5511930860166   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 23:17:21.758+00  2026-01-07 23:17:21.759+00  2026-01-07 23:17:21.759+00  \N  \N  \N  \N  novo    \N
681 74  Cristiane   \N  5511983159242   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 23:48:11.349+00  2026-01-07 23:48:11.349+00  2026-01-07 23:48:11.349+00  \N  \N  \N  \N  novo    \N
639 74  160292575154286 \N  160292575154286 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 16:57:18.663+00  2026-01-07 16:57:18.663+00  2026-01-07 16:57:18.663+00  \N  \N  \N  \N  novo    \N
641 74  281178624008439 \N  281178624008439 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 17:13:08.82+00   2026-01-07 17:13:08.82+00   2026-01-07 17:13:08.82+00   \N  \N  \N  \N  novo    \N
645 74  196335907143911 \N  196335907143911 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 17:25:17.677+00  2026-01-07 17:25:17.677+00  2026-01-07 17:25:17.677+00  \N  \N  \N  \N  novo    \N
648 74  266353118290041 \N  266353118290041 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 17:34:03.979+00  2026-01-07 17:34:03.979+00  2026-01-07 17:34:03.979+00  \N  \N  \N  \N  novo    \N
679 74  João Paulo  \N  556699731336    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 23:46:58.424+00  2026-01-07 23:46:58.424+00  2026-01-07 23:46:58.424+00  \N  \N  \N  \N  novo    \N
394 86  177468434591946 \N  177468434591946 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:58:39.403+00  2026-01-07 05:58:39.403+00  2026-01-07 05:58:39.403+00  \N  \N  \N  \N  novo    \N
364 86  50247296435 \N  5550247296435   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 04:59:41.263+00  2026-01-07 04:59:41.263+00  2026-01-07 04:59:41.263+00  \N  \N  \N  \N  novo    \N
365 86  50247296435 \N  5550247296435   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 04:59:41.265+00  2026-01-07 04:59:41.265+00  2026-01-07 04:59:41.265+00  \N  \N  \N  \N  novo    \N
395 86  231301453983949 \N  231301453983949 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:59:21.163+00  2026-01-07 05:59:21.163+00  2026-01-07 05:59:21.163+00  \N  \N  \N  \N  novo    \N
401 86  183167570997255 \N  183167570997255 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:06:08.219+00  2026-01-07 06:06:08.219+00  2026-01-07 06:06:08.219+00  \N  \N  \N  \N  novo    \N
404 86  32998384775306  \N  32998384775306  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:09:48.103+00  2026-01-07 06:09:48.103+00  2026-01-07 06:09:48.103+00  \N  \N  \N  \N  novo    \N
405 86  268384050671664 \N  268384050671664 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:10:19.849+00  2026-01-07 06:10:19.849+00  2026-01-07 06:10:19.849+00  \N  \N  \N  \N  novo    \N
408 86  53485278081038  \N  53485278081038  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:15:53.299+00  2026-01-07 06:15:53.299+00  2026-01-07 06:15:53.299+00  \N  \N  \N  \N  novo    \N
409 86  244559766388935 \N  244559766388935 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:16:04.363+00  2026-01-07 06:16:04.363+00  2026-01-07 06:16:04.363+00  \N  \N  \N  \N  novo    \N
412 86  153274984435884 \N  153274984435884 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:17:56.606+00  2026-01-07 06:17:56.606+00  2026-01-07 06:17:56.606+00  \N  \N  \N  \N  novo    \N
413 86  101125005021198 \N  101125005021198 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:18:02.51+00   2026-01-07 06:18:02.51+00   2026-01-07 06:18:02.51+00   \N  \N  \N  \N  novo    \N
386 86  Multiservicios Digi \N  5550254173745   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:47:25.92+00   2026-01-07 05:47:25.92+00   2026-01-07 05:47:25.92+00   \N  \N  \N  \N  novo    \N
425 86  214065498615994 \N  214065498615994 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:43:23.397+00  2026-01-07 06:43:23.398+00  2026-01-07 06:43:23.398+00  \N  \N  \N  \N  novo    \N
461 86  130863408935167 \N  130863408935167 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:50:59.873+00  2026-01-07 07:50:59.873+00  2026-01-07 07:50:59.873+00  \N  \N  \N  \N  novo    \N
464 86  219855080931493 \N  219855080931493 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:55:24.98+00   2026-01-07 07:55:24.981+00  2026-01-07 07:55:24.981+00  \N  \N  \N  \N  novo    \N
466 86  37985126998065  \N  37985126998065  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:06:05.65+00   2026-01-07 08:06:05.65+00   2026-01-07 08:06:05.65+00   \N  \N  \N  \N  novo    \N
467 86  183244981055570 \N  183244981055570 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:07:38.699+00  2026-01-07 08:07:38.699+00  2026-01-07 08:07:38.699+00  \N  \N  \N  \N  novo    \N
468 86  110694343135427 \N  110694343135427 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:09:29.367+00  2026-01-07 08:09:29.368+00  2026-01-07 08:09:29.368+00  \N  \N  \N  \N  novo    \N
481 86  176987062685927 \N  176987062685927 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:37:36.617+00  2026-01-07 08:37:36.617+00  2026-01-07 08:37:36.617+00  \N  \N  \N  \N  novo    \N
899 103 Alejandra Maldonado \N  5541796600648   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 00:30:01.021+00  2026-01-16 00:30:01.021+00  2026-01-16 00:30:01.021+00  \N  \N  \N  \N  novo    \N
861 103 Simone  \N  5511948337852   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 00:43:55.776+00  2026-01-15 00:43:55.776+00  2026-01-15 00:43:55.776+00  \N  \N  \N  \N  novo    \N
949 103 Lucas   \N  5511981287330   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 23:30:42.998+00  2026-01-16 23:30:42.998+00  2026-01-16 23:30:42.998+00  \N  \N  \N  \N  novo    \N
1005    103 Adelaide Fornari    \N  5519997062571   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-18 16:28:38.548+00  2026-01-18 16:28:38.548+00  2026-01-18 16:28:38.548+00  \N  \N  \N  \N  novo    \N
1185    112 Systemix Atendimento    \N  5511974922968   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-28 17:26:09.456+00  2026-01-28 17:26:09.456+00  2026-01-28 17:26:09.456+00  \N  \N  \N  \N  novo    \N
1188    112 Cristiano Rossetti  \N  554788710041    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-28 20:18:00.091+00  2026-01-28 20:18:00.091+00  2026-01-28 20:18:00.091+00  \N  \N  \N  \N  novo    \N
1155    112 Juliana De Rossi    \N  555183023535    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-26 22:57:31.123+00  2026-01-26 22:57:31.123+00  2026-01-26 22:57:35.139+00  \N  \N  \N  \N  novo    \N
1157    112 Atendimento 123 \N  555138401235    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 00:06:14.321+00  2026-01-27 00:06:14.322+00  2026-01-27 00:06:14.322+00  \N  \N  \N  \N  novo    \N
1288    112 Leonardo Rosa   \N  554788064515    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-05 18:27:23.042+00  2026-02-05 18:26:53.987+00  2026-02-05 18:27:23.042+00  \N  \N  \N  \N  novo    \N
1256    112 Pedro Henrique  \N  556294593677    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 14:21:23.77+00   2026-02-03 17:01:44.595+00  2026-02-04 14:21:23.77+00   \N  \N  \N  \N  novo    \N
1195    112 Cleber  \N  555198885709    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-29 12:12:47.882+00  2026-01-29 12:12:47.882+00  2026-01-29 12:12:47.882+00  \N  \N  \N  \N  novo    \N
1131    112 Fae Developer   \N  552433540335    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-04 22:16:24.559+00  2026-01-25 17:36:45.16+00   2026-02-04 22:16:24.56+00   \N  \N  \N  \N  novo    \N
1196    112 Victor Souza    \N  553173112043    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-30 19:14:05.322+00  2026-01-29 12:23:25.782+00  2026-01-30 19:14:05.322+00  \N  \N  \N  \N  novo    \N
1167    112 Jc Carretas Porto Alegre    \N  555171000329    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 16:42:46.443+00  2026-01-27 16:42:46.443+00  2026-01-27 16:42:46.443+00  \N  \N  \N  \N  novo    \N
1257    112 MIKAEL SUPORTE - VIRALIZE   \N  5511966527045   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.911+00  2026-02-03 17:01:44.678+00  2026-02-03 17:01:44.911+00  \N  \N  \N  \N  novo    \N
1243    112 Matheus Palmarante  \N  555194593333    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 23:34:05.12+00   2026-02-03 17:01:44.358+00  2026-02-03 23:34:05.12+00   \N  \N  \N  \N  novo    \N
1244    112 Matheus Palmarante  \N  555194593333    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.358+00  2026-02-03 17:01:44.358+00  2026-02-03 17:01:44.358+00  \N  \N  \N  \N  novo    \N
1245    112 Matheus Palmarante  \N  555194593333    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.372+00  2026-02-03 17:01:44.372+00  2026-02-03 17:01:44.372+00  \N  \N  \N  \N  novo    \N
1246    112 Matheus Palmarante  \N  555194593333    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.373+00  2026-02-03 17:01:44.373+00  2026-02-03 17:01:44.373+00  \N  \N  \N  \N  novo    \N
1248    112 Matheus Palmarante  \N  555194593333    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.389+00  2026-02-03 17:01:44.389+00  2026-02-03 17:01:44.389+00  \N  \N  \N  \N  novo    \N
1249    112 Matheus Palmarante  \N  555194593333    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 17:01:44.389+00  2026-02-03 17:01:44.389+00  2026-02-03 17:01:44.389+00  \N  \N  \N  \N  novo    \N
691 5   Victória Lima   \N  5524999589981   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-08 14:06:18.543+00  2026-01-08 14:06:18.543+00  2026-01-08 14:06:18.543+00  \N  \N  \N  \N  novo    \N
692 5   172515968163969 \N  172515968163969 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-08 14:59:35.853+00  2026-01-08 14:59:35.853+00  2026-01-08 14:59:35.853+00  \N  \N  \N  \N  novo    \N
410 5   Janaina Tsuda   \N  61065912160499  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:17:14.145+00  2026-01-07 06:17:14.145+00  2026-01-07 06:17:14.145+00  \N  \N  \N  \N  novo    \N
379 5   13799830585451  \N  13799830585451  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 05:29:31.132+00  2026-01-07 05:29:31.132+00  2026-01-07 05:29:31.132+00  \N  \N  \N  \N  novo    \N
348 5   46995599278120  \N  46995599278120  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 23:14:26.972+00  2026-01-06 23:14:26.972+00  2026-01-06 23:14:26.972+00  \N  \N  \N  \N  novo    \N
302 5   38805465759887  \N  38805465759887  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 14:44:12.149+00  2026-01-06 14:44:12.149+00  2026-01-06 14:44:12.149+00  \N  \N  \N  \N  novo    \N
1189    5   Thaissa Rodrigues🫶🏼🫶🏼   \N  5524999786533   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-28 20:32:14.133+00  2026-01-28 20:32:14.133+00  2026-01-28 20:32:14.133+00  \N  \N  \N  \N  novo    \N
402 5   135776851472605 \N  135776851472605 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:08:05.463+00  2026-01-07 06:08:05.463+00  2026-01-07 06:08:05.463+00  \N  \N  \N  \N  novo    \N
403 5   130047482585247 \N  130047482585247 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:08:40.797+00  2026-01-07 06:08:40.797+00  2026-01-07 06:08:40.797+00  \N  \N  \N  \N  novo    \N
407 5   107387302215841 \N  107387302215841 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 06:15:29.024+00  2026-01-07 06:15:29.024+00  2026-01-07 06:15:29.024+00  \N  \N  \N  \N  novo    \N
913 5   🥰   \N  553298360676    \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 11:46:55.139+00  2026-01-16 11:46:55.139+00  2026-01-16 11:46:55.139+00  \N  \N  \N  \N  novo    \N
449 5   55383771107393  \N  55383771107393  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:31:42.405+00  2026-01-07 07:31:42.405+00  2026-01-07 07:31:42.405+00  \N  \N  \N  \N  novo    \N
451 5   121809668174045 \N  121809668174045 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 07:33:55.392+00  2026-01-07 07:33:55.392+00  2026-01-07 07:33:55.392+00  \N  \N  \N  \N  novo    \N
465 5   279138581672188 \N  279138581672188 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:01:23.52+00   2026-01-07 08:01:23.52+00   2026-01-07 08:01:23.52+00   \N  \N  \N  \N  novo    \N
469 5   281174396125396 \N  281174396125396 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:10:22.251+00  2026-01-07 08:10:22.251+00  2026-01-07 08:10:22.251+00  \N  \N  \N  \N  novo    \N
474 5   80049768272024  \N  80049768272024  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:20:32.88+00   2026-01-07 08:20:32.88+00   2026-01-07 08:20:32.88+00   \N  \N  \N  \N  novo    \N
475 5   155293300301889 \N  155293300301889 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:27:57.598+00  2026-01-07 08:27:57.598+00  2026-01-07 08:27:57.598+00  \N  \N  \N  \N  novo    \N
477 5   13155669410008  \N  13155669410008  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:37:09.327+00  2026-01-07 08:37:09.327+00  2026-01-07 08:37:09.327+00  \N  \N  \N  \N  novo    \N
479 5   218729916964869 \N  218729916964869 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:37:29.694+00  2026-01-07 08:37:29.695+00  2026-01-07 08:37:29.695+00  \N  \N  \N  \N  novo    \N
480 5   59914928001222  \N  59914928001222  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 08:37:30.073+00  2026-01-07 08:37:30.073+00  2026-01-07 08:37:30.073+00  \N  \N  \N  \N  novo    \N
507 5   270046219792427 \N  270046219792427 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:27:13.642+00  2026-01-07 09:27:13.642+00  2026-01-07 09:27:13.642+00  \N  \N  \N  \N  novo    \N
1198    5   Inês crispin    \N  5512991504918   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-03 19:38:38.258+00  2026-01-29 17:13:25.248+00  2026-02-03 19:38:38.258+00  \N  \N  \N  \N  novo    \N
869 5   fabiolanotoroberto  \N  5512992157672   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 13:27:38+00  2026-01-15 13:27:38+00  2026-01-15 13:27:38+00  \N  \N  \N  \N  novo    \N
1163    5   Eliana  \N  5524998916102   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 13:28:09.06+00   2026-01-27 13:28:09.06+00   2026-01-27 13:28:09.06+00   \N  \N  \N  \N  novo    \N
494 5   54597641068619  \N  54597641068619  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:14:44.166+00  2026-01-07 09:14:44.166+00  2026-01-07 09:14:44.166+00  \N  \N  \N  \N  novo    \N
516 5   274667520704698 \N  274667520704698 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:32:55.121+00  2026-01-07 09:32:55.121+00  2026-01-07 09:32:55.121+00  \N  \N  \N  \N  novo    \N
1164    5   Isabela \N  5524992914485   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-27 15:33:36.968+00  2026-01-27 15:33:36.968+00  2026-01-27 15:33:36.968+00  \N  \N  \N  \N  novo    \N
528 5   140552955805732 \N  140552955805732 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 09:58:54.362+00  2026-01-07 09:58:54.362+00  2026-01-07 09:58:54.362+00  \N  \N  \N  \N  novo    \N
532 5   100553858253009 \N  100553858253009 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:08:12.401+00  2026-01-07 10:08:12.401+00  2026-01-07 10:08:12.401+00  \N  \N  \N  \N  novo    \N
533 5   32912334426215  \N  32912334426215  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:09:12.676+00  2026-01-07 10:09:12.676+00  2026-01-07 10:09:12.676+00  \N  \N  \N  \N  novo    \N
919 5   Kelly Almeida 🩵💙    \N  5524999370623   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 16:14:56.811+00  2026-01-16 16:14:56.811+00  2026-01-16 16:14:56.811+00  \N  \N  \N  \N  novo    \N
839 5   Anderson Rodrigues  \N  5524981307272   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-14 15:13:09.069+00  2026-01-14 15:13:09.069+00  2026-01-14 15:23:58.268+00  \N  \N  \N  \N  novo    \N
541 5   150040404344960 \N  150040404344960 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:23:43.619+00  2026-01-07 10:23:43.62+00   2026-01-07 10:23:43.62+00   \N  \N  \N  \N  novo    \N
537 5   12035035242643  \N  12035035242643  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:19:26.732+00  2026-01-07 10:19:26.732+00  2026-01-07 10:19:26.732+00  \N  \N  \N  \N  novo    \N
545 5   247969953636354 \N  247969953636354 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:36:13.258+00  2026-01-07 10:36:13.258+00  2026-01-07 10:36:13.258+00  \N  \N  \N  \N  novo    \N
549 5   12438258884820  \N  12438258884820  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:49:58.263+00  2026-01-07 10:49:58.263+00  2026-01-07 10:49:58.263+00  \N  \N  \N  \N  novo    \N
553 5   224150249558226 \N  224150249558226 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 10:56:25.206+00  2026-01-07 10:56:25.206+00  2026-01-07 10:56:25.206+00  \N  \N  \N  \N  novo    \N
557 5   1688022827013   \N  1688022827013   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:02:04.279+00  2026-01-07 11:02:04.279+00  2026-01-07 11:02:04.279+00  \N  \N  \N  \N  novo    \N
565 5   234943468843146 \N  234943468843146 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:11:41.343+00  2026-01-07 11:11:41.344+00  2026-01-07 11:11:41.344+00  \N  \N  \N  \N  novo    \N
566 5   217548800917670 \N  217548800917670 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 11:14:58.18+00   2026-01-07 11:14:58.18+00   2026-01-07 11:14:58.18+00   \N  \N  \N  \N  novo    \N
922 5   Teresinha   \N  5524999957193   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-16 18:01:29.055+00  2026-01-16 18:01:29.056+00  2026-01-16 18:39:02.982+00  \N  \N  \N  \N  novo    \N
600 5   54692214272003  \N  54692214272003  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 12:38:39.273+00  2026-01-07 12:38:39.273+00  2026-01-07 12:38:39.273+00  \N  \N  \N  \N  novo    \N
612 5   144083335045218 \N  144083335045218 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 13:05:34.803+00  2026-01-07 13:05:34.803+00  2026-01-07 13:05:34.803+00  \N  \N  \N  \N  novo    \N
876 5   Paulinha🥰   \N  5524999021951   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-15 16:21:38.197+00  2026-01-15 16:21:38.197+00  2026-01-15 16:21:38.197+00  \N  \N  \N  \N  novo    \N
632 5   143920176578606 \N  143920176578606 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 15:37:38.377+00  2026-01-07 15:37:38.377+00  2026-01-07 15:37:38.377+00  \N  \N  \N  \N  novo    \N
633 5   38530269052985  \N  38530269052985  \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 15:57:14.979+00  2026-01-07 15:57:14.979+00  2026-01-07 15:57:14.979+00  \N  \N  \N  \N  novo    \N
298 5   Ze Escobar  \N  5524988088788   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-05 20:05:18.108+00  2026-01-06 13:20:07.904+00  2026-02-05 20:05:18.108+00  \N  \N  \N  \N  novo    \N
614 5   Magda   \N  5524999986078   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 13:18:43.201+00  2026-01-07 13:18:43.201+00  2026-01-07 13:18:43.201+00  \N  \N  \N  \N  novo    \N
318 5   5524998128480   \N  5524998128480   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-06 19:07:50.614+00  2026-01-06 19:07:50.614+00  2026-01-06 19:07:50.614+00  \N  \N  \N  \N  novo    \N
688 5   5521979599912   \N  5521979599912   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-08 13:05:01.495+00  2026-01-08 13:05:01.496+00  2026-01-08 13:05:01.496+00  \N  \N  \N  \N  novo    \N
649 5   117763859284222 \N  117763859284222 \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-07 17:35:35.693+00  2026-01-07 17:35:35.693+00  2026-01-07 17:35:35.693+00  \N  \N  \N  \N  novo    \N
689 5   Bruna Silva \N  5524999856904   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-01-08 13:22:15.553+00  2026-01-08 13:22:15.553+00  2026-01-08 13:22:15.553+00  \N  \N  \N  \N  novo    \N
643 5   Mayra Aves🤪 \N  5524988358789   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-05 15:00:05.226+00  2026-01-07 17:19:23.646+00  2026-02-05 15:00:05.226+00  \N  \N  \N  \N  novo    \N
1060    5   Lene    \N  5521980512700   \N  \N  \N  \N  \N  \N  \N  new 0   \N  \N  \N  2026-02-05 19:08:38.183+00  2026-01-22 17:19:29.192+00  2026-02-05 19:08:38.183+00  \N  \N  \N  \N  novo    \N
\.


--
-- Data for Name: financeiro_faturas; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.financeiro_faturas (id, company_id, client_id, descricao, valor, status, data_vencimento, data_pagamento, tipo_referencia, referencia_id, tipo_recorrencia, quantidade_ciclos, ciclo_atual, data_inicio, data_fim, ativa, observacoes, created_at, updated_at, valor_pago, payment_provider, payment_link, payment_external_id, checkout_token, project_id) FROM stdin;
11  104 12  Pagamento mes   889.00  aberta  2026-01-14  2026-01-15 03:00:00+00  \N  \N  unica   \N  1   2026-01-14  \N  t   \N  2026-01-14 16:04:21.401+00  2026-01-14 16:04:21.401+00  0.00    \N  \N  \N  \N  \N
12  104 13  Plano   889.90  aberta  2026-01-14  2026-01-16 03:00:00+00  \N  \N  unica   \N  1   2026-01-14  \N  t   \N  2026-01-14 22:05:35.278+00  2026-01-14 22:05:35.278+00  0.00    \N  \N  \N  \N  \N
14  112 22  Trafego pago    5.00    aberta  2026-01-26  \N  servico 5   unica   \N  1   2026-01-25  \N  t   \N  2026-01-25 23:37:48.088+00  2026-01-25 23:37:48.495+00  0.00    mercadopago https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=56775135-b7f847c9-ff8e-467f-91ee-f491c1d447b3   56775135-b7f847c9-ff8e-467f-91ee-f491c1d447b3   1426a7b52eb30ff97dcb1cd0d884d027    \N
15  133 23  Projeto: dsfsdvsd - vsdvsdvsdv  500.00  aberta  2026-02-18  \N  servico 7   unica   \N  1   2026-02-04  \N  t   1231231231321321564156  2026-02-04 03:25:08.303+00  2026-02-04 03:29:33.973+00  20.00   mercadopago \N  \N  \N  \N
\.


--
-- Data for Name: financeiro_pagamentos; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.financeiro_pagamentos (id, company_id, fatura_id, metodo_pagamento, valor, data_pagamento, observacoes, created_at) FROM stdin;
\.


--
-- Data for Name: media_files; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.media_files (id, folder_id, company_id, original_name, custom_name, mime_type, size, storage_path, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: media_folders; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.media_folders (id, name, description, company_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: profissionais; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.profissionais (id, "companyId", nome, servicos, agenda, ativo, comissao, "valorEmAberto", "valoresRecebidos", "valoresAReceber", "createdAt", "updatedAt") FROM stdin;
1   1   Rafael  [{"id": 1, "nome": "Corte de cabelo", "valorOriginal": "25.00", "possuiDesconto": false, "valorComDesconto": null}, {"id": 2, "nome": "Corte e Barba", "valorOriginal": "50.00", "possuiDesconto": true, "valorComDesconto": "40.00"}]  [{"dia": "segunda-feira", "fim": "17:00", "inicio": "10:00", "almocoFim": "13:30", "almocoInicio": "12:00", "duracaoAtendimento": 30}, {"dia": "quarta-feira", "fim": "17:00", "inicio": "10:00", "almocoFim": "13:30", "almocoInicio": "12:00", "duracaoAtendimento": 30}] t   20.00   0.00    0.00    0.00    2025-12-05 19:47:13.774 2025-12-05 19:47:26.848
2   1   Katellin    [{"id": 3, "nome": "Luzes", "valorOriginal": "70.00", "possuiDesconto": false, "valorComDesconto": null}]   [{"dia": "sexta-feira", "fim": "22:00", "inicio": "10:00", "almocoFim": "16:00", "almocoInicio": "13:00", "duracaoAtendimento": 90}]    t   20.00   0.00    0.00    0.00    2025-12-05 19:52:24.081 2025-12-05 19:52:24.081
\.


--
-- Data for Name: project_products; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.project_products (id, "companyId", "projectId", "productId", quantity, "unitPrice", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: project_services; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.project_services (id, "companyId", "projectId", "serviceId", quantity, "unitPrice", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: project_task_users; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.project_task_users (id, "companyId", "taskId", "userId", responsibility, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: project_tasks; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.project_tasks (id, "companyId", "projectId", title, description, status, "order", "startDate", "dueDate", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: project_users; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.project_users (id, "companyId", "projectId", "userId", role, "effortAllocation", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.projects (id, "companyId", "clientId", "invoiceId", name, description, "deliveryTime", warranty, terms, status, "startDate", "endDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: scheduled_dispatch_logs; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.scheduled_dispatch_logs (id, dispatcher_id, contact_id, ticket_id, company_id, status, error_message, sent_at, created_at, updated_at) FROM stdin;
1   1   \N  \N  1   error   Cannot read properties of undefined (reading 'enableLGPD')  \N  2026-01-27 09:00:00.121 2026-01-27 09:00:00.234
\.


--
-- Data for Name: scheduled_dispatchers; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.scheduled_dispatchers (id, company_id, title, message_template, event_type, whatsapp_id, start_time, send_interval_seconds, days_before_due, days_after_due, active, created_at, updated_at) FROM stdin;
1   1   teste   Olá  {{firstName}} lembre de pagar a sua Fatura  {{contactName}} no valor de  {{invoiceValue}} que vence no dia  {{invoiceDueDate}} invoice_reminder    \N  09:00   60  1   \N  t   2025-12-24 19:30:51.095 2025-12-24 19:30:51.095
\.


--
-- Data for Name: servicos; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.servicos (id, "companyId", nome, descricao, "valorOriginal", "possuiDesconto", "valorComDesconto", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: slider_home; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.slider_home (id, name, image, "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tutorial_videos; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.tutorial_videos (id, title, description, video_url, thumbnail_url, company_id, user_id, is_active, views_count, created_at, updated_at) FROM stdin;
1   Como conectar um canal  \N  https://www.youtube.com/watch?v=5Peo-ivmupE https://img.youtube.com/vi/4JipHEz53sU/hqdefault.jpg    1   1   f   0   2025-12-03 19:05:28.005+00  2025-12-03 23:53:10.178587+00
2   Como conectar um Canal  \N  https://www.youtube.com/watch?v=5Peo-ivmupE https://img.youtube.com/vi/5Peo-ivmupE/hqdefault.jpg    1   1   f   0   2025-12-03 23:53:28.333+00  2025-12-04 03:14:00.409003+00
3   Como add uma conexão    \N  https://www.youtube.com/watch?v=ko70cExuzZM&list=RDko70cExuzZM&start_radio=1    https://img.youtube.com/vi/ko70cExuzZM/hqdefault.jpg    1   1   f   5   2025-12-04 03:14:18.812+00  2026-01-02 03:35:46.073026+00
4   Como conectar o whatsapp    Como conectar o whatsapp    https://www.youtube.com/watch?v=39RelPcYVnI https://img.youtube.com/vi/39RelPcYVnI/hqdefault.jpg    1   1   f   10  2026-01-15 05:27:40.75+00   2026-02-06 21:36:51.133417+00
5   Criando um fluxo automação  Criando um fluxo automação  https://www.youtube.com/watch?v=39RelPcYVnI https://img.youtube.com/vi/39RelPcYVnI/hqdefault.jpg    1   1   f   9   2026-01-15 05:28:12.726+00  2026-02-06 21:36:52.923679+00
\.


--
-- Data for Name: user_schedules; Type: TABLE DATA; Schema: public; Owner: empresa
--

COPY public.user_schedules (id, name, description, active, user_id, company_id, created_at, updated_at, user_google_calendar_integration_id) FROM stdin;
\.


--
-- Name: Announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Announcements_id_seq"', 1, true);


--
-- Name: ApiUsages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."ApiUsages_id_seq"', 4, true);


--
-- Name: AutomationActions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."AutomationActions_id_seq"', 7, true);


--
-- Name: AutomationExecutions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."AutomationExecutions_id_seq"', 1, false);


--
-- Name: AutomationLogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."AutomationLogs_id_seq"', 1, false);


--
-- Name: Automations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Automations_id_seq"', 5, true);


--
-- Name: Baileys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Baileys_id_seq"', 3583, true);


--
-- Name: CampaignSettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."CampaignSettings_id_seq"', 16, true);


--
-- Name: CampaignShipping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."CampaignShipping_id_seq"', 594, true);


--
-- Name: Campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Campaigns_id_seq"', 28, true);


--
-- Name: ChatMessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."ChatMessages_id_seq"', 9, true);


--
-- Name: ChatUsers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."ChatUsers_id_seq"', 11, true);


--
-- Name: Chatbots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Chatbots_id_seq"', 1, false);


--
-- Name: Chats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Chats_id_seq"', 4, true);


--
-- Name: CompaniesSettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."CompaniesSettings_id_seq"', 103, true);


--
-- Name: Companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Companies_id_seq"', 143, true);


--
-- Name: ContactCustomFields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."ContactCustomFields_id_seq"', 10, true);


--
-- Name: ContactGroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."ContactGroups_id_seq"', 1, false);


--
-- Name: ContactListItems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."ContactListItems_id_seq"', 599, true);


--
-- Name: ContactLists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."ContactLists_id_seq"', 31, true);


--
-- Name: ContactWallets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."ContactWallets_id_seq"', 1, false);


--
-- Name: Contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Contacts_id_seq"', 2614, true);


--
-- Name: DialogChatBots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."DialogChatBots_id_seq"', 1, false);


--
-- Name: Faturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Faturas_id_seq"', 3, true);


--
-- Name: Ferramentas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Ferramentas_id_seq"', 15, true);


--
-- Name: FilesOptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."FilesOptions_id_seq"', 3, true);


--
-- Name: Files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Files_id_seq"', 3, true);


--
-- Name: FlowAudios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."FlowAudios_id_seq"', 1, false);


--
-- Name: FlowBuilders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."FlowBuilders_id_seq"', 61, true);


--
-- Name: FlowCampaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."FlowCampaigns_id_seq"', 4, true);


--
-- Name: FlowDefaults_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."FlowDefaults_id_seq"', 1, false);


--
-- Name: FlowImgs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."FlowImgs_id_seq"', 18, true);


--
-- Name: GoogleCalendarIntegrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."GoogleCalendarIntegrations_id_seq"', 12, true);


--
-- Name: GoogleSheetsTokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."GoogleSheetsTokens_id_seq"', 1, false);


--
-- Name: Helps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Helps_id_seq"', 1, false);


--
-- Name: IaWorkflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."IaWorkflows_id_seq"', 32, true);


--
-- Name: Integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Integrations_id_seq"', 1, false);


--
-- Name: Invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Invoices_id_seq"', 113, true);


--
-- Name: LogTickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."LogTickets_id_seq"', 11625, true);


--
-- Name: MediaFiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."MediaFiles_id_seq"', 1, false);


--
-- Name: MediaFolders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."MediaFolders_id_seq"', 1, false);


--
-- Name: Messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Messages_id_seq"', 21497, true);


--
-- Name: MobileWebhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."MobileWebhooks_id_seq"', 1, false);


--
-- Name: Negocios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Negocios_id_seq"', 32, true);


--
-- Name: Partners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Partners_id_seq"', 1, false);


--
-- Name: Plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Plans_id_seq"', 4, true);


--
-- Name: Produtos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Produtos_id_seq"', 21, true);


--
-- Name: PromptToolSettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."PromptToolSettings_id_seq"', 834, true);


--
-- Name: Prompts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Prompts_id_seq"', 20, true);


--
-- Name: QueueIntegrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."QueueIntegrations_id_seq"', 13, true);


--
-- Name: QueueOptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."QueueOptions_id_seq"', 1, false);


--
-- Name: Queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Queues_id_seq"', 53, true);


--
-- Name: QuickMessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."QuickMessages_id_seq"', 11, true);


--
-- Name: ScheduledMessagesEnvios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."ScheduledMessagesEnvios_id_seq"', 1, false);


--
-- Name: ScheduledMessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."ScheduledMessages_id_seq"', 1, false);


--
-- Name: Schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Schedules_id_seq"', 32, true);


--
-- Name: Settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Settings_id_seq"', 97, true);


--
-- Name: SliderBanners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."SliderBanners_id_seq"', 1, false);


--
-- Name: Subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Subscriptions_id_seq"', 1, false);


--
-- Name: Tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Tags_id_seq"', 107, true);


--
-- Name: TicketNotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."TicketNotes_id_seq"', 37, true);


--
-- Name: TicketTraking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."TicketTraking_id_seq"', 2299, true);


--
-- Name: Tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Tickets_id_seq"', 1823, true);


--
-- Name: UserDevices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."UserDevices_id_seq"', 1, false);


--
-- Name: UserGoogleCalendarIntegrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."UserGoogleCalendarIntegrations_id_seq"', 5, true);


--
-- Name: UserRatings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."UserRatings_id_seq"', 9, true);


--
-- Name: UserServices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."UserServices_id_seq"', 5, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Users_id_seq"', 141, true);


--
-- Name: Versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Versions_id_seq"', 1, false);


--
-- Name: Webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Webhooks_id_seq"', 12, true);


--
-- Name: Whatsapps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public."Whatsapps_id_seq"', 136, true);


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.appointments_id_seq', 21, true);


--
-- Name: company_api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.company_api_keys_id_seq', 1, true);


--
-- Name: company_integration_field_maps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.company_integration_field_maps_id_seq', 1, false);


--
-- Name: company_integration_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.company_integration_settings_id_seq', 1, false);


--
-- Name: company_payment_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.company_payment_settings_id_seq', 3, true);


--
-- Name: crm_client_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.crm_client_contacts_id_seq', 14, true);


--
-- Name: crm_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.crm_clients_id_seq', 23, true);


--
-- Name: crm_leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.crm_leads_id_seq', 1290, true);


--
-- Name: financeiro_faturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.financeiro_faturas_id_seq', 15, true);


--
-- Name: financeiro_pagamentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.financeiro_pagamentos_id_seq', 6, true);


--
-- Name: media_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.media_files_id_seq', 1, false);


--
-- Name: media_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.media_folders_id_seq', 1, false);


--
-- Name: profissionais_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.profissionais_id_seq', 2, true);


--
-- Name: project_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.project_products_id_seq', 3, true);


--
-- Name: project_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.project_services_id_seq', 3, true);


--
-- Name: project_task_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.project_task_users_id_seq', 4, true);


--
-- Name: project_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.project_tasks_id_seq', 8, true);


--
-- Name: project_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.project_users_id_seq', 7, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.projects_id_seq', 6, true);


--
-- Name: scheduled_dispatch_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.scheduled_dispatch_logs_id_seq', 1, true);


--
-- Name: scheduled_dispatchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.scheduled_dispatchers_id_seq', 2, true);


--
-- Name: servicos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.servicos_id_seq', 7, true);


--
-- Name: slider_home_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.slider_home_id_seq', 8, true);


--
-- Name: tutorial_videos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.tutorial_videos_id_seq', 5, true);


--
-- Name: user_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: empresa
--

SELECT pg_catalog.setval('public.user_schedules_id_seq', 6, true);


--
-- Name: Announcements Announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Announcements"
    ADD CONSTRAINT "Announcements_pkey" PRIMARY KEY (id);


--
-- Name: ApiUsages ApiUsages_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ApiUsages"
    ADD CONSTRAINT "ApiUsages_pkey" PRIMARY KEY (id);


--
-- Name: AutomationActions AutomationActions_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationActions"
    ADD CONSTRAINT "AutomationActions_pkey" PRIMARY KEY (id);


--
-- Name: AutomationExecutions AutomationExecutions_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationExecutions"
    ADD CONSTRAINT "AutomationExecutions_pkey" PRIMARY KEY (id);


--
-- Name: AutomationLogs AutomationLogs_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationLogs"
    ADD CONSTRAINT "AutomationLogs_pkey" PRIMARY KEY (id);


--
-- Name: Automations Automations_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Automations"
    ADD CONSTRAINT "Automations_pkey" PRIMARY KEY (id);


--
-- Name: Baileys Baileys_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Baileys"
    ADD CONSTRAINT "Baileys_pkey" PRIMARY KEY (id, "whatsappId");


--
-- Name: CampaignSettings CampaignSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."CampaignSettings"
    ADD CONSTRAINT "CampaignSettings_pkey" PRIMARY KEY (id);


--
-- Name: CampaignShipping CampaignShipping_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."CampaignShipping"
    ADD CONSTRAINT "CampaignShipping_pkey" PRIMARY KEY (id);


--
-- Name: Campaigns Campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_pkey" PRIMARY KEY (id);


--
-- Name: ChatMessages ChatMessages_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_pkey" PRIMARY KEY (id);


--
-- Name: ChatUsers ChatUsers_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ChatUsers"
    ADD CONSTRAINT "ChatUsers_pkey" PRIMARY KEY (id);


--
-- Name: Chatbots Chatbots_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_pkey" PRIMARY KEY (id);


--
-- Name: Chats Chats_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chats"
    ADD CONSTRAINT "Chats_pkey" PRIMARY KEY (id);


--
-- Name: CompaniesSettings CompaniesSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."CompaniesSettings"
    ADD CONSTRAINT "CompaniesSettings_pkey" PRIMARY KEY (id);


--
-- Name: Companies Companies_name_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_name_key" UNIQUE (name);


--
-- Name: Companies Companies_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_pkey" PRIMARY KEY (id);


--
-- Name: ContactCustomFields ContactCustomFields_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactCustomFields"
    ADD CONSTRAINT "ContactCustomFields_pkey" PRIMARY KEY (id);


--
-- Name: ContactGroups ContactGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactGroups"
    ADD CONSTRAINT "ContactGroups_pkey" PRIMARY KEY (id);


--
-- Name: ContactListItems ContactListItems_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactListItems"
    ADD CONSTRAINT "ContactListItems_pkey" PRIMARY KEY (id);


--
-- Name: ContactLists ContactLists_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactLists"
    ADD CONSTRAINT "ContactLists_pkey" PRIMARY KEY (id);


--
-- Name: ContactWallets ContactWallets_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactWallets"
    ADD CONSTRAINT "ContactWallets_pkey" PRIMARY KEY (id);


--
-- Name: Contacts Contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT "Contacts_pkey" PRIMARY KEY (id);


--
-- Name: DialogChatBots DialogChatBots_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."DialogChatBots"
    ADD CONSTRAINT "DialogChatBots_pkey" PRIMARY KEY (id);


--
-- Name: Faturas Faturas_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Faturas"
    ADD CONSTRAINT "Faturas_pkey" PRIMARY KEY (id);


--
-- Name: Ferramentas Ferramentas_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Ferramentas"
    ADD CONSTRAINT "Ferramentas_pkey" PRIMARY KEY (id);


--
-- Name: FilesOptions FilesOptions_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FilesOptions"
    ADD CONSTRAINT "FilesOptions_pkey" PRIMARY KEY (id);


--
-- Name: Files Files_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT "Files_pkey" PRIMARY KEY (id);


--
-- Name: FlowAudios FlowAudios_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FlowAudios"
    ADD CONSTRAINT "FlowAudios_pkey" PRIMARY KEY (id);


--
-- Name: FlowBuilders FlowBuilders_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FlowBuilders"
    ADD CONSTRAINT "FlowBuilders_pkey" PRIMARY KEY (id);


--
-- Name: FlowCampaigns FlowCampaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FlowCampaigns"
    ADD CONSTRAINT "FlowCampaigns_pkey" PRIMARY KEY (id);


--
-- Name: FlowDefaults FlowDefaults_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FlowDefaults"
    ADD CONSTRAINT "FlowDefaults_pkey" PRIMARY KEY (id);


--
-- Name: FlowImgs FlowImgs_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FlowImgs"
    ADD CONSTRAINT "FlowImgs_pkey" PRIMARY KEY (id);


--
-- Name: GoogleCalendarIntegrations GoogleCalendarIntegrations_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."GoogleCalendarIntegrations"
    ADD CONSTRAINT "GoogleCalendarIntegrations_pkey" PRIMARY KEY (id);


--
-- Name: GoogleSheetsTokens GoogleSheetsTokens_companyId_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."GoogleSheetsTokens"
    ADD CONSTRAINT "GoogleSheetsTokens_companyId_key" UNIQUE ("companyId");


--
-- Name: GoogleSheetsTokens GoogleSheetsTokens_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."GoogleSheetsTokens"
    ADD CONSTRAINT "GoogleSheetsTokens_pkey" PRIMARY KEY (id);


--
-- Name: Helps Helps_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Helps"
    ADD CONSTRAINT "Helps_pkey" PRIMARY KEY (id);


--
-- Name: IaWorkflows IaWorkflows_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."IaWorkflows"
    ADD CONSTRAINT "IaWorkflows_pkey" PRIMARY KEY (id);


--
-- Name: Integrations Integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Integrations"
    ADD CONSTRAINT "Integrations_pkey" PRIMARY KEY (id);


--
-- Name: Invoices Invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Invoices"
    ADD CONSTRAINT "Invoices_pkey" PRIMARY KEY (id);


--
-- Name: LogTickets LogTickets_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."LogTickets"
    ADD CONSTRAINT "LogTickets_pkey" PRIMARY KEY (id);


--
-- Name: MediaFiles MediaFiles_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."MediaFiles"
    ADD CONSTRAINT "MediaFiles_pkey" PRIMARY KEY (id);


--
-- Name: MediaFolders MediaFolders_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."MediaFolders"
    ADD CONSTRAINT "MediaFolders_pkey" PRIMARY KEY (id);


--
-- Name: Messages Messages_id_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_id_key" UNIQUE (id);


--
-- Name: Messages Messages_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_pkey" PRIMARY KEY (id);


--
-- Name: MobileWebhooks MobileWebhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."MobileWebhooks"
    ADD CONSTRAINT "MobileWebhooks_pkey" PRIMARY KEY (id);


--
-- Name: Negocios Negocios_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Negocios"
    ADD CONSTRAINT "Negocios_pkey" PRIMARY KEY (id);


--
-- Name: Partners Partners_document_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Partners"
    ADD CONSTRAINT "Partners_document_key" UNIQUE (document);


--
-- Name: Partners Partners_name_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Partners"
    ADD CONSTRAINT "Partners_name_key" UNIQUE (name);


--
-- Name: Partners Partners_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Partners"
    ADD CONSTRAINT "Partners_pkey" PRIMARY KEY (id);


--
-- Name: Plans Plans_name_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Plans"
    ADD CONSTRAINT "Plans_name_key" UNIQUE (name);


--
-- Name: Plans Plans_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Plans"
    ADD CONSTRAINT "Plans_pkey" PRIMARY KEY (id);


--
-- Name: Produtos Produtos_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Produtos"
    ADD CONSTRAINT "Produtos_pkey" PRIMARY KEY (id);


--
-- Name: PromptToolSettings PromptToolSettings_company_prompt_tool_unique; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."PromptToolSettings"
    ADD CONSTRAINT "PromptToolSettings_company_prompt_tool_unique" UNIQUE ("companyId", "promptId", "toolName");


--
-- Name: PromptToolSettings PromptToolSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."PromptToolSettings"
    ADD CONSTRAINT "PromptToolSettings_pkey" PRIMARY KEY (id);


--
-- Name: Prompts Prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Prompts"
    ADD CONSTRAINT "Prompts_pkey" PRIMARY KEY (id);


--
-- Name: QueueIntegrations QueueIntegrations_name_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QueueIntegrations"
    ADD CONSTRAINT "QueueIntegrations_name_key" UNIQUE (name);


--
-- Name: QueueIntegrations QueueIntegrations_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QueueIntegrations"
    ADD CONSTRAINT "QueueIntegrations_pkey" PRIMARY KEY (id);


--
-- Name: QueueIntegrations QueueIntegrations_projectName_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QueueIntegrations"
    ADD CONSTRAINT "QueueIntegrations_projectName_key" UNIQUE ("projectName");


--
-- Name: QueueOptions QueueOptions_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QueueOptions"
    ADD CONSTRAINT "QueueOptions_pkey" PRIMARY KEY (id);


--
-- Name: Queues Queues_color_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_color_key" UNIQUE (color, "companyId");


--
-- Name: Queues Queues_name_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_name_key" UNIQUE (name, "companyId");


--
-- Name: Queues Queues_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_pkey" PRIMARY KEY (id);


--
-- Name: QuickMessages QuickMessages_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QuickMessages"
    ADD CONSTRAINT "QuickMessages_pkey" PRIMARY KEY (id);


--
-- Name: ScheduledMessagesEnvios ScheduledMessagesEnvios_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ScheduledMessagesEnvios"
    ADD CONSTRAINT "ScheduledMessagesEnvios_pkey" PRIMARY KEY (id);


--
-- Name: ScheduledMessages ScheduledMessages_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ScheduledMessages"
    ADD CONSTRAINT "ScheduledMessages_pkey" PRIMARY KEY (id);


--
-- Name: Schedules Schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_pkey" PRIMARY KEY (id);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: SliderBanners SliderBanners_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."SliderBanners"
    ADD CONSTRAINT "SliderBanners_pkey" PRIMARY KEY (id);


--
-- Name: Subscriptions Subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Subscriptions"
    ADD CONSTRAINT "Subscriptions_pkey" PRIMARY KEY (id);


--
-- Name: Tags Tags_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tags"
    ADD CONSTRAINT "Tags_pkey" PRIMARY KEY (id);


--
-- Name: TicketNotes TicketNotes_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_pkey" PRIMARY KEY (id);


--
-- Name: TicketTraking TicketTraking_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_pkey" PRIMARY KEY (id);


--
-- Name: Tickets Tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_pkey" PRIMARY KEY (id);


--
-- Name: UserDevices UserDevices_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserDevices"
    ADD CONSTRAINT "UserDevices_pkey" PRIMARY KEY (id);


--
-- Name: UserDevices UserDevices_userId_deviceToken_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserDevices"
    ADD CONSTRAINT "UserDevices_userId_deviceToken_key" UNIQUE ("userId", "deviceToken");


--
-- Name: UserGoogleCalendarIntegrations UserGoogleCalendarIntegrations_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserGoogleCalendarIntegrations"
    ADD CONSTRAINT "UserGoogleCalendarIntegrations_pkey" PRIMARY KEY (id);


--
-- Name: UserQueues UserQueues_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserQueues"
    ADD CONSTRAINT "UserQueues_pkey" PRIMARY KEY ("userId", "queueId");


--
-- Name: UserRatings UserRatings_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_pkey" PRIMARY KEY (id);


--
-- Name: UserServices UserServices_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserServices"
    ADD CONSTRAINT "UserServices_pkey" PRIMARY KEY (id);


--
-- Name: UserServices UserServices_userId_serviceId_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserServices"
    ADD CONSTRAINT "UserServices_userId_serviceId_key" UNIQUE ("userId", "serviceId");


--
-- Name: Users Users_email_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key" UNIQUE (email);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: Versions Versions_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Versions"
    ADD CONSTRAINT "Versions_pkey" PRIMARY KEY (id);


--
-- Name: Webhooks Webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Webhooks"
    ADD CONSTRAINT "Webhooks_pkey" PRIMARY KEY (id);


--
-- Name: WhatsappQueues WhatsappQueues_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."WhatsappQueues"
    ADD CONSTRAINT "WhatsappQueues_pkey" PRIMARY KEY ("whatsappId", "queueId");


--
-- Name: Whatsapps Whatsapps_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_pkey" PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: company_api_keys company_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_api_keys
    ADD CONSTRAINT company_api_keys_pkey PRIMARY KEY (id);


--
-- Name: company_api_keys company_api_keys_token_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_api_keys
    ADD CONSTRAINT company_api_keys_token_key UNIQUE (token);


--
-- Name: company_integration_field_maps company_integration_field_maps_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_integration_field_maps
    ADD CONSTRAINT company_integration_field_maps_pkey PRIMARY KEY (id);


--
-- Name: company_integration_settings company_integration_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_integration_settings
    ADD CONSTRAINT company_integration_settings_pkey PRIMARY KEY (id);


--
-- Name: company_payment_settings company_payment_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_payment_settings
    ADD CONSTRAINT company_payment_settings_pkey PRIMARY KEY (id);


--
-- Name: Tickets contactid_companyid_whatsappid_unique; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT contactid_companyid_whatsappid_unique UNIQUE (id, "contactId", "companyId", "whatsappId");


--
-- Name: Contacts contacts_company_number_unique; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT contacts_company_number_unique UNIQUE ("companyId", number);


--
-- Name: crm_client_contacts crm_client_contacts_client_id_contact_id_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_client_contacts
    ADD CONSTRAINT crm_client_contacts_client_id_contact_id_key UNIQUE (client_id, contact_id);


--
-- Name: crm_client_contacts crm_client_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_client_contacts
    ADD CONSTRAINT crm_client_contacts_pkey PRIMARY KEY (id);


--
-- Name: crm_clients crm_clients_company_id_document_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_company_id_document_key UNIQUE (company_id, document);


--
-- Name: crm_clients crm_clients_company_id_document_unique; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_company_id_document_unique UNIQUE (company_id, document);


--
-- Name: crm_clients crm_clients_company_id_email_unique; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_company_id_email_unique UNIQUE (company_id, email);


--
-- Name: crm_clients crm_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_pkey PRIMARY KEY (id);


--
-- Name: crm_leads crm_leads_company_id_email_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_company_id_email_key UNIQUE (company_id, email);


--
-- Name: crm_leads crm_leads_company_id_email_unique; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_company_id_email_unique UNIQUE (company_id, email);


--
-- Name: crm_leads crm_leads_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_pkey PRIMARY KEY (id);


--
-- Name: financeiro_faturas financeiro_faturas_id_company_unique; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.financeiro_faturas
    ADD CONSTRAINT financeiro_faturas_id_company_unique UNIQUE (id, company_id);


--
-- Name: financeiro_faturas financeiro_faturas_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.financeiro_faturas
    ADD CONSTRAINT financeiro_faturas_pkey PRIMARY KEY (id);


--
-- Name: financeiro_pagamentos financeiro_pagamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.financeiro_pagamentos
    ADD CONSTRAINT financeiro_pagamentos_pkey PRIMARY KEY (id);


--
-- Name: media_files media_files_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_pkey PRIMARY KEY (id);


--
-- Name: media_folders media_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.media_folders
    ADD CONSTRAINT media_folders_pkey PRIMARY KEY (id);


--
-- Name: Contacts number_companyid_unique; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT number_companyid_unique UNIQUE (number, "companyId");


--
-- Name: profissionais profissionais_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.profissionais
    ADD CONSTRAINT profissionais_pkey PRIMARY KEY (id);


--
-- Name: project_products project_products_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_products
    ADD CONSTRAINT project_products_pkey PRIMARY KEY (id);


--
-- Name: project_services project_services_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_services
    ADD CONSTRAINT project_services_pkey PRIMARY KEY (id);


--
-- Name: project_task_users project_task_users_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_task_users
    ADD CONSTRAINT project_task_users_pkey PRIMARY KEY (id);


--
-- Name: project_tasks project_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_pkey PRIMARY KEY (id);


--
-- Name: project_users project_users_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_users
    ADD CONSTRAINT project_users_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: scheduled_dispatch_logs scheduled_dispatch_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.scheduled_dispatch_logs
    ADD CONSTRAINT scheduled_dispatch_logs_pkey PRIMARY KEY (id);


--
-- Name: scheduled_dispatchers scheduled_dispatchers_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.scheduled_dispatchers
    ADD CONSTRAINT scheduled_dispatchers_pkey PRIMARY KEY (id);


--
-- Name: servicos servicos_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.servicos
    ADD CONSTRAINT servicos_pkey PRIMARY KEY (id);


--
-- Name: slider_home slider_home_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.slider_home
    ADD CONSTRAINT slider_home_pkey PRIMARY KEY (id);


--
-- Name: tutorial_videos tutorial_videos_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.tutorial_videos
    ADD CONSTRAINT tutorial_videos_pkey PRIMARY KEY (id);


--
-- Name: user_schedules user_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.user_schedules
    ADD CONSTRAINT user_schedules_pkey PRIMARY KEY (id);


--
-- Name: user_schedules user_schedules_user_id_key; Type: CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.user_schedules
    ADD CONSTRAINT user_schedules_user_id_key UNIQUE (user_id);


--
-- Name: MediaFiles_company_id_idx; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "MediaFiles_company_id_idx" ON public."MediaFiles" USING btree (company_id);


--
-- Name: MediaFiles_folder_id_idx; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "MediaFiles_folder_id_idx" ON public."MediaFiles" USING btree (folder_id);


--
-- Name: MediaFolders_company_id_idx; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "MediaFolders_company_id_idx" ON public."MediaFolders" USING btree (company_id);


--
-- Name: automation_actions_automation_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automation_actions_automation_id ON public."AutomationActions" USING btree ("automationId");


--
-- Name: automation_actions_order; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automation_actions_order ON public."AutomationActions" USING btree ("order");


--
-- Name: automation_executions_automation_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automation_executions_automation_id ON public."AutomationExecutions" USING btree ("automationId");


--
-- Name: automation_executions_contact_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automation_executions_contact_id ON public."AutomationExecutions" USING btree ("contactId");


--
-- Name: automation_executions_scheduled_at; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automation_executions_scheduled_at ON public."AutomationExecutions" USING btree ("scheduledAt");


--
-- Name: automation_executions_status; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automation_executions_status ON public."AutomationExecutions" USING btree (status);


--
-- Name: automation_logs_automation_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automation_logs_automation_id ON public."AutomationLogs" USING btree ("automationId");


--
-- Name: automation_logs_contact_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automation_logs_contact_id ON public."AutomationLogs" USING btree ("contactId");


--
-- Name: automation_logs_executed_at; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automation_logs_executed_at ON public."AutomationLogs" USING btree ("executedAt");


--
-- Name: automation_logs_status; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automation_logs_status ON public."AutomationLogs" USING btree (status);


--
-- Name: automation_logs_ticket_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automation_logs_ticket_id ON public."AutomationLogs" USING btree ("ticketId");


--
-- Name: automations_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automations_company_id ON public."Automations" USING btree ("companyId");


--
-- Name: automations_is_active; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automations_is_active ON public."Automations" USING btree ("isActive");


--
-- Name: automations_trigger_type; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX automations_trigger_type ON public."Automations" USING btree ("triggerType");


--
-- Name: company_api_keys_company_active; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX company_api_keys_company_active ON public.company_api_keys USING btree (company_id, active);


--
-- Name: company_integration_field_maps_unique; Type: INDEX; Schema: public; Owner: empresa
--

CREATE UNIQUE INDEX company_integration_field_maps_unique ON public.company_integration_field_maps USING btree (integration_id, external_field);


--
-- Name: company_integration_settings_company_name; Type: INDEX; Schema: public; Owner: empresa
--

CREATE UNIQUE INDEX company_integration_settings_company_name ON public.company_integration_settings USING btree (company_id, name);


--
-- Name: company_payment_settings_company_provider; Type: INDEX; Schema: public; Owner: empresa
--

CREATE UNIQUE INDEX company_payment_settings_company_provider ON public.company_payment_settings USING btree (company_id, provider);


--
-- Name: contacts_lid_index; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX contacts_lid_index ON public."Contacts" USING btree (lid);


--
-- Name: crm_clients_asaas_customer_id_idx; Type: INDEX; Schema: public; Owner: empresa
--

CREATE UNIQUE INDEX crm_clients_asaas_customer_id_idx ON public.crm_clients USING btree (asaas_customer_id) WHERE (asaas_customer_id IS NOT NULL);


--
-- Name: financeiro_faturas_checkout_token_idx; Type: INDEX; Schema: public; Owner: empresa
--

CREATE UNIQUE INDEX financeiro_faturas_checkout_token_idx ON public.financeiro_faturas USING btree (checkout_token) WHERE (checkout_token IS NOT NULL);


--
-- Name: google_calendar_integrations_company_user_unique; Type: INDEX; Schema: public; Owner: empresa
--

CREATE UNIQUE INDEX google_calendar_integrations_company_user_unique ON public."GoogleCalendarIntegrations" USING btree ("companyId", "userId");


--
-- Name: idx_ContactCustomFields_contact_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_ContactCustomFields_contact_id" ON public."ContactCustomFields" USING btree ("contactId");


--
-- Name: idx_LogTickets_ticket_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_LogTickets_ticket_id" ON public."LogTickets" USING btree ("ticketId");


--
-- Name: idx_Messages_contact_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_Messages_contact_id" ON public."Messages" USING btree ("contactId");


--
-- Name: idx_TicketTags_tag_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_TicketTags_tag_id" ON public."TicketTags" USING btree ("tagId");


--
-- Name: idx_TicketTags_ticket_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_TicketTags_ticket_id" ON public."TicketTags" USING btree ("ticketId");


--
-- Name: idx_TicketTraking_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_TicketTraking_company_id" ON public."TicketTraking" USING btree ("companyId");


--
-- Name: idx_TicketTraking_ticket_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_TicketTraking_ticket_id" ON public."TicketTraking" USING btree ("ticketId");


--
-- Name: idx_appointments_google_event_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_appointments_google_event_id ON public.appointments USING btree (google_event_id);


--
-- Name: idx_client_contacts_contact; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_client_contacts_contact ON public.crm_client_contacts USING btree (contact_id);


--
-- Name: idx_clients_company; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_clients_company ON public.crm_clients USING btree (company_id);


--
-- Name: idx_clients_status; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_clients_status ON public.crm_clients USING btree (company_id, status);


--
-- Name: idx_cont_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_cont_company_id ON public."Contacts" USING btree ("companyId");


--
-- Name: idx_contactTag_contact_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_contactTag_contact_id" ON public."ContactTags" USING btree ("contactId");


--
-- Name: idx_contactTag_tagId; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_contactTag_tagId" ON public."ContactTags" USING btree ("tagId");


--
-- Name: idx_contactTag_tag_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_contactTag_tag_id" ON public."ContactTags" USING btree ("tagId");


--
-- Name: idx_contact_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_contact_company_id ON public."Contacts" USING btree ("companyId");


--
-- Name: idx_contact_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_contact_id ON public."Contacts" USING btree (id);


--
-- Name: idx_contact_name; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_contact_name ON public."Contacts" USING btree (name);


--
-- Name: idx_contact_number; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_contact_number ON public."Contacts" USING btree (number);


--
-- Name: idx_contact_whatsapp_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_contact_whatsapp_id ON public."Contacts" USING btree ("whatsappId");


--
-- Name: idx_cpsh_campaign_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_cpsh_campaign_id ON public."CampaignShipping" USING btree ("campaignId");


--
-- Name: idx_crm_clients_contact_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_crm_clients_contact_id ON public.crm_clients USING btree (contact_id);


--
-- Name: idx_crm_leads_contact_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_crm_leads_contact_id ON public.crm_leads USING btree (contact_id);


--
-- Name: idx_crm_leads_lead_status; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_crm_leads_lead_status ON public.crm_leads USING btree (lead_status);


--
-- Name: idx_ctli_contact_list_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_ctli_contact_list_id ON public."ContactListItems" USING btree ("contactListId");


--
-- Name: idx_faturas_company; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_faturas_company ON public.financeiro_faturas USING btree (company_id);


--
-- Name: idx_faturas_recorrencia; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_faturas_recorrencia ON public.financeiro_faturas USING btree (company_id, tipo_recorrencia, ativa);


--
-- Name: idx_faturas_status; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_faturas_status ON public.financeiro_faturas USING btree (company_id, status);


--
-- Name: idx_financeiro_faturas_company; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_financeiro_faturas_company ON public.financeiro_faturas USING btree (company_id);


--
-- Name: idx_financeiro_faturas_project_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_financeiro_faturas_project_id ON public.financeiro_faturas USING btree (project_id);


--
-- Name: idx_financeiro_faturas_recorrencia; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_financeiro_faturas_recorrencia ON public.financeiro_faturas USING btree (company_id, tipo_recorrencia, ativa);


--
-- Name: idx_financeiro_faturas_status; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_financeiro_faturas_status ON public.financeiro_faturas USING btree (company_id, status);


--
-- Name: idx_financeiro_pagamentos_company; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_financeiro_pagamentos_company ON public.financeiro_pagamentos USING btree (company_id);


--
-- Name: idx_flowbui_id_user_id_active; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_flowbui_id_user_id_active ON public."FlowBuilders" USING btree (id, user_id, active);


--
-- Name: idx_flowcamp_id_company_id_phrase; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_flowcamp_id_company_id_phrase ON public."FlowCampaigns" USING btree (id, "companyId", phrase);


--
-- Name: idx_flowdefa_id_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_flowdefa_id_company_id ON public."FlowDefaults" USING btree (id, "companyId");


--
-- Name: idx_leads_company; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_leads_company ON public.crm_leads USING btree (company_id);


--
-- Name: idx_leads_owner; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_leads_owner ON public.crm_leads USING btree (company_id, owner_user_id);


--
-- Name: idx_leads_status; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_leads_status ON public.crm_leads USING btree (company_id, status);


--
-- Name: idx_message_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_message_company_id ON public."Messages" USING btree ("companyId");


--
-- Name: idx_message_quoted_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_message_quoted_id ON public."Messages" USING btree ("quotedMsgId");


--
-- Name: idx_message_ticket_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_message_ticket_id ON public."Messages" USING btree ("ticketId");


--
-- Name: idx_messages_wid; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_messages_wid ON public."Messages" USING btree (wid);


--
-- Name: idx_ms_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_ms_company_id ON public."Messages" USING btree ("companyId");


--
-- Name: idx_ms_company_id_ticket_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_ms_company_id_ticket_id ON public."Messages" USING btree ("companyId", "ticketId");


--
-- Name: idx_queues_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_queues_id ON public."Queues" USING btree (id);


--
-- Name: idx_sched_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_sched_company_id ON public."Schedules" USING btree ("companyId");


--
-- Name: idx_tg_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_tg_company_id ON public."Tags" USING btree ("companyId");


--
-- Name: idx_ticket_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_ticket_company_id ON public."Tickets" USING btree ("companyId");


--
-- Name: idx_ticket_contact_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_ticket_contact_id ON public."Tickets" USING btree ("contactId");


--
-- Name: idx_ticket_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_ticket_id ON public."Tickets" USING btree (id);


--
-- Name: idx_ticket_queue_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_ticket_queue_id ON public."Tickets" USING btree ("queueId");


--
-- Name: idx_ticket_status; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_ticket_status ON public."Tickets" USING btree (status);


--
-- Name: idx_ticket_user_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_ticket_user_id ON public."Tickets" USING btree ("userId");


--
-- Name: idx_ticket_whatsapp_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_ticket_whatsapp_id ON public."Tickets" USING btree ("whatsappId");


--
-- Name: idx_tickets_crm_client_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_tickets_crm_client_id ON public."Tickets" USING btree (crm_client_id);


--
-- Name: idx_tickets_crm_lead_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_tickets_crm_lead_id ON public."Tickets" USING btree (crm_lead_id);


--
-- Name: idx_tutorial_videos_active; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_tutorial_videos_active ON public.tutorial_videos USING btree (is_active);


--
-- Name: idx_tutorial_videos_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_tutorial_videos_company_id ON public.tutorial_videos USING btree (company_id);


--
-- Name: idx_tutorial_videos_created_at; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_tutorial_videos_created_at ON public.tutorial_videos USING btree (created_at DESC);


--
-- Name: idx_tutorial_videos_user_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_tutorial_videos_user_id ON public.tutorial_videos USING btree (user_id);


--
-- Name: idx_user_devices_deviceToken; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_user_devices_deviceToken" ON public."UserDevices" USING btree ("deviceToken");


--
-- Name: idx_user_devices_userId; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX "idx_user_devices_userId" ON public."UserDevices" USING btree ("userId");


--
-- Name: idx_user_google_calendar_integrations_active; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_user_google_calendar_integrations_active ON public."UserGoogleCalendarIntegrations" USING btree (active);


--
-- Name: idx_user_google_calendar_integrations_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_user_google_calendar_integrations_company_id ON public."UserGoogleCalendarIntegrations" USING btree (company_id);


--
-- Name: idx_user_google_calendar_integrations_email; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_user_google_calendar_integrations_email ON public."UserGoogleCalendarIntegrations" USING btree (email);


--
-- Name: idx_user_schedules_google_calendar_integration_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_user_schedules_google_calendar_integration_id ON public.user_schedules USING btree (user_google_calendar_integration_id);


--
-- Name: idx_userratings_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_userratings_company_id ON public."UserRatings" USING btree ("companyId");


--
-- Name: idx_userratings_ticket_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX idx_userratings_ticket_id ON public."UserRatings" USING btree ("ticketId");


--
-- Name: media_files_company_id_idx; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX media_files_company_id_idx ON public.media_files USING btree (company_id);


--
-- Name: media_files_folder_id_idx; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX media_files_folder_id_idx ON public.media_files USING btree (folder_id);


--
-- Name: media_folders_company_id_idx; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX media_folders_company_id_idx ON public.media_folders USING btree (company_id);


--
-- Name: project_products_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX project_products_company_id ON public.project_products USING btree ("companyId");


--
-- Name: project_products_unique; Type: INDEX; Schema: public; Owner: empresa
--

CREATE UNIQUE INDEX project_products_unique ON public.project_products USING btree ("projectId", "productId");


--
-- Name: project_services_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX project_services_company_id ON public.project_services USING btree ("companyId");


--
-- Name: project_services_unique; Type: INDEX; Schema: public; Owner: empresa
--

CREATE UNIQUE INDEX project_services_unique ON public.project_services USING btree ("projectId", "serviceId");


--
-- Name: project_task_users_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX project_task_users_company_id ON public.project_task_users USING btree ("companyId");


--
-- Name: project_task_users_unique; Type: INDEX; Schema: public; Owner: empresa
--

CREATE UNIQUE INDEX project_task_users_unique ON public.project_task_users USING btree ("taskId", "userId");


--
-- Name: project_tasks_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX project_tasks_company_id ON public.project_tasks USING btree ("companyId");


--
-- Name: project_tasks_project_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX project_tasks_project_id ON public.project_tasks USING btree ("projectId");


--
-- Name: project_tasks_status; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX project_tasks_status ON public.project_tasks USING btree (status);


--
-- Name: project_users_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX project_users_company_id ON public.project_users USING btree ("companyId");


--
-- Name: project_users_unique; Type: INDEX; Schema: public; Owner: empresa
--

CREATE UNIQUE INDEX project_users_unique ON public.project_users USING btree ("projectId", "userId");


--
-- Name: projects_client_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX projects_client_id ON public.projects USING btree ("clientId");


--
-- Name: projects_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX projects_company_id ON public.projects USING btree ("companyId");


--
-- Name: projects_status; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX projects_status ON public.projects USING btree (status);


--
-- Name: scheduled_dispatch_logs_dispatcher_status; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX scheduled_dispatch_logs_dispatcher_status ON public.scheduled_dispatch_logs USING btree (dispatcher_id, status);


--
-- Name: scheduled_dispatchers_company_event; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX scheduled_dispatchers_company_event ON public.scheduled_dispatchers USING btree (company_id, event_type);


--
-- Name: tickets_uuid_idx; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX tickets_uuid_idx ON public."Tickets" USING btree (uuid);


--
-- Name: tutorial_videos_company_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX tutorial_videos_company_id ON public.tutorial_videos USING btree (company_id);


--
-- Name: tutorial_videos_is_active; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX tutorial_videos_is_active ON public.tutorial_videos USING btree (is_active);


--
-- Name: tutorial_videos_user_id; Type: INDEX; Schema: public; Owner: empresa
--

CREATE INDEX tutorial_videos_user_id ON public.tutorial_videos USING btree (user_id);


--
-- Name: user_google_calendar_integrations_user_id_unique; Type: INDEX; Schema: public; Owner: empresa
--

CREATE UNIQUE INDEX user_google_calendar_integrations_user_id_unique ON public."UserGoogleCalendarIntegrations" USING btree (user_id);


--
-- Name: tutorial_videos trigger_tutorial_videos_updated_at; Type: TRIGGER; Schema: public; Owner: empresa
--

CREATE TRIGGER trigger_tutorial_videos_updated_at BEFORE UPDATE ON public.tutorial_videos FOR EACH ROW EXECUTE FUNCTION public.update_tutorial_videos_updated_at();


--
-- Name: UserDevices update_user_device_updated_at_trigger; Type: TRIGGER; Schema: public; Owner: empresa
--

CREATE TRIGGER update_user_device_updated_at_trigger BEFORE UPDATE ON public."UserDevices" FOR EACH ROW EXECUTE FUNCTION public.update_user_device_updated_at();


--
-- Name: UserGoogleCalendarIntegrations update_user_google_calendar_integrations_updated_at; Type: TRIGGER; Schema: public; Owner: empresa
--

CREATE TRIGGER update_user_google_calendar_integrations_updated_at BEFORE UPDATE ON public."UserGoogleCalendarIntegrations" FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: Announcements Announcements_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Announcements"
    ADD CONSTRAINT "Announcements_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationActions AutomationActions_automationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationActions"
    ADD CONSTRAINT "AutomationActions_automationId_fkey" FOREIGN KEY ("automationId") REFERENCES public."Automations"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationExecutions AutomationExecutions_automationActionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationExecutions"
    ADD CONSTRAINT "AutomationExecutions_automationActionId_fkey" FOREIGN KEY ("automationActionId") REFERENCES public."AutomationActions"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationExecutions AutomationExecutions_automationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationExecutions"
    ADD CONSTRAINT "AutomationExecutions_automationId_fkey" FOREIGN KEY ("automationId") REFERENCES public."Automations"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationExecutions AutomationExecutions_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationExecutions"
    ADD CONSTRAINT "AutomationExecutions_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationExecutions AutomationExecutions_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationExecutions"
    ADD CONSTRAINT "AutomationExecutions_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AutomationLogs AutomationLogs_automationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationLogs"
    ADD CONSTRAINT "AutomationLogs_automationId_fkey" FOREIGN KEY ("automationId") REFERENCES public."Automations"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AutomationLogs AutomationLogs_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationLogs"
    ADD CONSTRAINT "AutomationLogs_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AutomationLogs AutomationLogs_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."AutomationLogs"
    ADD CONSTRAINT "AutomationLogs_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Automations Automations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Automations"
    ADD CONSTRAINT "Automations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignSettings CampaignSettings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."CampaignSettings"
    ADD CONSTRAINT "CampaignSettings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignShipping CampaignShipping_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."CampaignShipping"
    ADD CONSTRAINT "CampaignShipping_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public."Campaigns"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CampaignShipping CampaignShipping_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."CampaignShipping"
    ADD CONSTRAINT "CampaignShipping_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."ContactListItems"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Campaigns Campaigns_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Campaigns Campaigns_contactListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_contactListId_fkey" FOREIGN KEY ("contactListId") REFERENCES public."ContactLists"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Campaigns Campaigns_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Campaigns Campaigns_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Campaigns Campaigns_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Campaigns"
    ADD CONSTRAINT "Campaigns_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: ChatMessages ChatMessages_chatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_chatId_fkey" FOREIGN KEY ("chatId") REFERENCES public."Chats"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatMessages ChatMessages_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatUsers ChatUsers_chatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ChatUsers"
    ADD CONSTRAINT "ChatUsers_chatId_fkey" FOREIGN KEY ("chatId") REFERENCES public."Chats"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatUsers ChatUsers_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ChatUsers"
    ADD CONSTRAINT "ChatUsers_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Chatbots Chatbots_chatbotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_chatbotId_fkey" FOREIGN KEY ("chatbotId") REFERENCES public."Chatbots"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Chatbots Chatbots_optFileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_optFileId_fkey" FOREIGN KEY ("optFileId") REFERENCES public."Files"(id);


--
-- Name: Chatbots Chatbots_optIntegrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_optIntegrationId_fkey" FOREIGN KEY ("optIntegrationId") REFERENCES public."QueueIntegrations"(id);


--
-- Name: Chatbots Chatbots_optQueueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_optQueueId_fkey" FOREIGN KEY ("optQueueId") REFERENCES public."Queues"(id);


--
-- Name: Chatbots Chatbots_optUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_optUserId_fkey" FOREIGN KEY ("optUserId") REFERENCES public."Users"(id);


--
-- Name: Chatbots Chatbots_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chatbots"
    ADD CONSTRAINT "Chatbots_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Chats Chats_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chats"
    ADD CONSTRAINT "Chats_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Chats Chats_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Chats"
    ADD CONSTRAINT "Chats_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CompaniesSettings CompaniesSettings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."CompaniesSettings"
    ADD CONSTRAINT "CompaniesSettings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Companies Companies_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plans"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ContactCustomFields ContactCustomFields_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactCustomFields"
    ADD CONSTRAINT "ContactCustomFields_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactListItems ContactListItems_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactListItems"
    ADD CONSTRAINT "ContactListItems_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactListItems ContactListItems_contactListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactListItems"
    ADD CONSTRAINT "ContactListItems_contactListId_fkey" FOREIGN KEY ("contactListId") REFERENCES public."ContactLists"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactLists ContactLists_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactLists"
    ADD CONSTRAINT "ContactLists_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactTags ContactTags_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactTags"
    ADD CONSTRAINT "ContactTags_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactTags ContactTags_tagId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactTags"
    ADD CONSTRAINT "ContactTags_tagId_fkey" FOREIGN KEY ("tagId") REFERENCES public."Tags"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactWallets ContactWallets_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactWallets"
    ADD CONSTRAINT "ContactWallets_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactWallets ContactWallets_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactWallets"
    ADD CONSTRAINT "ContactWallets_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ContactWallets ContactWallets_walletId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."ContactWallets"
    ADD CONSTRAINT "ContactWallets_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Contacts Contacts_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT "Contacts_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Contacts Contacts_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Contacts"
    ADD CONSTRAINT "Contacts_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DialogChatBots DialogChatBots_chatbotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."DialogChatBots"
    ADD CONSTRAINT "DialogChatBots_chatbotId_fkey" FOREIGN KEY ("chatbotId") REFERENCES public."Chatbots"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DialogChatBots DialogChatBots_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."DialogChatBots"
    ADD CONSTRAINT "DialogChatBots_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DialogChatBots DialogChatBots_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."DialogChatBots"
    ADD CONSTRAINT "DialogChatBots_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Faturas Faturas_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Faturas"
    ADD CONSTRAINT "Faturas_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Faturas Faturas_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Faturas"
    ADD CONSTRAINT "Faturas_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Ferramentas Ferramentas_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Ferramentas"
    ADD CONSTRAINT "Ferramentas_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FilesOptions FilesOptions_fileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FilesOptions"
    ADD CONSTRAINT "FilesOptions_fileId_fkey" FOREIGN KEY ("fileId") REFERENCES public."Files"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Files Files_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Files"
    ADD CONSTRAINT "Files_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FlowCampaigns FlowCampaigns_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."FlowCampaigns"
    ADD CONSTRAINT "FlowCampaigns_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: GoogleCalendarIntegrations GoogleCalendarIntegrations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."GoogleCalendarIntegrations"
    ADD CONSTRAINT "GoogleCalendarIntegrations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GoogleCalendarIntegrations GoogleCalendarIntegrations_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."GoogleCalendarIntegrations"
    ADD CONSTRAINT "GoogleCalendarIntegrations_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: GoogleSheetsTokens GoogleSheetsTokens_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."GoogleSheetsTokens"
    ADD CONSTRAINT "GoogleSheetsTokens_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Integrations Integrations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Integrations"
    ADD CONSTRAINT "Integrations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoices Invoices_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Invoices"
    ADD CONSTRAINT "Invoices_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LogTickets LogTickets_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."LogTickets"
    ADD CONSTRAINT "LogTickets_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LogTickets LogTickets_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."LogTickets"
    ADD CONSTRAINT "LogTickets_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LogTickets LogTickets_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."LogTickets"
    ADD CONSTRAINT "LogTickets_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MediaFiles MediaFiles_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."MediaFiles"
    ADD CONSTRAINT "MediaFiles_company_id_fkey" FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON DELETE CASCADE;


--
-- Name: MediaFiles MediaFiles_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."MediaFiles"
    ADD CONSTRAINT "MediaFiles_folder_id_fkey" FOREIGN KEY (folder_id) REFERENCES public."MediaFolders"(id) ON DELETE CASCADE;


--
-- Name: MediaFolders MediaFolders_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."MediaFolders"
    ADD CONSTRAINT "MediaFolders_company_id_fkey" FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON DELETE CASCADE;


--
-- Name: Messages Messages_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Messages Messages_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Messages Messages_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Messages Messages_quotedMsgId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_quotedMsgId_fkey" FOREIGN KEY ("quotedMsgId") REFERENCES public."Messages"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Messages Messages_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Messages Messages_ticketTrakingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_ticketTrakingId_fkey" FOREIGN KEY ("ticketTrakingId") REFERENCES public."TicketTraking"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Messages Messages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MobileWebhooks MobileWebhooks_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."MobileWebhooks"
    ADD CONSTRAINT "MobileWebhooks_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MobileWebhooks MobileWebhooks_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."MobileWebhooks"
    ADD CONSTRAINT "MobileWebhooks_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Negocios Negocios_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Negocios"
    ADD CONSTRAINT "Negocios_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Produtos Produtos_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Produtos"
    ADD CONSTRAINT "Produtos_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PromptToolSettings PromptToolSettings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."PromptToolSettings"
    ADD CONSTRAINT "PromptToolSettings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PromptToolSettings PromptToolSettings_promptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."PromptToolSettings"
    ADD CONSTRAINT "PromptToolSettings_promptId_fkey" FOREIGN KEY ("promptId") REFERENCES public."Prompts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Prompts Prompts_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Prompts"
    ADD CONSTRAINT "Prompts_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id);


--
-- Name: Prompts Prompts_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Prompts"
    ADD CONSTRAINT "Prompts_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id);


--
-- Name: QueueIntegrations QueueIntegrations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QueueIntegrations"
    ADD CONSTRAINT "QueueIntegrations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: QueueOptions QueueOptions_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QueueOptions"
    ADD CONSTRAINT "QueueOptions_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."QueueOptions"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: QueueOptions QueueOptions_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QueueOptions"
    ADD CONSTRAINT "QueueOptions_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Queues Queues_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Queues Queues_fileListId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_fileListId_fkey" FOREIGN KEY ("fileListId") REFERENCES public."Files"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Queues Queues_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Queues"
    ADD CONSTRAINT "Queues_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public."QueueIntegrations"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: QuickMessages QuickMessages_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QuickMessages"
    ADD CONSTRAINT "QuickMessages_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: QuickMessages QuickMessages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."QuickMessages"
    ADD CONSTRAINT "QuickMessages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Schedules Schedules_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Schedules Schedules_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Schedules Schedules_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Schedules Schedules_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Schedules Schedules_ticketUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_ticketUserId_fkey" FOREIGN KEY ("ticketUserId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Schedules Schedules_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Schedules Schedules_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Schedules"
    ADD CONSTRAINT "Schedules_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Settings Settings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Settings"
    ADD CONSTRAINT "Settings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SliderBanners SliderBanners_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."SliderBanners"
    ADD CONSTRAINT "SliderBanners_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Subscriptions Subscriptions_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Subscriptions"
    ADD CONSTRAINT "Subscriptions_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tags Tags_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tags"
    ADD CONSTRAINT "Tags_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketNotes TicketNotes_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketNotes TicketNotes_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TicketNotes TicketNotes_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketNotes"
    ADD CONSTRAINT "TicketNotes_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: TicketTags TicketTags_tagId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketTags"
    ADD CONSTRAINT "TicketTags_tagId_fkey" FOREIGN KEY ("tagId") REFERENCES public."Tags"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketTags TicketTags_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketTags"
    ADD CONSTRAINT "TicketTags_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TicketTraking TicketTraking_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON DELETE SET NULL;


--
-- Name: TicketTraking TicketTraking_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: TicketTraking TicketTraking_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON DELETE SET NULL;


--
-- Name: TicketTraking TicketTraking_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON DELETE SET NULL;


--
-- Name: TicketTraking TicketTraking_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."TicketTraking"
    ADD CONSTRAINT "TicketTraking_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON DELETE SET NULL;


--
-- Name: Tickets Tickets_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tickets Tickets_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Tickets Tickets_crm_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_crm_client_id_fkey" FOREIGN KEY (crm_client_id) REFERENCES public.crm_clients(id) ON DELETE SET NULL;


--
-- Name: Tickets Tickets_crm_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_crm_lead_id_fkey" FOREIGN KEY (crm_lead_id) REFERENCES public.crm_leads(id) ON DELETE SET NULL;


--
-- Name: Tickets Tickets_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public."QueueIntegrations"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tickets Tickets_queueId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_queueId_fkey" FOREIGN KEY ("queueId") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tickets Tickets_queueOptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_queueOptionId_fkey" FOREIGN KEY ("queueOptionId") REFERENCES public."QueueOptions"(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: Tickets Tickets_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Tickets Tickets_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Tickets"
    ADD CONSTRAINT "Tickets_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: UserDevices UserDevices_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserDevices"
    ADD CONSTRAINT "UserDevices_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- Name: UserRatings UserRatings_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON DELETE SET NULL;


--
-- Name: UserRatings UserRatings_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public."Tickets"(id) ON DELETE SET NULL;


--
-- Name: UserRatings UserRatings_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserRatings"
    ADD CONSTRAINT "UserRatings_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON DELETE SET NULL;


--
-- Name: UserServices UserServices_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserServices"
    ADD CONSTRAINT "UserServices_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public.servicos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserServices UserServices_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserServices"
    ADD CONSTRAINT "UserServices_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Users Users_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Users Users_whatsappId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_whatsappId_fkey" FOREIGN KEY ("whatsappId") REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_flowIdNotPhrase_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_flowIdNotPhrase_fkey" FOREIGN KEY ("flowIdNotPhrase") REFERENCES public."FlowBuilders"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_flowIdWelcome_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_flowIdWelcome_fkey" FOREIGN KEY ("flowIdWelcome") REFERENCES public."FlowBuilders"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public."QueueIntegrations"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Whatsapps Whatsapps_promptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_promptId_fkey" FOREIGN KEY ("promptId") REFERENCES public."Prompts"(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: Whatsapps Whatsapps_queueIdImportMessages_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."Whatsapps"
    ADD CONSTRAINT "Whatsapps_queueIdImportMessages_fkey" FOREIGN KEY ("queueIdImportMessages") REFERENCES public."Queues"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: appointments appointments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.crm_clients(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON DELETE CASCADE;


--
-- Name: appointments appointments_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public."Contacts"(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.user_schedules(id) ON DELETE CASCADE;


--
-- Name: appointments appointments_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.servicos(id) ON DELETE SET NULL;


--
-- Name: company_api_keys company_api_keys_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_api_keys
    ADD CONSTRAINT company_api_keys_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_integration_field_maps company_integration_field_maps_integration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_integration_field_maps
    ADD CONSTRAINT company_integration_field_maps_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES public.company_integration_settings(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_integration_settings company_integration_settings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_integration_settings
    ADD CONSTRAINT company_integration_settings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_payment_settings company_payment_settings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.company_payment_settings
    ADD CONSTRAINT company_payment_settings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: crm_client_contacts crm_client_contacts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_client_contacts
    ADD CONSTRAINT crm_client_contacts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.crm_clients(id) ON DELETE CASCADE;


--
-- Name: crm_client_contacts crm_client_contacts_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_client_contacts
    ADD CONSTRAINT crm_client_contacts_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public."Contacts"(id) ON DELETE CASCADE;


--
-- Name: crm_clients crm_clients_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public."Contacts"(id) ON DELETE SET NULL;


--
-- Name: crm_clients crm_clients_primary_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_clients
    ADD CONSTRAINT crm_clients_primary_ticket_id_fkey FOREIGN KEY (primary_ticket_id) REFERENCES public."Tickets"(id) ON DELETE SET NULL;


--
-- Name: crm_leads crm_leads_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public."Contacts"(id) ON DELETE SET NULL;


--
-- Name: crm_leads crm_leads_converted_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_converted_client_id_fkey FOREIGN KEY (converted_client_id) REFERENCES public.crm_clients(id) ON DELETE SET NULL;


--
-- Name: crm_leads crm_leads_primary_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.crm_leads
    ADD CONSTRAINT crm_leads_primary_ticket_id_fkey FOREIGN KEY (primary_ticket_id) REFERENCES public."Tickets"(id) ON DELETE SET NULL;


--
-- Name: financeiro_faturas financeiro_faturas_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.financeiro_faturas
    ADD CONSTRAINT financeiro_faturas_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: financeiro_pagamentos financeiro_pagamentos_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.financeiro_pagamentos
    ADD CONSTRAINT financeiro_pagamentos_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: financeiro_pagamentos financeiro_pagamentos_fatura_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.financeiro_pagamentos
    ADD CONSTRAINT financeiro_pagamentos_fatura_id_fkey FOREIGN KEY (fatura_id) REFERENCES public.financeiro_faturas(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: financeiro_pagamentos fk_financeiro_pagamentos_fatura; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.financeiro_pagamentos
    ADD CONSTRAINT fk_financeiro_pagamentos_fatura FOREIGN KEY (fatura_id, company_id) REFERENCES public.financeiro_faturas(id, company_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tutorial_videos fk_tutorial_videos_company; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.tutorial_videos
    ADD CONSTRAINT fk_tutorial_videos_company FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON DELETE CASCADE;


--
-- Name: tutorial_videos fk_tutorial_videos_user; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.tutorial_videos
    ADD CONSTRAINT fk_tutorial_videos_user FOREIGN KEY (user_id) REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- Name: UserGoogleCalendarIntegrations fk_user_google_calendar_integrations_company_id; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserGoogleCalendarIntegrations"
    ADD CONSTRAINT fk_user_google_calendar_integrations_company_id FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserGoogleCalendarIntegrations fk_user_google_calendar_integrations_user_id; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public."UserGoogleCalendarIntegrations"
    ADD CONSTRAINT fk_user_google_calendar_integrations_user_id FOREIGN KEY (user_id) REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_schedules fk_user_schedules_google_calendar_integration; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.user_schedules
    ADD CONSTRAINT fk_user_schedules_google_calendar_integration FOREIGN KEY (user_google_calendar_integration_id) REFERENCES public."UserGoogleCalendarIntegrations"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_files media_files_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_files media_files_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.media_folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_folders media_folders_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.media_folders
    ADD CONSTRAINT media_folders_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: profissionais profissionais_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.profissionais
    ADD CONSTRAINT "profissionais_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_products project_products_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_products
    ADD CONSTRAINT "project_products_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_products project_products_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_products
    ADD CONSTRAINT "project_products_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Produtos"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_products project_products_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_products
    ADD CONSTRAINT "project_products_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_services project_services_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_services
    ADD CONSTRAINT "project_services_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_services project_services_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_services
    ADD CONSTRAINT "project_services_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_services project_services_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_services
    ADD CONSTRAINT "project_services_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public.servicos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_task_users project_task_users_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_task_users
    ADD CONSTRAINT "project_task_users_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_task_users project_task_users_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_task_users
    ADD CONSTRAINT "project_task_users_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public.project_tasks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_task_users project_task_users_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_task_users
    ADD CONSTRAINT "project_task_users_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_tasks project_tasks_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT "project_tasks_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_tasks project_tasks_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT "project_tasks_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_users project_users_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_users
    ADD CONSTRAINT "project_users_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_users project_users_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_users
    ADD CONSTRAINT "project_users_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_users project_users_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.project_users
    ADD CONSTRAINT "project_users_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.crm_clients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: projects projects_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoices"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: scheduled_dispatch_logs scheduled_dispatch_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.scheduled_dispatch_logs
    ADD CONSTRAINT scheduled_dispatch_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scheduled_dispatch_logs scheduled_dispatch_logs_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.scheduled_dispatch_logs
    ADD CONSTRAINT scheduled_dispatch_logs_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public."Contacts"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: scheduled_dispatch_logs scheduled_dispatch_logs_dispatcher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.scheduled_dispatch_logs
    ADD CONSTRAINT scheduled_dispatch_logs_dispatcher_id_fkey FOREIGN KEY (dispatcher_id) REFERENCES public.scheduled_dispatchers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scheduled_dispatch_logs scheduled_dispatch_logs_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.scheduled_dispatch_logs
    ADD CONSTRAINT scheduled_dispatch_logs_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public."Tickets"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: scheduled_dispatchers scheduled_dispatchers_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.scheduled_dispatchers
    ADD CONSTRAINT scheduled_dispatchers_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scheduled_dispatchers scheduled_dispatchers_whatsapp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.scheduled_dispatchers
    ADD CONSTRAINT scheduled_dispatchers_whatsapp_id_fkey FOREIGN KEY (whatsapp_id) REFERENCES public."Whatsapps"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: servicos servicos_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.servicos
    ADD CONSTRAINT "servicos_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: slider_home slider_home_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.slider_home
    ADD CONSTRAINT "slider_home_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Companies"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_schedules user_schedules_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.user_schedules
    ADD CONSTRAINT user_schedules_company_id_fkey FOREIGN KEY (company_id) REFERENCES public."Companies"(id) ON DELETE CASCADE;


--
-- Name: user_schedules user_schedules_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: empresa
--

ALTER TABLE ONLY public.user_schedules
    ADD CONSTRAINT user_schedules_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict nqGA0EF3GxDruHC2SYMup7cKXffLkP66zmiCRPp2MYMOe9V9WCi2CbkuCoKMynv

