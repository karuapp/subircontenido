import { QueryInterface } from "sequelize";
import { hash } from "bcryptjs";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    return queryInterface.sequelize.transaction(async t => {
      // Revisar si el superadmin ya existe
      const userExists = await queryInterface.rawSelect(
        '"Users"', // ← IMPORTANTE: tabla con comillas
        { where: { id: 1 } },
        ['id']
      );

      if (!userExists) {
        const passwordHash = await hash("123456", 8);

        return queryInterface.bulkInsert(
          '"Users"', // ← IMPORTANTE: tabla con comillas
          [{
            id: 1,
            name: "Administrador",
            email: "superadmin@admin.com",
            profile: "admin",
            passwordHash,
            companyId: 1,
            createdAt: new Date(),
            updatedAt: new Date(),
            super: true,
            online: false,
            endWork: "23:59",
            startWork: "00:00"
          }],
          { transaction: t }
        );
      }
    });
  },

  down: async (queryInterface: QueryInterface) => {
    return queryInterface.bulkDelete('"Users"', { id: 1 });
  }
};
