"use strict";

const fs = require("fs");
const path = require("path");

module.exports = {
  up: async (queryInterface) => {
    const sqlPath = path.resolve(
      __dirname,
      "../sql/database.sql"
    );

    const sql = fs.readFileSync(sqlPath, "utf8");
    await queryInterface.sequelize.query(sql);
  },

  down: async () => {
    // No reversible
  }
};
