import { Request, Response } from "express";

import AppError from "../errors/AppError";
import { getAsaasSecondCopyByCpf } from "../services/PaymentGatewayService";

export const secondCopyByCpf = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  const cpf = (req.body?.cpf || req.query?.cpf || "").toString();

  if (!companyId) {
    throw new AppError("Empresa no identificada.", 400);
  }

  if (!cpf) {
    throw new AppError("Indique el CPF del cliente.", 400);
  }

  const data = await getAsaasSecondCopyByCpf(companyId, cpf);

  return res.json({
    message: "Si obtengo un duplicado correctamente.",
    data
  });
};

export default { secondCopyByCpf };
