import { Request, Response } from "express";
import { fn, col, Op } from "sequelize";
import DashboardDataService, { DashboardData, Params } from "../services/ReportService/DashbardDataService";
import { TicketsAttendance } from "../services/ReportService/TicketsAttendance";
import { TicketsDayService } from "../services/ReportService/TicketsDayService";
import TicketsQueuesService from "../services/TicketServices/TicketsQueuesService";
import Tag from "../models/Tag";
import TicketTag from "../models/TicketTag";
import ContactTag from "../models/ContactTag";

type IndexQuery = {
  initialDate: string;
  finalDate: string;
  companyId: number | any;
};

type IndexQueryPainel = {
  dateStart: string;
  dateEnd: string;
  status: string[];
  queuesIds: string[];
  showAll: string;
};
export const index = async (req: Request, res: Response): Promise<Response> => {
  const params: Params = req.query;
  const { companyId } = req.user;
  let daysInterval = 3;

  const dashboardData: DashboardData = await DashboardDataService(
    companyId,
    params
  );

  // ==============================
  // Métricas adicionais: Tags e Kanban
  // ==============================
  try {
    // Total de tags da empresa
    const totalTags = await (Tag as any).count({ where: { companyId } });

    // Etiquetas configuradas como Kanban, con recuento de tickets por etiqueta.
    const kanbanTags = await (Tag as any).findAll({
      where: { companyId, kanban: 1 },
      include: [
        {
          model: TicketTag,
          as: "ticketTags",
          attributes: []
        }
      ],
      attributes: [
        "id",
        "name",
        "color",
        [fn("COUNT", col("ticketTags.ticketId")), "ticketsCount"]
      ],
      group: ["Tag.id"],
      order: [["id", "ASC"]]
    });

    const kanbanSummary = kanbanTags.map(tag => ({
      id: tag.id,
      name: tag.name,
      color: (tag as any).color,
      ticketsCount: Number((tag as any).get("ticketsCount") || 0)
    }));

    const tagsSummary = {
      totalTags,
      totalKanbanTags: kanbanSummary.length
    };

    // Contatos por Tag (todas as tags, incluindo Kanban)
    const tagsWithContacts = await (Tag as any).findAll({
      where: { companyId },
      include: [
        {
          model: ContactTag,
          as: "contactTags",
          attributes: []
        }
      ],
      attributes: [
        "id",
        "name",
        "color",
        "kanban",
        [fn("COUNT", col("contactTags.contactId")), "contactsCount"]
      ],
      group: ["Tag.id"],
      order: [["name", "ASC"]]
    });

    const tagsContactsSummary = tagsWithContacts.map(tag => ({
      id: tag.id,
      name: tag.name,
      color: (tag as any).color,
      kanban: (tag as any).kanban,
      contactsCount: Number((tag as any).get("contactsCount") || 0)
    }));

    // Tendencia de contactos por etiqueta (7, 15 y 30 días).
    const now = new Date();
    const date7d = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const date15d = new Date(now.getTime() - 15 * 24 * 60 * 60 * 1000);
    const date30d = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const contactsByTag7d = await ContactTag.findAll({
      include: [
        {
          model: Tag,
          as: "tags",
          where: { companyId },
          attributes: []
        }
      ],
      attributes: [["tagId", "tagId"], [fn("COUNT", col("contactId")), "count7d"]],
      where: {
        createdAt: { [Op.gte]: date7d }
      },
      group: ["ContactTag.tagId"]
    });

    const contactsByTag15d = await ContactTag.findAll({
      include: [
        {
          model: Tag,
          as: "tags",
          where: { companyId },
          attributes: []
        }
      ],
      attributes: [["tagId", "tagId"], [fn("COUNT", col("contactId")), "count15d"]],
      where: {
        createdAt: { [Op.gte]: date15d }
      },
      group: ["ContactTag.tagId"]
    });

    const contactsByTag30d = await ContactTag.findAll({
      include: [
        {
          model: Tag,
          as: "tags",
          where: { companyId },
          attributes: []
        }
      ],
      attributes: [["tagId", "tagId"], [fn("COUNT", col("contactId")), "count30d"]],
      where: {
        createdAt: { [Op.gte]: date30d }
      },
      group: ["ContactTag.tagId"]
    });

    const trendMap: Record<number, { contacts7d: number; contacts15d: number; contacts30d: number }> = {};

    contactsByTag7d.forEach((row: any) => {
      const tagId = row.get("tagId") as number;
      if (!trendMap[tagId]) trendMap[tagId] = { contacts7d: 0, contacts15d: 0, contacts30d: 0 };
      trendMap[tagId].contacts7d = Number(row.get("count7d") || 0);
    });

    contactsByTag15d.forEach((row: any) => {
      const tagId = row.get("tagId") as number;
      if (!trendMap[tagId]) trendMap[tagId] = { contacts7d: 0, contacts15d: 0, contacts30d: 0 };
      trendMap[tagId].contacts15d = Number(row.get("count15d") || 0);
    });

    contactsByTag30d.forEach((row: any) => {
      const tagId = row.get("tagId") as number;
      if (!trendMap[tagId]) trendMap[tagId] = { contacts7d: 0, contacts15d: 0, contacts30d: 0 };
      trendMap[tagId].contacts30d = Number(row.get("count30d") || 0);
    });

    const tagsContactsTrend = tagsContactsSummary.map(tag => ({
      ...tag,
      contacts7d: trendMap[tag.id]?.contacts7d || 0,
      contacts15d: trendMap[tag.id]?.contacts15d || 0,
      contacts30d: trendMap[tag.id]?.contacts30d || 0
    }));

    return res.status(200).json({
      ...dashboardData,
      tagsSummary,
      kanbanSummary,
      tagsContactsSummary,
      tagsContactsTrend
    });
  } catch (err) {
    // En caso de error en las métricas adicionales, volvemos al panel básico.
    console.error("Error al cargar las métricas de etiqueta/kanban en el panel.:", err);
    return res.status(200).json(dashboardData);
  }
};

export const reportsUsers = async (req: Request, res: Response): Promise<Response> => {

  const { initialDate, finalDate, companyId } = req.query as IndexQuery

  const { data } = await TicketsAttendance({ initialDate, finalDate, companyId });

  return res.json({ data });

}

export const reportsDay = async (req: Request, res: Response): Promise<Response> => {

  const { initialDate, finalDate, companyId } = req.query as IndexQuery

  const { count, data } = await TicketsDayService({ initialDate, finalDate, companyId });

  return res.json({ count, data });

}

export const DashTicketsQueues = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { companyId, profile, id: userId } = req.user;
  const { dateStart, dateEnd, status, queuesIds, showAll } = req.query as IndexQueryPainel;

  const tickets = await TicketsQueuesService({
    showAll: profile === "admin" ? showAll : false,
    dateStart,
    dateEnd,
    status,
    queuesIds,
    userId,
    companyId,
    profile
  });

  return res.status(200).json(tickets);
};