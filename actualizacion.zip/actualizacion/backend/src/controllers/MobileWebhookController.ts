import { Request, Response } from "express";
import axios from "axios";
import MobileWebhook from "../models/MobileWebhook";
import { getIO } from "../libs/socket";

interface AuthenticatedRequest extends Request {
  user: {
    id: string;
    companyId: number;
    profile: string;
  };
}

// Registrar un webhook para notificaciones móviles
export const registerWebhook = async (
  req: AuthenticatedRequest,
  res: Response
): Promise<Response> => {
  try {
    const { webhookUrl, deviceToken, platform } = req.body;
    const { user } = req;

    if (!webhookUrl || !deviceToken || !platform) {
      return res.status(400).json({
        error: "webhookUrl, deviceToken y la plataforma son obligatorias."
      });
    }

    // Comprobar si ya existe un webhook para este usuario y dispositivo.
    const existingWebhook = await MobileWebhook.findOne({
      where: {
        userId: user.id,
        companyId: user.companyId,
        deviceToken
      }
    });

    if (existingWebhook) {
      // Actualizar webhook existente
      await existingWebhook.update({
        webhookUrl,
        platform,
        isActive: true
      });

      return res.status(200).json({
        message: "Webhook actualizado correctamente",
        webhook: existingWebhook
      });
    }

    // Crear nuevo webhook
    const webhook = await MobileWebhook.create({
      userId: user.id,
      companyId: user.companyId,
      webhookUrl,
      deviceToken,
      platform,
      isActive: true
    });

    return res.status(201).json({
      message: "Webhook registrado correctamente",
      webhook
    });
  } catch (error) {
    console.error("Error al registrar el webhook:", error);
    return res.status(500).json({
      error: "Error interno del servidor"
    });
  }
};

// Remover webhook
export const unregisterWebhook = async (
  req: AuthenticatedRequest,
  res: Response
): Promise<Response> => {
  try {
    const { deviceToken } = req.body;
    const { user } = req;

    if (!deviceToken) {
      return res.status(400).json({
        error: "deviceToken Obligatorio"
      });
    }

    const webhook = await MobileWebhook.findOne({
      where: {
        userId: user.id,
        companyId: user.companyId,
        deviceToken
      }
    });

    if (!webhook) {
      return res.status(404).json({
        error: "Webhook no encontrado"
      });
    }

    await webhook.update({ isActive: false });

    return res.status(200).json({
      message: "Webhook eliminado correctamente"
    });
  } catch (error) {
    console.error("Error al eliminar el webhook:", error);
    return res.status(500).json({
      error: "Error interno del servidor"
    });
  }
};

// Listar los webhooks del usuario
export const listWebhooks = async (
  req: AuthenticatedRequest,
  res: Response
): Promise<Response> => {
  try {
    const { user } = req;

    const webhooks = await MobileWebhook.findAll({
      where: {
        userId: user.id,
        companyId: user.companyId,
        isActive: true
      }
    });

    return res.status(200).json({
      webhooks
    });
  } catch (error) {
    console.error("Error al listar los webhooks:", error);
    return res.status(500).json({
      error: "Error interno del servidor"
    });
  }
};

// Testar webhook
export const testWebhook = async (
  req: AuthenticatedRequest,
  res: Response
): Promise<Response> => {
  try {
    const { deviceToken } = req.body;
    const { user } = req;

    if (!deviceToken) {
      return res.status(400).json({
        error: "deviceToken Obligatorio"
      });
    }

    const webhook = await MobileWebhook.findOne({
      where: {
        userId: user.id,
        companyId: user.companyId,
        deviceToken,
        isActive: true
      }
    });

    if (!webhook) {
      return res.status(404).json({
        error: "Webhook no encontrado"
      });
    }

    // Enviar notificação de teste
    const testNotification = {
      type: "test",
      title: "Prueba de notificación",
      message: "Esta es una prueba del sistema de notificaciones móviles",
      timestamp: new Date().toISOString(),
      userId: user.id,
      companyId: user.companyId
    };

    try {
      await axios.post(webhook.webhookUrl, testNotification, {
        timeout: 5000,
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Whaticket-Mobile-Webhook/1.0'
        }
      });

      return res.status(200).json({
        message: "Notificación de prueba enviada correctamente"
      });
    } catch (webhookError) {
      console.error("Error al enviar el webhook de prueba:", webhookError);
      return res.status(400).json({
        error: "Error al enviar la notificación de prueba",
        details: webhookError.message
      });
    }
  } catch (error) {
    console.error("Error al probar el webhook:", error);
    return res.status(500).json({
      error: "Error interno del servidor"
    });
  }
};

// Función para enviar notificaciones de mensajes nuevos.
export const sendMessageNotification = async (
  messageData: any,
  companyId: number,
  ticketUserId?: number
): Promise<void> => {
  try {
    // Buscar webhooks activos para la empresa.
    const whereClause: any = {
      companyId,
      isActive: true
    };

    // Si el mensaje tiene un usuario específico, filtrar solo por ese usuario.
    if (ticketUserId) {
      whereClause.userId = ticketUserId;
    }

    const webhooks = await MobileWebhook.findAll({
      where: whereClause
    });

    if (webhooks.length === 0) {
      return;
    }

    // Preparar dados da notificação
    const notification = {
      type: "new_message",
      title: `Nuevo mensaje - ${messageData.contact?.name || "Contacto"}`,
      message: messageData.body || "Nuevo mensaje recibido",
      timestamp: new Date().toISOString(),
      companyId,
      ticketId: messageData.ticketId,
      contactId: messageData.contactId,
      contactName: messageData.contact?.name,
      fromMe: messageData.fromMe,
      messageId: messageData.id,
      queueId: messageData.queueId
    };

    // Enviar notificação para todos os webhooks
    const promises = webhooks.map(async (webhook) => {
      try {
        await axios.post(webhook.webhookUrl, notification, {
          timeout: 5000,
          headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'Whaticket-Mobile-Webhook/1.0'
          }
        });
        console.log(`Notificación enviada al webhook ${webhook.id}`);
      } catch (error) {
        console.error(`Error al enviar la notificación al webhook ${webhook.id}:`, error.message);
        
        // Se o webhook falhar múltiplas vezes, desativar
        webhook.failureCount = (webhook.failureCount || 0) + 1;
        if (webhook.failureCount >= 5) {
          await webhook.update({ isActive: false });
          console.log(`Webhook ${webhook.id} deshabilitado después de múltiples fallas`);
        } else {
          await webhook.update({ failureCount: webhook.failureCount });
        }
      }
    });

    await Promise.allSettled(promises);
  } catch (error) {
    console.error("Error al enviar notificaciones móviles.:", error);
  }
};
