import { Request, Response } from "express";
import AddCustomerToWalletService from "../../services/CustomerWalletService/AddCustomerToWalletService";

export const addCustomer = async (req: Request, res: Response): Promise<Response> => {
  const { walletId, clientId } = req.body;
  const { companyId } = req.user;

  const walletCustomer = await AddCustomerToWalletService({
    walletId,
    clientId,
    companyId
  });

  return res.status(201).json(walletCustomer);
};
