import { Request, Response } from "express";
import ListWalletsService from "../../services/CustomerWalletService/ListWalletsService";

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { companyId } = req.user;
  
  const wallets = await ListWalletsService({ companyId });

  return res.status(200).json(wallets);
};
