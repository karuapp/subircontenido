import { Request, Response } from "express";
import AddUserToWalletService from "../../services/CustomerWalletService/AddUserToWalletService";

export const addUser = async (req: Request, res: Response): Promise<Response> => {
  const { walletId, userId, isActive } = req.body;
  const { companyId } = req.user;

  const walletUser = await AddUserToWalletService({
    walletId,
    userId,
    companyId,
    isActive
  });

  return res.status(201).json(walletUser);
};
