import { Request, Response } from "express";
import CreateWalletService from "../../services/CustomerWalletService/CreateWalletService";

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { name, description, isActive } = req.body;
  const { companyId } = req.user;

  const wallet = await CreateWalletService({
    name,
    description,
    companyId,
    isActive
  });

  return res.status(201).json(wallet);
};
