import { Op } from "sequelize";
import moment from "moment";
import Automation from "../../models/Automation";
import AutomationAction from "../../models/AutomationAction";
import Contact from "../../models/Contact";
import Ticket from "../../models/Ticket";
import Whatsapp from "../../models/Whatsapp";
import logger from "../../utils/logger";
import { processAutomationForContact } from "./ProcessAutomationService";
import FindOrCreateTicketService from "../TicketServices/FindOrCreateTicketService";
import GetDefaultWhatsApp from "../../helpers/GetDefaultWhatsApp";

// Buscar contatos que fazem aniversário hoje
const getBirthdayContacts = async (companyId: number): Promise<Contact[]> => {
  const today = moment();
  const day = today.date();
  const month = today.month() + 1; // moment usa 0-11

  // Encuentra contactos que cumplen años hoy
  const contacts = await Contact.findAll({
    where: {
      companyId,
      [Op.and]: [
        { birthday: { [Op.ne]: null } }
      ]
    }
  });

  // Filtrar por día y mes
  return contacts.filter(contact => {
    if (!contact.birthday) return false;
    const bday = moment(contact.birthday);
    return bday.date() === day && (bday.month() + 1) === month;
  });
};

// Procesar automatizaciones de cumpleaños para una empresa
export const processBirthdayAutomations = async (companyId: number): Promise<void> => {
  try {
    // Encuentra automatizaciones de cumpleaños activas
    const automations = await Automation.findAll({
      where: {
        companyId,
        triggerType: "birthday",
        isActive: true
      },
      include: [
        {
          model: AutomationAction,
          as: "actions",
          separate: true,
          order: [["order", "ASC"]]
        }
      ]
    });

    if (automations.length === 0) {
      return;
    }

    // Buscando contactos con cumpleaños
    const contacts = await getBirthdayContacts(companyId);

    if (contacts.length === 0) {
      logger.info(`[Automation Birthday] Hoy no hay cumpleaños para la empresa. ${companyId}`);
      return;
    }

    logger.info(`[Automation Birthday] ${contacts.length} Se encontraron personas que celebran cumpleaños para la empresa. ${companyId}`);

    // Buscar WhatsApp estándar.
    let whatsapp: Whatsapp | null = null;
    try {
      whatsapp = await GetDefaultWhatsApp(companyId);
    } catch (e) {
      logger.error(`[Automation Birthday] Error al buscar WhatsApp predeterminado: ${e}`);
      return;
    }

    // Procesar cada contacto
    for (const contact of contacts) {
      for (const automation of automations) {
        try {
          // Crear o buscar un ticket para el contacto
          const ticket = await FindOrCreateTicketService(
            contact,
            whatsapp!,
            0, // unreadMessages
            companyId,
            0, // queueId
            null, // userId
            null, // groupContact
            "whatsapp", // channel
            null, // wbot
            false // isImported
          );

          await processAutomationForContact(automation, contact, ticket);

          logger.info(`[Automation Birthday] Automatización ${automation.id} procesado para contacto ${contact.id}`);
        } catch (error: any) {
          logger.error(`[Automation Birthday] Error al procesar la automatización ${automation.id} para contacto ${contact.id}: ${error.message}`);
        }
      }
    }
  } catch (error: any) {
    logger.error(`[Automation Birthday] Error general: ${error.message}`);
  }
};

export default processBirthdayAutomations;
