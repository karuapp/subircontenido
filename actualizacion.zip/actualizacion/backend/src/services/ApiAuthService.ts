import axios from 'axios';

const API_BASE_URL = 'https://sandboxapicore.imaginasoft.pt/api/v1';
const USERNAME = 'sandboxapi_nsapi_266844693';
const PASSWORD = 'ieN83R8ilgqPu6RCEsUFdg9H22OzfKG2wjSoSsnt@AqYKsntqJIF&Ux2$2O1';

interface AuthResponse {
  token: string; // Asegúrese de que la API devuelva el token en este formato
}

class AuthService {
  private static token: string | null = null; // Caché de tokens

  private static async fetchAuthToken(): Promise<string> {
    try {
      const response = await axios.post<AuthResponse>(
        `${API_BASE_URL}/Authentication`,
        {
          username: USERNAME,
          password: PASSWORD,
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      // Verifique que el token se haya devuelto correctamente
      if (!response.data.token) {
        throw new Error('Token no encontrado en la respuesta');
      }

      return response.data.token;
    } catch (error) {
      // Mejorar la gestión de errores
      if (error.response) {
        // Error devuelto por la API
        throw new Error(
          `Error de autenticación: ${error.response.status} - ${error.response.data.message || 'No hay mensaje de error.'}`
        );
      } else if (error.request) {
        // Error de conexión
        throw new Error('Error de autenticación: No se recibió respuesta del servidor');
      } else {
        // Error genérico
        throw new Error('Error de autenticación: ' + error.message);
      }
    }
  }

  public static async getAuthToken(): Promise<string> {
    // Si el token ya está en caché, devuélvalo.
    if (this.token) {
      return this.token;
    }

    // De lo contrario, obtenga un nuevo token.
    this.token = await this.fetchAuthToken();
    return this.token;
  }

  // Método para borrar la caché del token (útil para cerrar sesión o tokens caducados).
  public static clearToken(): void {
    this.token = null;
  }
}

export default AuthService;