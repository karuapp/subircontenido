interface WebhookConfig {
    attempts: number;
    backoff: {
      type: 'fixed' | 'exponential';
      delay: number;
    };
    limiter: {
      max: number;
      duration: number;
    };
  }
  
  interface Config {
    webhook: WebhookConfig;
    // Agregue otras configuraciones según sea necesario.
  }
  
  function configLoader(): Config {

    return {
      webhook: {
        attempts: 3,
        backoff: {
          type: 'exponential',
          delay: 1000,
        },
        limiter: {
          max: 1,
          duration: 150,
        },
      },
      // Agregue otras configuraciones según sea necesario.
    };
  }
  
  export default configLoader;
  