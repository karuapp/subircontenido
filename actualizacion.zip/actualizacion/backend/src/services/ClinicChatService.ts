import { getAppointments, createAppointment, getPatients, createPatient } from './imaginasoftApi';

// Función para consultar disponibilidad
export const checkAppointmentAvailability = async (medicId: string, date: string, time: string) => {
  const appointments = await getAppointments({ medicId, date, time });
  return { available: appointments.length === 0, appointments };
};

export const handleAppointmentRequest = async (patientInfo, medicId, date, time) => {
  // Primero, crea un paciente en Imaginasoft (si aún no existe).
  const patient = await createPatient(patientInfo);

  // Consulta la disponibilidad con el método ajustado anteriormente.
  const availability = await checkAppointmentAvailability(medicId, date, time);

  if (availability.available) {
    // Programa una cita con el método createAppointment existente.
    const appointment = await createAppointment({
      patientId: patient.id,
      medicId,
      date,
      time
    });
    return { success: true, appointment };
  } else {
    return { success: false, message: 'Franja horaria no disponible.', availability };
  }
};
