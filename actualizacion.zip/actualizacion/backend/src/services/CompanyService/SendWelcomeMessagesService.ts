import Setting from "../../models/Setting";
import { SendMailWithSettings, replaceVariables } from "../../helpers/SendMailWithSettings";

interface WelcomeData {
  nome: string;
  email: string;
  empresa: string;
  telefone: string;
  plano: string;
  senha: string;
  diasTeste: string;
}

async function getWelcomeSettings(): Promise<{ welcomeEmailText: string; welcomeWhatsappText: string }> {
  try {
    const settings = await Setting.findAll({
      where: {
        companyId: 1,
        key: ["welcomeEmailText", "welcomeWhatsappText"]
      }
    });

    const welcomeEmailText = settings.find(s => s.key === "welcomeEmailText")?.value || "";
    const welcomeWhatsappText = settings.find(s => s.key === "welcomeWhatsappText")?.value || "";

    return { welcomeEmailText, welcomeWhatsappText };
  } catch (error) {
    console.error("Error al obtener la configuración de bienvenida:", error);
    return { welcomeEmailText: "", welcomeWhatsappText: "" };
  }
}

async function getAppName(): Promise<string> {
  try {
    const setting = await Setting.findOne({
      where: {
        companyId: 1,
        key: "appName"
      }
    });
    return setting?.value || "Sistema";
  } catch (error) {
    return "Sistema";
  }
}

export async function sendWelcomeEmail(data: WelcomeData): Promise<boolean> {
  try {
    const { welcomeEmailText } = await getWelcomeSettings();
    const appName = await getAppName();

    if (!welcomeEmailText) {
      console.log("Texto de bienvenida no configurado");
      return false;
    }

    const variables: Record<string, string> = {
      nome: data.nome,
      email: data.email,
      empresa: data.empresa,
      telefone: data.telefone,
      plano: data.plano,
      senha: data.senha,
      diasTeste: data.diasTeste
    };

    const emailBody = replaceVariables(welcomeEmailText, variables);

    const result = await SendMailWithSettings({
      to: data.email,
      subject: `Bienvenido a ${appName}!`,
      html: emailBody.replace(/\n/g, '<br>')
    });

    if (result) {
      console.log(`Correo de bienvenida enviado a ${data.email}`);
    }

    return result;
  } catch (error) {
    console.error("Error al enviar el correo de bienvenida:", error);
    return false;
  }
}

export async function getWelcomeWhatsappText(data: WelcomeData): Promise<string | null> {
  try {
    const { welcomeWhatsappText } = await getWelcomeSettings();

    if (!welcomeWhatsappText) {
      console.log("Texto de bienvenida de WhatsApp no configurado");
      return null;
    }

    const variables: Record<string, string> = {
      nome: data.nome,
      email: data.email,
      empresa: data.empresa,
      telefone: data.telefone,
      plano: data.plano,
      senha: data.senha,
      diasTeste: data.diasTeste
    };

    return replaceVariables(welcomeWhatsappText, variables);
  } catch (error) {
    console.error("Error al recibir el texto de bienvenida de WhatsApp:", error);
    return null;
  }
}

export default { sendWelcomeEmail, getWelcomeWhatsappText };
