import AppError from "../../errors/AppError";
import Appointment from "../../models/Appointment";
import UserSchedule from "../../models/UserSchedule";
import UserGoogleCalendarIntegration from "../../models/UserGoogleCalendarIntegration";
import { deleteGoogleCalendarEvent } from "../../helpers/googleCalendarClient";

const DeleteAppointmentService = async (
  id: string | number,
  companyId: number
): Promise<void> => {
  const appointment = await Appointment.findOne({
    where: { id, companyId }
  });

  if (!appointment) {
    throw new AppError("Cita no encontrada", 404);
  }

  console.log("DEBUG - Eliminando cita:", {
    id: appointment.id,
    title: appointment.title,
    googleEventId: appointment.googleEventId,
    scheduleId: appointment.scheduleId
  });

  // Sincronizar con Google Calendar si hay un evento vinculado
  if (appointment.googleEventId) {
    try {
      console.log("DEBUG - Eliminando evento en Google Calendar:", appointment.googleEventId);
      
      const schedule = await UserSchedule.findOne({
        where: { id: appointment.scheduleId }
      });

      console.log("DEBUG - Horario encontrado:", {
        id: schedule?.id,
        userGoogleCalendarIntegrationId: schedule?.userGoogleCalendarIntegrationId
      });

      if (schedule?.userGoogleCalendarIntegrationId) {
        const integration = await UserGoogleCalendarIntegration.findOne({
          where: { id: schedule.userGoogleCalendarIntegrationId }
        });

        console.log("DEBUG - Integración encontrada:", {
          id: integration?.id,
          email: integration?.email,
          hasAccessToken: !!integration?.accessToken,
          hasRefreshToken: !!integration?.refreshToken,
          calendarId: integration?.calendarId
        });

        if (integration && integration.accessToken) {
          console.log("DEBUG - Llamada deleteGoogleCalendarEvent...");
          await deleteGoogleCalendarEvent(
            integration.accessToken,
            integration.refreshToken,
            appointment.googleEventId,
            integration.calendarId
          );
          
          console.log("DEBUG - Evento eliminado de Google Calendar:", appointment.googleEventId);
        } else {
          console.log("DEBUG - Integración no encontrada o falta el token de acceso");
        }
      } else {
        console.log("DEBUG - El horario no tiene integración vinculada");
      }
    } catch (error) {
      console.error("ERROR - Error al eliminar el evento de Google Calendar:", error);
      // No olvide eliminar la cita si falla en Google Calendar
    }
  } else {
    console.log("DEBUG - La cita no tiene un googleEventId para eliminar");
  }

  await appointment.destroy();
};

export default DeleteAppointmentService;
