import axios from 'axios';
import AuthService from './ApiAuthService'; // Servicio de autenticación para obtener el token

const API_BASE_URL = 'https://sandboxapicore.imaginasoft.pt/api/v1';

class ApiService {
  private static async getAuthToken(): Promise<string> {
    return await AuthService.getAuthToken(); // Obtener el token de autenticación
  }

  // Punto final para la autenticación (ya implementado en AuthService)
  // ...

  // Punto final para obtener todos los usuarios
  public static async getUsers(): Promise<any> {
    const token = await this.getAuthToken();
    try {
      const response = await axios.get(`${API_BASE_URL}/users`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Error al obtener usuarios: ' + error.message);
    }
  }

  // Punto final para obtener un usuario por ID
  public static async getUserById(id: string): Promise<any> {
    const token = await this.getAuthToken();
    try {
      const response = await axios.get(`${API_BASE_URL}/users/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Error al obtener un usuario por ID: ' + error.message);
    }
  }

  // Punto final para crear un nuevo usuario
  public static async createUser(userData: any): Promise<any> {
    const token = await this.getAuthToken();
    try {
      const response = await axios.post(`${API_BASE_URL}/users`, userData, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Error al crear el usuario: ' + error.message);
    }
  }

  // Punto final para actualizar un usuario
  public static async updateUser(id: string, userData: any): Promise<any> {
    const token = await this.getAuthToken();
    try {
      const response = await axios.put(`${API_BASE_URL}/users/${id}`, userData, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Error al actualizar el usuario: ' + error.message);
    }
  }

  // Punto final para eliminar un usuario
  public static async deleteUser(id: string): Promise<any> {
    const token = await this.getAuthToken();
    try {
      const response = await axios.delete(`${API_BASE_URL}/users/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Error al eliminar el usuario: ' + error.message);
    }
  }

  // Punto final para obtener todos los productos
  public static async getProducts(): Promise<any> {
    const token = await this.getAuthToken();
    try {
      const response = await axios.get(`${API_BASE_URL}/products`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Error al obtener los productos: ' + error.message);
    }
  }

  // Punto final para obtener un producto por ID
  public static async getProductById(id: string): Promise<any> {
    const token = await this.getAuthToken();
    try {
      const response = await axios.get(`${API_BASE_URL}/products/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Error al obtener el producto por ID: ' + error.message);
    }
  }

  // Punto final para crear un nuevo producto
  public static async createProduct(productData: any): Promise<any> {
    const token = await this.getAuthToken();
    try {
      const response = await axios.post(`${API_BASE_URL}/products`, productData, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Error al crear el producto: ' + error.message);
    }
  }

  // Punto final para actualizar un producto
  public static async updateProduct(id: string, productData: any): Promise<any> {
    const token = await this.getAuthToken();
    try {
      const response = await axios.put(`${API_BASE_URL}/products/${id}`, productData, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Error al actualizar el producto: ' + error.message);
    }
  }

  // Punto final para eliminar un producto
  public static async deleteProduct(id: string): Promise<any> {
    const token = await this.getAuthToken();
    try {
      const response = await axios.delete(`${API_BASE_URL}/products/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (error) {
      throw new Error('Error al eliminar el producto: ' + error.message);
    }
  }
}

export default ApiService;