// Test file to verify FollowUp import
import FollowUp from "./FollowUp";

console.log("FModelo followUp importado exitosamente:", FollowUp);

export default FollowUp;
