// Test file to verify FollowUp import
import FollowUp from "./FollowUp";

console.log("FollowUp model imported successfully:", FollowUp);

export default FollowUp;
